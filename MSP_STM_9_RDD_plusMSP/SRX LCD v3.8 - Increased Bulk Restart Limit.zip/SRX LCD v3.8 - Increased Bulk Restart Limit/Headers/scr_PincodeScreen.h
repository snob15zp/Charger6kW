#ifndef SCR_PINCODESCREEN_H
#define SCR_PINCODESCREEN_H

#define MAX_CODES 4

typedef struct
{
 unsigned char PassCode[5];
 unsigned char Code1;
 unsigned char Code2;
 unsigned char Code3;
 unsigned char Code4;
} scr_PincodeScreen_Type;

enum CODE_DIGIT
{
 FirstCode =0,
 SecondCode,
 ThirdCode,
 LastCode,
 FinishedPin
} ;

extern  scr_PincodeScreen_Type scr_PincodeScreen;

void UpdatePincodeScreen(scr_PincodeScreen_Type *t);
void Init_PincodeScreen(scr_PincodeScreen_Type *t);
void Save_PincodeScreen(scr_PincodeScreen_Type *t);
void PincodeLogic(unsigned char value);
void DeleteCodeLogic(unsigned char deleted);





#endif