#ifndef SCR_TIMEDATEEDITSCREEN_H
#define SCR_TIMEDATEEDITSCREEN_H

void UpdateTimeDateEditScreen(void);
void Init_TimeDateEditScreen(void);

#endif