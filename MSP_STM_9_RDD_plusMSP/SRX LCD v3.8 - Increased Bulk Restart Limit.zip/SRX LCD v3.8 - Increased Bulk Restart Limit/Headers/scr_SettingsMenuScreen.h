#ifndef SCR_SETTINGSMENUSCREEN_H
#define SCR_SETTINGSMENUSCREEN_H

void UpdateSettingsMenuScreen(void); // This is the only thing that needs updating on this screen.
void Init_SettingsMenuScreen(void);

#endif