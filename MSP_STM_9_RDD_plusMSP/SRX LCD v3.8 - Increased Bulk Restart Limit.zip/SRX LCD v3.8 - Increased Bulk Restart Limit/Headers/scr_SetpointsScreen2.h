#ifndef SCR_SETPOINTSSCREEN2_H
#define SCR_SETPOINTSSCREEN2_H

#include "CoolMax_LCD_objects.h"
#include "scr_SetpointsEditScreen.h"

#define MAX_LABELS_SETPOINTS2 4
#define MAX_LENGTH 9

typedef struct
{
 int initialised;
 float BlkRstVolt;
 float FloatVolt;
 float BlkTime;
 float BlkVolt;
 float TriggerValue;
 float ResetValue;
 unsigned char PageNum;
} scr_SetpointsScreen2_Type;

enum SELECTED_LABEL2
{
 FirstLabel2=0,
 Label_a2,
 Label_a3,
 LastLabel2
} ;

extern scr_SetpointsScreen2_Type scr_SetpointsScreen2;

void Init_SetpointsScreen2(scr_SetpointsScreen2_Type *screen);
void UpdateSetpointsScreen2(scr_SetpointsScreen2_Type *Screen);
void PassSetpointValues2(scr_SetpointsEditScreen_Type *Screen);

void SelectLabel2(enum SELECTED_LABEL2 lbl);
void DeselectLabel2(enum SELECTED_LABEL2 lbl);
void GetSetpoints2MainStruct(void);
void SetSetpoints2MainStruct(void);

void IncrementLabelSelection2(void);
void DecrementLabelSelection2(void);


#endif