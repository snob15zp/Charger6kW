#ifndef FRAM_H
#define FRAM_H

// 2 Mbit F-RAM chip
#define FRAM_MEMORY_SIZE    ((unsigned long)0x40000)
#define FLASH_SECTOR_SIZE   ((unsigned long)0x1000)
#define FLASH_SECTOR_MASK   ~((unsigned long)0x00000fff)

void FRAMInit();
int FRAMWriteBuffer(unsigned long memAddr, unsigned char *buffer, unsigned int length);
int FRAMReadBuffer(unsigned long memAddr, unsigned char *buffer, unsigned int len);

int flash_ERASE_SECTOR(unsigned long memAddr);
int flash_ERASE_ALL(void);

#endif