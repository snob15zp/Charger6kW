#ifndef SCR_INFORMATIONSCREEN_H
#define SCR_INFORMATIONSCREEN_H

#define MAX_INFO_POINTS 7

enum INFO_LABEL
{
 SerialNumber=0,
 ProductModel,
 HardwareVer,
 FirmwareVer,
 NominalVolt,
 StatusCodeA,
 StatusCodeB
} ;

typedef struct
{
 unsigned char SerialNumber[8]; // change from 5 to 8
 unsigned char ProductModel[8];
 unsigned char HardwareVer[6];
 unsigned char FirmwareVer[6];
 float         NominalVolt;
 unsigned char StatusCodeA[9];
 unsigned char StatusCodeB[9];
 } scr_InformationScreen_Type;
 
 extern scr_InformationScreen_Type scr_InformationScreen;
 
void UpdateInformationScreen(void);
void Init_InformationScreen(scr_InformationScreen_Type *screen);
void GetInformationMainStruct(void);
void GetProductModel(void);
void GetSerialNumber(void);
void GetHardwareVersion(void);
void GetFirmwareVersion(void);
void GetInformationMainStruct(void);
void GetStatusCodeB(void);
void GetStatusCodeA(void);

#endif