#ifndef _SERIAL1_H_
#define _SERIAL1_H_

void InitBitsSer0_d(void);
void InitSer0_d(void);
void putchar0_d(unsigned int c);
void sendChar0_d(unsigned int c);
unsigned int getchar0_d(void);
int kbhit0_d(void);
void flushRx0_d(void);
void flushTx0_d(void);
void putString0_d(char *s);
 
#endif