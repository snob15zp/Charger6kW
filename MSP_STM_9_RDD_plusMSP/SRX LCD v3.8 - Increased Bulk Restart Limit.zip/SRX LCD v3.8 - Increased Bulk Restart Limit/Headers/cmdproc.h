#ifndef _CMDPROC_H_
#define _CMDPROC_H_

#include "features.h"

#ifdef ENABLE_LOG
#define commandNo 17
#else
#define commandNo 15
#endif

#define flash

typedef struct {
  char *name;
  void (*func)(void);
} command_type;

extern unsigned int inMainEventFlag;
void MainEvent(void); 

void cmdTest(void);
void cmdVersion(void);
void cmdEdit(void);
void cmdReal(void);
void cmdReal2(void);
void cmdNominalVolt(void);
void cmdStatus(void);
void cmdFloatVolt(void);
void cmdEvents(void);
void cmdSysInfo(void);
void cmdWDTReset(void);
void cmdComms(void);
void cmdTime(void);
void cmdTouchCal(void);
void cmdFormatSDC(void);
void cmdLog(void);
void cmdChargeReset(void);

void prompt();
 
extern const flash command_type commandList[commandNo];

#endif