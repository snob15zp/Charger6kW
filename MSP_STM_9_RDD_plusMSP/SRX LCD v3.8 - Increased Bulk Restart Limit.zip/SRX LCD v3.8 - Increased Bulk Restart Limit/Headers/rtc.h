#ifndef _RTC_H_
#define _RTC_H_
 
 typedef struct
 {
  unsigned char sec;
  unsigned char min;
  unsigned char hour;
  unsigned char date;
  unsigned char month;
  unsigned char year;
  unsigned char wkday;
 }time ;
 
 unsigned char ConvertToBCD(unsigned char c);   //convert from hex to BCD
 unsigned char ConvertfromBCD(unsigned char c);
 int IntSetTime(time *t);
 int IntSetDate(time *t);
 int IntGetDate(time *t);
 int IntGetTime(time *t);
 
 extern time curIntTime;

 void Set_RTCALRM(void);
 void IntRtcInit(void);
 void Set_RTCCON(void);
 
 
 
 
 #endif