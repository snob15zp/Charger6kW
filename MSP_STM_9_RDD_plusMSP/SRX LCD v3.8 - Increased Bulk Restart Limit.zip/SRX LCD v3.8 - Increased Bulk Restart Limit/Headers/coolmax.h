#ifndef _COOLAMAX_H_
#define _COOLMAX_H_

#include "protocol.h"
#include "__Time.h"

#define MAX_STATUS_MSG_LEN 32

extern telemetry_t telemetry;
extern factoryConfig_t factoryConfig;
extern userConfig_t userConfig_R;
extern userConfig_t userConfig_W;
extern eventConfig_t eventConfig;
extern sysInfo_t sysInfo;
extern command_t command;
extern miscState_t miscState;

extern TimeStruct coolmax_time;
extern TimeStruct lcd_time;

extern int isUserConfigInit;
extern int isSysInfoInit;
extern int requestRemoteReset;
extern int isRemoteResetSent;
extern int requestOutputEnabled; // added pk
extern int isOutputEnabledSent;
extern int requestSmartShutdownUpdate;
extern int isMiscStateInit;
extern unsigned char Password[5];

void UpdateRxCoolMaxData();
void UpdateTxCoolMaxData();

void RequestTelemetryPacket();

void RequestUserConfigPacket();
void RequestSysInfoPacket();
void SendUserConfigPacket();
void SendResetPacket();
void SendTimePacket();
void SendOutputPacket(int enable);
void SendMiscPacket(void);
void RequestMiscState();

int CompareUserConfigData();

extern char statusMessage[MAX_STATUS_MSG_LEN+1];

#define FLOAT_PREC 1E-3

#endif