#ifndef LOCALCONFIG_H
#define LOCALCONFIG_H

typedef struct
{
   unsigned char midnightReset : 1;
   unsigned char outputStatus : 1;
   unsigned char : 7;
   unsigned char : 8;
   unsigned char : 8;
   unsigned char : 8;
   float dailyCharge;
   float totalCharge;
   unsigned char spare[20];
} LocalConfig;

extern LocalConfig CONFIG;

void ConfigInit();
int ConfigRead();
int ConfigWrite();
int ConfigReset();
int ConfigResetCharge();
void ConfigSetDefaults();

#endif