#ifndef SCR_REALTIMESCREEN_H
#define SCR_REALTIMESCREEN_H

#define MAX_SIZE 12
#define VERSION "V3.6" //The PIC version update

#define TURBINE false
#define TURBINE_COLOR 0xAEA4

#define HYDRO false
#define HYDRO_COLOR 0xFFFE0


#include "rtc.h"
#include "externalRtc.h"


//Control Mode definitions from typedef enum CTRL_Mode_ in Coolmax Embedded Firmware (ctrl.c)
#define        CTRL_MODE_MPPT_REG  0
#define        CTRL_MODE_OUT_REG  1
#define        CTRL_MODE_VIN_LIM  2
        
typedef struct
{
  float PVVolts;
  float PVAmps;
  float ChrgVolts;
  float ChrgAmps;
  float PVOcVolts;
  float DailyCharge;
  float TotalCharge;
  float PVPower;
  float BatTemp;   // color coded depending on what value is displayed. Check what tolerances are
  int   IsErrorSet;
  unsigned char Time;
  unsigned char Date[9];
  
} scr_RealTimeScreen_Type;

extern scr_RealTimeScreen_Type scr_RealTimeScreen;

void Update_RealTimeScreenTime(void); // ensure this is updated on screen when changes are made in settings
void Update_RealTimeScreenDate(void); // ensure this is updated on screen when changes are made in settings
void Init_RealTimeScreen(scr_RealTimeScreen_Type *screen);
void Update_RealTimeScreen(scr_RealTimeScreen_Type *screen);
void OutputPersist();
void Save_RealTimeScreen(scr_RealTimeScreen_Type *screen);
void GetRealtimeMainStruct(void);
void SendRealtime2MainStruct(void);
void DispTelemetryTime(time *t);
void DispTelemetryDate(time *t);
void FlashAlarmButton();
void DispNotifactions();
void UpdateBatteryStatus();

#endif