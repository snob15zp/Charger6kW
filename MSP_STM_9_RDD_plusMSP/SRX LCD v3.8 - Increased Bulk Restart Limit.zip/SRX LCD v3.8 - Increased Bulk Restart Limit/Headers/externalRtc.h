#ifndef _EXTERNALRTC_H_
#define _EXTERNALRTC_H_

typedef struct
 {
  unsigned char sec;
  unsigned char min;
  unsigned char hour;
  unsigned char date;
  unsigned char month;
  unsigned char year;
 }ExtTime;
 
 extern ExtTime curTime;

int ExtGetTime(ExtTime *t);
int ExtSetTime(ExtTime *t);
int ExtSetDate(ExtTime *t);
int check1HzClock(int on);
int set1HzClock(int on);
void ExtRtcInit();
void ExtRtcStart();
#endif