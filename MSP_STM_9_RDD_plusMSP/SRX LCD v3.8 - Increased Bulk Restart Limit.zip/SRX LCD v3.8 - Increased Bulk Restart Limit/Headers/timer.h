// ----------------------------------------------------------------------------
// Filename    : timer.h
// Created On  : 01/10/2012
// Last Modify : 27/11/2012
// Authours    : Adrian Edmonds, Carl Joyce & Pavle Krkeljas
// Company     : Australian Energy Research Laboratories (AERL)
// Website     : http://www.aerl.com.au
// Description : This file contains header definitions for PIC32 timers 1 and 2.
// ----------------------------------------------------------------------------
#ifndef _TIMER_H_
#define _TIMER_H_
// ----------------------------------------------------------------------------
#define BACKLIGHT_TIMER_MAX 1200

extern int counter1;
extern int counter2;
extern int bkLightCounter;

void InitTimer1(unsigned long period);
void StartTimer1(void);
void StopTimer1(void);

void InitTimer2(unsigned long period);
void StartTimer2(void);
void StopTimer2(void);
// ----------------------------------------------------------------------------
#endif