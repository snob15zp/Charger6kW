#ifndef LOG_H
#define LOG_H

#include "protocol.h"

typedef struct
{
    unsigned char sec;
    unsigned char min;
    unsigned char hour;
    unsigned char day;
    unsigned char month;
    unsigned int year;

    float pvVoltage;
    float pvCurrent;
    float outputVoltage;
    float outputCurrent;
    float ocVoltage;
    float outputCharge;
    float pvPower;
} LogEntry;

typedef struct
{
    unsigned char sec;
    unsigned char min;
    unsigned char hour;
    unsigned char day;
    unsigned char month;
    unsigned int year;

    eventFlags_t eventFlags;
    status_t status;
    
    int forcedReset;
    int outputOn;
    int outputOff;
} EventLogEntry;

typedef enum
{
    LOG_RESET_STATS = 0,
    LOG_RESET_EVENT,
    LOG_RESET_ALL
} LogResetType;

#define LOG_BAD_VALUE 0x80000000ul

void LogInit();
void LogEvent();
void LogMidnightReset();
void LogPower(int on);
void LogCheck();
void LogPrintInfo();

unsigned long LogGetEntryCount();
unsigned long LogGetEntryID(unsigned long index);
unsigned long LogGetEntryIndex(unsigned long id);
unsigned long LogGetMaxEntries();
unsigned long LogGetEventEntryCount();
unsigned long LogGetEventEntryID(unsigned long index);
unsigned long LogGetEventEntryIndex(unsigned long id);
unsigned long LogGetEventMaxEntries();

// Get entry by index. 0 is always the newest entry.
int LogGetEntry(unsigned long index, LogEntry* logEntry);
// Get entry by ID. Each entry has a unique ID.
int LogGetEntryByID(unsigned long id, LogEntry* logEntry);

int LogGetEventEntry(unsigned long index, EventLogEntry* logEntry);
int LogGetEventEntryByID(unsigned long id, EventLogEntry* logEntry);

int LogAddEntry(LogEntry* logEntry);
int LogAddEventEntry(EventLogEntry* logEntry);

unsigned int LogGetPeriod();
int LogSetPeriod(unsigned int period);

int LogReset(LogResetType resetType);

#endif