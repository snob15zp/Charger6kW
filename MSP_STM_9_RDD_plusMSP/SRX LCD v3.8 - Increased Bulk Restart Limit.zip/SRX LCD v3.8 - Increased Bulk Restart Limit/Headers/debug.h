#ifndef _DEBUG_H_
#define _DEBUG_H_

extern sfr sbit WDT;

extern int CtrlCReceived;
extern char prevSentChar[4];

extern char readbuff[64];
extern char writebuff[64];

void InitBitsUSBDebug(void);
void InitUSBDebug(void);
void putchar(char c);
void sendChar(char c);
char getchar(void);
int kbhit(void);
void putString(char *s);
void UpdateUSBBuffers();

#endif