#include "fram.h"
#include "general.h"
#include "cmdlib.h"

#include <built_in.h>

extern void debug_light(int check);
extern void debug_prj_stop(void);

/*---------------------------------------------------------------------------*/
/* Instruction codes */
static const unsigned char FRAM_OP_WRSR = 0x01;
#define BLS_CODE_WRITE_STATUS     0x01 /**< Write Status Register */
#define BLS_CODE_PROGRAM          0x02 /**< Page Program */
#define BLS_CODE_READ             0x03 /**< Read Data */
#define BLS_CODE_READ_STATUS      0x05 /**< Read Status Register */
#define BLS_CODE_WRITE_ENABLE     0x06 /**< Write Enable */
#define BLS_CODE_SECTOR_ERASE     0x20 /**< Sector Erase */
#define BLS_CODE_MDID             0x90 /**< Manufacturer Device ID */

#define BLS_CODE_PD               0xB9 /**< Power down */
#define BLS_CODE_RPD              0xAB /**< Release Power-Down */
/*---------------------------------------------------------------------------*/
/* Erase instructions */

#define BLS_CODE_ERASE_4K         0x20 /**< Sector Erase */
#define BLS_CODE_ERASE_32K        0x52
#define BLS_CODE_ERASE_64K        0xD8
#define BLS_CODE_ERASE_ALL        0xC7 /**< Mass Erase */
/*---------------------------------------------------------------------------*/
/* Bitmasks of the status register */

#define BLS_STATUS_SRWD_BM        0x80
#define BLS_STATUS_BP_BM          0x0C
#define BLS_STATUS_WEL_BM         0x02
#define BLS_STATUS_WIP_BM         0x01

#define BLS_STATUS_BIT_BUSY       0x01 /**< Busy bit of the status register */
/*---------------------------------------------------------------------------*/
/* Part specific constants */
#define BLS_DEVICE_ID_W25X20CL    0x11
#define BLS_DEVICE_ID_W25X40CL    0x12

#define BLS_MANUFACTURER_ID       0xEF

#define BLS_PROGRAM_PAGE_SIZE     ((unsigned long)256)
#define BLS_ERASE_SECTOR_SIZE     4096
/*---------------------------------------------------------------------------*/
#define VERIFY_PART_ERROR           -1
#define VERIFY_PART_POWERED_DOWN     0
#define VERIFY_PART_OK               1



const unsigned int norma = 50;
const unsigned int brak =  1000;


extern unsigned int get_time(void);


static const unsigned int FLASH_CLOCK_DIVIDER = 4;
//static const unsigned int FLASH_CLOCK_DIVIDER = 64;

sbit FLASH_CS at LATC2_bit;
sbit FLASH_CS_Direction at TRISC2_bit;

sbit FL3_CS at LATC3_bit;
sbit FL3_CS_Direction at TRISC3_bit;

sbit FLB3_CS at LATB0_bit;
sbit FLB3_CS_Direction at TRISB0_bit;



void select_on_bus(void)
{
  FLASH_CS = 0;
}
void deselect(void)
{
  FLASH_CS = 1;
}

void FRAMSetSPI(void)
{
    SPI2_Init_Advanced(_SPI_MASTER, _SPI_8_BIT, FLASH_CLOCK_DIVIDER, _SPI_SS_DISABLE, _SPI_DATA_SAMPLE_MIDDLE, _SPI_CLK_IDLE_LOW, _SPI_IDLE_2_ACTIVE);
    SPI_Set_Active(SPI2_Read, SPI2_Write);
}

void FRAMInit(void)
{
    FLASH_CS_Direction = 0;
    deselect();
    FRAMSetSPI();
    
    // Disable protected regions
//    FRAMWriteStatusRegister(0x40);
}

void write_enable(void)
{
  select_on_bus();
  SPI2_Write(BLS_CODE_WRITE_ENABLE);
  deselect();
}

int wait_ready(void)
{
char take;
int cnt = 0;

  select_on_bus();
  SPI2_Write(BLS_CODE_READ_STATUS);
  do {
     cnt++;
     delay_ms(1);
     take = SPI2_Read(0xff);
     take &= BLS_STATUS_BIT_BUSY;
  } while ( (take == BLS_STATUS_BIT_BUSY) && (cnt<2000) );
  deselect();
  if ( cnt < 2000 )
     return 0;
  else
     return 1;
}

unsigned char FRAMReadStatusRegister()
{
    unsigned char status = 0;

//    FRAMSetSPI();
//    CS_FRAM = 0;
//    SPI2_Write(FRAM_OP_RDSR);
//    status = (unsigned char)SPI2_Read(0xFF);
//    CS_FRAM = 1;

    return status;
}

void FRAMWriteStatusRegister(unsigned char reg)
{
    write_enable();
    select_on_bus();
    SPI2_Write(BLS_CODE_WRITE_STATUS);
    SPI2_Write(reg);
    deselect();
}

int FRAMReadBuffer(unsigned long memAddr, unsigned char *buffer, unsigned int len)
{
unsigned int i;
      if ( (memAddr + len) > FRAM_MEMORY_SIZE )
         return 0;
      if ( len == 0 )
         return 1;
      if ( wait_ready() )
         return 0;

      select_on_bus();
      SPI2_Write(BLS_CODE_READ);
      SPI2_Write(Higher(memAddr));
      SPI2_Write(Hi(memAddr));
      SPI2_Write(Lo(memAddr));
      for ( i=0; i<len; i++ )
          buffer[i] = (unsigned char) SPI2_Read(0xFF);
      deselect();
      return 1;
}



int wrBuffer(unsigned long memAddr, unsigned char *buffer, unsigned int  length)
{
unsigned int i;
unsigned int ilen;
unsigned char data_buff;

    if ( length == 0 )
       return 0;

    while ( length > 0 )
    {
        if ( wait_ready() )
           return 0;
        write_enable();

        ilen = BLS_PROGRAM_PAGE_SIZE - (memAddr % BLS_PROGRAM_PAGE_SIZE);
        if ( length < ilen)
        {
            ilen = length;
        }

        select_on_bus();
        SPI2_Write(BLS_CODE_PROGRAM);
        SPI2_Write(Higher(memAddr));
        SPI2_Write(Hi(memAddr));
        SPI2_Write(Lo(memAddr));

        for ( i = 0; i < ilen; i++ )
        {
            data_buff = *buffer;
            SPI2_Write(data_buff);
            buffer++;
        }

        memAddr += ilen;
        length -= ilen;
        deselect();
    }
    return 1;
}

int FRAMWriteBuffer(unsigned long memAddr, unsigned char *buffer, unsigned int  length)
{
unsigned long secAddr1;
unsigned long secAddr2;
unsigned long memAddr1;
unsigned long memAddr2;
unsigned int  length1;
unsigned int  length2;
unsigned char *buf1;
unsigned char *buf2;
int retWr = 0;

    if ( (memAddr + length) > FRAM_MEMORY_SIZE )
       return 0;

    memAddr1 = memAddr & ~FLASH_SECTOR_MASK;
    if ( !memAddr1 )
        flash_ERASE_SECTOR(memAddr);

    secAddr1 = memAddr & FLASH_SECTOR_MASK;
    secAddr2 = memAddr + length - 1;
    secAddr2 &= FLASH_SECTOR_MASK;
    if ( secAddr1 == secAddr2 )
    {
        retWr = wrBuffer(memAddr, buffer, length);
    }
    else
    {
        memAddr1 = memAddr;
        length1 = BLS_PROGRAM_PAGE_SIZE - (memAddr % BLS_PROGRAM_PAGE_SIZE);
        buf1 = buffer[0];

        memAddr2 = secAddr2;
        length2 = length - length1;
        buf2 = buffer[length1 - 1];

        retWr = wrBuffer(memAddr1, buf1, length1);
        flash_ERASE_SECTOR(memAddr2);
        retWr = wrBuffer(memAddr2, buf2, length2);
    }
    return retWr;
}




//---------------------------------------------------------------------------
int flash_ERASE_SECTOR(unsigned long memAddr)
{
unsigned long checkAddrSec;

    checkAddrSec = memAddr & ~FLASH_SECTOR_MASK;
    if ( checkAddrSec )
        return 0;

    if ( wait_ready() )
        return 0;
    write_enable();

    select_on_bus();
    SPI2_Write(BLS_CODE_SECTOR_ERASE);
    SPI2_Write(Higher(memAddr));
    SPI2_Write(Hi(memAddr));
    SPI2_Write(Lo(memAddr));
    deselect();
    return 1;
}

int flash_ERASE_ALL(void)
{
unsigned long checkAddrSec;

    if ( wait_ready() )
        return 0;

    write_enable();
    select_on_bus();
    SPI2_Write(BLS_CODE_ERASE_ALL);
    deselect();
    delay_ms(2000);
    return 1;
}
