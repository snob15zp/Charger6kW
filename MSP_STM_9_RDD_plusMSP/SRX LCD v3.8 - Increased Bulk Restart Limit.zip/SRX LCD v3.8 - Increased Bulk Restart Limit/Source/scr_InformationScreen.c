#include "scr_MainMenuScreen.h"
#include "scr_RealTimeScreen.h"
#include "scr_InformationScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "scr_SetpointsScreen2.h"
#include "protocol.h"
#include "screen.h"
#include "debug.h"
#include "coolmax.h"
#include "cmdlib.h"

extern Tscreen* CurrentScreen;
extern Tscreen* PreviousScreen;

TLabel *InfoValue[MAX_INFO_POINTS];


scr_InformationScreen_Type scr_InformationScreen;

void Init_InformationScreen(scr_InformationScreen_Type *screen)
{
     if (CurrentScreen != &InformationScreen)
     {
        InfoValue[SerialNumber] = &lbl_InformationScreenSerialNumber_Value;
        InfoValue[ProductModel] = &lbl_InformationScreenProductModel_Value;
        InfoValue[HardwareVer] = &lbl_InformationScreenHardwareVer_Value;
        InfoValue[FirmwareVer] = &lbl_InformationScreenFirmwareVer_Value;
        InfoValue[NominalVolt] = &lbl_InformationScreenNominalVolt_Value;
        InfoValue[StatusCodeA] = &lbl_InformationScreenStatusCodeA_Value;
        InfoValue[StatusCodeB] = &lbl_InformationScreenStatusCodeB_Value;
        
        PreviousScreen = CurrentScreen;
        DrawScreen(&InformationScreen);
     }
}

void UpdateInformationScreen(void) // This is the only thing that needs to be updated on this screen
{
     char nomVolt[9];
     
     GetInformationMainStruct();
     
  if (CurrentScreen == &InformationScreen)
     {
     //Display the Serial Number on Screen
     ClearLbl(InfoValue[SerialNumber],boxRound_InformationScreen_BackgroundPanel.Color);
     TFT_Set_Font( InfoValue[SerialNumber]->FontName, CL_BLACK, FO_HORIZONTAL);
     
     InfoValue[SerialNumber]->Caption[0] = scr_InformationScreen.SerialNumber[0];
     InfoValue[SerialNumber]->Caption[1] = scr_InformationScreen.SerialNumber[1];
     InfoValue[SerialNumber]->Caption[2] = scr_InformationScreen.SerialNumber[2];
     InfoValue[SerialNumber]->Caption[3] = scr_InformationScreen.SerialNumber[3];
     InfoValue[SerialNumber]->Caption[4] = scr_InformationScreen.SerialNumber[4];
     InfoValue[SerialNumber]->Caption[5] = scr_InformationScreen.SerialNumber[5];
     InfoValue[SerialNumber]->Caption[6] = scr_InformationScreen.SerialNumber[6];
     InfoValue[SerialNumber]->Caption[7] = scr_InformationScreen.SerialNumber[7];

     
     
     
     TFT_Write_Text(InfoValue[SerialNumber]->Caption, InfoValue[SerialNumber]->Left, InfoValue[SerialNumber]->Top);
     
     //Display Product Model
     ClearLbl(InfoValue[ProductModel],boxRound_InformationScreen_BackgroundPanel.Color);
     TFT_Set_Font( InfoValue[ProductModel]->FontName, CL_BLACK, FO_HORIZONTAL);
     
     InfoValue[ProductModel]->Caption[0] = scr_InformationScreen.ProductModel[0];
     InfoValue[ProductModel]->Caption[1] = scr_InformationScreen.ProductModel[1];
     InfoValue[ProductModel]->Caption[2] = scr_InformationScreen.ProductModel[2];
     InfoValue[ProductModel]->Caption[3] = scr_InformationScreen.ProductModel[3];
     InfoValue[ProductModel]->Caption[4] = scr_InformationScreen.ProductModel[4];
     InfoValue[ProductModel]->Caption[5] = scr_InformationScreen.ProductModel[5];
     InfoValue[ProductModel]->Caption[6] = scr_InformationScreen.ProductModel[6];
     InfoValue[ProductModel]->Caption[7] = scr_InformationScreen.ProductModel[7];
     
     TFT_Write_Text(InfoValue[ProductModel]->Caption, InfoValue[ProductModel]->Left, InfoValue[ProductModel]->Top);
     
     //Display Hardware Ver
     ClearLbl(InfoValue[HardwareVer],boxRound_InformationScreen_BackgroundPanel.Color);
     TFT_Set_Font( InfoValue[HardwareVer]->FontName, CL_BLACK, FO_HORIZONTAL);
     
     InfoValue[HardwareVer]->Caption[0] = scr_informationScreen.HardwareVer[0];
     InfoValue[HardwareVer]->Caption[1] = scr_informationScreen.HardwareVer[1];
     InfoValue[HardwareVer]->Caption[2] = scr_informationScreen.HardwareVer[2];
     InfoValue[HardwareVer]->Caption[3] = scr_informationScreen.HardwareVer[3];
     InfoValue[HardwareVer]->Caption[4] = scr_informationScreen.HardwareVer[4];
     InfoValue[HardwareVer]->Caption[5] = scr_informationScreen.HardwareVer[5];
     
     TFT_Write_Text(InfoValue[HardwareVer]->Caption, InfoValue[HardwareVer]->Left, InfoValue[HardwareVer]->Top);
     
     // Display Firmware Ver  .
     ClearLbl(InfoValue[FirmwareVer],boxRound_InformationScreen_BackgroundPanel.Color);
     TFT_Set_Font( InfoValue[FirmwareVer]->FontName, CL_BLACK, FO_HORIZONTAL);

     InfoValue[FirmwareVer]->Caption[0] = scr_informationScreen.FirmwareVer[0];
     InfoValue[FirmwareVer]->Caption[1] = scr_informationScreen.FirmwareVer[1];
     InfoValue[FirmwareVer]->Caption[2] = scr_informationScreen.FirmwareVer[2];
     InfoValue[FirmwareVer]->Caption[3] = scr_informationScreen.FirmwareVer[3];
     InfoValue[FirmwareVer]->Caption[4] = scr_informationScreen.FirmwareVer[4];
     InfoValue[FirmwareVer]->Caption[5] = scr_informationScreen.FirmwareVer[5];
     
     TFT_Write_Text(InfoValue[FirmwareVer]->Caption, InfoValue[FirmwareVer]->Left, InfoValue[FirmwareVer]->Top);
     
     //Nominal Voltage
     ClearLbl(InfoValue[NominalVolt],boxRound_InformationScreen_BackgroundPanel.Color);
     TFT_Set_Font( InfoValue[NominalVolt]->FontName, CL_BLACK, FO_HORIZONTAL);
     
     sprintf(nomVolt,"%06.2f V", scr_InformationScreen.NominalVolt);
     strncpy(InfoValue[NominalVolt]->Caption, nomVolt, 8);
     InfoValue[NominalVolt]->Caption[8] = 0x00;
     TFT_Write_Text(InfoValue[NominalVolt]->Caption, InfoValue[NominalVolt]->Left, InfoValue[NominalVolt]->Top);
     
     
     //Status CodesA
     ClearLbl(InfoValue[StatusCodeA],boxRound_InformationScreen_BackgroundPanel.Color);
     TFT_Set_Font( InfoValue[StatusCodeA]->FontName, CL_BLACK, FO_HORIZONTAL);
     
     InfoValue[StatusCodeA]->Caption[0] = scr_informationScreen.StatusCodeA[0];
     InfoValue[StatusCodeA]->Caption[1] = scr_informationScreen.StatusCodeA[1];
     InfoValue[StatusCodeA]->Caption[2] = scr_informationScreen.StatusCodeA[2];
     InfoValue[StatusCodeA]->Caption[3] = scr_informationScreen.StatusCodeA[3];
     InfoValue[StatusCodeA]->Caption[4] = scr_informationScreen.StatusCodeA[4];
     InfoValue[StatusCodeA]->Caption[5] = scr_informationScreen.StatusCodeA[5];
     InfoValue[StatusCodeA]->Caption[6] = scr_informationScreen.StatusCodeA[6];
     InfoValue[StatusCodeA]->Caption[7] = scr_informationScreen.StatusCodeA[7];
     InfoValue[StatusCodeA]->Caption[8] = 0x00;
     
     TFT_Write_Text(InfoValue[StatusCodeA]->Caption, InfoValue[StatusCodeA]->Left, InfoValue[StatusCodeA]->Top);
     
     //Status CodesB
     ClearLbl(InfoValue[StatusCodeB],boxRound_InformationScreen_BackgroundPanel.Color);
     TFT_Set_Font( InfoValue[StatusCodeB]->FontName, CL_BLACK, FO_HORIZONTAL);

     InfoValue[StatusCodeB]->Caption[0] = scr_informationScreen.StatusCodeB[0];
     InfoValue[StatusCodeB]->Caption[1] = scr_informationScreen.StatusCodeB[1];
     InfoValue[StatusCodeB]->Caption[2] = scr_informationScreen.StatusCodeB[2];
     InfoValue[StatusCodeB]->Caption[3] = scr_informationScreen.StatusCodeB[3];
     InfoValue[StatusCodeB]->Caption[4] = scr_informationScreen.StatusCodeB[4];
     InfoValue[StatusCodeB]->Caption[5] = scr_informationScreen.StatusCodeB[5];
     InfoValue[StatusCodeB]->Caption[6] = scr_informationScreen.StatusCodeB[6];
     InfoValue[StatusCodeB]->Caption[7] = scr_informationScreen.StatusCodeB[7];
     InfoValue[StatusCodeB]->Caption[8] = 0x00;

     TFT_Write_Text(InfoValue[StatusCodeB]->Caption, InfoValue[StatusCodeB]->Left, InfoValue[StatusCodeB]->Top);
     }
     

     

}

void GetProductModel()
{

 scr_InformationScreen.ProductModel[0] = sysInfo.productID[0];
 scr_InformationScreen.ProductModel[1] = sysInfo.productID[1];
 scr_InformationScreen.ProductModel[2] = sysInfo.productID[2];
 scr_InformationScreen.ProductModel[3] = sysInfo.productID[3];
 scr_InformationScreen.ProductModel[4] = '-';  //separator;
 
 scr_InformationScreen.ProductModel[5] = sysInfo.modelType[0];
 scr_InformationScreen.ProductModel[6] = sysInfo.modelType[1];
 scr_InformationScreen.ProductModel[7] = 0x00; //end of character

}

void GetSerialNumber() // gets serial number data and stores in local struct
{
  scr_informationScreen.SerialNumber[0] = telemetry.serialNumber[0];
  scr_informationScreen.SerialNumber[1] = telemetry.serialNumber[1];
  scr_informationScreen.SerialNumber[2] = telemetry.serialNumber[2];
  scr_informationScreen.SerialNumber[3] = telemetry.serialNumber[3];
  scr_informationScreen.SerialNumber[4] = '-';
  scr_informationScreen.SerialNumber[5] = telemetry.serialNumber[4];
  scr_informationScreen.SerialNumber[6] = telemetry.serialNumber[5];
  scr_informationScreen.SerialNumber[7] = telemetry.serialNumber[6];
  scr_informationScreen.SerialNumber[8] = telemetry.serialNumber[7];
}

void GetHardwareVersion() // gets hardware version data and stores in local struct
{
 scr_informationScreen.HardwareVer[0] = sysInfo.hwVersion[0];
 scr_informationScreen.HardwareVer[1] = sysInfo.hwVersion[1];
 scr_informationScreen.HardwareVer[2] = sysInfo.hwVersion[2];
 scr_informationScreen.HardwareVer[3] = sysInfo.hwVersion[3];
 scr_informationScreen.HardwareVer[4] = sysInfo.hwVersion[4];
 scr_informationScreen.HardwareVer[5] = 0x00;
}

void GetFirmwareVersion() // gets firmware version data and stores in local struct
{
 scr_informationScreen.FirmwareVer[0] =  sysInfo.fwVersion[0];
 scr_informationScreen.FirmwareVer[1] =  sysInfo.fwVersion[1];
 scr_informationScreen.FirmwareVer[2] =  sysInfo.fwVersion[2];
 scr_informationScreen.FirmwareVer[3] =  sysInfo.fwVersion[3];
 scr_informationScreen.FirmwareVer[4] =  sysInfo.fwVersion[4];
 scr_informationScreen.FirmwareVer[5] =  0x00;
}

void GetStatusCodeA()
{
  if( ! telemetry.status.config_factoryCRC)
  scr_InformationScreen.StatusCodeA[0] = '0';
  else
  scr_InformationScreen.StatusCodeA[0] = '1';
  
  
  if( ! telemetry.status.config_factoryCheck)
  scr_InformationScreen.StatusCodeA[1] = '0';
  else
  scr_InformationScreen.StatusCodeA[1] = '1';
  
  if( ! telemetry.status.config_userCRC)
  scr_InformationScreen.StatusCodeA[2] = '0';
  else
  scr_InformationScreen.StatusCodeA[2] = '1';

  if( ! telemetry.status.config_userCheck)
  scr_InformationScreen.StatusCodeA[3] = '0';
  else
  scr_InformationScreen.StatusCodeA[3] = '1';
  
  if( ! telemetry.status.config_eventCRC)
  scr_InformationScreen.StatusCodeA[4] = '0';
  else
  scr_InformationScreen.StatusCodeA[4] = '1';

  if( ! telemetry.status.config_eventCheck)
  scr_InformationScreen.StatusCodeA[5] = '0';
  else
  scr_InformationScreen.StatusCodeA[5] = '1';

  if( ! telemetry.status.safety_operation)
  scr_InformationScreen.StatusCodeA[6] = '0';
  else
  scr_InformationScreen.StatusCodeA[6] = '1';

  if( ! telemetry.status.control_isSlave)
  scr_InformationScreen.StatusCodeA[7] = '0';
  else
  scr_InformationScreen.StatusCodeA[7] = '1';
  
  scr_InformationScreen.StatusCodeA[8] = 0x00;
}

void GetStatusCodeB()
{
  if( ! telemetry.status.control_usingBulk)
  scr_InformationScreen.StatusCodeB[0] = '0';
  else
  scr_InformationScreen.StatusCodeB[0] = '1';
  
  if( ! telemetry.status.control_mode)
  scr_InformationScreen.StatusCodeB[1] = '0';
  else
  scr_InformationScreen.StatusCodeB[1] = ('0' + (char) telemetry.status.control_mode);
  
  scr_InformationScreen.StatusCodeB[2] = '*';
  scr_InformationScreen.StatusCodeB[3] = '*';
  
  scr_InformationScreen.StatusCodeB[4] = '?';
  if ((telemetry.status.statistics >= 0) && (telemetry.status.statistics <= 9))
  {
     scr_InformationScreen.StatusCodeB[4] = ('0' + (char) telemetry.status.statistics);
  }
  else
  {
    if ((telemetry.status.statistics >= 10) && (telemetry.status.statistics <= 15))
    {
       scr_InformationScreen.StatusCodeB[4] = ('A' + (char) telemetry.status.statistics);
    }
  }
  
  scr_InformationScreen.StatusCodeB[5] = '?';
  if ((telemetry.status.flags >= 0) && (telemetry.status.flags <= 9))
  {
     scr_InformationScreen.StatusCodeB[5] = ('0' + (char) telemetry.status.flags);
  }
  else
  {
    if ((telemetry.status.flags >= 10) && (telemetry.status.flags <= 15))
    {
       scr_InformationScreen.StatusCodeB[5] = ('A' + (char) telemetry.status.flags);
    }
  }
  
  scr_InformationScreen.StatusCodeB[6] = '?';
  if ((telemetry.status.telemetry >= 0) && (telemetry.status.telemetry <= 9))
  {
     scr_InformationScreen.StatusCodeB[6] = ('0' + (char) telemetry.status.telemetry);
  }
  else
  {
    if ((telemetry.status.telemetry >= 10) && (telemetry.status.telemetry <= 15))
    {
       scr_InformationScreen.StatusCodeB[6] = ('A' + (char) telemetry.status.telemetry);
    }
  }
  
  scr_InformationScreen.StatusCodeB[7] = '?';
  if ((telemetry.status.communications >= 0) && (telemetry.status.communications <= 9))
  {
     scr_InformationScreen.StatusCodeB[7] = ('0' + (char) telemetry.status.communications);
  }
  else
  {
    if ((telemetry.status.communications >= 10) && (telemetry.status.communications <= 15))
    {
       scr_InformationScreen.StatusCodeB[7] = ('A' + (char) telemetry.status.communications);
    }
  }
  
  scr_InformationScreen.StatusCodeB[8] = 0x00;
}





void GetInformationMainStruct()
{
GetSerialNumber();
GetProductModel();
GetHardwareVersion();
GetFirmwareVersion();
scr_InformationScreen.NominalVolt = userConfig_R.setPointsConfig.nominalVolt;
GetStatusCodeA();
GetStatusCodeB();
}






//Event Handlers

void btn_InformationScreen_MenuOnClick() 
{
       Init_MainMenuScreen();
}

void btn_InformationScreen_RealTimeOnClick() 
{
       Init_RealTimeScreen(&scr_RealTimeScreen);
}