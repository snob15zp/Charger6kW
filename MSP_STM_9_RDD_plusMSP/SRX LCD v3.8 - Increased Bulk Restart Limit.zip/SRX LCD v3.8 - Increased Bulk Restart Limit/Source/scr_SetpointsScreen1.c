#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "scr_SetpointsScreen1.h"
#include "scr_SetpointsScreen2.h"
#include "scr_SetpointsEditScreen.h"
#include "scr_MainMenuScreen.h"
#include "scr_SettingsMenuScreen.h"
#include "scr_PincodeScreen.h"
#include "scr_NotificationScreen.h"
#include "scr_NotificationScreen.h"
#include "protocol.h"
#include "general.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"
#include "coolmax.h"

TLabel *labelNames1[MAX_LABELS_SETPOINTS1];
TLabel *labelValues1[MAX_LABELS_SETPOINTS1];
TLabel *labelDesig1[MAX_LABELS_SETPOINTS1];
TBox_Round *selectionBoxes1[MAX_LABELS_SETPOINTS1];

scr_SetpointsScreen1_Type scr_SetpointsScreen1;

extern Tscreen* CurrentScreen;
extern Tscreen* PreviousScreen;

enum SELECTED_LABEL1 curLabel1= FirstLabel;

float originalNominalVoltage = 0.0;
float originalOcVoltage = 0.0;
 
void Init_SetpointsScreen1(scr_SetpointsScreen1_Type *Screen)
{
    GetSetpoints1MainStruct();     // Transfers values from MainStruct to values in local struct.
    GetSetpoints2MainStruct();

   if (CurrentScreen != &SetpointsScreen1)
   {
   labelNames1[FirstLabel] = &lbl_SetpointsScreen1BatVolt_Name;  // Switched all
   labelNames1[Label_a] = &lbl_SetpointsScreen1OcVolt_Name;
   labelNames1[Label_b] = &lbl_SetpointsScreen1MpVolt_Name;
   labelNames1[LastLabel] = &lbl_SetpointsScreen1TempComp_Name;
   
   labelValues1[FirstLabel] = &lbl_SetpointsScreen1BatVolt_Value; // Switched all
   labelValues1[Label_a] = &lbl_SetpointsScreen1OCVolt_Value;
   labelValues1[Label_b] = &lbl_SetpointsScreen1MpVolt_Value;
   labelValues1[LastLabel] = &lbl_SetpointsScreen1TempComp_Value;
   
   labelDesig1[FirstLabel] = &lbl_SetpointsScreen1BatVolt_Desig; // Switched all
   labelDesig1[Label_a] = &lbl_SetpointsScreen1OCVolt_Desig;
   labelDesig1[Label_b] = &lbl_SetpointsScreen1MpVolt_Desig;
   labelDesig1[LastLabel] = &lbl_SetpointsScreen1TempComp_Desig;
   
   selectionBoxes1[FirstLabel] = &boxRound_SetpointsScreen1_BatVoltSelectionBox;
   selectionBoxes1[Label_a] = &boxRound_SetpointsScreen1_OcVoltSelectionBox;
   selectionBoxes1[Label_b] = &boxRound_SetpointsScreen1_SelectionBoxMpVolt;
   selectionBoxes1[LastLabel] = &boxRound_SetpointsScreen1_SelectionBoxTempComp;

   PreviousScreen = CurrentScreen; // The Current Screen is still the value of previous Screen and is only updated in Drawscreen
   
   DeselectLabel1(curLabel1); //solves problem of having any other Label other than the selected Label as being selected

     if (PreviousScreen == &SettingsMenuScreen) // if comming from settings menu the first Label is selected
        {
         curLabel1 = FirstLabel;
        }
   
     if (PreviousScreen == &SetpointsScreen2)   // if comming from seconds setpoints Screen the selected Label on first Screen is LastLabel
        {
         curLabel1 = LastLabel;
         originalNominalVoltage = userConfig_R.setPointsConfig.nominalVolt;
         originalOcVoltage = userConfig_R.setPointsConfig.pvOcVolt;
        }
        
     if (PreviousScreen == &SetpointsEditScreen)   // if comming from seconds setpoints Screen the selected Label on first Screen is LastLabel
        {
         switch(curLabel1)
         {
          case Firstlabel:
                          Screen->BatVolt = scr_SetpointsEditScreen.RawFloatValue;
                          if (fabs(Screen->BatVolt - originalNominalVoltage) > FLOAT_PREC)
                          {
                             scr_SetpointsScreen2.BlkRstVolt =  Screen->BatVolt * 1.05f;
                             scr_SetpointsScreen2.TriggerValue = Screen->BatVolt * 0.78f;
                             scr_SetpointsScreen2.ResetValue = Screen->BatVolt * 1.07f;
                             scr_SetpointsScreen2.BlkVolt = Screen->BatVolt * 1.2f;
                             scr_SetpointsScreen2.FloatVolt = Screen->BatVolt * 1.15f;
                             scr_SetpointsScreen2.BlkTime = 120.00;
                          }
                          break;
                          
          case Label_a:
                          Screen->OcVolt = scr_SetpointsEditScreen.RawFloatValue;
                          if (fabs(Screen->OcVolt - originalOcVoltage) > FLOAT_PREC)
                          {
                             scr_SetpointsScreen1.MpVolt =  Screen->OcVolt * 0.777f;
                          }
                          break;
                          
          case Label_b:
                          Screen->MpVolt = scr_SetpointsEditScreen.RawFloatValue;
                          break;

          case Lastlabel:
                          Screen->TempComp = scr_SetpointsEditScreen.RawFloatValue;
                          break;
          }
          
         }
         
   DrawScreen(&SetpointsScreen1);

   SelectLabel1(FirstLabel);
   DeselectLabel1(FirstLabel);
   SelectLabel1(Label_a);
   DeselectLabel1(Label_a);
   SelectLabel1(Label_b);
   DeselectLabel1(Label_b);
   SelectLabel1(LastLabel);
   DeselectLabel1(LastLabel);
   
   //gives the correct apparence of the background of the boxes
   //DeselectRoundBox(selectionBoxes1[FirstLabel],BOX_COLOR );
   //DeselectRoundBox(selectionBoxes1[Label_a],BOX_COLOR );
   //DeselectRoundBox(selectionBoxes1[Label_b],BOX_COLOR );
   //DeselectRoundBox(selectionBoxes1[LastLabel],BOX_COLOR );
   SelectLabel1(curLabel1);
   
   }
}

void UpdateSetpointsScreen1(scr_SetpointsScreen1_Type *Screen)
{
  int i=0;
 
   char ocVolt[9];
   char mpVolt[9];
   char batVolt[9];
   char tmpCmp[9];
  

  
  if (CurrentScreen == &SetpointsScreen1)
     {
     
     for(i ; i <MAX_LABELS_SETPOINTS1; i++)
     {
         if (curLabel1 == i)
         {
           ClearLbl(labelValues1[i],SELECTED_BOX_COLOR);
           TFT_Set_Font(labelValues1[i]->FontName, CL_BLACK, FO_HORIZONTAL);
         }

         else
         {
           ClearLbl(labelValues1[i],BOX_COLOR);
           TFT_Set_Font(labelValues1[i]->FontName, UNSELECTED_VALUE_COLOR, FO_HORIZONTAL);
         }
         
         switch( i )
         {
            case FirstLabel:
                            sprintf(batVolt,"%3.1f", Screen->BatVolt); //%06.2f
                            strncpy(labelValues1[FirstLabel]->Caption, batVolt, 8);
                            labelValues1[FirstLabel]->Caption[8] = 0x00;
                            if (labelValues1[FirstLabel]->Visible == 1)
                            TFT_Write_Text(labelValues1[FirstLabel]->Caption, labelValues1[FirstLabel]->Left, labelValues1[FirstLabel]->Top);
                            break;
                            
            case Label_a:
                            sprintf(ocVolt,"%3.1f", Screen->OcVolt);
                            strncpy(labelValues1[Label_a]->Caption, ocVolt, 8);
                            labelValues1[Label_a]->Caption[8] = 0x00;
                            if (labelValues1[Label_a]->Visible == 1)
                            TFT_Write_Text(labelValues1[Label_a]->Caption, labelValues1[Label_a]->Left, labelValues1[Label_a]->Top);
                            break;
                            
            case Label_b:
                            sprintf(mpVolt,"%3.1f", Screen->MpVolt);
                            strncpy(labelValues1[Label_b]->Caption, mpVolt, 8);
                            labelValues1[Label_b]->Caption[8] = 0x00;
                            if (labelValues1[Label_b]->Visible == 1)
                            TFT_Write_Text(labelValues1[Label_b]->Caption, labelValues1[Label_b]->Left, labelValues1[Label_b]->Top);
                            break;
                            
            case LastLabel:
                            sprintf(tmpCmp,"%+3.1f", Screen->TempComp);
                            strncpy(labelValues1[LastLabel]->Caption, tmpCmp, 8);
                            labelValues1[LastLabel]->Caption[8] = 0x00;
                            if (labelValues1[LastLabel]->Visible == 1)
                            TFT_Write_Text(labelValues1[LastLabel]->Caption, labelValues1[LastLabel]->Left, labelValues1[LastLabel]->Top);
                            break;
         }
     


     }
   }
}

// these are the parameters that are passed to the edit Screen
void PassSetpointValues1(scr_SetpointsEditScreen_Type *Screen)
{
  if (curLabel1 == FirstLabel)
   {
     Screen->RawFloatValue = scr_SetpointsScreen1.BatVolt;
     Screen->DecimalPlaces = 2;
     //ClearLbl(labelValues1[i],BOX_COLOR);
     //TFT_Set_Font(labelValues1[i]->FontName, CL_BLACK, FO_HORIZONTAL);
     
     strncpy(Screen->DigType, "Volt", 4);
     Screen->DigType[4] = 0x00;
     strncpy(Screen->SetpointTitle, "Bat Voltage", 11);
     Screen->SetpointTitle[11] = 0x00;
     return;

   }
   
  if (curLabel1 == Label_a)
   {
     Screen->RawFloatValue = scr_SetpointsScreen1.OcVolt;
    // Screen->IsVolt =1;
     Screen->DecimalPlaces = 2;
     strncpy(Screen->DigType, "Volt", 4);
     Screen->DigType[4] = 0x00;
     strncpy(Screen->SetpointTitle, "OC Voltage", 11);
     Screen->SetpointTitle[11] = 0x00;
     return;

   }
   
   if (curLabel1 == Label_b)
   {
     Screen->RawFloatValue = scr_SetpointsScreen1.MpVolt;
     //Screen->IsVolt =1;
     Screen->DecimalPlaces = 2;
     strncpy(Screen->DigType, "Volt", 4);
     Screen->DigType[4] = 0x00;
     strncpy(Screen->SetpointTitle, "MP Voltage", 11);
     Screen->SetpointTitle[11] = 0x00;
     return;
   }
   
   if (curLabel1 == LastLabel)
   {
     Screen->RawFloatValue = scr_SetpointsScreen1.TempComp;
     //Screen->IsVolt =1;
     Screen->DecimalPlaces = 1;
     strncpy(Screen->DigType, "mv/C", 4);
     Screen->DigType[4] = 0x00;
     strncpy(Screen->SetpointTitle, " RTS Comp", 9);
     Screen->SetpointTitle[9] = 0x00;
     return;
   }
}

void SelectLabel1(enum SELECTED_LABEL1 lbl)
{
  selectionBoxes1[lbl]->Visible = 1;
  DrawRoundBox(selectionBoxes1[lbl]);
  
  TFT_Set_Font(labelNames1[lbl]->FontName,SELECTED_NAME_COLOR, FO_HORIZONTAL);
  TFT_Write_Text(labelNames1[lbl]->Caption, labelNames1[lbl]->Left, labelNames1[lbl]->Top);
  
  TFT_Set_Font(labelValues1[lbl]->FontName,SELECTED_VALUE_COLOR, FO_HORIZONTAL);
  TFT_Write_Text(labelValues1[lbl]->Caption, labelValues1[lbl]->Left, labelValues1[lbl]->Top);

  TFT_Set_Font(labelDesig1[lbl]->FontName,SELECTED_VALUE_COLOR, FO_HORIZONTAL);
  TFT_Write_Text(labelDesig1[lbl]->Caption, labelDesig1[lbl]->Left, labelDesig1[lbl]->Top);

}

void DeselectLabel1(enum SELECTED_LABEL1 lbl)
{
  selectionBoxes1[lbl]->Visible = 0;
  DeselectRoundBox(selectionBoxes1[lbl],BOX_COLOR); //CurrentScreen->Color

  TFT_Set_Font(labelNames1[lbl]->FontName,UNSELECTED_NAME_COLOR, FO_HORIZONTAL);
  TFT_Write_Text(labelNames1[lbl]->Caption, labelNames1[lbl]->Left, labelNames1[lbl]->Top);

  TFT_Set_Font(labelValues1[lbl]->FontName,UNSELECTED_VALUE_COLOR, FO_HORIZONTAL);
  TFT_Write_Text(labelValues1[lbl]->Caption, labelValues1[lbl]->Left, labelValues1[lbl]->Top);
  
  TFT_Set_Font(labelDesig1[lbl]->FontName,UNSELECTED_VALUE_COLOR, FO_HORIZONTAL);
  TFT_Write_Text(labelDesig1[lbl]->Caption, labelDesig1[lbl]->Left, labelDesig1[lbl]->Top);
  
}

void IncrementLabelSelection1() //Selection of active Label when up button pressed
{
  if (curLabel1 == FirstLabel)
  return;

  DeselectLabel1(curLabel1);
  SelectLabel1(curLabel1-1);
  curLabel1 = curLabel1-1;
}

void DecrementLabelSelection1()   // Selection of active Label when down button is pressed
{
 if (curLabel1 == LastLabel)
 {
  Init_SetpointsScreen2(&scr_SetpointsScreen2);
  return;
 }
 
 DeselectLabel1(curLabel1);
 SelectLabel1(curLabel1+1);
 curLabel1 = curLabel1+1;
}

void GetSetpoints1MainStruct()
{
  if (!scr_SetpointsScreen1.initialised)
  {
    scr_SetpointsScreen1.OcVolt =  userConfig_R.setPointsConfig.pvOcVolt;
    scr_SetpointsScreen1.MpVolt =  userConfig_R.setPointsConfig.pvMpVolt;
    scr_SetpointsScreen1.BatVolt = userConfig_R.setPointsConfig.nominalVolt;
    scr_SetpointsScreen1.TempComp =  userConfig_R.setPointsConfig.tempCompensation;
    scr_SetpointsScreen1.initialised = true;
  }
}

void SetSetpoints1MainStruct()
{
  userConfig_W.setPointsConfig.pvOcVolt = scr_SetpointsScreen1.OcVolt;
  userConfig_W.setPointsConfig.pvMpVolt = scr_SetpointsScreen1.MpVolt;
  userConfig_W.setPointsConfig.nominalVolt = scr_SetpointsScreen1.BatVolt;
  userConfig_W.setPointsConfig.tempCompensation = scr_SetpointsScreen1.TempComp;
}

void DisplayNotificationWarning(char *warning, char *messageType)  //checks rules associated with setpoints
{
notificationScreenType = STATUS_SCREEN_WARNING;
Init_NotificationScreen();

ClearLbl(&lbl_NotificationScreen_WarningSetpoint,boxRound_NotificationScreenPanel.Color);
strncpy(lbl_NotificationScreen_WarningSetpoint.Caption,messageType, strlen(messageType) ) ;
lbl_NotificationScreen_WarningSetpoint.Caption[strlen(messageType)] = 0x00;   // length of message + 1 maybe
TFT_Set_Font(lbl_NotificationScreen_WarningSetpoint.FontName, CL_BLUE, FO_HORIZONTAL);
TFT_Write_Text(lbl_NotificationScreen_WarningSetpoint.Caption,  lbl_NotificationScreen_WarningSetpoint.Left,  lbl_NotificationScreen_WarningSetpoint.Top);

UpdateNotificationScreen(warning);
}



int VerifySetpointValues()
{
// MAXIMUM BATT VOLT LIMIT FOR HV UNIT
if(sysInfo.modelType[0] == 'H')
{
    if(scr_SetpointsScreen1.BatVolt >144.5)
    {
      DisplayNotificationWarning("Battery Voltage above 144.5 Vnom.", "Vnom Voltage");
      return false;
    }
}

else // MAXIMUM BATT VOLT LIMIT FOR MV UNIT
{
     if(scr_SetpointsScreen1.BatVolt > 60.5)
    {
      DisplayNotificationWarning("Battery Voltage above 60 Vnom.", "Vnom Voltage");
      return false;
    }
}

//MINIMUM BAT VOLT LIMIT FOR HV UNIT
if(sysInfo.modelType[0] == 'H')
{
    if(scr_SetpointsScreen1.BatVolt < 47.5 )
    {
      DisplayNotificationWarning("Battery Voltage below 48V Min.", "Vnom Voltage");
      return false;
    }
}

else  //MINIMUM BAT VOLT LIMIT FOR MV UNIT
{
    if(scr_SetpointsScreen1.BatVolt < 23.5 )
    {
      DisplayNotificationWarning("Battery Voltage below 24V Min.", "Vnom Voltage");
      return false;
    }
}

if(sysInfo.modelType[0] == 'H')
{

    if(scr_SetpointsScreen1.OcVolt > 297.00)     // depends if HV or MV
    {
      DisplayNotificationWarning("OC Voltage above 297V Max.", "Voc Voltage");
       return false;
    }
    
}

else
{

    if(scr_SetpointsScreen1.OcVolt > 297.00)     // depends if HV or MV
    {
    DisplayNotificationWarning("OC Voltage above 297V Max.", "Voc Voltage");
    return false;
    }
}


if(sysInfo.modelType[0] == 'H')
{

    if(scr_SetpointsScreen1.MpVolt > 250.00)
    {
      DisplayNotificationWarning("MP Voltage above 250V Max.", "Mpp Voltage");
      return false;
    }

}

else
{

    if(scr_SetpointsScreen1.MpVolt > 250.00)
    {
      DisplayNotificationWarning("MP Voltage above 250V Max.", "Mpp Voltage");
      return false;
    }

}

if(scr_SetpointsScreen1.BatVolt <= 132.5)
{

    if(scr_SetpointsScreen1.MpVolt < (scr_SetpointsScreen1.BatVolt + ((0.3)*scr_SetpointsScreen1.BatVolt)) )
    {
      DisplayNotificationWarning("MP Voltage below 130% Vnom", "Mpp Voltage");
      return false;
    }

}

else
{

    if(scr_SetpointsScreen1.MpVolt < (scr_SetpointsScreen1.BatVolt + ((0.25)*scr_SetpointsScreen1.BatVolt)) )
    {
      DisplayNotificationWarning("MP Voltage below 125% Vnom", "Mpp Voltage");
      return false;
    }

}

if (scr_SetpointsScreen1.BatVolt <= 132.5)
{
        if(scr_SetpointsScreen2.FloatVolt >( scr_SetpointsScreen1.BatVolt + ((0.2)*scr_SetpointsScreen1.BatVolt)) )  //sealed lead acid adjustment
        {
           DisplayNotificationWarning("Float Voltage exceeds limit.", "Float Voltage");
          return false;
        }
}
else
{
        if(scr_SetpointsScreen2.FloatVolt >( scr_SetpointsScreen1.BatVolt + ((0.15)*scr_SetpointsScreen1.BatVolt)) )  //sealed lead acid adjustment for 144V Battery
        {
           DisplayNotificationWarning("Float Voltage exceeds limit.", "Float Voltage");
          return false;
        }
}        

if (scr_SetpointsScreen1.BatVolt <= 132.5)
{
        if(scr_SetpointsScreen2.BlkVolt > ( scr_SetpointsScreen1.BatVolt + ((0.3)*scr_SetpointsScreen1.BatVolt)) ) // sealed lead acid adjustment
        {
         DisplayNotificationWarning("Absorb Voltage exceeds limit.", "Absorb Voltage");
         return false;
        }
}
else
{
        if(scr_SetpointsScreen2.BlkVolt > ( scr_SetpointsScreen1.BatVolt + ((0.2)*scr_SetpointsScreen1.BatVolt)) ) // sealed lead acid adjustment for 144V Battery
        {
         DisplayNotificationWarning("Absorb Voltage exceeds limit.", "Absorb Voltage");
         return false;
        }
}

if(scr_SetpointsScreen2.BlkVolt >=  scr_SetpointsScreen1.MpVolt)
{ 
 DisplayNotificationWarning("Absorb Voltage exceeds Vmpp.", "Absorb Voltage");
  return false;
}

if(scr_SetpointsScreen2.BlkRstVolt > ( scr_SetpointsScreen1.BatVolt + ((0.105)*scr_SetpointsScreen1.BatVolt)) ) //check that this holds true
{
 DisplayNotificationWarning("ReBulk Voltage exceeds limit.", "ReBulk Voltage");
  return false;
}

if(scr_SetpointsScreen2.FloatVolt >  scr_SetpointsScreen2.BlkVolt)
{
   DisplayNotificationWarning("Float Point above Absorb Point.", "Float Voltage");
  return false;
}

if(scr_SetpointsScreen1.OcVolt < scr_SetpointsScreen1.MpVolt)
{
  DisplayNotificationWarning("Voc [Array] below Vmpp [Array].", "Voc Voltage");
  return false;
}

if(scr_SetpointsScreen1.OcVolt < 50.0)
{
  DisplayNotificationWarning("Voc voltage below 50V Min.", "Voc Voltage");
  return false;
}

notificationScreenType = STATUS_SCREEN_PASS;
return true;


}



//Event Handlers

void btn_SetpointsScreen1_UpOnClick()
{
 IncrementLabelSelection1();
}

void btn_SetpointsScreen1_DownOnClick()
{
  DecrementLabelSelection1();
}

void btn_SetpointsScreen1_EditOnClick()
{
 ClearLbl(&lbl_SetpointsEditScreen_DigType,boxRound_SetpointsEditScreen_BackgroundPanel.Color);
 
 if(PassCodeFlag == false)
 Init_PincodeScreen(&scr_PincodeScreen);
 
 else if(PassCodeFlag == true)
 Init_SetpointsEditScreen(&scr_SetpointsEditScreen);
}

void btn_SetpointsScreen1_NextOnClick()
{
 Init_SetpointsScreen2(&scr_SetpointsScreen2);
}