// ----------------------------------------------------------------------------
// Filename    : rs485.c
// Created On  : 01/10/2012
// Last Modify : 27/11/2012
// Authours    : Adrian Edmonds, Carl Joyce & Pavle Krkeljas
// Company     : Australian Energy Research Laboratories (AERL)
// Website     : http://www.aerl.com.au
// Description : This file contains code for the RS-485 driver which is
//               connected to UART 1 (i.e. 2nd Serial Port).
// ----------------------------------------------------------------------------
#include "rs485.h"
#include "general.h"
// ----------------------------------------------------------------------------
// Constant Definitions & Variables
// ----------------------------------------------------------------------------
// USARTD1 Transmitter Buffer ...
#define TX_BUFFER_SIZE_USARTD1 64
char tx_buffer_USARTD1[TX_BUFFER_SIZE_USARTD1];

sbit RS485_TX_ENABLE at LATD14_bit;      // LATD11_bit on Test Kit
sbit RS485_TX_ENABLE_DIR at TRISD14_bit; // TRISD11_bit on Test Kit

#if TX_BUFFER_SIZE_USARTD1 <= 256
   unsigned char tx_wr_index_USARTD1 = 0;
   unsigned char tx_rd_index_USARTD1 = 0;
   unsigned char tx_counter_USARTD1 = 0;
#else
   unsigned int tx_wr_index_USARTD1 = 0;
   unsigned int tx_rd_index_USARTD1 = 0;
   unsigned int tx_counter_USARTD1 = 0;
#endif

// USARTD1 Receiver Buffer ...
#define RX_BUFFER_SIZE_USARTD1 192
char rx_buffer_USARTD1[RX_BUFFER_SIZE_USARTD1];

sbit RS485_RX_ENABLE at LATD15_bit;      // LATD11_bit on Text Kit
sbit RS485_RX_ENABLE_DIR at TRISD15_bit; // TRISD11_bit on Test Kit

#if RX_BUFFER_SIZE_USARTD1 <= 256
   unsigned char rx_wr_index_USARTD1 = 0;
   unsigned char rx_rd_index_USARTD1 = 0;
   unsigned char rx_counter_USARTD1 = 0;
#else
   unsigned int rx_wr_index_USARTD1 = 0;
   unsigned int rx_rd_index_USARTD1 = 0;
   unsigned int rx_counter_USARTD1 = 0;
#endif

// This flag is set on USARTD1 Receiver buffer overflow
bit rx_buffer_overflow_USARTD1;
// ----------------------------------------------------------------------------
// RS-485 (UART1) Initialization
// ----------------------------------------------------------------------------
void RS485_Init(unsigned long baudRate, unsigned long clkFreq,
                unsigned char parity, unsigned char stopBits)
{
   rx_buffer_overflow_usartd1 = 0;   // Clear RX Buffer overflow flag (UART 1)
   RS485_FlushRx();                  // Flush the Rx Buffer
   RS485_FlushTx();                  // Flush the Tx Buffer
   
   // Initialize UART2 ...
   UART2_Init_Advanced(baudRate, clkFreq,
                       _UART_LOW_SPEED,
                       parity,     // _UART_8BIT_NOPARITY,
                       stopBits);  // _UART_TWO_STOPBITS);

   Delay_ms(100);                 // Wait for UART module to stabilize
   
   U2IP0_bit = HIGH;              // set interrupt
   U2IP1_bit = HIGH;              // priority
   U2IP2_bit = HIGH;              // to 7

   U2STA.B7 = HIGH;               // RX Interrupt on Full Buffer of 4 chars.
   U2STA.B6 = HIGH;

   U2STA.B15 = HIGH;              // TX Interrupt when Empty Buffer of 4 chars.
   U2STA.B14 = LOW;

   U2RXIF_bit = LOW;              // Ensure interrupt not pending
   U2TXIF_bit = LOW;              // Ensure interrupt not pending
   
   RS485_TX_ENABLE_DIR = PIN_OUTPUT;  // For Test kit, TX/RX is the same pin
   RS485_RX_ENABLE_DIR = PIN_OUTPUT;
}
// ----------------------------------------------------------------------------
void RS485_InitRxTx(void)
{
   // Turn on RS485 RX enable bit (i.e. set LOW to receive) ...
   RS485_RX_ENABLE = LOW;
   // Turn off RS485 TX enable bit (i.e. set HIGH to transmit) ...
   RS485_TX_ENABLE = LOW;

   // Enable Rx/Tx Interrupts for UART 2 ...
   U2RXIE_bit = HIGH;                 // Enable RX interrupt
   U2TXIE_bit = LOW;                  // Disable TX interrupt
}
// ----------------------------------------------------------------------------
void RS485_FlushRx(void)
{
   rx_wr_index_USARTD1 = 0;           // Reset RX write index
   rx_rd_index_USARTD1 = 0;           // Reset RX read index
   rx_counter_USARTD1 = 0;            // Reset RX counter
}
// ----------------------------------------------------------------------------
void RS485_FlushTx(void)
{
   tx_wr_index_USARTD1 = 0;           // Reset TX write index
   tx_rd_index_USARTD1 = 0;           // Reset TX read index
   tx_counter_USARTD1 = 0;            // Reset TX counter
}
// ----------------------------------------------------------------------------
int RS485_kbhit(void)
{
#if RX_BUFFER_SIZE_USARTD1 < 256
    unsigned char tmp;
#else
    unsigned int tmp;
#endif

    DisableInterrupts();
    tmp = rx_counter_usartd1;
    EnableInterrupts();

    return ((tmp != 0) || (U2STA.B0));
}
// ----------------------------------------------------------------------------
// Method Name : RS485_PutChar
// Parameters  : char c
// Return Type : Void
// Description : Writes a character to the USARTD1 Transmitter buffer.
// Extra Notes : USARTD1 is used as default output device by 'putchar' method.
// ----------------------------------------------------------------------------
void RS485_PutChar(char c)
{
   // Turn on RS485 TX enable bit (i.e. set HIGH to transmit) ...
   RS485_TX_ENABLE = HIGH;

   // Wait for ...
   while (tx_counter_USARTD1 == TX_BUFFER_SIZE_USARTD1);

   DisableInterrupts();
   if (tx_counter_USARTD1 || (U2STA.B9))
   {
      tx_buffer_usartd1[tx_wr_index_USARTD1++] = c;
   #if TX_BUFFER_SIZE_USARTD1 != 256
      if (tx_wr_index_USARTD1 == TX_BUFFER_SIZE_USARTD1)
         tx_wr_index_USARTD1 = 0;
   #endif
      ++tx_counter_USARTD1;
      U2TXIE_bit = HIGH;
      U2TXIF_bit = HIGH;
      EnableInterrupts();
   }
   else
   {
      EnableInterrupts();
      UART2_Write(c);
   }
}
// ----------------------------------------------------------------------------
void RS485_PutString(char *s)
{
   while(*s != 0x00)       // While not end of string character
   {
      RS485_PutChar(*s);  // Put single char in Tx Buffer and don't set TX flag.
      s++;                // Increment character index
   }
   //RS485_SendChar(0x00);
}
// ----------------------------------------------------------------------------
char RS485_GetChar(void)
{
   char c;
   
   while ((rx_counter_usartd1 == 0) && (!U2STA.B0));

   if ((rx_counter_usartd1 == 0) && (U2STA.B0))
   {
      c =  UART2_Read();
      return c;
   }

   c = rx_buffer_usartd1[rx_rd_index_usartd1++];
#if RX_BUFFER_SIZE_USARTD1 != 256
   if (rx_rd_index_usartd1 == RX_BUFFER_SIZE_USARTD1)
      rx_rd_index_USARTD1 = 0;
#endif

   DisableInterrupts();
   --rx_counter_usartd1;
   EnableInterrupts();

   return c;
}
// ----------------------------------------------------------------------------
char* RS485_GetString(void)
{
   char str[64];
   char c;
   int i = 0;
   
   c = RS485_GetChar();

   while(c != 0x00)
   {
      str[i] = c;
      i++;
      c = RS485_GetChar();
   }
   return &str;
}
// ----------------------------------------------------------------------------
int RS485_TxBufferFull(void)
{
#if TX_BUFFER_SIZE_USARTD1<256
    unsigned char tmp;
#else
    unsigned int tmp;
#endif

    DisableInterrupts();
    tmp = tx_counter_usartd1;
    EnableInterrupts();

    return (tmp == TX_BUFFER_SIZE_USARTD1);
}
// ----------------------------------------------------------------------------
void UART2_Handler() iv IVT_UART_2 ilevel 7 ics ICS_SRS
{
   char uart_rd;
   unsigned char status;

   // If UART2 RX Interrupt Flag is set ...
   if (U2RXIF_bit)
   {
      // While there is data available at UART2 ...
      while (U2STA.B0)
      {
         status = 0;                 // Reset status flag
         uart_rd = UART2_Read();     // Read the received character
         if (status == 0)            // If status flag set (i.e. char was read)
         {
            rx_buffer_USARTD1[rx_wr_index_USARTD1++] = uart_rd; // Put data into buffer, then increment index
            #if RX_BUFFER_SIZE_USARTD1 == 256                   // Special case if receiver buffer size = 256
            if (++rx_counter_USARTD1 == 0)                      // Increment counter, then check equal 0
            {
            #else                                               // Else, buffer size != 256
            if (rx_wr_index_USARTD1 == RX_BUFFER_SIZE_USARTD1)  // If index equals buffer size
               rx_wr_index_USARTD1 = 0;                         // Reset index to zero

            if (++rx_counter_USARTD1 == RX_BUFFER_SIZE_USARTD1) // If counter equals buffer size
            {
               rx_counter_USARTD1 = 0;                          // Reset counter to zero
            #endif
               rx_buffer_overflow_USARTD1 = 1;                  // Set buffer overflow flag
            };
         }
      }
      U2RXIF_bit = LOW;                                         // Clear Rx Interrupt flag for UART
      //pxMBFrameCBByteReceived();                                // Execute Modbus Byte Recevied Callback Function
   }
   
   // If UART2 TX Interrupt Flag is set ...
   if (U2TXIF_bit)
   {
      if (tx_counter_USARTD1)                                   // If transmit counter for UART != zero (i.e. There's data to transmit)
      {
         --tx_counter_USARTD1;                                  // Decrement counter
         UART2_Write(tx_buffer_USARTD1[tx_rd_index_USARTD1++]); // Write current byte in Tx Buffer to UART, then increment index
         #if TX_BUFFER_SIZE_USARTD1 != 256                      // If Tx Buffer size != 256
         if (tx_rd_index_USARTD1 == TX_BUFFER_SIZE_USARTD1)     // If Tx Buffer index = Buffer Size
            tx_rd_index_USARTD1 = 0;                            // Reset Tx Buffer Index
         #endif
         U2TXIE_bit = HIGH;                                     // Enable Tx Interrupt for UART
      }
      else                                                      // Else
      {
         U2TXIE_bit = LOW;                                      // Disable Tx Interrupt for UART
         RS485_TX_ENABLE = LOW;                                 // Disable Tx on RS485 chip (i.e. Enable receive if only one Tx/Rx line)
      }
      U2TXIF_bit = LOW;                                         // Clear Tx Interrupt flag for UART
      //pxMBFrameCBTransmitterEmpty();                            // Execute ModBus Transmitter callback function
   }
}
// ----------------------------------------------------------------------------
// End of File (rs485.c)
// ----------------------------------------------------------------------------