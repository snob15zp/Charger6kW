#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "scr_SetpointsScreen2.h"
#include "scr_SetpointsScreen1.h"
#include "scr_SetpointsEditScreen.h"
#include "scr_MainMenuScreen.h"
#include "scr_SettingsMenuScreen.h"
#include "scr_PincodeScreen.h"
#include "scr_NotificationScreen.h"
#include "protocol.h"
#include "general.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"
#include "coolmax.h"

TLabel *labelNames2[MAX_LABELS_SETPOINTS2];
TLabel *labelValues2[MAX_LABELS_SETPOINTS2];
TLabel *labelDesig2[MAX_LABELS_SETPOINTS2];
TBox_Round *selectionBoxes2[MAX_LABELS_SETPOINTS2];

scr_SetpointsScreen2_Type scr_SetpointsScreen2;

extern Tscreen* CurrentScreen;
extern Tscreen* PreviousScreen;

enum SELECTED_LABEL2 curLabel2 = FirstLabel2;


void Init_SetpointsScreen2(scr_SetpointsScreen2_Type *Screen)
{
     GetSetpoints2MainStruct();
     
     if (CurrentScreen != &SetpointsScreen2)
     {
     labelNames2[FirstLabel2] = &lbl_SetpointsScreen2BulkVolt_Name; // Switched all
     labelNames2[Label_a2] = &lbl_SetpointsScreen2BulkTime_Name;
     labelNames2[Label_a3] = &lbl_SetpointsScreen2FloatVolt_Name;
     labelNames2[LastLabel2] = &lbl_SetpointsScreen2BulkResetVolt_Name;
     
     labelValues2[FirstLabel2] = &lbl_SetpointsScreen2BulkVolt_Value; // Switched all
     labelValues2[Label_a2] = &lbl_SetpointsScreen2BulkTime_Value;
     labelValues2[Label_a3] = &lbl_SetpointsScreen2FloatVolt_Value;
     labelValues2[LastLabel2] = &lbl_SetpointsScreen2BulkResetVolt_Value;
     
     labelDesig2[FirstLabel2] = &lbl_SetpointsScreen2BulkVolt_Desig; // Switched all
     labelDesig2[Label_a2] = &lbl_SetpointsScreen2BulkTime_Desig;
     labelDesig2[Label_a3] = &lbl_SetpointsScreen2FloatVolt_Desig;
     labelDesig2[LastLabel2] = &lbl_SetpointsScreen2BulkResetVolt_Desig;
     
     selectionBoxes2[FirstLabel2] = &boxRound_SetpointsScreen2_BulkVoltSelectionBox;
     selectionBoxes2[Label_a2] = &boxRound_SetpointsScreen2_BulkTimeSelectionBox;
     selectionBoxes2[Label_a3] = &boxRound_SetpointsScreen2_FloatVoltSelectionBox;
     selectionBoxes2[LastLabel2] = &boxRound_SetpointsScreen2_BulkResetVoltSelectionBox;
     
     PreviousScreen = CurrentScreen;
     
     DeselectLabel2(curLabel2); //solves problem of having any other Label other than the selected Label as being selected
     
    if (PreviousScreen == &SetpointsScreen1) // if comming from settings menu the first Label is selected
    {
       curLabel2 = FirstLabel2;
    }
    
    if (PreviousScreen == &SetpointsEditScreen)   // if comming from seconds setpoints Screen the selected Label on first Screen is LastLabel
        {
         switch(curLabel2)
         {
          case FirstLabel2:
                          Screen->BlkVolt = scr_SetpointsEditScreen.RawFloatValue;
                          break;

          case Label_a2:
                          Screen->BlkTime = scr_SetpointsEditScreen.RawFloatValue;
                          break;

          case Label_a3:
                          Screen->FloatVolt = scr_SetpointsEditScreen.RawFloatValue;
                          break;
                          
          case LastLabel2:
                          Screen->BlkRstVolt = scr_SetpointsEditScreen.RawFloatValue;
                          break;
          }

         }
         
         DrawScreen(&SetpointsScreen2);
         SelectLabel2(FirstLabel2);
         DeselectLabel2(FirstLabel2);
         SelectLabel2(Label_a2);
         DeselectLabel2(Label_a2);
         SelectLabel2(Label_a3);
         DeselectLabel2(Label_a3);
         SelectLabel2(LastLabel2);
         DeselectLabel2(LastLabel2);
         SelectLabel2(curLabel2);
     
     }
}


void UpdateSetpointsScreen2(scr_SetpointsScreen2_Type *Screen) // This is the only thing that needs to be updated on this screen
{
   char blkRstVolt[MAX_LENGTH];
   char blkTime[MAX_LENGTH];
   char floatVolt[MAX_LENGTH];
   char blkVolt[MAX_LENGTH];
   
   int i=0;
  
  if (CurrentScreen == &SetpointsScreen2)
     {

       for(i ; i < MAX_LABELS_SETPOINTS2; i++)
     {
         if (curLabel2 == i)
         {
           ClearLbl(labelValues2[i],SELECTED_BOX_COLOR);
           TFT_Set_Font(labelValues2[i]->FontName, CL_BLACK, FO_HORIZONTAL);
         }

         else
         {
           ClearLbl(labelValues2[i],BOX_COLOR);
           TFT_Set_Font(labelValues2[i]->FontName, UNSELECTED_VALUE_COLOR, FO_HORIZONTAL);
         }
         
         switch( i )
         {
            case FirstLabel2:
                            sprintf(blkVolt,"%3.1f", Screen->BlkVolt);
                            strncpy(labelValues2[FirstLabel2]->Caption, blkVolt, 8);
                            labelValues2[FirstLabel2]->Caption[8] = 0x00;
                            if (labelValues2[FirstLabel2]->Visible == 1)
                            TFT_Write_Text(labelValues2[FirstLabel2]->Caption, labelValues2[FirstLabel2]->Left, labelValues2[FirstLabel2]->Top);
                            //printd("Label='%s' '%s'\r\n",blkRstVolt,labelValues2[FirstLabel2]->Caption); //prints out debug information
                            break;

            case Label_a2:
                            sprintf(blkTime,"%3.1f", Screen->BlkTime);  //needs only one Decimal place
                            strncpy(labelValues2[Label_a2]->Caption, blkTime, 8);
                            labelValues2[Label_a2]->Caption[8] = 0x00;
                            if (labelValues2[Label_a2]->Visible == 1)
                            TFT_Write_Text(labelValues2[Label_a2]->Caption, labelValues2[Label_a2]->Left, labelValues2[Label_a2]->Top);
                            break;


           case Label_a3:   
                            sprintf(floatVolt,"%3.1f", Screen->FloatVolt);
                            strncpy(labelValues2[Label_a3]->Caption, floatVolt, 8);
                            labelValues2[Label_a3]->Caption[8] = 0x00;
                            if (labelValues2[Label_a3]->Visible == 1)
                            TFT_Write_Text(labelValues2[Label_a3]->Caption, labelValues2[Label_a3]->Left, labelValues2[Label_a3]->Top);
                            break;


            case LastLabel2:
                            sprintf(blkRstVolt,"%3.1f", Screen->BlkRstVolt);
                            strncpy(labelValues2[LastLabel2]->Caption, blkRstVolt, 8);
                            labelValues2[LastLabel2]->Caption[8] = 0x00;
                            if (labelValues2[LastLabel2]->Visible == 1)
                            TFT_Write_Text(labelValues2[LastLabel2]->Caption, labelValues2[LastLabel2]->Left, labelValues2[LastLabel2]->Top);
                            break;
         }



     }
   }
}

void PassSetpointValues2(scr_SetpointsEditScreen_Type *Screen)
{
  if (curLabel2 == FirstLabel2)
   {
     Screen->RawFloatValue = scr_SetpointsScreen2.BlkVolt;
     Screen->DecimalPlaces = 2;
     strncpy(Screen->DigType, "Volts", 6);
     Screen->DigType[5] = 0x00;
     strncpy(Screen->SetpointTitle, "Absorb Point", 12);
     Screen->SetpointTitle[12] = 0x00;
     return;

   }

   if (curLabel2 == Label_a2)
   {
     Screen->RawFloatValue = scr_SetpointsScreen2.BlkTime;
     Screen->DecimalPlaces = 2;
     strncpy(Screen->DigType, "Mins", 5);
     Screen->DigType[5] = 0x00;
     strncpy(Screen->SetpointTitle, "Absorb Time", 11);
     Screen->SetpointTitle[11] = 0x00;
     return;

   }

   if (curLabel2 == Label_a3)
   {
     Screen->RawFloatValue = scr_SetpointsScreen2.FloatVolt;
     Screen->DecimalPlaces = 2;
     strncpy(Screen->DigType, "Volts", 6);
     Screen->DigType[5] = 0x00;
     strncpy(Screen->SetpointTitle, "Float Point", 11);
     Screen->SetpointTitle[11] = 0x00;
     return;
   }
   
   if (curLabel2 == LastLabel2)
   {
     Screen->RawFloatValue = scr_SetpointsScreen2.BlkRstVolt;
     Screen->DecimalPlaces = 2;
     strncpy(Screen->DigType, "Volts", 6);
     Screen->DigType[5] = 0x00;
     strncpy(Screen->SetpointTitle, "ReBulk Point", 13);
     Screen->SetpointTitle[12] = 0x00;
     return;

   }
   
   
}

void SelectLabel2(enum SELECTED_LABEL2 lbl)
{
  selectionBoxes2[lbl]->Visible = 1;
  DrawRoundBox(selectionBoxes2[lbl]);

  TFT_Set_Font(labelNames2[lbl]->FontName,SELECTED_NAME_COLOR, FO_HORIZONTAL);
  TFT_Write_Text(labelNames2[lbl]->Caption, labelNames2[lbl]->Left, labelNames2[lbl]->Top);

  TFT_Set_Font(labelValues2[lbl]->FontName,SELECTED_VALUE_COLOR, FO_HORIZONTAL);
  TFT_Write_Text(labelValues2[lbl]->Caption, labelValues2[lbl]->Left, labelValues2[lbl]->Top);
  
  TFT_Set_Font(labelDesig2[lbl]->FontName,SELECTED_VALUE_COLOR, FO_HORIZONTAL);
  TFT_Write_Text(labelDesig2[lbl]->Caption, labelDesig2[lbl]->Left, labelDesig2[lbl]->Top);

}
void DeselectLabel2(enum SELECTED_LABEL2 lbl)
{
  selectionBoxes2[lbl]->Visible = 0;
  DeselectRoundBox(selectionBoxes2[lbl],BOX_COLOR);

  TFT_Set_Font(labelNames2[lbl]->FontName,UNSELECTED_NAME_COLOR, FO_HORIZONTAL);
  TFT_Write_Text(labelNames2[lbl]->Caption, labelNames2[lbl]->Left, labelNames2[lbl]->Top);

  TFT_Set_Font(labelValues2[lbl]->FontName,UNSELECTED_VALUE_COLOR, FO_HORIZONTAL);
  TFT_Write_Text(labelValues2[lbl]->Caption, labelValues2[lbl]->Left, labelValues2[lbl]->Top);
  
  TFT_Set_Font(labelDesig2[lbl]->FontName,UNSELECTED_VALUE_COLOR, FO_HORIZONTAL);
  TFT_Write_Text(labelDesig2[lbl]->Caption, labelDesig2[lbl]->Left, labelDesig2[lbl]->Top);
  
}

void IncrementLabelSelection2()
{
   if (curLabel2 == FirstLabel2)
   {
      Init_SetpointsScreen1(&scr_SetpointsScreen1);
      return;
   }
  DeselectLabel2(curLabel2);
  SelectLabel2(curLabel2-1);
  curLabel2 = curLabel2-1;

}

void DecrementLabelSelection2()
{
 if (curLabel2 == LastLabel2)
 return;
 
 DeselectLabel2(curLabel2);
 SelectLabel2(curLabel2+1);
 curLabel2 = curLabel2+1;
}

void GetSetpoints2MainStruct()
{
  if (!scr_SetpointsScreen2.initialised)
  {
    scr_SetpointsScreen2.BlkRstVolt =  userConfig_R.setPointsConfig.bulkResetVolt;
    scr_SetpointsScreen2.BlkTime  = (float) ((uint32_t) userConfig_R.setPointsConfig.bulkTime / 60l);
    scr_SetpointsScreen2.BlkTime  += ((float) ((uint32_t) userConfig_R.setPointsConfig.bulkTime % 60l)) / 100.0f;
    scr_SetpointsScreen2.FloatVolt = userConfig_R.setPointsConfig.floatVolt;
    scr_SetpointsScreen2.BlkVolt  =  userConfig_R.setPointsConfig.bulkVolt;
    scr_SetpointsScreen2.TriggerValue  = userConfig_R.lowOutVoltGenset.triggerVal;
    scr_SetpointsScreen2.ResetValue  = userConfig_R.lowOutVoltGenset.resetVal;
    scr_SetpointsScreen2.initialised = true;
  }
}

void SetSetpoints2MainStruct()
{
  uint32_t t;
  userConfig_W.setPointsConfig.bulkResetVolt = scr_SetpointsScreen2.BlkRstVolt;
  t = (uint32_t) (scr_SetpointsScreen2.BlkTime * 100.0f);
  userConfig_W.setPointsConfig.bulkTime = (uint32_t) (t / 100l);
  userConfig_W.setPointsConfig.bulkTime *= 60l;
  userConfig_W.setPointsConfig.bulkTime += (uint32_t)(t % 100l);
  userConfig_W.setPointsConfig.floatVolt = scr_SetpointsScreen2.FloatVolt;
  userConfig_W.setPointsConfig.bulkVolt = scr_SetpointsScreen2.BlkVolt;
  userConfig_W.lowOutVoltGenset.triggerVal = scr_SetpointsScreen2.TriggerValue;
  userConfig_W.lowOutVoltGenset.resetVal = scr_SetpointsScreen2.ResetValue;
}

// Event Handlers

void btn_SetpointsScreen2_ApplyOnClick() 
{
int res;

res = VerifySetpointValues();

if (!res)
return;

SetSetpoints1MainStruct();
SetSetpoints2MainStruct();

res = CompareUserConfigData();
if (!res)
{
   Init_NotificationScreen();
}
else
{
   Init_SettingsMenuScreen();
}
}

void btn_SetpointsScreen2_UpOnClick() 
{
  IncrementLabelSelection2();
}

void btn_SetpointsScreen2_DownOnClick() 
{
 DecrementLabelSelection2();
}

void btn_SetpointsScreen2_EditOnClick() 
{
 ClearLbl(&lbl_SetpointsEditScreen_DigType,boxRound_SetpointsEditScreen_BackgroundPanel.Color);

 if(PassCodeFlag == false)
 Init_PincodeScreen(&scr_PincodeScreen);

 else if(PassCodeFlag == true)
 Init_SetpointsEditScreen(&scr_SetpointsEditScreen);
}

void btn_SetpointsScreen2_BackOnClick()
{    
 PassCodeFlag = false;
 Init_SettingsMenuScreen();
}