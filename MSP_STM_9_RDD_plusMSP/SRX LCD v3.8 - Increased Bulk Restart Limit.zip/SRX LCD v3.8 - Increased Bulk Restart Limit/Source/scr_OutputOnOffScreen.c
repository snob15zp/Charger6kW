#include "scr_RealTimeScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "scr_OutputOnOffScreen.h"
#include "scr_NotificationScreen.h"
#include "protocol.h"
#include "general.h"
#include "coolmax.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"
#include "features.h"
#include "localConfig.h"
#include "log.h"

extern Tscreen* CurrentScreen;
extern Tscreen* PreviousScreen;

int WriteOutputState = Undefined;
int ReadSmartShutDownState = Undefined;
int WriteSmartShutDownState = Undefined;
int HasSmartShutdownChanged = false;
int PreviousReadOutputState = Undefined;

enum COOLMAX_OUTPUT_STATE ReadOutputState = Undefined; // telemetry data of output state of coolmax as either On or OFF

void Init_OutputOnOffScreen(void)
{
     if (CurrentScreen != &OutputOnOffScreen)
     {
        PreviousScreen = CurrentScreen;
        
        // could set the ReadOutputState to be Undefined here
        
#ifdef ENABLE_MIDNIGHT_RESET
       chk_OutputOnOffScreen_MidnightReset.Active = true;
       chk_OutputOnOffScreen_MidnightReset.Visible = true;
       chk_OutputOnOffScreen_MidnightReset.Checked = CONFIG.midnightReset;
       DrawCheckBox(&chk_OutputOnOffScreen_MidnightReset);
#endif

         if (ReadOutputState == Undefined)   // telemetry state undfined
         {
             btn_OutputOnOffScreen_EnableDisable.Caption = "                "; //clear previous caption
             btn_OutputOnOffScreen_EnableDisable.Caption = "READING OUTPUT";
             btn_OutputOnOffScreen_EnableDisable.Gradient = false;
             btn_OutputOnOffScreen_EnableDisable.Active = false;
             DrawRoundButton(&btn_OutputOnOffScreen_EnableDisable);

             ClearLbl(&lbl_OutputOnOffScreen_OutputOnOff,boxRound_OutputOnOffScreen_OnOffPanel.Color);
             TFT_Set_Font(lbl_OutputOnOffScreen_OutputOnOff.FontName, CL_BLACK, FO_HORIZONTAL);
             strncpy(lbl_OutputOnOffScreen_OutputOnOff.Caption, "   ", 3);
             lbl_OutputOnOffScreen_OutputOnOff.Caption[3] = 0x00;
             TFT_Write_Text(lbl_OutputOnOffScreen_OutputOnOff.Caption, lbl_OutputOnOffScreen_OutputOnOff.Left, lbl_OutputOnOffScreen_OutputOnOff.Top);

             DrawScreen(&OutputOnOffScreen);

             PreviousReadOutputState = ReadOutputState;
             return;

         }

         if (ReadOutputState == Output_ON) // if telemetry state output is ON
         {
             DisplayDisableOutputButton();    // shows that the output can be Disabled because currently it is enabled.
         }

         if (ReadOutputState == Output_OFF)  // if telemetry state output is OFF
         {
             DisplayEnableOutputButton();   // Shows that the output can be Enabled because it is currently disabled
         }
         
        if ((ReadOutputState == Output_SHUTDOWN) && (telemetry.pvVoltage > telemetry.outputVoltage))
        {
          DisplayShutdownOutputButton();
        }
        else if ((ReadOutputState == Output_SHUTDOWN) && (telemetry.pvVoltage <= telemetry.outputVoltage))
        {
          DisplayPVMissingOutputButton();
        }
        else
        {
         if (ReadOutputState ==  Output_GROUNDFAULT)
         {
           DisplayGroundFaultOutputButton();
         }        
         else
         {
           if ((PreviousReadOutputState == EnablingOutput)&&(ReadOutputState != Output_ON)) // ensuring when leaving the Screen and comming back on the button is disabled.
           {
             ClearLbl(&lbl_OutputOnOffScreen_OutputOnOff,boxRound_OutputOnOffScreen_OnOffPanel.Color);
             TFT_Set_Font(lbl_OutputOnOffScreen_OutputOnOff.FontName, CL_BLACK, FO_HORIZONTAL);
             strncpy(lbl_OutputOnOffScreen_OutputOnOff.Caption, "   ", 3);
             lbl_OutputOnOffScreen_OutputOnOff.Caption[3] = 0x00;
             TFT_Write_Text(lbl_OutputOnOffScreen_OutputOnOff.Caption, lbl_OutputOnOffScreen_OutputOnOff.Left, lbl_OutputOnOffScreen_OutputOnOff.Top);

             btn_OutputOnOffScreen_EnableDisable.Caption = "                 ";
             btn_OutputOnOffScreen_EnableDisable.Caption = "ENABLING OUTPUT";
             btn_OutputOnOffScreen_EnableDisable.Gradient = false;
             btn_OutputOnOffScreen_EnableDisable.Active = false;
             btn_OutputOnOffScreen_EnableDisable.Color = CL_GRAY;
             DrawRoundButton(&btn_OutputOnOffScreen_EnableDisable);
           }

            if ((PreviousReadOutputState == DisablingOutput)&&(ReadOutputState != Output_OFF))
           {
             ClearLbl(&lbl_OutputOnOffScreen_OutputOnOff,boxRound_OutputOnOffScreen_OnOffPanel.Color);
             TFT_Set_Font(lbl_OutputOnOffScreen_OutputOnOff.FontName, CL_BLACK, FO_HORIZONTAL);
             strncpy(lbl_OutputOnOffScreen_OutputOnOff.Caption, "   ", 3);
             lbl_OutputOnOffScreen_OutputOnOff.Caption[3] = 0x00;
             TFT_Write_Text(lbl_OutputOnOffScreen_OutputOnOff.Caption, lbl_OutputOnOffScreen_OutputOnOff.Left, lbl_OutputOnOffScreen_OutputOnOff.Top);

             btn_OutputOnOffScreen_EnableDisable.Caption = "                 ";
             btn_OutputOnOffScreen_EnableDisable.Caption = "DISABLING OUTPUT";
             btn_OutputOnOffScreen_EnableDisable.Gradient = false;
             btn_OutputOnOffScreen_EnableDisable.Active = false;
             btn_OutputOnOffScreen_EnableDisable.Color = CL_GRAY;
             DrawRoundButton(&btn_OutputOnOffScreen_EnableDisable);
           }
         }
        }
     }
     DrawScreen(&OutputOnOffScreen);
}

  void InitializeOnOffScreenDefaults(void)
  {
  WriteOutputState = Undefined;
  ReadSmartShutDownState = Undefined;
  WriteSmartShutDownState = Undefined;
  HasSmartShutdownChanged = false;
  PreviousReadOutputState = Undefined;
  }

void DisplayEnableOutputButton()
{
      btn_OutputOnOffScreen_EnableDisable.Caption = "                ";; //clear previous caption
      btn_OutputOnOffScreen_EnableDisable.Caption = "Enable Output";
      btn_OutputOnOffScreen_EnableDisable.Gradient = false; //Changed from true to false
      btn_OutputOnOffScreen_EnableDisable.Active = true;
      btn_OutputOnOffScreen_EnableDisable.Color = 0x5E88; //Changed from Cl_Green to 0x2D42
      DrawRoundButton(&btn_OutputOnOffScreen_EnableDisable);
      
      ClearLbl(&lbl_OutputOnOffScreen_OutputOnOff,boxRound_OutputOnOffScreen_OnOffPanel.Color);
      TFT_Set_Font(lbl_OutputOnOffScreen_OutputOnOff.FontName, 0xD9E7, FO_HORIZONTAL);
      strncpy(lbl_OutputOnOffScreen_OutputOnOff.Caption, "OFF", 3);
      lbl_OutputOnOffScreen_OutputOnOff.Caption[3] = 0x00;
      TFT_Write_Text(lbl_OutputOnOffScreen_OutputOnOff.Caption, lbl_OutputOnOffScreen_OutputOnOff.Left, lbl_OutputOnOffScreen_OutputOnOff.Top);
      
}

void DisplayDisableOutputButton(void)
{
      btn_OutputOnOffScreen_EnableDisable.Caption = "                "; //clear previous caption
      btn_OutputOnOffScreen_EnableDisable.Caption = "Disable Output" ;
      btn_OutputOnOffScreen_EnableDisable.Gradient = false;
      btn_OutputOnOffScreen_EnableDisable.Active = true;
      btn_OutputOnOffScreen_EnableDisable.Color = 0xD9E7;        //Changed from Cl_RED gradient to 0xD9E7
      DrawRoundButton(&btn_OutputOnOffScreen_EnableDisable) ;
      
      ClearLbl(&lbl_OutputOnOffScreen_OutputOnOff,boxRound_OutputOnOffScreen_OnOffPanel.Color);
      TFT_Set_Font(lbl_OutputOnOffScreen_OutputOnOff.FontName, 0x5E88, FO_HORIZONTAL);
      strncpy(lbl_OutputOnOffScreen_OutputOnOff.Caption, "ON", 3);
      lbl_OutputOnOffScreen_OutputOnOff.Caption[3] = 0x00;
      TFT_Write_Text(lbl_OutputOnOffScreen_OutputOnOff.Caption, lbl_OutputOnOffScreen_OutputOnOff.Left, lbl_OutputOnOffScreen_OutputOnOff.Top);
}

void DisplayShutdownOutputButton(void)
{
      ClearLbl(&lbl_OutputOnOffScreen_OutputOnOff,boxRound_OutputOnOffScreen_OnOffPanel.Color);
      TFT_Set_Font(lbl_OutputOnOffScreen_OutputOnOff.FontName, 0xD9E7, FO_HORIZONTAL);
      strncpy(lbl_OutputOnOffScreen_OutputOnOff.Caption, "OFF", 3);
      lbl_OutputOnOffScreen_OutputOnOff.Caption[3] = 0x00;
      TFT_Write_Text(lbl_OutputOnOffScreen_OutputOnOff.Caption, lbl_OutputOnOffScreen_OutputOnOff.Left, lbl_OutputOnOffScreen_OutputOnOff.Top);

      btn_OutputOnOffScreen_EnableDisable.Caption = "              ";
      btn_OutputOnOffScreen_EnableDisable.Caption = "ALARM DETECTED";
      btn_OutputOnOffScreen_EnableDisable.Gradient = false;
      btn_OutputOnOffScreen_EnableDisable.Active = false;
      btn_OutputOnOffScreen_EnableDisable.Color = CL_GRAY;
      DrawRoundButton(&btn_OutputOnOffScreen_EnableDisable);
}

void DisplayPVMissingOutputButton(void)
{
      ClearLbl(&lbl_OutputOnOffScreen_OutputOnOff,boxRound_OutputOnOffScreen_OnOffPanel.Color);
      TFT_Set_Font(lbl_OutputOnOffScreen_OutputOnOff.FontName, 0xD9E7, FO_HORIZONTAL);
      strncpy(lbl_OutputOnOffScreen_OutputOnOff.Caption, "OFF", 3);
      lbl_OutputOnOffScreen_OutputOnOff.Caption[3] = 0x00;
      TFT_Write_Text(lbl_OutputOnOffScreen_OutputOnOff.Caption, lbl_OutputOnOffScreen_OutputOnOff.Left, lbl_OutputOnOffScreen_OutputOnOff.Top);

      btn_OutputOnOffScreen_EnableDisable.Caption = "              ";
      btn_OutputOnOffScreen_EnableDisable.Caption = "LOW PV VOLTAGE";
      btn_OutputOnOffScreen_EnableDisable.Gradient = false;
      btn_OutputOnOffScreen_EnableDisable.Active = false;
      btn_OutputOnOffScreen_EnableDisable.Color = 0x3459;
      DrawRoundButton(&btn_OutputOnOffScreen_EnableDisable);
}

void DisplayGroundFaultOutputButton(void)
{
      ClearLbl(&lbl_OutputOnOffScreen_OutputOnOff,boxRound_OutputOnOffScreen_OnOffPanel.Color);
      TFT_Set_Font(lbl_OutputOnOffScreen_OutputOnOff.FontName, 0xD9E7, FO_HORIZONTAL);
      strncpy(lbl_OutputOnOffScreen_OutputOnOff.Caption, "OFF", 3);
      lbl_OutputOnOffScreen_OutputOnOff.Caption[3] = 0x00;
      TFT_Write_Text(lbl_OutputOnOffScreen_OutputOnOff.Caption, lbl_OutputOnOffScreen_OutputOnOff.Left, lbl_OutputOnOffScreen_OutputOnOff.Top);

      btn_OutputOnOffScreen_EnableDisable.Caption = "              ";
      btn_OutputOnOffScreen_EnableDisable.Caption = "GROUND FAULT  ";
      btn_OutputOnOffScreen_EnableDisable.Gradient = false;
      btn_OutputOnOffScreen_EnableDisable.Active = false;
      btn_OutputOnOffScreen_EnableDisable.Color = CL_GRAY;
      DrawRoundButton(&btn_OutputOnOffScreen_EnableDisable);
}

/*
void SetOutputOnOffScreenValues(void)
{
     printd("SET OUTPUT ON OFF SCREEN VALUES\r\n");
     miscState.enableSmartShutdown = WriteSmartShutDownState;
}
*/

void UpdateOutputOnOffScreen(void)      // this is the section where i get the bits comming from control module
{

  if (CurrentScreen == &OutputOnOffScreen)
     {
       if(isOutputEnabledSent == true)  // if command reply has been received redraw button according to state of output
       {

          if (PreviousReadOutputState == EnablingOutput)
          {
              if (ReadOutputState == Output_ON)
              {
              DisplayDisableOutputButton();
              PreviousReadOutputState = ReadOutputState;
              isOutputEnabledSent = false;
              }
              return;
          }

          if (PreviousReadOutputState == DisablingOutput)
          {
             if (ReadOutputState == Output_OFF)
             {
              DisplayEnableOutputButton();
              PreviousReadOutputState = ReadOutputState;
              isOutputEnabledSent = false;
             }
             return;
          }
       }
      }
}


void RefreshOutputControlStateEnableButton(void)
{
   
  if (CurrentScreen == &OutputOnOffScreen)
     {
         if (PreviousReadOutputState == Undefined) // Runs this only once at the start
         {
               if (ReadOutputState == Output_ON) // if telemetry state output is ON
               {
                   DisplayDisableOutputButton();
               }

               if (ReadOutputState == Output_OFF)  // if telemetry state output is OFF
               {
                   DisplayEnableOutputButton();
               }
               
               if ((ReadOutputState == Output_SHUTDOWN) && (telemetry.pvVoltage > telemetry.outputVoltage))  // if telemetry state output is SHUTDOWN
               {
                   DisplayShutdownOutputButton();
               }
               
               if ((ReadOutputState == Output_SHUTDOWN) && (telemetry.pvVoltage <= telemetry.outputVoltage))  // if telemetry state output is SHUTDOWN
               {
                   DisplayPVMissingOutputButton();
               }
               
               if (ReadOutputState == Output_GROUNDFAULT)  // if telemetry state output is GROUND FAULT
               {
                   DisplayGroundFaultOutputButton();
               }
              
               PreviousReadOutputState = ReadOutputState;
         }

         if((ReadOutputState == Output_SHUTDOWN) && (telemetry.pvVoltage > telemetry.outputVoltage))    //  && (PreviousReadOutputState != Output_SHUTDOWN)
         {
            DisplayShutdownOutputButton();
            PreviousReadOutputState = ReadOutputState;
         }
                 
         if((ReadOutputState == Output_SHUTDOWN) && (telemetry.pvVoltage <= telemetry.outputVoltage))
         {
            DisplayPVMissingOutputButton();
            PreviousReadOutputState = ReadOutputState;
         }
         
         if((ReadOutputState == Output_GROUNDFAULT) && (PreviousReadOutputState != Output_GROUNDFAULT))
         {
            DisplayGroundFaultOutputButton();
            PreviousReadOutputState = ReadOutputState;
         }
         
         if((ReadOutputState == Output_OFF) && (PreviousReadOutputState == Output_ON || PreviousReadOutputState == Output_SHUTDOWN || PreviousReadOutputState == Output_GROUNDFAULT))
         {
            DisplayEnableOutputButton();
            PreviousReadOutputState = ReadOutputState;
         }

         if((ReadOutputState == Output_ON) && (PreviousReadOutputState == Output_OFF || PreviousReadOutputState == Output_SHUTDOWN || PreviousReadOutputState == Output_GROUNDFAULT))
         {
            DisplayDisableOutputButton();
            PreviousReadOutputState = ReadOutputState;
         }
     }
}

void btn_OutputOnOffScreen_EnableDisableOnClick() //Turns the output on or off depending on state that the unit is in at the moment and the state of button.
{
     if (ReadOutputState == Output_ON)
     {
       requestOutputEnabled = true;
       WriteOutputState = Output_OFF;
       btn_OutputOnOffScreen_EnableDisable.Caption = "                  ";
       btn_OutputOnOffScreen_EnableDisable.Caption = "DISABLING OUTPUT";
       btn_OutputOnOffScreen_EnableDisable.Gradient = false;
       btn_OutputOnOffScreen_EnableDisable.Active = false;
       btn_OutputOnOffScreen_EnableDisable.Color = CL_GRAY;
       DrawRoundButton(&btn_OutputOnOffScreen_EnableDisable);
       
       ClearLbl(&lbl_OutputOnOffScreen_OutputOnOff,boxRound_OutputOnOffScreen_OnOffPanel.Color);
       TFT_Set_Font(lbl_OutputOnOffScreen_OutputOnOff.FontName, CL_BLACK, FO_HORIZONTAL);
       strncpy(lbl_OutputOnOffScreen_OutputOnOff.Caption, "   ", 3);
       lbl_OutputOnOffScreen_OutputOnOff.Caption[3] = 0x00;
       TFT_Write_Text(lbl_OutputOnOffScreen_OutputOnOff.Caption, lbl_OutputOnOffScreen_OutputOnOff.Left, lbl_OutputOnOffScreen_OutputOnOff.Top);
       
       PreviousReadOutputState = DisablingOutput;
       
       LogPower(0);
     }
        
     if (ReadOutputState == Output_OFF)
     {
       requestOutputEnabled = true;
       WriteOutputState = Output_ON;
       btn_OutputOnOffScreen_EnableDisable.Caption = "                 ";
       btn_OutputOnOffScreen_EnableDisable.Caption = "ENABLING OUTPUT";
       btn_OutputOnOffScreen_EnableDisable.Gradient = false;
       btn_OutputOnOffScreen_EnableDisable.Active = false;
       btn_OutputOnOffScreen_EnableDisable.Color = CL_GRAY;
       DrawRoundButton(&btn_OutputOnOffScreen_EnableDisable);
       
       ClearLbl(&lbl_OutputOnOffScreen_OutputOnOff,boxRound_OutputOnOffScreen_OnOffPanel.Color);
       TFT_Set_Font(lbl_OutputOnOffScreen_OutputOnOff.FontName, CL_BLACK, FO_HORIZONTAL);
       strncpy(lbl_OutputOnOffScreen_OutputOnOff.Caption, "   ", 3);
       lbl_OutputOnOffScreen_OutputOnOff.Caption[3] = 0x00;
       TFT_Write_Text(lbl_OutputOnOffScreen_OutputOnOff.Caption, lbl_OutputOnOffScreen_OutputOnOff.Left, lbl_OutputOnOffScreen_OutputOnOff.Top);
       
       PreviousReadOutputState = EnablingOutput;
       
       LogPower(1);
   }
        
}

void btn_OutputOnOffScreen_BackOnClick()
{
    if((ReadOutputState == EnablingOutput) || (ReadOutputState == Output_ON))
    {
     lbl_OutputOnOffScreen_OutputOnOff.Font_Color = 0x5E88;
    }
    else if((ReadOutputState == DisablingOutput) || (ReadOutputState == Output_Off) || (ReadOutputState == Output_Shutdown))
    {
     lbl_OutputOnOffScreen_OutputOnOff.Font_Color = 0xD9E7;
    }
        
    Init_RealTimeScreen(&scr_RealTimeScreen);
}

void chk_OutputOnOffScreen_MidnightOnClick()
{
   if (chk_OutputOnOffScreen_MidnightReset.Checked)
   {
      CONFIG.midnightReset = 1;
   }
   else
   {
      CONFIG.midnightReset = 0;
   }
   ConfigWrite();
   DrawCheckBox(&chk_OutputOnOffScreen_MidnightReset);
}