#include "scr_SettingsMenuScreen.h"
#include "scr_CanBusInfoScreen.h"
#include "scr_MainMenuScreen.h"
#include "scr_RealTimeScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "coolmax.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"

extern Tscreen* CurrentScreen;
extern Tscreen* PreviousScreen;

enum COMMS_INFO_LABEL curInfoValue = ModbusId;

TLabel *CommsInfoValue[MAX_COMMS_POINTS];

scr_CanBaseIfonScreen_Type scr_CanBaseIfonScreen;

void Init_CanBusInfoScreen(scr_CanBaseIfonScreen_Type *screen)
{
     if (CurrentScreen != &CanBusInfoScreen)
     {
        CommsInfoValue[ModbusId] = &lbl_CanBusInfoScreenModbusId_Value;
        CommsInfoValue[ModbusBaud] = &lbl_CanBusInfoScreenModbusBaud_Value;
        CommsInfoValue[CanBaseId] = &lbl_CanBusInfoScreenCanBaseId_Value;
        CommsInfoValue[CanBaseBaud] = &lbl_CanBusInfoScreenCanBaud_Value;
        CommsInfoValue[UnitMode] = &lbl_CanBusInfoScreenColumnEmpty_Value;
     
        ClearLbl(CommsInfoValue[ModbusId],boxRound_CanBusInfoScreen_BackgroundPanel.Color);
        ClearLbl(CommsInfoValue[ModbusBaud],boxRound_CanBusInfoScreen_BackgroundPanel.Color);
        ClearLbl(CommsInfoValue[CanBaseId],boxRound_CanBusInfoScreen_BackgroundPanel.Color);
        ClearLbl(CommsInfoValue[CanBaseBaud],boxRound_CanBusInfoScreen_BackgroundPanel.Color);
        ClearLbl(CommsInfoValue[UnitMode],boxRound_CanBusInfoScreen_BackgroundPanel.Color);
        
        PreviousScreen = CurrentScreen;
        DrawScreen(&CanBusInfoScreen);
        
        GetCommsMainStruct();
     }
     
     GetCommsMainStruct();
}

void UpdateCanBusInfoScreen(void) // This is the only thing that needs to be updated on this screen
{
  if (CurrentScreen == &CanBusInfoScreen)
  {
      unsigned char ModbusBaudTemp;
      unsigned char CanBusBaudRateTemp;
      int i;
      int isSlave;
      
      ModbusBaudTemp = scr_CanBaseIfonScreen.modBusBaudRate;
      CanBusBaudRateTemp = scr_CanBaseIfonScreen.canBaudRate;
      isSlave = scr_CanBaseIfonScreen.unitMode;


     for (curInfoValue = 0; curInfoValue < MAX_COMMS_POINTS ; curInfoValue++)
     {
            ClearLbl(CommsInfoValue[curInfoValue],boxRound_CanBusInfoScreen_BackgroundPanel.Color);
            TFT_Set_Font(CommsInfoValue[curInfoValue]->FontName, CL_RED, FO_HORIZONTAL);
      
      if (curInfoValue == ModbusBaud)
      {
           switch(ModbusBaudTemp)
           {


                case _1200:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "1.2 Kb/s", 8);
                           CommsInfoValue[curInfoValue]->Caption[8] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;

                case _2400:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "2.4 Kb/s", 8);
                           CommsInfoValue[curInfoValue]->Caption[8] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;

                case _4800:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "4.8 Kb/s", 8);
                           CommsInfoValue[curInfoValue]->Caption[8] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;

                case _9600:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "9.6 Kb/s", 8);
                           CommsInfoValue[curInfoValue]->Caption[8] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;

                case _19200:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "19.2 Kb/s", 9);
                           CommsInfoValue[curInfoValue]->Caption[9] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;

                case _38400:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "38.4 Kb/s", 9);
                           CommsInfoValue[curInfoValue]->Caption[9] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;

                case _57600:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "57.6 Kb/s", 9);
                           CommsInfoValue[curInfoValue]->Caption[9] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;
            }
       }
           
       if (curInfoValue == CanBaseBaud)
       {
           switch(CanBusBaudRateTemp)
           {


                case _50:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "50 Kb/s", 7);
                           CommsInfoValue[curInfoValue]->Caption[7] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;

                case _100:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "100 Kb/s", 8);
                           CommsInfoValue[curInfoValue]->Caption[8] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;

                case _125:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "125 Kb/s", 8);
                           CommsInfoValue[curInfoValue]->Caption[8] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;

                case _250:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "250 Kb/s", 8);
                           CommsInfoValue[curInfoValue]->Caption[8] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;

                case _500:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "500 Kb/s", 8);
                           CommsInfoValue[curInfoValue]->Caption[8] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;

                case _1000:
                           strncpy(CommsInfoValue[curInfoValue]->Caption, "1000 Kb/s", 9);
                           CommsInfoValue[curInfoValue]->Caption[9] = 0x00;
                           TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                           break;
           }

        }
        
      if (curInfoValue == ModbusId)
      {
        sprintf(CommsInfoValue[curInfoValue]->Caption,"%04X", (unsigned int)scr_CanBaseIfonScreen.modBusId);
        CommsInfoValue[curInfoValue]->Caption[4] = 0x00;
        TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
      }
      
     if (curInfoValue == CanBaseId)
      {
        sprintf(CommsInfoValue[curInfoValue]->Caption,"%04X", (unsigned int) scr_CanBaseIfonScreen.canBaseId);
        CommsInfoValue[curInfoValue]->Caption[4] = 0x00;
        TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
      }

      if (curInfoValue == UnitMode)
      {
          switch(isSlave)
          {
           case Slave:

                      TFT_Set_Font(CommsInfoValue[curInfoValue]->FontName, CL_BLUE, FO_HORIZONTAL);
                      strncpy(CommsInfoValue[curInfoValue]->Caption, "SLAVE", 5);
                      CommsInfoValue[curInfoValue]->Caption[5] = 0x00;
                      TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                      break;

           case Master:

                       TFT_Set_Font(CommsInfoValue[curInfoValue]->FontName, CL_GREEN, FO_HORIZONTAL);
                       strncpy(CommsInfoValue[curInfoValue]->Caption, "MASTER", 6);
                       CommsInfoValue[curInfoValue]->Caption[6] = 0x00;
                       TFT_Write_Text(CommsInfoValue[curInfoValue]->Caption, CommsInfoValue[curInfoValue]->Left, CommsInfoValue[curInfoValue]->Top);
                       break;
           }
      }
     }
    }

  }
  

void GetCommsMainStruct(void)
{
  scr_CanBaseIfonScreen.modBusId = userConfig_R.commsConfig.modBusAddress;
  scr_CanBaseIfonScreen.canBaudRate= userConfig_R.commsConfig.canBaudRate;
  scr_CanBaseIfonScreen.canBaseId = userConfig_R.commsConfig.canBusID;
  scr_CanBaseIfonScreen.unitMode = userConfig_R.commsConfig.isSlave ;
  scr_CanBaseIfonScreen.modBusBaudRate = _9600;
}


//EVENT HANDLERS

void btn_CanBusInfoScreen_SettingsMenuOnClick() 
{
  Init_SettingsMenuScreen();
}

void btn_CanBusInfoScreen_RealTimeOnClick() 
{
  Init_RealTimeScreen(&scr_RealTimeScreen);
}