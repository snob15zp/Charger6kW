// ----------------------------------------------------------------------------
// Filename    : timer.c
// Created On  : 01/10/2012
// Last Modify : 27/11/2012
// Authors     : Adrian Edmonds, Carl Joyce & Pavle Krkeljas
// Company     : Australian Energy Research Laboratories (AERL)
// Website     : http://www.aerl.com.au
// Description : This file contains code to initialize, start and stop timers
//               1 and 2, as well as both Interrupt Service Routines (ISRs).
// ----------------------------------------------------------------------------
#include "timer.h"
#include "cmdlib.h"
#include "mbport.h"
// ----------------------------------------------------------------------------
sbit TFT_BLED_TMP at LATA9_bit;
int counter1 = 0;
int counter2 = 0;
int bkLightCounter = BACKLIGHT_TIMER_MAX;
// ----------------------------------------------------------------------------
void InitTimer1(unsigned long period)
{
   TMR1 = 0;                 // reset timer value to zero
   PR1 = period;             // Load period register

   T1IP0_bit = 1;            // set interrupt
   T1IP1_bit = 1;            // priority
   T1IP2_bit = 1;            // to 7

   TCKPS0_bit = 1;           // Set Timer Input Clock
   TCKPS1_bit = 1;           // Prescale value to 1:256
}
// ----------------------------------------------------------------------------
void StartTimer1(void)
{
   T1IE_bit = 1;             // Enable Timer1 Interrupt
   ON__T1CON_bit = 1;        // Enable Timer1
//   LATD10_bit = 0;
}
// ----------------------------------------------------------------------------
void StopTimer1(void)
{
   T1IE_bit = 0;             // Disable Timer1 Interrupt
   ON__T1CON_bit = 0;        // Disable Timer1
}
// ----------------------------------------------------------------------------
void Timer1_interrupt() iv IVT_TIMER_1 ilevel 7 ics ICS_SRS
{
   T1IF_bit = 0;             // Clear Timer1 Interrupt Flag
   counter1++;
//   LATD10_bit = 1;
   pxMBPortCBTimerExpired();     // Run ModBus callback routine
}
// ----------------------------------------------------------------------------
void InitTimer2(unsigned long period)
{
   TMR2 = 0;                 // reset timer value to zero
   PR2 = period;             // Load period register

   T2IP0_bit = 1;            // set interrupt
   T2IP1_bit = 1;            // priority
   T2IP2_bit = 1;            // to 7 (not 2)

   TCKPS0_T2CON_bit = 1;     // Set Timer Input Clock
   TCKPS1_T2CON_bit = 1;     // Prescale value to 1:256
}
// ----------------------------------------------------------------------------
void StartTimer2(void)
{
   T2IE_bit = 1;             // Enable Timer2 Interrupt
   ON__T2CON_bit = 1;        // Enable Timer2
}
// ----------------------------------------------------------------------------
void StopTimer2(void)
{
   T2IE_bit = 0;             // Disable Timer2 Interrupt
   ON__T2CON_bit = 0;        // Disable Timer2
}
// ----------------------------------------------------------------------------
void Timer2_interrupt() iv IVT_TIMER_2 ilevel 7 ics ICS_SRS
{
   T2IF_bit = 0;                 // Clear T2 Interrupt Flag
   counter2++;
   if ((counter2 % 16 == 0) || (bkLightCounter > 0))
   {
      TFT_BLED_TMP = 1; // Toggle LCD backlight
   }
   else
   {
      TFT_BLED_TMP = 0; // Toggle LCD backlight
   }
   
}
// ----------------------------------------------------------------------------
// End of File (timer.c)
// ----------------------------------------------------------------------------