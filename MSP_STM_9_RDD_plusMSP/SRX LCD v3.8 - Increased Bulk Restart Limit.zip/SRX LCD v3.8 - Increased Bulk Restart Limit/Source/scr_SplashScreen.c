#include "scr_SplashScreen.h"
#include "scr_RealTimeScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"


void SplashScreenTimeout(void)
{
 Delay_ms(2000);
 DrawScreen(&RealTimeScreen);
}