#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "built_in.h"


// TFT module connections
char TFT_DataPort at LATE;
sbit TFT_RST at LATC1_bit;
sbit TFT_BLED at LATD2_bit;
sbit TFT_RS at LATB15_bit;
sbit TFT_CS at LATF12_bit;
sbit TFT_RD at LATD5_bit;
sbit TFT_WR at LATD4_bit;
char TFT_DataPort_Direction at TRISE;
sbit TFT_RST_Direction at TRISC1_bit;
sbit TFT_BLED_Direction at TRISD2_bit;
sbit TFT_RS_Direction at TRISB15_bit;
sbit TFT_CS_Direction at TRISF12_bit;
sbit TFT_RD_Direction at TRISD5_bit;
sbit TFT_WR_Direction at TRISD4_bit;
// End TFT module connections

// Touch Panel module connections
sbit DRIVEX_LEFT at LATB13_bit;
sbit DRIVEX_RIGHT at LATB11_bit;
sbit DRIVEY_UP at LATB12_bit;
sbit DRIVEY_DOWN at LATB10_bit;
sbit DRIVEX_LEFT_DIRECTION at TRISB13_bit;
sbit DRIVEX_RIGHT_DIRECTION at TRISB11_bit;
sbit DRIVEY_UP_DIRECTION at TRISB12_bit;
sbit DRIVEY_DOWN_DIRECTION at TRISB10_bit;
// End Touch Panel module connections

// Global variables
unsigned int Xcoord, Ycoord;
const ADC_THRESHOLD = 900;
char PenDown;
typedef unsigned long TPointer;
TPointer PressedObject;
int PressedObjectType;
unsigned int caption_length, caption_height;
unsigned int display_width, display_height;

int _object_count;
unsigned short object_pressed;
TButton_Round *local_round_button;
TButton_Round *exec_round_button;
int round_button_order;
TLabel *local_label;
TLabel *exec_label;
int label_order;
TImage *local_image;
TImage *exec_image;
int image_order;
TBox_Round *local_round_box;
TBox_Round *exec_round_box;
int box_round_order;
TCBox_Round *local_round_cbox;
TCBox_Round *exec_round_cbox;
int cbox_round_order;
TCheckBox *local_checkBox;
TCheckBox *exec_checkBox;
int checkBox_order;
TRadioButton *local_radio_button;
TRadioButton *exec_radio_button;
int radio_button_order;

void PMPWaitBusy() {
  while(PMMODEbits.BUSY);
}

void Set_Index(unsigned short index) {
  TFT_RS = 0;
  PMDIN = index;
  PMPWaitBusy();
}

void Write_Command( unsigned short cmd ) {
  TFT_RS = 1;
  PMDIN = cmd;
  PMPWaitBusy();
}

void Write_Data(unsigned int _data) {
  TFT_RS = 1;
  PMDIN = _data;
  PMPWaitBusy();
}


void Init_ADC() {
  AD1PCFG = 0xFFFF;
  PCFG12_bit = 0;
  PCFG13_bit = 0;
  // PMP setup
  ADC1_Init();
}
static void InitializeTouchPanel() {
  Init_ADC();
  TFT_Set_Active(Set_Index, Write_Command, Write_Data);
  //TFT_Init(320, 240);  //OLD Displays
  TFT_Init_ILI9341_8bit(320, 240);  //NEW Displays

  TP_TFT_Init(320, 240, 13, 12);                                  // Initialize touch panel
  TP_TFT_Set_ADC_Threshold(ADC_THRESHOLD);                              // Set touch panel ADC threshold

  PenDown = 0;
  PressedObject = 0;
  PressedObjectType = -1;
}

void Calibrate() {
  TFT_Set_Pen(CL_WHITE, 3);
  TFT_Set_Font(TFT_defaultFont, CL_WHITE, FO_HORIZONTAL);
  TFT_Write_Text("Touch selected corners for calibration", 50, 100);
  TFT_Line(315, 1, 319, 1);
  TFT_Line(310, 10, 319, 1);
  TFT_Line(319, 5, 319, 1);
  TFT_Write_Text("first here", 250, 20);

  TP_TFT_Calibrate_Max();   //NEW Displays                   // Calibration of bottom left corner
  //TP_TFT_Calibrate_Min();     //OLD Displays                 // Calibration of bottom left corner
  Delay_ms(500);

  TFT_Set_Pen(CL_BLACK, 3);
  TFT_Set_Font(TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
  TFT_Line(315, 1, 319, 1);
  TFT_Line(310, 10, 319, 1);
  TFT_Line(319, 5, 319, 1);
  TFT_Write_Text("first here", 250, 20);

  TFT_Set_Pen(CL_WHITE, 3);
  TFT_Set_Font(TFT_defaultFont, CL_WHITE, FO_HORIZONTAL);
  TFT_Line(0, 239, 0, 235);
  TFT_Line(0, 239, 5, 239);
  TFT_Line(0, 239, 10, 229);
  TFT_Write_Text("now here ", 15, 200);

  TP_TFT_Calibrate_Min();   //NEW Displays                 // Calibration of bottom left corner
  ///TP_TFT_Calibrate_Max();   //OLD Displays                   // Calibration of bottom left corner
  Delay_ms(500);
}


/////////////////////////
  TScreen*  CurrentScreen;

  TScreen                RealTimeScreen;
  TBox_Round             boxRound_RealTimeScreen_BackgroundPanel;
  TBox_Round             boxRound_RealTimeScreenChrgAmps;
  TBox_Round             boxRound_RealTimeScreenChrgVolts;
  TBox_Round             boxRound_RealTimeScreenPvAmps;
  TBox_Round             boxRound_RealTimeScreenPvVolts;
  TLabel                 lbl_RealTimeScreenPvVolts_Name;
char lbl_RealTimeScreenPvVolts_Name_Caption[3] = "PV";

  TLabel                 Diagram2_Label2;
char Diagram2_Label2_Caption[1] = "";

  TLabel                 lbl_RealTimeScreenChrgVolts_Name;
char lbl_RealTimeScreenChrgVolts_Name_Caption[8] = "Battery";

  TLabel                 lbl_RealTimeScreenChrgAmps_Name;
char lbl_RealTimeScreenChrgAmps_Name_Caption[9] = "Amps Out";

  TLabel                 lbl_RealTimeScreenPvVolts_Value;
char lbl_RealTimeScreenPvVolts_Value_Caption[8] = "000.0";

  TLabel                 lbl_RealTimeScreenChrgVolts_Value;
char lbl_RealTimeScreenChrgVolts_Value_Caption[8] = "000.0";

  TLabel                 lbl_RealTimeScreenChrgAmps_Value;
char lbl_RealTimeScreenChrgAmps_Value_Caption[8] = "000.0";

  TButton_Round          btn_RealTimeScreen_Errors;
char btn_RealTimeScreen_Errors_Caption[7] = "Alarms";

  TButton_Round          btn_RealTimeScreen_Settings;
char btn_RealTimeScreen_Settings_Caption[7] = "Config";

  TButton_Round          btn_RealTimeScreen_OnOff;
char btn_RealTimeScreen_OnOff_Caption[7] = "ON/OFF";

  TButton_Round          btn_RealTimeScreen_Menu;
char btn_RealTimeScreen_Menu_Caption[5] = "Menu";

  TLabel                 lbl_RealTimeScreen_RtcTime;
char lbl_RealTimeScreen_RtcTime_Caption[7] = "000000";

  TLabel                 lbl_RealTimeScreen_Date;
char lbl_RealTimeScreen_Date_Caption[9] = "01/01/12";

  TLabel                 lbl_RealTimeScreenPvOcVolt_Name;
char lbl_RealTimeScreenPvOcVolt_Name_Caption[7] = "PV Voc";

  TLabel                 lbl_RealTimeScreenPvPower_Name;
char lbl_RealTimeScreenPvPower_Name_Caption[10] = "PV Power";

  TLabel                 lbl_RealTimeScreenDailyOc_Name;
char lbl_RealTimeScreenDailyOc_Name_Caption[8] = "Charge ";

  TLabel                 lbl_RealTimeScreenBatTemp_Name;
char lbl_RealTimeScreenBatTemp_Name_Caption[18] = "Temperature (B)";

  TLabel                 lbl_RealTimeScreenTotalOc_Value;
char lbl_RealTimeScreenTotalOc_Value_Caption[16] = "00000000 Ah    ";

  TLabel                 lbl_RealTimeScreenPvOcVolt_Value;
char lbl_RealTimeScreenPvOcVolt_Value_Caption[10] = "000.0 V";

  TLabel                 lbl_RealTimeScreenPvPower_Value;
char lbl_RealTimeScreenPvPower_Value_Caption[10] = "000.0 W";

  TLabel                 lbl_RealTimeScreenBatTemp_Value;
char lbl_RealTimeScreenBatTemp_Value_Caption[10] = "000.0 C";

  TLabel                 lbl_RealTimeScreenPvAmps_Name;
char lbl_RealTimeScreenPvAmps_Name_Caption[8] = "Amps In";

  TLabel                 lbl_RealTimeScreenPvAmps_Value;
char lbl_RealTimeScreenPvAmps_Value_Caption[8] = "000.0";

  TLabel                 Label1;
char Label1_Caption[1] = "";

  TLabel                 lbl_RealTimeScreen_FirmwareVersion;
char lbl_RealTimeScreen_FirmwareVersion_Caption[7] = "V0.000";

  TLabel                 lbl_RealTimeScreen_FltBlk;
char lbl_RealTimeScreen_FltBlk_Caption[10] = "_________";

  TLabel                 lbl_RealTimeScreen_HvMv;
char lbl_RealTimeScreen_HvMv_Caption[3] = "__";

  TLabel                 lbl_RealTimeScreenDailyOc_Value;
char lbl_RealTimeScreenDailyOc_Value_Caption[13] = "(0000.0)    ";

  TLine                  Line3;
  TLine                  Line4;
  TLine                  Line5;
  TLabel                 Label6;
char Label6_Caption[4] = "SRX";

  TLine                  Line9;
  TButton_Round          * const code Screen1_Buttons_Round[4]=
         {
         &btn_RealTimeScreen_Errors,
         &btn_RealTimeScreen_Settings,
         &btn_RealTimeScreen_OnOff,
         &btn_RealTimeScreen_Menu
         };
  TLabel                 * const code Screen1_Labels[25]=
         {
         &lbl_RealTimeScreenPvVolts_Name,
         &Diagram2_Label2,     
         &lbl_RealTimeScreenChrgVolts_Name,
         &lbl_RealTimeScreenChrgAmps_Name,
         &lbl_RealTimeScreenPvVolts_Value,
         &lbl_RealTimeScreenChrgVolts_Value,
         &lbl_RealTimeScreenChrgAmps_Value,
         &lbl_RealTimeScreen_RtcTime,
         &lbl_RealTimeScreen_Date,
         &lbl_RealTimeScreenPvOcVolt_Name,
         &lbl_RealTimeScreenPvPower_Name,
         &lbl_RealTimeScreenDailyOc_Name,
         &lbl_RealTimeScreenBatTemp_Name,
         &lbl_RealTimeScreenTotalOc_Value,
         &lbl_RealTimeScreenPvOcVolt_Value,
         &lbl_RealTimeScreenPvPower_Value,
         &lbl_RealTimeScreenBatTemp_Value,
         &lbl_RealTimeScreenPvAmps_Name,
         &lbl_RealTimeScreenPvAmps_Value,
         &Label1,              
         &lbl_RealTimeScreen_FirmwareVersion,
         &lbl_RealTimeScreen_FltBlk,
         &lbl_RealTimeScreen_HvMv,
         &lbl_RealTimeScreenDailyOc_Value,
         &Label6               
         };
  TBox_Round             * const code Screen1_Boxes_Round[5]=
         {
         &boxRound_RealTimeScreen_BackgroundPanel,
         &boxRound_RealTimeScreenChrgAmps,
         &boxRound_RealTimeScreenChrgVolts,
         &boxRound_RealTimeScreenPvAmps,
         &boxRound_RealTimeScreenPvVolts
         };
  TLine                  * const code Screen1_Lines[4]=
         {
         &Line3,               
         &Line4,               
         &Line5,               
         &Line9                
         };


  TScreen                MainMenuScreen;
  TButton_Round          btn_MainMenuScreen_Settings;
char btn_MainMenuScreen_Settings_Caption[9] = "Settings";

  TButton_Round          btn_MainMenuScreen_Information;
char btn_MainMenuScreen_Information_Caption[12] = "Information";

  TButton_Round          btn_MainMenuScreen_Errors;
char btn_MainMenuScreen_Errors_Caption[7] = "Alarms";

  TButton_Round          btn_MainMenuScreen_RealTimeScreen;
char btn_MainMenuScreen_RealTimeScreen_Caption[5] = "Back";

  TLabel                 lbl_MainMenuScreen_ScreenTitle;
char lbl_MainMenuScreen_ScreenTitle_Caption[10] = "MAIN MENU";

  TButton_Round          * const code Screen2_Buttons_Round[4]=
         {
         &btn_MainMenuScreen_Settings,
         &btn_MainMenuScreen_Information,
         &btn_MainMenuScreen_Errors,
         &btn_MainMenuScreen_RealTimeScreen
         };
  TLabel                 * const code Screen2_Labels[1]=
         {
         &lbl_MainMenuScreen_ScreenTitle
         };


  TScreen                SettingsMenuScreen;
  TButton_Round          btn_SettingsMenuScreen_Setpoints;
char btn_SettingsMenuScreen_Setpoints_Caption[11] = "Set Points";

  TButton_Round          btn_SettingsMenuScreen_TimeAndDate;
char btn_SettingsMenuScreen_TimeAndDate_Caption[12] = "Date & Time";

  TButton_Round          btn_SettingsMenuScreen_CanBusInfo;
char btn_SettingsMenuScreen_CanBusInfo_Caption[6] = "Comms";

  TLabel                 lbl_SettingsMenuScreen_ScreenTitle;
char lbl_SettingsMenuScreen_ScreenTitle_Caption[9] = "SETTINGS";

  TButton_Round          btn_SettingsMenuScreen_Menu;
char btn_SettingsMenuScreen_Menu_Caption[5] = "Back";

  TButton_Round          * const code Screen3_Buttons_Round[4]=
         {
         &btn_SettingsMenuScreen_Setpoints,
         &btn_SettingsMenuScreen_TimeAndDate,
         &btn_SettingsMenuScreen_CanBusInfo,
         &btn_SettingsMenuScreen_Menu
         };
  TLabel                 * const code Screen3_Labels[1]=
         {
         &lbl_SettingsMenuScreen_ScreenTitle
         };


  TScreen                SplashScreen;
  TImage               Diagram4_StartupImage;
  TImage                 * const code Screen4_Images[1]=
         {
         &Diagram4_StartupImage
         };


  TScreen                SetpointsScreen1;
  TBox_Round             boxRound_SetpointsScreen1_OcVoltSelectionBox;
  TBox_Round             boxRound_SetpointsScreen1_BatVoltSelectionBox;
  TButton_Round          btn_SetpointsScreen1_Edit;
char btn_SetpointsScreen1_Edit_Caption[5] = "Edit";

  TButton_Round          btn_SetpointsScreen1_Down;
char btn_SetpointsScreen1_Down_Caption[5] = "Down";

  TLabel                 lbl_SetpointsScreen1BatVolt_Name;
char lbl_SetpointsScreen1BatVolt_Name_Caption[17] = "Vnom [Battery]:";

  TButton_Round          btn_SetpointsScreen1_Next;
char btn_SetpointsScreen1_Next_Caption[5] = "Next";

  TLabel                 lbl_SetpointsScreen1_ScreenTitle;
char lbl_SetpointsScreen1_ScreenTitle_Caption[11] = "SET POINTS";

  TLabel                 lbl_SetpointsScreen1OcVolt_Name;
char lbl_SetpointsScreen1OcVolt_Name_Caption[17] = "Voc [Array]:";

  TLabel                 lbl_SetpointsScreen1BatVolt_Value;
char lbl_SetpointsScreen1BatVolt_Value_Caption[11] = "0.0";

  TLabel                 lbl_SetpointsScreen1OCVolt_Value;
char lbl_SetpointsScreen1OCVolt_Value_Caption[9] = "0.0";

  TLabel                 lbl_SetpointsScreen1_PageNumber;
char lbl_SetpointsScreen1_PageNumber_Caption[4] = "1/2";

  TButton_Round          btn_SetpointsScreen1_Up;
char btn_SetpointsScreen1_Up_Caption[3] = "Up";

  TBox_Round             boxRound_SetpointsScreen1_SelectionBoxMpVolt;
  TLabel                 lbl_SetpointsScreen1MpVolt_Name;
char lbl_SetpointsScreen1MpVolt_Name_Caption[17] = "Vmpp [Array]:";

  TLabel                 lbl_SetpointsScreen1MpVolt_Value;
char lbl_SetpointsScreen1MpVolt_Value_Caption[10] = "0.0";

  TBox_Round             boxRound_SetpointsScreen1_SelectionBoxTempComp;
  TLabel                 lbl_SetpointsScreen1TempComp_Name;
char lbl_SetpointsScreen1TempComp_Name_Caption[10] = "RTS Comp:";

  TLabel                 lbl_SetpointsScreen1TempComp_Value;
char lbl_SetpointsScreen1TempComp_Value_Caption[9] = "+0.0";

  TLabel                 lbl_SetpointsScreen1BatVolt_Desig;
char lbl_SetpointsScreen1BatVolt_Desig_Caption[3] = "V";

  TLabel                 lbl_SetpointsScreen1OCVolt_Desig;
char lbl_SetpointsScreen1OCVolt_Desig_Caption[3] = "V";

  TLabel                 lbl_SetpointsScreen1MpVolt_Desig;
char lbl_SetpointsScreen1MpVolt_Desig_Caption[3] = "V";

  TLabel                 lbl_SetpointsScreen1TempComp_Desig;
char lbl_SetpointsScreen1TempComp_Desig_Caption[5] = "mv/C";

  TButton_Round          * const code Screen5_Buttons_Round[4]=
         {
         &btn_SetpointsScreen1_Edit,
         &btn_SetpointsScreen1_Down,
         &btn_SetpointsScreen1_Next,
         &btn_SetpointsScreen1_Up
         };
  TLabel                 * const code Screen5_Labels[14]=
         {
         &lbl_SetpointsScreen1_ScreenTitle,
         &lbl_SetpointsScreen1BatVolt_Name,
         &lbl_SetpointsScreen1OcVolt_Name,
         &lbl_SetpointsScreen1BatVolt_Value,
         &lbl_SetpointsScreen1OCVolt_Value,
         &lbl_SetpointsScreen1_PageNumber,
         &lbl_SetpointsScreen1MpVolt_Name,
         &lbl_SetpointsScreen1MpVolt_Value,
         &lbl_SetpointsScreen1TempComp_Name,
         &lbl_SetpointsScreen1TempComp_Value,
         &lbl_SetpointsScreen1BatVolt_Desig,
         &lbl_SetpointsScreen1OCVolt_Desig,
         &lbl_SetpointsScreen1MpVolt_Desig,
         &lbl_SetpointsScreen1TempComp_Desig
         };
  TBox_Round             * const code Screen5_Boxes_Round[4]=
         {
         &boxRound_SetpointsScreen1_OcVoltSelectionBox,
         &boxRound_SetpointsScreen1_BatVoltSelectionBox,
         &boxRound_SetpointsScreen1_SelectionBoxMpVolt,
         &boxRound_SetpointsScreen1_SelectionBoxTempComp
         };


  TScreen                SetpointsScreen2;
  TBox_Round             boxRound_SetpointsScreen2_BulkResetVoltSelectionBox;
  TBox_Round             boxRound_SetpointsScreen2_FloatVoltSelectionBox;
  TBox_Round             boxRound_SetpointsScreen2_BulkVoltSelectionBox;
  TButton_Round          btn_SetpointsScreen2_Edit;
char btn_SetpointsScreen2_Edit_Caption[5] = "Edit";

  TButton_Round          btn_SetpointsScreen2_Down;
char btn_SetpointsScreen2_Down_Caption[5] = "Down";

  TButton_Round          btn_SetpointsScreen2_Apply;
char btn_SetpointsScreen2_Apply_Caption[6] = "Save";

  TLabel                 lbl_SetpointsScreen2BulkVolt_Name;
char lbl_SetpointsScreen2BulkVolt_Name_Caption[8] = "Absorb:";

  TButton_Round          btn_SetpointsScreen2_Back;
char btn_SetpointsScreen2_Back_Caption[7] = "Cancel";

  TLabel                 lbl_SetpointsScreen2_ScreenTitle;
char lbl_SetpointsScreen2_ScreenTitle_Caption[11] = "SET POINTS";

  TLabel                 lbl_SetpointsScreen2FloatVolt_Name;
char lbl_SetpointsScreen2FloatVolt_Name_Caption[7] = "Float:";

  TLabel                 lbl_SetpointsScreen2BulkResetVolt_Name;
char lbl_SetpointsScreen2BulkResetVolt_Name_Caption[8] = "ReBulk:";

  TLabel                 lbl_SetpointsScreen2BulkVolt_Value;
char lbl_SetpointsScreen2BulkVolt_Value_Caption[9] = "0.0";

  TLabel                 lbl_SetpointsScreen2BulkResetVolt_Value;
char lbl_SetpointsScreen2BulkResetVolt_Value_Caption[9] = "0.0";

  TLabel                 lbl_SetpointsScreen2_PageNumber;
char lbl_SetpointsScreen2_PageNumber_Caption[4] = "2/2";

  TButton_Round          btn_SetpointsScreen2_Up;
char btn_SetpointsScreen2_Up_Caption[3] = "Up";

  TBox_Round             boxRound_SetpointsScreen2_BulkTimeSelectionBox;
  TLabel                 lbl_SetpointsScreen2BulkTime_Name;
char lbl_SetpointsScreen2BulkTime_Name_Caption[13] = "Absorb Time:";

  TLabel                 lbl_SetpointsScreen2BulkTime_Value;
char lbl_SetpointsScreen2BulkTime_Value_Caption[9] = "0.0";

  TLabel                 lbl_SetpointsScreen2FloatVolt_Value;
char lbl_SetpointsScreen2FloatVolt_Value_Caption[9] = "0.0";

  TLabel                 lbl_SetpointsScreen2BulkVolt_Desig;
char lbl_SetpointsScreen2BulkVolt_Desig_Caption[3] = "V";

  TLabel                 lbl_SetpointsScreen2BulkTime_Desig;
char lbl_SetpointsScreen2BulkTime_Desig_Caption[3] = "M";

  TLabel                 lbl_SetpointsScreen2FloatVolt_Desig;
char lbl_SetpointsScreen2FloatVolt_Desig_Caption[3] = "V";

  TLabel                 lbl_SetpointsScreen2BulkResetVolt_Desig;
char lbl_SetpointsScreen2BulkResetVolt_Desig_Caption[5] = "V";

  TButton_Round          * const code Screen6_Buttons_Round[5]=
         {
         &btn_SetpointsScreen2_Edit,
         &btn_SetpointsScreen2_Down,
         &btn_SetpointsScreen2_Apply,
         &btn_SetpointsScreen2_Back,
         &btn_SetpointsScreen2_Up
         };
  TLabel                 * const code Screen6_Labels[14]=
         {
         &lbl_SetpointsScreen2BulkVolt_Name,
         &lbl_SetpointsScreen2_ScreenTitle,
         &lbl_SetpointsScreen2FloatVolt_Name,
         &lbl_SetpointsScreen2BulkResetVolt_Name,
         &lbl_SetpointsScreen2BulkVolt_Value,
         &lbl_SetpointsScreen2BulkResetVolt_Value,
         &lbl_SetpointsScreen2_PageNumber,
         &lbl_SetpointsScreen2BulkTime_Name,
         &lbl_SetpointsScreen2BulkTime_Value,
         &lbl_SetpointsScreen2FloatVolt_Value,
         &lbl_SetpointsScreen2BulkVolt_Desig,
         &lbl_SetpointsScreen2BulkTime_Desig,
         &lbl_SetpointsScreen2FloatVolt_Desig,
         &lbl_SetpointsScreen2BulkResetVolt_Desig
         };
  TBox_Round             * const code Screen6_Boxes_Round[4]=
         {
         &boxRound_SetpointsScreen2_BulkResetVoltSelectionBox,
         &boxRound_SetpointsScreen2_FloatVoltSelectionBox,
         &boxRound_SetpointsScreen2_BulkVoltSelectionBox,
         &boxRound_SetpointsScreen2_BulkTimeSelectionBox
         };


  TScreen                SetpointsEditScreen;
  TBox_Round             boxRound_SetpointsEditScreen_BackgroundPanel;
  TLabel                 lbl_SetpointsEditScreen_DigType;
char lbl_SetpointsEditScreen_DigType_Caption[6] = "00000";

  TLabel                 lbl_SetpointsEditScreen_Digit5;
char lbl_SetpointsEditScreen_Digit5_Caption[2] = "0";

  TLabel                 lbl_SetpointsEditScreen_Digit4;
char lbl_SetpointsEditScreen_Digit4_Caption[2] = "0";

  TLabel                 lbl_SetpointsEditScreen_Decimal;
char lbl_SetpointsEditScreen_Decimal_Caption[2] = ".";

  TLabel                 lbl_SetpointsEditScreen_Digit3;
char lbl_SetpointsEditScreen_Digit3_Caption[2] = "0";

  TLabel                 lbl_SetpointsEditScreen_Digit2;
char lbl_SetpointsEditScreen_Digit2_Caption[2] = "0";

  TLabel                 lbl_SetpointsEditScreen_Digit1;
char lbl_SetpointsEditScreen_Digit1_Caption[2] = "0";

  TButton_Round          btn_SetpointsEditScreen_Accept;
char btn_SetpointsEditScreen_Accept_Caption[6] = "Apply";

  TButton_Round          btn_SetpointsEditScreen_Down;
char btn_SetpointsEditScreen_Down_Caption[5] = "Down";

  TButton_Round          btn_SetpointsEditScreen_Next;
char btn_SetpointsEditScreen_Next_Caption[5] = "Next";

  TButton_Round          btn_SetpointsEditScreen_Cancel;
char btn_SetpointsEditScreen_Cancel_Caption[5] = "Back";

  TLabel                 lbl_SetpointsEditScreen_ScreenTitle;
char lbl_SetpointsEditScreen_ScreenTitle_Caption[19] = "Rebulk Voltage";

  TButton_Round          btn_SetpointsEditScreen_Up;
char btn_SetpointsEditScreen_Up_Caption[3] = "Up";

  TButton_Round          * const code Screen7_Buttons_Round[5]=
         {
         &btn_SetpointsEditScreen_Accept,
         &btn_SetpointsEditScreen_Down,
         &btn_SetpointsEditScreen_Next,
         &btn_SetpointsEditScreen_Cancel,
         &btn_SetpointsEditScreen_Up
         };
  TLabel                 * const code Screen7_Labels[8]=
         {
         &lbl_SetpointsEditScreen_DigType,
         &lbl_SetpointsEditScreen_Digit5,
         &lbl_SetpointsEditScreen_Digit4,
         &lbl_SetpointsEditScreen_Decimal,
         &lbl_SetpointsEditScreen_Digit3,
         &lbl_SetpointsEditScreen_Digit2,
         &lbl_SetpointsEditScreen_Digit1,
         &lbl_SetpointsEditScreen_ScreenTitle
         };
  TBox_Round             * const code Screen7_Boxes_Round[1]=
         {
         &boxRound_SetpointsEditScreen_BackgroundPanel
         };


  TScreen                TimeDateEditScreen;
  TLabel                 lbl_TimeDateEditScreen_ScreenTitle;
char lbl_TimeDateEditScreen_ScreenTitle_Caption[12] = "TIME / DATE";

  TButton_Round          btn_TimeDateEditScreen_TimeSelect;
char btn_TimeDateEditScreen_TimeSelect_Caption[5] = "Time";

  TButton_Round          btn_TimeDateEditScreen_DateSelect;
char btn_TimeDateEditScreen_DateSelect_Caption[5] = "Date";

  TLabel                 Diagram8_Label68;
char Diagram8_Label68_Caption[1] = "";

  TButton_Round          btn_TimedDateEditScreen_Back;
char btn_TimedDateEditScreen_Back_Caption[5] = "Back";

  TButton_Round          * const code Screen8_Buttons_Round[3]=
         {
         &btn_TimeDateEditScreen_TimeSelect,
         &btn_TimeDateEditScreen_DateSelect,
         &btn_TimedDateEditScreen_Back
         };
  TLabel                 * const code Screen8_Labels[2]=
         {
         &lbl_TimeDateEditScreen_ScreenTitle,
         &Diagram8_Label68     
         };


  TScreen                TimeEditScreen;
  TBox_Round             boxRound_TimeEditScreen_BackgroundPanel;
  TLabel                 lbl_TimeEditScreen_ScreenTitle;
char lbl_TimeEditScreen_ScreenTitle_Caption[9] = "SET TIME";

  TButton_Round          btn_TimedEditScreen_Accept;
char btn_TimedEditScreen_Accept_Caption[6] = "Apply";

  TButton_Round          btn_TimedEditScreen_Down;
char btn_TimedEditScreen_Down_Caption[5] = "Down";

  TButton_Round          btn_TimedEditScreen_Next;
char btn_TimedEditScreen_Next_Caption[5] = "Next";

  TButton_Round          btn_TimedEditScreen_Back;
char btn_TimedEditScreen_Back_Caption[5] = "Back";

  TButton_Round          btn_TimedEditScreen_Up;
char btn_TimedEditScreen_Up_Caption[3] = "Up";

  TLabel                 lbl_TimeEditScreen_Hours;
char lbl_TimeEditScreen_Hours_Caption[3] = "00";

  TLabel                 lbl_TimeEditScreen_Colon1;
char lbl_TimeEditScreen_Colon1_Caption[2] = ":";

  TLabel                 lbl_TimeEditScreen_Minutes;
char lbl_TimeEditScreen_Minutes_Caption[3] = "00";

  TLabel                 lbl_TimeEditScreen_Colon2;
char lbl_TimeEditScreen_Colon2_Caption[2] = ":";

  TLabel                 lbl_TimeEditScreen_Seconds;
char lbl_TimeEditScreen_Seconds_Caption[3] = "00";

  TButton_Round          * const code Screen9_Buttons_Round[5]=
         {
         &btn_TimedEditScreen_Accept,
         &btn_TimedEditScreen_Down,
         &btn_TimedEditScreen_Next,
         &btn_TimedEditScreen_Back,
         &btn_TimedEditScreen_Up
         };
  TLabel                 * const code Screen9_Labels[6]=
         {
         &lbl_TimeEditScreen_ScreenTitle,
         &lbl_TimeEditScreen_Hours,
         &lbl_TimeEditScreen_Colon1,
         &lbl_TimeEditScreen_Minutes,
         &lbl_TimeEditScreen_Colon2,
         &lbl_TimeEditScreen_Seconds
         };
  TBox_Round             * const code Screen9_Boxes_Round[1]=
         {
         &boxRound_TimeEditScreen_BackgroundPanel
         };


  TScreen                InformationScreen;
  TBox_Round             boxRound_InformationScreen_BackgroundPanel;
  TButton_Round          btn_InformationScreen_RealTime;
char btn_InformationScreen_RealTime_Caption[10] = "Real Time";

  TButton_Round          btn_InformationScreen_Menu;
char btn_InformationScreen_Menu_Caption[10] = "Back";

  TLabel                 lbl_InformationScreen_ScreenTitle;
char lbl_InformationScreen_ScreenTitle_Caption[12] = "DEVICE INFO";

  TLabel                 lbl_InformationScreenSerialNumber_Name;
char lbl_InformationScreenSerialNumber_Name_Caption[15] = "Serial Number:";

  TLabel                 lbl_InformationScreenProductModel_Name;
char lbl_InformationScreenProductModel_Name_Caption[15] = "Product Model:";

  TLabel                 lbl_InformationScreenHardwareVer_Name;
char lbl_InformationScreenHardwareVer_Name_Caption[18] = "Hardware Version:";

  TLabel                 lbl_InformationScreenSerialNumber_Value;
char lbl_InformationScreenSerialNumber_Value_Caption[9] = "00000000";

  TLabel                 lbl_InformationScreenProductModel_Value;
char lbl_InformationScreenProductModel_Value_Caption[9] = "00000000";

  TLabel                 lbl_InformationScreenHardwareVer_Value;
char lbl_InformationScreenHardwareVer_Value_Caption[9] = "00000000";

  TLabel                 lbl_InformationScreenFirmwareVer_Name;
char lbl_InformationScreenFirmwareVer_Name_Caption[18] = "Firmware Version:";

  TLabel                 lbl_InformationScreenFirmwareVer_Value;
char lbl_InformationScreenFirmwareVer_Value_Caption[9] = "00000000";

  TLabel                 lbl_InformationScreenNominalVolt_Name;
char lbl_InformationScreenNominalVolt_Name_Caption[17] = "Nominal Voltage:";

  TLabel                 lbl_InformationScreenNominalVolt_Value;
char lbl_InformationScreenNominalVolt_Value_Caption[9] = "00000000";

  TLabel                 lbl_InformationScreenStatusCodeA_Name;
char lbl_InformationScreenStatusCodeA_Name_Caption[15] = "Status Code A:";

  TLabel                 lbl_InformationScreenStatusCodeA_Value;
char lbl_InformationScreenStatusCodeA_Value_Caption[9] = "00000000";

  TLabel                 lbl_InformationScreenStatusCodeB_Name;
char lbl_InformationScreenStatusCodeB_Name_Caption[15] = "Status Code B:";

  TLabel                 lbl_InformationScreenStatusCodeB_Value;
char lbl_InformationScreenStatusCodeB_Value_Caption[9] = "00000000";

  TButton_Round          * const code Screen10_Buttons_Round[2]=
         {
         &btn_InformationScreen_RealTime,
         &btn_InformationScreen_Menu
         };
  TLabel                 * const code Screen10_Labels[15]=
         {
         &lbl_InformationScreen_ScreenTitle,
         &lbl_InformationScreenSerialNumber_Name,
         &lbl_InformationScreenProductModel_Name,
         &lbl_InformationScreenHardwareVer_Name,
         &lbl_InformationScreenSerialNumber_Value,
         &lbl_InformationScreenProductModel_Value,
         &lbl_InformationScreenHardwareVer_Value,
         &lbl_InformationScreenFirmwareVer_Name,
         &lbl_InformationScreenFirmwareVer_Value,
         &lbl_InformationScreenNominalVolt_Name,
         &lbl_InformationScreenNominalVolt_Value,
         &lbl_InformationScreenStatusCodeA_Name,
         &lbl_InformationScreenStatusCodeA_Value,
         &lbl_InformationScreenStatusCodeB_Name,
         &lbl_InformationScreenStatusCodeB_Value
         };
  TBox_Round             * const code Screen10_Boxes_Round[1]=
         {
         &boxRound_InformationScreen_BackgroundPanel
         };


  TScreen                CanBusInfoScreen;
  TBox_Round             boxRound_CanBusInfoScreen_BackgroundPanel;
  TLabel                 lbl_CanBusInfoScreen_ScreenTitle;
char lbl_CanBusInfoScreen_ScreenTitle_Caption[11] = "COMMS INFO";

  TLabel                 lbl_CanBusInfoScreenModbusId_Name;
char lbl_CanBusInfoScreenModbusId_Name_Caption[11] = "MODBUS ID:";

  TLabel                 lbl_CanBusInfoScreenModbusBaud_Name;
char lbl_CanBusInfoScreenModbusBaud_Name_Caption[12] = "MOD-B BAUD:";

  TLabel                 lbl_CanBusInfoScreenCanBaseId_Name;
char lbl_CanBusInfoScreenCanBaseId_Name_Caption[11] = "CANBUS ID:";

  TLabel                 lbl_CanBusInfoScreenModbusId_Value;
char lbl_CanBusInfoScreenModbusId_Value_Caption[8] = "0x6FOOO";

  TLabel                 lbl_CanBusInfoScreenModbusBaud_Value;
char lbl_CanBusInfoScreenModbusBaud_Value_Caption[10] = "1024 Kb/s";

  TLabel                 lbl_CanBusInfoScreenCanBaseId_Value;
char lbl_CanBusInfoScreenCanBaseId_Value_Caption[8] = "0x6FOOO";

  TLabel                 lbl_CanBusInfoScreenCanBaud_Name;
char lbl_CanBusInfoScreenCanBaud_Name_Caption[12] = "CAN-B BAUD:";

  TLabel                 lbl_CanBusInfoScreenCanBaud_Value;
char lbl_CanBusInfoScreenCanBaud_Value_Caption[10] = "1024 Kb/s";

  TLabel                 lbl_CanBusInfoScreenColumn5Empty_Name;
char lbl_CanBusInfoScreenColumn5Empty_Name_Caption[11] = "UNIT MODE:";

  TLabel                 lbl_CanBusInfoScreenColumnEmpty_Value;
char lbl_CanBusInfoScreenColumnEmpty_Value_Caption[7] = "MASTER";

  TButton_Round          btn_CanBusInfoScreen_RealTime;
char btn_CanBusInfoScreen_RealTime_Caption[10] = "Real Time";

  TButton_Round          btn_CanBusInfoScreen_SettingsMenu;
char btn_CanBusInfoScreen_SettingsMenu_Caption[9] = "Back";

  TLine                  Line8;
  TLine                  Line2;
  TLine                  Line6;
  TLine                  Line7;
  TButton_Round          * const code Screen11_Buttons_Round[2]=
         {
         &btn_CanBusInfoScreen_RealTime,
         &btn_CanBusInfoScreen_SettingsMenu
         };
  TLabel                 * const code Screen11_Labels[11]=
         {
         &lbl_CanBusInfoScreen_ScreenTitle,
         &lbl_CanBusInfoScreenModbusId_Name,
         &lbl_CanBusInfoScreenModbusBaud_Name,
         &lbl_CanBusInfoScreenCanBaseId_Name,
         &lbl_CanBusInfoScreenModbusId_Value,
         &lbl_CanBusInfoScreenModbusBaud_Value,
         &lbl_CanBusInfoScreenCanBaseId_Value,
         &lbl_CanBusInfoScreenCanBaud_Name,
         &lbl_CanBusInfoScreenCanBaud_Value,
         &lbl_CanBusInfoScreenColumn5Empty_Name,
         &lbl_CanBusInfoScreenColumnEmpty_Value
         };
  TBox_Round             * const code Screen11_Boxes_Round[1]=
         {
         &boxRound_CanBusInfoScreen_BackgroundPanel
         };
  TLine                  * const code Screen11_Lines[4]=
         {
         &Line8,               
         &Line2,               
         &Line6,               
         &Line7                
         };


  TScreen                DateEditScreen;
  TBox_Round             boxRound_DateEditScreen_BackgroundPanel;
  TLabel                 lbl_DateEditScreen_ScreenTitle;
char lbl_DateEditScreen_ScreenTitle_Caption[9] = "SET DATE";

  TButton_Round          btn_DatedEditScreen_Accept;
char btn_DatedEditScreen_Accept_Caption[6] = "Apply";

  TButton_Round          btn_DatedEditScreen_Down;
char btn_DatedEditScreen_Down_Caption[5] = "Down";

  TButton_Round          btn_DateEditScreen_Next;
char btn_DateEditScreen_Next_Caption[5] = "Next";

  TButton_Round          btn_DatedEditScreen_Back;
char btn_DatedEditScreen_Back_Caption[5] = "Back";

  TButton_Round          btn_DateEditScreen_Up;
char btn_DateEditScreen_Up_Caption[3] = "Up";

  TLabel                 lbl_DateEditScreen_Day;
char lbl_DateEditScreen_Day_Caption[3] = "01";

  TLabel                 lbl_DateEditScreen_ForwardSlash1;
char lbl_DateEditScreen_ForwardSlash1_Caption[2] = "/";

  TLabel                 lbl_DateEditScreen_Month;
char lbl_DateEditScreen_Month_Caption[3] = "01";

  TLabel                 lbl_DateEditScreen_ForwardSlash2;
char lbl_DateEditScreen_ForwardSlash2_Caption[2] = "/";

  TLabel                 lbl_DateEditScreen_Year;
char lbl_DateEditScreen_Year_Caption[3] = "18";

  TButton_Round          * const code Screen12_Buttons_Round[5]=
         {
         &btn_DatedEditScreen_Accept,
         &btn_DatedEditScreen_Down,
         &btn_DateEditScreen_Next,
         &btn_DatedEditScreen_Back,
         &btn_DateEditScreen_Up
         };
  TLabel                 * const code Screen12_Labels[6]=
         {
         &lbl_DateEditScreen_ScreenTitle,
         &lbl_DateEditScreen_Day,
         &lbl_DateEditScreen_ForwardSlash1,
         &lbl_DateEditScreen_Month,
         &lbl_DateEditScreen_ForwardSlash2,
         &lbl_DateEditScreen_Year
         };
  TBox_Round             * const code Screen12_Boxes_Round[1]=
         {
         &boxRound_DateEditScreen_BackgroundPanel
         };


  TScreen                ErrorScreen;
  TBox_Round             boxRound_ErrorScreen_BackgroundPanel2;
  TBox_Round             boxRound_ErrorScreen_BackgroundPanel1;
  TButton_Round          btn_ErrorScreen_ConfirmErrors;
char btn_ErrorScreen_ConfirmErrors_Caption[15] = "Confirm";

  TButton_Round          btn_ErrorScreen_Menu;
char btn_ErrorScreen_Menu_Caption[5] = "Back";

  TLabel                 lbl_ErrorScreen_ScreenTitle;
char lbl_ErrorScreen_ScreenTitle_Caption[7] = "ALARMS";

  TLabel                 lbl_ErrorScreen_Pos1;
char lbl_ErrorScreen_Pos1_Caption[15] = "00000000000000";

  TLabel                 lbl_ErrorScreen_Pos2;
char lbl_ErrorScreen_Pos2_Caption[15] = "00000000000000";

  TLabel                 lbl_ErrorScreen_Pos3;
char lbl_ErrorScreen_Pos3_Caption[15] = "00000000000000";

  TLabel                 lbl_ErrorScreen_Pos4;
char lbl_ErrorScreen_Pos4_Caption[15] = "00000000000000";

  TLabel                 lbl_ErrorScreen_Pos6;
char lbl_ErrorScreen_Pos6_Caption[15] = "00000000000000";

  TLabel                 lbl_ErrorScreen_Pos7;
char lbl_ErrorScreen_Pos7_Caption[15] = "00000000000000";

  TLabel                 lbl_ErrorScreen_Pos8;
char lbl_ErrorScreen_Pos8_Caption[15] = "00000000000000";

  TLabel                 lbl_ErrorScreen_Pos9;
char lbl_ErrorScreen_Pos9_Caption[15] = "00000000000000";

  TLabel                 lbl_ErrorScreen_Pos5;
char lbl_ErrorScreen_Pos5_Caption[15] = "00000000000000";

  TLabel                 lbl_ErrorScreen_Pos10;
char lbl_ErrorScreen_Pos10_Caption[15] = "00000000000000";

  TButton_Round          * const code Screen13_Buttons_Round[2]=
         {
         &btn_ErrorScreen_ConfirmErrors,
         &btn_ErrorScreen_Menu 
         };
  TLabel                 * const code Screen13_Labels[11]=
         {
         &lbl_ErrorScreen_ScreenTitle,
         &lbl_ErrorScreen_Pos1,
         &lbl_ErrorScreen_Pos2,
         &lbl_ErrorScreen_Pos3,
         &lbl_ErrorScreen_Pos4,
         &lbl_ErrorScreen_Pos6,
         &lbl_ErrorScreen_Pos7,
         &lbl_ErrorScreen_Pos8,
         &lbl_ErrorScreen_Pos9,
         &lbl_ErrorScreen_Pos5,
         &lbl_ErrorScreen_Pos10
         };
  TBox_Round             * const code Screen13_Boxes_Round[2]=
         {
         &boxRound_ErrorScreen_BackgroundPanel2,
         &boxRound_ErrorScreen_BackgroundPanel1
         };


  TScreen                BatterySettingsScreen;
  TBox_Round             BoxRound1;
  TButton_Round          ButtonRound1;
char ButtonRound1_Caption[7] = "Accept";

  TButton_Round          ButtonRound2;
char ButtonRound2_Caption[6] = "Lower";

  TButton_Round          ButtonRound3;
char ButtonRound3_Caption[5] = "Back";

  TButton_Round          ButtonRound4;
char ButtonRound4_Caption[7] = "Higher";

  TRadioButton                 RadioButton1;
char RadioButton1_Caption[25] = "Flooded Lead Acid  (FLA)";

  TRadioButton                 RadioButton2;
char RadioButton2_Caption[23] = "Sealed Lead Acid (SLA)";

  TRadioButton                 RadioButton3;
char RadioButton3_Caption[20] = "Litium Ion (Li-Ion)";

  TRadioButton                 RadioButton4;
char RadioButton4_Caption[25] = "Absorbed Glass Mat (AGM)";

  TBox_Round             BoxRound2;
  TLabel                 Label2;
char Label2_Caption[4] = "048";

  TLabel                 Label3;
char Label3_Caption[17] = "Nominal Battery ";

  TLabel                 Label4;
char Label4_Caption[8] = "Voltage";

  TLabel                 Label5;
char Label5_Caption[2] = "V";

  TButton_Round          * const code Screen14_Buttons_Round[4]=
         {
         &ButtonRound1,        
         &ButtonRound2,        
         &ButtonRound3,        
         &ButtonRound4         
         };
  TLabel                 * const code Screen14_Labels[4]=
         {
         &Label2,              
         &Label3,              
         &Label4,              
         &Label5               
         };
  TBox_Round             * const code Screen14_Boxes_Round[2]=
         {
         &BoxRound1,           
         &BoxRound2            
         };
  TRadioButton               * const code Screen14_RadioButtons[4]=
         {
         &RadioButton1,        
         &RadioButton2,        
         &RadioButton3,        
         &RadioButton4         
         };


  TScreen                PincodeScreen;
  TLabel                 lbl_PincodeScreen_Instruction;
char lbl_PincodeScreen_Instruction_Caption[15] = "ENTER PIN CODE";

  TButton_Round          btn_PincodeScreen_Delete;
char btn_PincodeScreen_Delete_Caption[7] = "Delete";

  TButton_Round          btn_PincodeScreen_Enter;
char btn_PincodeScreen_Enter_Caption[6] = "Enter";

  TButton_Round          btn_PincodeScreen_Num1;
char btn_PincodeScreen_Num1_Caption[2] = "1";

  TButton_Round          btn_PincodeScreen_Num4;
char btn_PincodeScreen_Num4_Caption[2] = "4";

  TButton_Round          btn_PincodeScreen_Num7;
char btn_PincodeScreen_Num7_Caption[2] = "7";

  TButton_Round          btn_PincodeScreen_Num0;
char btn_PincodeScreen_Num0_Caption[2] = "0";

  TButton_Round          btn_PincodeScreen_Num8;
char btn_PincodeScreen_Num8_Caption[2] = "8";

  TButton_Round          btn_PincodeScreen_Num5;
char btn_PincodeScreen_Num5_Caption[2] = "5";

  TButton_Round          btn_PincodeScreen_Num2;
char btn_PincodeScreen_Num2_Caption[2] = "2";

  TButton_Round          btn_PincodeScreen_Num3;
char btn_PincodeScreen_Num3_Caption[2] = "3";

  TButton_Round          btn_PincodeScreen_Num6;
char btn_PincodeScreen_Num6_Caption[2] = "6";

  TButton_Round          btn_PincodeScreen_Num9;
char btn_PincodeScreen_Num9_Caption[2] = "9";

  TLabel                 lbl_PincodeScreen_Dig1;
char lbl_PincodeScreen_Dig1_Caption[2] = "_";

  TLabel                 lbl_PincodeScreen_Dig2;
char lbl_PincodeScreen_Dig2_Caption[2] = "_";

  TLabel                 lbl_PincodeScreen_Dig3;
char lbl_PincodeScreen_Dig3_Caption[2] = "_";

  TLabel                 lbl_PincodeScreen_Dig4;
char lbl_PincodeScreen_Dig4_Caption[2] = "_";

  TButton_Round          * const code Screen15_Buttons_Round[12]=
         {
         &btn_PincodeScreen_Delete,
         &btn_PincodeScreen_Enter,
         &btn_PincodeScreen_Num1,
         &btn_PincodeScreen_Num4,
         &btn_PincodeScreen_Num7,
         &btn_PincodeScreen_Num0,
         &btn_PincodeScreen_Num8,
         &btn_PincodeScreen_Num5,
         &btn_PincodeScreen_Num2,
         &btn_PincodeScreen_Num3,
         &btn_PincodeScreen_Num6,
         &btn_PincodeScreen_Num9
         };
  TLabel                 * const code Screen15_Labels[5]=
         {
         &lbl_PincodeScreen_Instruction,
         &lbl_PincodeScreen_Dig1,
         &lbl_PincodeScreen_Dig2,
         &lbl_PincodeScreen_Dig3,
         &lbl_PincodeScreen_Dig4
         };


  TScreen                Notification_Screen;
  TButton_Round          btn_NotificationScreen_Return;
char btn_NotificationScreen_Return_Caption[7] = "Return";

  TBox_Round             boxRound_NotificationScreenPanel;
  TLabel                 lbl_NotificationScreen_InfoLabel;
char lbl_NotificationScreen_InfoLabel_Caption[33] = "Alarm notification message, here";

  TButton_Round          btn_NotificationScreen_Menu;
char btn_NotificationScreen_Menu_Caption[7] = "RETURN";

  TLabel                 lbl_NotificationScreen_Status;
char lbl_NotificationScreen_Status_Caption[16] = "COOLMAX  STATUS";

  TLabel                 lbl_NotificationScreen_WarningSetpoint;
char lbl_NotificationScreen_WarningSetpoint_Caption[20] = "STATUS POINTS NAMES";

  TLabel                 lbl_NotificationScreen_Warning;
char lbl_NotificationScreen_Warning_Caption[8] = "WARNING";

  TButton_Round          * const code Screen16_Buttons_Round[2]=
         {
         &btn_NotificationScreen_Return,
         &btn_NotificationScreen_Menu
         };
  TLabel                 * const code Screen16_Labels[4]=
         {
         &lbl_NotificationScreen_InfoLabel,
         &lbl_NotificationScreen_Status,
         &lbl_NotificationScreen_WarningSetpoint,
         &lbl_NotificationScreen_Warning
         };
  TBox_Round             * const code Screen16_Boxes_Round[1]=
         {
         &boxRound_NotificationScreenPanel
         };


  TScreen                OutputOnOffScreen;
  TCBox_Round             boxRound_OutputOnOffScreen_TopPanel = 
         {
         &OutputOnOffScreen    , //   boxRound_OutputOnOffScreen_TopPanel.OwnerScreen
         0                     , //   boxRound_OutputOnOffScreen_TopPanel.Order           
         2                     , //   boxRound_OutputOnOffScreen_TopPanel.Left           
         2                     , //   boxRound_OutputOnOffScreen_TopPanel.Top             
         316                   , //   boxRound_OutputOnOffScreen_TopPanel.Width           
         236                   , //   boxRound_OutputOnOffScreen_TopPanel.Height          
         1                     , //   boxRound_OutputOnOffScreen_TopPanel.Pen_Width       
         0x0000                , //   boxRound_OutputOnOffScreen_TopPanel.Pen_Color       
         1                     , //   boxRound_OutputOnOffScreen_TopPanel.Visible         
         0                     , //   boxRound_OutputOnOffScreen_TopPanel.Active          
         1                     , //   boxRound_OutputOnOffScreen_TopPanel.Transparent     
         1                     , //   boxRound_OutputOnOffScreen_TopPanel.Gradient        
         0                     , //   boxRound_OutputOnOffScreen_TopPanel.Gradient_Orientation    
         0xFFFF                , //   boxRound_OutputOnOffScreen_TopPanel.Gradient_Start_Color    
         0xFFFF                , //   boxRound_OutputOnOffScreen_TopPanel.Gradient_End_Color
         0xFFFF                , //   boxRound_OutputOnOffScreen_TopPanel.Color
         1                     , //   boxRound_OutputOnOffScreen_TopPanel.CornerRadius           
         1                     , //   boxRound_OutputOnOffScreen_TopPanel.PressColEnabled 
         0x8410                , //   boxRound_OutputOnOffScreen_TopPanel.Press_Color     
         0                     ,//  boxRound_OutputOnOffScreen_TopPanel.OnUpPtr
         0                     ,//  boxRound_OutputOnOffScreen_TopPanel.OnDownPtr
         0                     ,//  boxRound_OutputOnOffScreen_TopPanel.OnClickPtr
         0                      //  boxRound_OutputOnOffScreen_TopPanel.OnPressPtr
         };
  TLabel                 lbl_OutputOnOffScreen_ScreenTitle;
char lbl_OutputOnOffScreen_ScreenTitle_Caption[15] = "OUTPUT CONTROL";

  TLabel                 lbl_OutputOnOffScreen_OutputState;
char lbl_OutputOnOffScreen_OutputState_Caption[16] = "Output is now: ";

  TLine                  Line1;
  TButton_Round          btn_OutputOnOffScreen_Back;
char btn_OutputOnOffScreen_Back_Caption[5] = "Back";

  TButton_Round          btn_OutputOnOffScreen_EnableDisable;
char btn_OutputOnOffScreen_EnableDisable_Caption[15] = "Disable Output";

  TBox_Round             boxRound_OutputOnOffScreen_OnOffPanel;
  TLabel                 lbl_OutputOnOffScreen_OutputOnOff;
char lbl_OutputOnOffScreen_OutputOnOff_Caption[4] = "---";

  TCheckBox                 chk_OutputOnOffScreen_MidnightReset;
char chk_OutputOnOffScreen_MidnightReset_Caption[16] = " Midnight Reset";

  TButton_Round          * const code Screen17_Buttons_Round[2]=
         {
         &btn_OutputOnOffScreen_Back,
         &btn_OutputOnOffScreen_EnableDisable
         };
  TLabel                 * const code Screen17_Labels[3]=
         {
         &lbl_OutputOnOffScreen_ScreenTitle,
         &lbl_OutputOnOffScreen_OutputOnOff,
         &lbl_OutputOnOffScreen_OutputState
         };
  TBox_Round             * const code Screen17_Boxes_Round[1]=
         {
         &boxRound_OutputOnOffScreen_OnOffPanel
         };
  TCBox_Round             * const code Screen17_CBoxes_Round[1]=
         {
         &boxRound_OutputOnOffScreen_TopPanel
         };
  TLine                  * const code Screen17_Lines[1]=
         {
         &Line1                
         };
  TCheckBox               * const code Screen17_CheckBoxes[1]=
         {
         &chk_OutputOnOffScreen_MidnightReset
         };




static void InitializeObjects() {
  RealTimeScreen.Color                     = 0x0000;
  RealTimeScreen.Width                     = 320;
  RealTimeScreen.Height                    = 240;
  RealTimeScreen.Buttons_RoundCount        = 4;
  RealTimeScreen.Buttons_Round             = Screen1_Buttons_Round;
  RealTimeScreen.LabelsCount               = 25;
  RealTimeScreen.Labels                    = Screen1_Labels;
  RealTimeScreen.ImagesCount               = 0;
  RealTimeScreen.Boxes_RoundCount          = 5;
  RealTimeScreen.Boxes_Round               = Screen1_Boxes_Round;
  RealTimeScreen.CBoxes_RoundCount          = 0;
  RealTimeScreen.LinesCount                = 4;
  RealTimeScreen.Lines                     = Screen1_Lines;
  RealTimeScreen.CheckBoxesCount           = 0;
  RealTimeScreen.RadioButtonsCount           = 0;
  RealTimeScreen.ObjectsCount              = 38;

  MainMenuScreen.Color                     = 0x2124;
  MainMenuScreen.Width                     = 320;
  MainMenuScreen.Height                    = 240;
  MainMenuScreen.Buttons_RoundCount        = 4;
  MainMenuScreen.Buttons_Round             = Screen2_Buttons_Round;
  MainMenuScreen.LabelsCount               = 1;
  MainMenuScreen.Labels                    = Screen2_Labels;
  MainMenuScreen.ImagesCount               = 0;
  MainMenuScreen.Boxes_RoundCount          = 0;
  MainMenuScreen.CBoxes_RoundCount          = 0;
  MainMenuScreen.LinesCount                = 0;
  MainMenuScreen.CheckBoxesCount           = 0;
  MainMenuScreen.RadioButtonsCount           = 0;
  MainMenuScreen.ObjectsCount              = 5;

  SettingsMenuScreen.Color                     = 0x2124;
  SettingsMenuScreen.Width                     = 320;
  SettingsMenuScreen.Height                    = 240;
  SettingsMenuScreen.Buttons_RoundCount        = 4;
  SettingsMenuScreen.Buttons_Round             = Screen3_Buttons_Round;
  SettingsMenuScreen.LabelsCount               = 1;
  SettingsMenuScreen.Labels                    = Screen3_Labels;
  SettingsMenuScreen.ImagesCount               = 0;
  SettingsMenuScreen.Boxes_RoundCount          = 0;
  SettingsMenuScreen.CBoxes_RoundCount          = 0;
  SettingsMenuScreen.LinesCount                = 0;
  SettingsMenuScreen.CheckBoxesCount           = 0;
  SettingsMenuScreen.RadioButtonsCount           = 0;
  SettingsMenuScreen.ObjectsCount              = 5;

  SplashScreen.Color                     = 0x0000;
  SplashScreen.Width                     = 320;
  SplashScreen.Height                    = 240;
  SplashScreen.Buttons_RoundCount        = 0;
  SplashScreen.LabelsCount               = 0;
  SplashScreen.ImagesCount               = 1;
  SplashScreen.Images                    = Screen4_Images;
  SplashScreen.Boxes_RoundCount          = 0;
  SplashScreen.CBoxes_RoundCount          = 0;
  SplashScreen.LinesCount                = 0;
  SplashScreen.CheckBoxesCount           = 0;
  SplashScreen.RadioButtonsCount           = 0;
  SplashScreen.ObjectsCount              = 1;

  SetpointsScreen1.Color                     = 0x2124;
  SetpointsScreen1.Width                     = 320;
  SetpointsScreen1.Height                    = 240;
  SetpointsScreen1.Buttons_RoundCount        = 4;
  SetpointsScreen1.Buttons_Round             = Screen5_Buttons_Round;
  SetpointsScreen1.LabelsCount               = 14;
  SetpointsScreen1.Labels                    = Screen5_Labels;
  SetpointsScreen1.ImagesCount               = 0;
  SetpointsScreen1.Boxes_RoundCount          = 4;
  SetpointsScreen1.Boxes_Round               = Screen5_Boxes_Round;
  SetpointsScreen1.CBoxes_RoundCount          = 0;
  SetpointsScreen1.LinesCount                = 0;
  SetpointsScreen1.CheckBoxesCount           = 0;
  SetpointsScreen1.RadioButtonsCount           = 0;
  SetpointsScreen1.ObjectsCount              = 22;

  SetpointsScreen2.Color                     = 0x2124;
  SetpointsScreen2.Width                     = 320;
  SetpointsScreen2.Height                    = 240;
  SetpointsScreen2.Buttons_RoundCount        = 5;
  SetpointsScreen2.Buttons_Round             = Screen6_Buttons_Round;
  SetpointsScreen2.LabelsCount               = 14;
  SetpointsScreen2.Labels                    = Screen6_Labels;
  SetpointsScreen2.ImagesCount               = 0;
  SetpointsScreen2.Boxes_RoundCount          = 4;
  SetpointsScreen2.Boxes_Round               = Screen6_Boxes_Round;
  SetpointsScreen2.CBoxes_RoundCount          = 0;
  SetpointsScreen2.LinesCount                = 0;
  SetpointsScreen2.CheckBoxesCount           = 0;
  SetpointsScreen2.RadioButtonsCount           = 0;
  SetpointsScreen2.ObjectsCount              = 23;

  SetpointsEditScreen.Color                     = 0x2124;
  SetpointsEditScreen.Width                     = 320;
  SetpointsEditScreen.Height                    = 240;
  SetpointsEditScreen.Buttons_RoundCount        = 5;
  SetpointsEditScreen.Buttons_Round             = Screen7_Buttons_Round;
  SetpointsEditScreen.LabelsCount               = 8;
  SetpointsEditScreen.Labels                    = Screen7_Labels;
  SetpointsEditScreen.ImagesCount               = 0;
  SetpointsEditScreen.Boxes_RoundCount          = 1;
  SetpointsEditScreen.Boxes_Round               = Screen7_Boxes_Round;
  SetpointsEditScreen.CBoxes_RoundCount          = 0;
  SetpointsEditScreen.LinesCount                = 0;
  SetpointsEditScreen.CheckBoxesCount           = 0;
  SetpointsEditScreen.RadioButtonsCount           = 0;
  SetpointsEditScreen.ObjectsCount              = 14;

  TimeDateEditScreen.Color                     = 0x2124;
  TimeDateEditScreen.Width                     = 320;
  TimeDateEditScreen.Height                    = 240;
  TimeDateEditScreen.Buttons_RoundCount        = 3;
  TimeDateEditScreen.Buttons_Round             = Screen8_Buttons_Round;
  TimeDateEditScreen.LabelsCount               = 2;
  TimeDateEditScreen.Labels                    = Screen8_Labels;
  TimeDateEditScreen.ImagesCount               = 0;
  TimeDateEditScreen.Boxes_RoundCount          = 0;
  TimeDateEditScreen.CBoxes_RoundCount          = 0;
  TimeDateEditScreen.LinesCount                = 0;
  TimeDateEditScreen.CheckBoxesCount           = 0;
  TimeDateEditScreen.RadioButtonsCount           = 0;
  TimeDateEditScreen.ObjectsCount              = 5;

  TimeEditScreen.Color                     = 0x2124;
  TimeEditScreen.Width                     = 320;
  TimeEditScreen.Height                    = 240;
  TimeEditScreen.Buttons_RoundCount        = 5;
  TimeEditScreen.Buttons_Round             = Screen9_Buttons_Round;
  TimeEditScreen.LabelsCount               = 6;
  TimeEditScreen.Labels                    = Screen9_Labels;
  TimeEditScreen.ImagesCount               = 0;
  TimeEditScreen.Boxes_RoundCount          = 1;
  TimeEditScreen.Boxes_Round               = Screen9_Boxes_Round;
  TimeEditScreen.CBoxes_RoundCount          = 0;
  TimeEditScreen.LinesCount                = 0;
  TimeEditScreen.CheckBoxesCount           = 0;
  TimeEditScreen.RadioButtonsCount           = 0;
  TimeEditScreen.ObjectsCount              = 12;

  InformationScreen.Color                     = 0x2124;
  InformationScreen.Width                     = 320;
  InformationScreen.Height                    = 240;
  InformationScreen.Buttons_RoundCount        = 2;
  InformationScreen.Buttons_Round             = Screen10_Buttons_Round;
  InformationScreen.LabelsCount               = 15;
  InformationScreen.Labels                    = Screen10_Labels;
  InformationScreen.ImagesCount               = 0;
  InformationScreen.Boxes_RoundCount          = 1;
  InformationScreen.Boxes_Round               = Screen10_Boxes_Round;
  InformationScreen.CBoxes_RoundCount          = 0;
  InformationScreen.LinesCount                = 0;
  InformationScreen.CheckBoxesCount           = 0;
  InformationScreen.RadioButtonsCount           = 0;
  InformationScreen.ObjectsCount              = 18;

  CanBusInfoScreen.Color                     = 0x2124;
  CanBusInfoScreen.Width                     = 320;
  CanBusInfoScreen.Height                    = 240;
  CanBusInfoScreen.Buttons_RoundCount        = 2;
  CanBusInfoScreen.Buttons_Round             = Screen11_Buttons_Round;
  CanBusInfoScreen.LabelsCount               = 11;
  CanBusInfoScreen.Labels                    = Screen11_Labels;
  CanBusInfoScreen.ImagesCount               = 0;
  CanBusInfoScreen.Boxes_RoundCount          = 1;
  CanBusInfoScreen.Boxes_Round               = Screen11_Boxes_Round;
  CanBusInfoScreen.CBoxes_RoundCount          = 0;
  CanBusInfoScreen.LinesCount                = 4;
  CanBusInfoScreen.Lines                     = Screen11_Lines;
  CanBusInfoScreen.CheckBoxesCount           = 0;
  CanBusInfoScreen.RadioButtonsCount           = 0;
  CanBusInfoScreen.ObjectsCount              = 18;

  DateEditScreen.Color                     = 0x2124;
  DateEditScreen.Width                     = 320;
  DateEditScreen.Height                    = 240;
  DateEditScreen.Buttons_RoundCount        = 5;
  DateEditScreen.Buttons_Round             = Screen12_Buttons_Round;
  DateEditScreen.LabelsCount               = 6;
  DateEditScreen.Labels                    = Screen12_Labels;
  DateEditScreen.ImagesCount               = 0;
  DateEditScreen.Boxes_RoundCount          = 1;
  DateEditScreen.Boxes_Round               = Screen12_Boxes_Round;
  DateEditScreen.CBoxes_RoundCount          = 0;
  DateEditScreen.LinesCount                = 0;
  DateEditScreen.CheckBoxesCount           = 0;
  DateEditScreen.RadioButtonsCount           = 0;
  DateEditScreen.ObjectsCount              = 12;

  ErrorScreen.Color                     = 0x2124;
  ErrorScreen.Width                     = 320;
  ErrorScreen.Height                    = 240;
  ErrorScreen.Buttons_RoundCount        = 2;
  ErrorScreen.Buttons_Round             = Screen13_Buttons_Round;
  ErrorScreen.LabelsCount               = 11;
  ErrorScreen.Labels                    = Screen13_Labels;
  ErrorScreen.ImagesCount               = 0;
  ErrorScreen.Boxes_RoundCount          = 2;
  ErrorScreen.Boxes_Round               = Screen13_Boxes_Round;
  ErrorScreen.CBoxes_RoundCount          = 0;
  ErrorScreen.LinesCount                = 0;
  ErrorScreen.CheckBoxesCount           = 0;
  ErrorScreen.RadioButtonsCount           = 0;
  ErrorScreen.ObjectsCount              = 15;

  BatterySettingsScreen.Color                     = 0x0000;
  BatterySettingsScreen.Width                     = 320;
  BatterySettingsScreen.Height                    = 240;
  BatterySettingsScreen.Buttons_RoundCount        = 4;
  BatterySettingsScreen.Buttons_Round             = Screen14_Buttons_Round;
  BatterySettingsScreen.LabelsCount               = 4;
  BatterySettingsScreen.Labels                    = Screen14_Labels;
  BatterySettingsScreen.ImagesCount               = 0;
  BatterySettingsScreen.Boxes_RoundCount          = 2;
  BatterySettingsScreen.Boxes_Round               = Screen14_Boxes_Round;
  BatterySettingsScreen.CBoxes_RoundCount          = 0;
  BatterySettingsScreen.LinesCount                = 0;
  BatterySettingsScreen.CheckBoxesCount           = 0;
  BatterySettingsScreen.RadioButtonsCount           = 4;
  BatterySettingsScreen.RadioButtons                = Screen14_RadioButtons;
  BatterySettingsScreen.ObjectsCount              = 14;

  PincodeScreen.Color                     = 0x2124;
  PincodeScreen.Width                     = 320;
  PincodeScreen.Height                    = 240;
  PincodeScreen.Buttons_RoundCount        = 12;
  PincodeScreen.Buttons_Round             = Screen15_Buttons_Round;
  PincodeScreen.LabelsCount               = 5;
  PincodeScreen.Labels                    = Screen15_Labels;
  PincodeScreen.ImagesCount               = 0;
  PincodeScreen.Boxes_RoundCount          = 0;
  PincodeScreen.CBoxes_RoundCount          = 0;
  PincodeScreen.LinesCount                = 0;
  PincodeScreen.CheckBoxesCount           = 0;
  PincodeScreen.RadioButtonsCount           = 0;
  PincodeScreen.ObjectsCount              = 17;

  Notification_Screen.Color                     = 0x2124;
  Notification_Screen.Width                     = 320;
  Notification_Screen.Height                    = 240;
  Notification_Screen.Buttons_RoundCount        = 2;
  Notification_Screen.Buttons_Round             = Screen16_Buttons_Round;
  Notification_Screen.LabelsCount               = 4;
  Notification_Screen.Labels                    = Screen16_Labels;
  Notification_Screen.ImagesCount               = 0;
  Notification_Screen.Boxes_RoundCount          = 1;
  Notification_Screen.Boxes_Round               = Screen16_Boxes_Round;
  Notification_Screen.CBoxes_RoundCount          = 0;
  Notification_Screen.LinesCount                = 0;
  Notification_Screen.CheckBoxesCount           = 0;
  Notification_Screen.RadioButtonsCount           = 0;
  Notification_Screen.ObjectsCount              = 7;

  OutputOnOffScreen.Color                     = 0x2124;
  OutputOnOffScreen.Width                     = 320;
  OutputOnOffScreen.Height                    = 240;
  OutputOnOffScreen.Buttons_RoundCount        = 2;
  OutputOnOffScreen.Buttons_Round             = Screen17_Buttons_Round;
  OutputOnOffScreen.LabelsCount               = 3;
  OutputOnOffScreen.Labels                    = Screen17_Labels;
  OutputOnOffScreen.ImagesCount               = 0;
  OutputOnOffScreen.Boxes_RoundCount          = 1;
  OutputOnOffScreen.Boxes_Round               = Screen17_Boxes_Round;
  OutputOnOffScreen.CBoxes_RoundCount          = 1;
  OutputOnOffScreen.CBoxes_Round               = Screen17_CBoxes_Round;
  OutputOnOffScreen.LinesCount                = 1;
  OutputOnOffScreen.Lines                     = Screen17_Lines;
  OutputOnOffScreen.CheckBoxesCount           = 1;
  OutputOnOffScreen.CheckBoxes                = Screen17_CheckBoxes;
  OutputOnOffScreen.RadioButtonsCount           = 0;
  OutputOnOffScreen.ObjectsCount              = 9;


  boxRound_RealTimeScreen_BackgroundPanel.OwnerScreen     = &RealTimeScreen;
  boxRound_RealTimeScreen_BackgroundPanel.Order           = 0;
  boxRound_RealTimeScreen_BackgroundPanel.Left            = 2;
  boxRound_RealTimeScreen_BackgroundPanel.Top             = 117;
  boxRound_RealTimeScreen_BackgroundPanel.Width           = 316;
  boxRound_RealTimeScreen_BackgroundPanel.Height          = 79;
  boxRound_RealTimeScreen_BackgroundPanel.Pen_Width       = 0;
  boxRound_RealTimeScreen_BackgroundPanel.Pen_Color       = 0x0000;
  boxRound_RealTimeScreen_BackgroundPanel.Visible         = 1;
  boxRound_RealTimeScreen_BackgroundPanel.Active          = 0;
  boxRound_RealTimeScreen_BackgroundPanel.Transparent     = 1;
  boxRound_RealTimeScreen_BackgroundPanel.Gradient        = 0;
  boxRound_RealTimeScreen_BackgroundPanel.Gradient_Orientation    = 0;
  boxRound_RealTimeScreen_BackgroundPanel.Gradient_Start_Color    = 0xE73C;
  boxRound_RealTimeScreen_BackgroundPanel.Gradient_End_Color      = 0xE73C;
  boxRound_RealTimeScreen_BackgroundPanel.Color           = 0xFFFF;
  boxRound_RealTimeScreen_BackgroundPanel.PressColEnabled     = 1;
  boxRound_RealTimeScreen_BackgroundPanel.Press_Color     = 0x8410;
  boxRound_RealTimeScreen_BackgroundPanel.Corner_Radius      = 0;
  boxRound_RealTimeScreen_BackgroundPanel.OnUpPtr         = 0;
  boxRound_RealTimeScreen_BackgroundPanel.OnDownPtr       = 0;
  boxRound_RealTimeScreen_BackgroundPanel.OnClickPtr      = 0;
  boxRound_RealTimeScreen_BackgroundPanel.OnPressPtr      = 0;

  boxRound_RealTimeScreenChrgAmps.OwnerScreen     = &RealTimeScreen;
  boxRound_RealTimeScreenChrgAmps.Order           = 1;
  boxRound_RealTimeScreenChrgAmps.Left            = 161;
  boxRound_RealTimeScreenChrgAmps.Top             = 68;
  boxRound_RealTimeScreenChrgAmps.Width           = 157;
  boxRound_RealTimeScreenChrgAmps.Height          = 47;
  boxRound_RealTimeScreenChrgAmps.Pen_Width       = 0;
  boxRound_RealTimeScreenChrgAmps.Pen_Color       = 0x0000;
  boxRound_RealTimeScreenChrgAmps.Visible         = 1;
  boxRound_RealTimeScreenChrgAmps.Active          = 0;
  boxRound_RealTimeScreenChrgAmps.Transparent     = 1;
  boxRound_RealTimeScreenChrgAmps.Gradient        = 0;
  boxRound_RealTimeScreenChrgAmps.Gradient_Orientation    = 0;
  boxRound_RealTimeScreenChrgAmps.Gradient_Start_Color    = 0xE73C;
  boxRound_RealTimeScreenChrgAmps.Gradient_End_Color      = 0xE73C;
  boxRound_RealTimeScreenChrgAmps.Color           = 0xFFFF;
  boxRound_RealTimeScreenChrgAmps.PressColEnabled     = 1;
  boxRound_RealTimeScreenChrgAmps.Press_Color     = 0x8410;
  boxRound_RealTimeScreenChrgAmps.Corner_Radius      = 0;
  boxRound_RealTimeScreenChrgAmps.OnUpPtr         = 0;
  boxRound_RealTimeScreenChrgAmps.OnDownPtr       = 0;
  boxRound_RealTimeScreenChrgAmps.OnClickPtr      = 0;
  boxRound_RealTimeScreenChrgAmps.OnPressPtr      = 0;

  boxRound_RealTimeScreenChrgVolts.OwnerScreen     = &RealTimeScreen;
  boxRound_RealTimeScreenChrgVolts.Order           = 2;
  boxRound_RealTimeScreenChrgVolts.Left            = 2;
  boxRound_RealTimeScreenChrgVolts.Top             = 68;
  boxRound_RealTimeScreenChrgVolts.Width           = 157;
  boxRound_RealTimeScreenChrgVolts.Height          = 47;
  boxRound_RealTimeScreenChrgVolts.Pen_Width       = 0;
  boxRound_RealTimeScreenChrgVolts.Pen_Color       = 0x0000;
  boxRound_RealTimeScreenChrgVolts.Visible         = 1;
  boxRound_RealTimeScreenChrgVolts.Active          = 0;
  boxRound_RealTimeScreenChrgVolts.Transparent     = 1;
  boxRound_RealTimeScreenChrgVolts.Gradient        = 0;
  boxRound_RealTimeScreenChrgVolts.Gradient_Orientation    = 0;
  boxRound_RealTimeScreenChrgVolts.Gradient_Start_Color    = 0xE73C;
  boxRound_RealTimeScreenChrgVolts.Gradient_End_Color      = 0xE73C;
  boxRound_RealTimeScreenChrgVolts.Color           = 0xFFFF;
  boxRound_RealTimeScreenChrgVolts.PressColEnabled     = 1;
  boxRound_RealTimeScreenChrgVolts.Press_Color     = 0x8410;
  boxRound_RealTimeScreenChrgVolts.Corner_Radius      = 0;
  boxRound_RealTimeScreenChrgVolts.OnUpPtr         = 0;
  boxRound_RealTimeScreenChrgVolts.OnDownPtr       = 0;
  boxRound_RealTimeScreenChrgVolts.OnClickPtr      = 0;
  boxRound_RealTimeScreenChrgVolts.OnPressPtr      = 0;

  boxRound_RealTimeScreenPvAmps.OwnerScreen     = &RealTimeScreen;
  boxRound_RealTimeScreenPvAmps.Order           = 3;
  boxRound_RealTimeScreenPvAmps.Left            = 161;
  boxRound_RealTimeScreenPvAmps.Top             = 18;
  boxRound_RealTimeScreenPvAmps.Width           = 157;
  boxRound_RealTimeScreenPvAmps.Height          = 48;
  boxRound_RealTimeScreenPvAmps.Pen_Width       = 0;
  boxRound_RealTimeScreenPvAmps.Pen_Color       = 0x0000;
  boxRound_RealTimeScreenPvAmps.Visible         = 1;
  boxRound_RealTimeScreenPvAmps.Active          = 0;
  boxRound_RealTimeScreenPvAmps.Transparent     = 1;
  boxRound_RealTimeScreenPvAmps.Gradient        = 0;
  boxRound_RealTimeScreenPvAmps.Gradient_Orientation    = 0;
  boxRound_RealTimeScreenPvAmps.Gradient_Start_Color    = 0xE73C;
  boxRound_RealTimeScreenPvAmps.Gradient_End_Color      = 0xE73C;
  boxRound_RealTimeScreenPvAmps.Color           = 0xFFFF;
  boxRound_RealTimeScreenPvAmps.PressColEnabled     = 1;
  boxRound_RealTimeScreenPvAmps.Press_Color     = 0x8410;
  boxRound_RealTimeScreenPvAmps.Corner_Radius      = 0;
  boxRound_RealTimeScreenPvAmps.OnUpPtr         = 0;
  boxRound_RealTimeScreenPvAmps.OnDownPtr       = 0;
  boxRound_RealTimeScreenPvAmps.OnClickPtr      = 0;
  boxRound_RealTimeScreenPvAmps.OnPressPtr      = 0;

  boxRound_RealTimeScreenPvVolts.OwnerScreen     = &RealTimeScreen;
  boxRound_RealTimeScreenPvVolts.Order           = 4;
  boxRound_RealTimeScreenPvVolts.Left            = 2;
  boxRound_RealTimeScreenPvVolts.Top             = 18;
  boxRound_RealTimeScreenPvVolts.Width           = 157;
  boxRound_RealTimeScreenPvVolts.Height          = 48;
  boxRound_RealTimeScreenPvVolts.Pen_Width       = 0;
  boxRound_RealTimeScreenPvVolts.Pen_Color       = 0x0000;
  boxRound_RealTimeScreenPvVolts.Visible         = 1;
  boxRound_RealTimeScreenPvVolts.Active          = 0;
  boxRound_RealTimeScreenPvVolts.Transparent     = 1;
  boxRound_RealTimeScreenPvVolts.Gradient        = 0;
  boxRound_RealTimeScreenPvVolts.Gradient_Orientation    = 0;
  boxRound_RealTimeScreenPvVolts.Gradient_Start_Color    = 0xE73C;
  boxRound_RealTimeScreenPvVolts.Gradient_End_Color      = 0xE73C;
  boxRound_RealTimeScreenPvVolts.Color           = 0xFFFF;
  boxRound_RealTimeScreenPvVolts.PressColEnabled     = 1;
  boxRound_RealTimeScreenPvVolts.Press_Color     = 0x8410;
  boxRound_RealTimeScreenPvVolts.Corner_Radius      = 0;
  boxRound_RealTimeScreenPvVolts.OnUpPtr         = 0;
  boxRound_RealTimeScreenPvVolts.OnDownPtr       = 0;
  boxRound_RealTimeScreenPvVolts.OnClickPtr      = 0;
  boxRound_RealTimeScreenPvVolts.OnPressPtr      = 0;

  lbl_RealTimeScreenPvVolts_Name.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenPvVolts_Name.Order          = 5;
  lbl_RealTimeScreenPvVolts_Name.Left           = 8;
  lbl_RealTimeScreenPvVolts_Name.Top            = 21;
  lbl_RealTimeScreenPvVolts_Name.Width          = 18;
  lbl_RealTimeScreenPvVolts_Name.Height         = 16;
  lbl_RealTimeScreenPvVolts_Name.Visible        = 1;
  lbl_RealTimeScreenPvVolts_Name.Active         = 0;
  lbl_RealTimeScreenPvVolts_Name.Caption        = lbl_RealTimeScreenPvVolts_Name_Caption;
  lbl_RealTimeScreenPvVolts_Name.FontName       = Helvetica13x16_Regular;
  lbl_RealTimeScreenPvVolts_Name.Font_Color     = 0x2124;
  lbl_RealTimeScreenPvVolts_Name.OnUpPtr         = 0;
  lbl_RealTimeScreenPvVolts_Name.OnDownPtr       = 0;
  lbl_RealTimeScreenPvVolts_Name.OnClickPtr      = 0;
  lbl_RealTimeScreenPvVolts_Name.OnPressPtr      = 0;

  Diagram2_Label2.OwnerScreen     = &RealTimeScreen;
  Diagram2_Label2.Order          = 6;
  Diagram2_Label2.Left           = 200;
  Diagram2_Label2.Top            = 73;
  Diagram2_Label2.Width          = -6;
  Diagram2_Label2.Height         = 0;
  Diagram2_Label2.Visible        = 1;
  Diagram2_Label2.Active         = 1;
  Diagram2_Label2.Caption        = Diagram2_Label2_Caption;
  Diagram2_Label2.FontName       = Tahoma19x23_Regular;
  Diagram2_Label2.Font_Color     = 0x0000;
  Diagram2_Label2.OnUpPtr         = 0;
  Diagram2_Label2.OnDownPtr       = 0;
  Diagram2_Label2.OnClickPtr      = 0;
  Diagram2_Label2.OnPressPtr      = 0;

  lbl_RealTimeScreenChrgVolts_Name.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenChrgVolts_Name.Order          = 7;
  lbl_RealTimeScreenChrgVolts_Name.Left           = 166;
  lbl_RealTimeScreenChrgVolts_Name.Top            = 21;
  lbl_RealTimeScreenChrgVolts_Name.Width          = 42;
  lbl_RealTimeScreenChrgVolts_Name.Height         = 16;
  lbl_RealTimeScreenChrgVolts_Name.Visible        = 1;
  lbl_RealTimeScreenChrgVolts_Name.Active         = 0;
  lbl_RealTimeScreenChrgVolts_Name.Caption        = lbl_RealTimeScreenChrgVolts_Name_Caption;
  lbl_RealTimeScreenChrgVolts_Name.FontName       = Helvetica13x16_Regular;
  lbl_RealTimeScreenChrgVolts_Name.Font_Color     = 0x2124;
  lbl_RealTimeScreenChrgVolts_Name.OnUpPtr         = 0;
  lbl_RealTimeScreenChrgVolts_Name.OnDownPtr       = 0;
  lbl_RealTimeScreenChrgVolts_Name.OnClickPtr      = 0;
  lbl_RealTimeScreenChrgVolts_Name.OnPressPtr      = 0;

  lbl_RealTimeScreenChrgAmps_Name.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenChrgAmps_Name.Order          = 8;
  lbl_RealTimeScreenChrgAmps_Name.Left           = 166;
  lbl_RealTimeScreenChrgAmps_Name.Top            = 71;
  lbl_RealTimeScreenChrgAmps_Name.Width          = 60;
  lbl_RealTimeScreenChrgAmps_Name.Height         = 16;
  lbl_RealTimeScreenChrgAmps_Name.Visible        = 1;
  lbl_RealTimeScreenChrgAmps_Name.Active         = 0;
  lbl_RealTimeScreenChrgAmps_Name.Caption        = lbl_RealTimeScreenChrgAmps_Name_Caption;
  lbl_RealTimeScreenChrgAmps_Name.FontName       = Helvetica13x16_Regular;
  lbl_RealTimeScreenChrgAmps_Name.Font_Color     = 0x2124;
  lbl_RealTimeScreenChrgAmps_Name.OnUpPtr         = 0;
  lbl_RealTimeScreenChrgAmps_Name.OnDownPtr       = 0;
  lbl_RealTimeScreenChrgAmps_Name.OnClickPtr      = 0;
  lbl_RealTimeScreenChrgAmps_Name.OnPressPtr      = 0;

  lbl_RealTimeScreenPvVolts_Value.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenPvVolts_Value.Order          = 9;
  lbl_RealTimeScreenPvVolts_Value.Left           = 63;
  lbl_RealTimeScreenPvVolts_Value.Top            = 32;
  lbl_RealTimeScreenPvVolts_Value.Width          = 89;
  lbl_RealTimeScreenPvVolts_Value.Height         = 30;
  lbl_RealTimeScreenPvVolts_Value.Visible        = 1;
  lbl_RealTimeScreenPvVolts_Value.Active         = 0;
  lbl_RealTimeScreenPvVolts_Value.Caption        = lbl_RealTimeScreenPvVolts_Value_Caption;
  lbl_RealTimeScreenPvVolts_Value.FontName       = Helvetica24x27_Regular;
  lbl_RealTimeScreenPvVolts_Value.Font_Color     = 0x2124;
  lbl_RealTimeScreenPvVolts_Value.OnUpPtr         = 0;
  lbl_RealTimeScreenPvVolts_Value.OnDownPtr       = 0;
  lbl_RealTimeScreenPvVolts_Value.OnClickPtr      = 0;
  lbl_RealTimeScreenPvVolts_Value.OnPressPtr      = 0;

  lbl_RealTimeScreenChrgVolts_Value.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenChrgVolts_Value.Order          = 10;
  lbl_RealTimeScreenChrgVolts_Value.Left           = 220;
  lbl_RealTimeScreenChrgVolts_Value.Top            = 32;
  lbl_RealTimeScreenChrgVolts_Value.Width          = 89;
  lbl_RealTimeScreenChrgVolts_Value.Height         = 30;
  lbl_RealTimeScreenChrgVolts_Value.Visible        = 1;
  lbl_RealTimeScreenChrgVolts_Value.Active         = 0;
  lbl_RealTimeScreenChrgVolts_Value.Caption        = lbl_RealTimeScreenChrgVolts_Value_Caption;
  lbl_RealTimeScreenChrgVolts_Value.FontName       = Helvetica24x27_Regular;
  lbl_RealTimeScreenChrgVolts_Value.Font_Color     = 0x2124;
  lbl_RealTimeScreenChrgVolts_Value.OnUpPtr         = 0;
  lbl_RealTimeScreenChrgVolts_Value.OnDownPtr       = 0;
  lbl_RealTimeScreenChrgVolts_Value.OnClickPtr      = 0;
  lbl_RealTimeScreenChrgVolts_Value.OnPressPtr      = 0;

  lbl_RealTimeScreenChrgAmps_Value.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenChrgAmps_Value.Order          = 11;
  lbl_RealTimeScreenChrgAmps_Value.Left           = 220;
  lbl_RealTimeScreenChrgAmps_Value.Top            = 82;
  lbl_RealTimeScreenChrgAmps_Value.Width          = 89;
  lbl_RealTimeScreenChrgAmps_Value.Height         = 30;
  lbl_RealTimeScreenChrgAmps_Value.Visible        = 1;
  lbl_RealTimeScreenChrgAmps_Value.Active         = 0;
  lbl_RealTimeScreenChrgAmps_Value.Caption        = lbl_RealTimeScreenChrgAmps_Value_Caption;
  lbl_RealTimeScreenChrgAmps_Value.FontName       = Helvetica24x27_Regular;
  lbl_RealTimeScreenChrgAmps_Value.Font_Color     = 0x2124;
  lbl_RealTimeScreenChrgAmps_Value.OnUpPtr         = 0;
  lbl_RealTimeScreenChrgAmps_Value.OnDownPtr       = 0;
  lbl_RealTimeScreenChrgAmps_Value.OnClickPtr      = 0;
  lbl_RealTimeScreenChrgAmps_Value.OnPressPtr      = 0;

  btn_RealTimeScreen_Errors.OwnerScreen     = &RealTimeScreen;
  btn_RealTimeScreen_Errors.Order           = 12;
  btn_RealTimeScreen_Errors.Left            = 226;
  btn_RealTimeScreen_Errors.Top             = 198;
  btn_RealTimeScreen_Errors.Width           = 92;
  btn_RealTimeScreen_Errors.Height          = 40;
  btn_RealTimeScreen_Errors.Pen_Width       = 1;
  btn_RealTimeScreen_Errors.Pen_Color       = 0x0000;
  btn_RealTimeScreen_Errors.Visible         = 1;
  btn_RealTimeScreen_Errors.Active          = 1;
  btn_RealTimeScreen_Errors.Transparent     = 1;
  btn_RealTimeScreen_Errors.Caption         = btn_RealTimeScreen_Errors_Caption;
  btn_RealTimeScreen_Errors.TextAlign             = _taCenter;
  btn_RealTimeScreen_Errors.FontName        = Arial_Black16x23_Bold;
  btn_RealTimeScreen_Errors.PressColEnabled = 1;
  btn_RealTimeScreen_Errors.Font_Color      = 0x0000;
  btn_RealTimeScreen_Errors.Gradient        = 0;
  btn_RealTimeScreen_Errors.Gradient_Orientation    = 0;
  btn_RealTimeScreen_Errors.Gradient_Start_Color    = 0xFFFF;
  btn_RealTimeScreen_Errors.Gradient_End_Color      = 0xFFFF;
  btn_RealTimeScreen_Errors.Color           = 0xFFFF;
  btn_RealTimeScreen_Errors.Press_Color     = 0x8410;
  btn_RealTimeScreen_Errors.Corner_Radius      = 0;
  btn_RealTimeScreen_Errors.OnUpPtr         = 0;
  btn_RealTimeScreen_Errors.OnDownPtr       = 0;
  btn_RealTimeScreen_Errors.OnClickPtr      = btn_RealTimeScreen_ErrorsOnClick;
  btn_RealTimeScreen_Errors.OnPressPtr      = 0;

  btn_RealTimeScreen_Settings.OwnerScreen     = &RealTimeScreen;
  btn_RealTimeScreen_Settings.Order           = 13;
  btn_RealTimeScreen_Settings.Left            = 161;
  btn_RealTimeScreen_Settings.Top             = 195;
  btn_RealTimeScreen_Settings.Width           = 63;
  btn_RealTimeScreen_Settings.Height          = 47;
  btn_RealTimeScreen_Settings.Pen_Width       = 1;
  btn_RealTimeScreen_Settings.Pen_Color       = 0x0000;
  btn_RealTimeScreen_Settings.Visible         = 0;
  btn_RealTimeScreen_Settings.Active          = 1;
  btn_RealTimeScreen_Settings.Transparent     = 1;
  btn_RealTimeScreen_Settings.Caption         = btn_RealTimeScreen_Settings_Caption;
  btn_RealTimeScreen_Settings.TextAlign             = _taCenter;
  btn_RealTimeScreen_Settings.FontName        = Arial_Black16x23_Bold;
  btn_RealTimeScreen_Settings.PressColEnabled = 1;
  btn_RealTimeScreen_Settings.Font_Color      = 0x0000;
  btn_RealTimeScreen_Settings.Gradient        = 1;
  btn_RealTimeScreen_Settings.Gradient_Orientation    = 0;
  btn_RealTimeScreen_Settings.Gradient_Start_Color    = 0xE73C;
  btn_RealTimeScreen_Settings.Gradient_End_Color      = 0xE73C;
  btn_RealTimeScreen_Settings.Color           = 0xFFFF;
  btn_RealTimeScreen_Settings.Press_Color     = 0x8410;
  btn_RealTimeScreen_Settings.Corner_Radius      = 0;
  btn_RealTimeScreen_Settings.OnUpPtr         = 0;
  btn_RealTimeScreen_Settings.OnDownPtr       = 0;
  btn_RealTimeScreen_Settings.OnClickPtr      = btn_RealTimeScreen_SettingsOnClick;
  btn_RealTimeScreen_Settings.OnPressPtr      = 0;

  btn_RealTimeScreen_OnOff.OwnerScreen     = &RealTimeScreen;
  btn_RealTimeScreen_OnOff.Order           = 14;
  btn_RealTimeScreen_OnOff.Left            = 83;
  btn_RealTimeScreen_OnOff.Top             = 198;
  btn_RealTimeScreen_OnOff.Width           = 141;
  btn_RealTimeScreen_OnOff.Height          = 40;
  btn_RealTimeScreen_OnOff.Pen_Width       = 1;
  btn_RealTimeScreen_OnOff.Pen_Color       = 0x0000;
  btn_RealTimeScreen_OnOff.Visible         = 1;
  btn_RealTimeScreen_OnOff.Active          = 1;
  btn_RealTimeScreen_OnOff.Transparent     = 1;
  btn_RealTimeScreen_OnOff.Caption         = btn_RealTimeScreen_OnOff_Caption;
  btn_RealTimeScreen_OnOff.TextAlign             = _taCenter;
  btn_RealTimeScreen_OnOff.FontName        = Arial_Black16x23_Bold;
  btn_RealTimeScreen_OnOff.PressColEnabled = 1;
  btn_RealTimeScreen_OnOff.Font_Color      = 0x0000;
  btn_RealTimeScreen_OnOff.Gradient        = 0;
  btn_RealTimeScreen_OnOff.Gradient_Orientation    = 0;
  btn_RealTimeScreen_OnOff.Gradient_Start_Color    = 0xE73C;
  btn_RealTimeScreen_OnOff.Gradient_End_Color      = 0x0000;
  btn_RealTimeScreen_OnOff.Color           = 0xFFFF;
  btn_RealTimeScreen_OnOff.Press_Color     = 0x8410;
  btn_RealTimeScreen_OnOff.Corner_Radius      = 0;
  btn_RealTimeScreen_OnOff.OnUpPtr         = 0;
  btn_RealTimeScreen_OnOff.OnDownPtr       = 0;
  btn_RealTimeScreen_OnOff.OnClickPtr      = btn_RealTimeScreen_OnOffOnClick;
  btn_RealTimeScreen_OnOff.OnPressPtr      = 0;

  btn_RealTimeScreen_Menu.OwnerScreen     = &RealTimeScreen;
  btn_RealTimeScreen_Menu.Order           = 15;
  btn_RealTimeScreen_Menu.Left            = 2;
  btn_RealTimeScreen_Menu.Top             = 198;
  btn_RealTimeScreen_Menu.Width           = 79;
  btn_RealTimeScreen_Menu.Height          = 40;
  btn_RealTimeScreen_Menu.Pen_Width       = 1;
  btn_RealTimeScreen_Menu.Pen_Color       = 0x0000;
  btn_RealTimeScreen_Menu.Visible         = 1;
  btn_RealTimeScreen_Menu.Active          = 1;
  btn_RealTimeScreen_Menu.Transparent     = 1;
  btn_RealTimeScreen_Menu.Caption         = btn_RealTimeScreen_Menu_Caption;
  btn_RealTimeScreen_Menu.TextAlign             = _taCenter;
  btn_RealTimeScreen_Menu.FontName        = Arial_Black16x23_Bold;
  btn_RealTimeScreen_Menu.PressColEnabled = 1;
  btn_RealTimeScreen_Menu.Font_Color      = 0x0000;
  btn_RealTimeScreen_Menu.Gradient        = 0;
  btn_RealTimeScreen_Menu.Gradient_Orientation    = 0;
  btn_RealTimeScreen_Menu.Gradient_Start_Color    = 0xE73C;
  btn_RealTimeScreen_Menu.Gradient_End_Color      = 0x0000;
  btn_RealTimeScreen_Menu.Color           = 0xFFFF;
  btn_RealTimeScreen_Menu.Press_Color     = 0x8410;
  btn_RealTimeScreen_Menu.Corner_Radius      = 0;
  btn_RealTimeScreen_Menu.OnUpPtr         = 0;
  btn_RealTimeScreen_Menu.OnDownPtr       = 0;
  btn_RealTimeScreen_Menu.OnClickPtr      = btn_RealTimeScreen_MenuOnClick;
  btn_RealTimeScreen_Menu.OnPressPtr      = 0;

  lbl_RealTimeScreen_RtcTime.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreen_RtcTime.Order          = 16;
  lbl_RealTimeScreen_RtcTime.Left           = 289;
  lbl_RealTimeScreen_RtcTime.Top            = 2;
  lbl_RealTimeScreen_RtcTime.Width          = 38;
  lbl_RealTimeScreen_RtcTime.Height         = 14;
  lbl_RealTimeScreen_RtcTime.Visible        = 1;
  lbl_RealTimeScreen_RtcTime.Active         = 0;
  lbl_RealTimeScreen_RtcTime.Caption        = lbl_RealTimeScreen_RtcTime_Caption;
  lbl_RealTimeScreen_RtcTime.FontName       = Helvetica11x14_Bold;
  lbl_RealTimeScreen_RtcTime.Font_Color     = 0xFFFF;
  lbl_RealTimeScreen_RtcTime.OnUpPtr         = 0;
  lbl_RealTimeScreen_RtcTime.OnDownPtr       = 0;
  lbl_RealTimeScreen_RtcTime.OnClickPtr      = 0;
  lbl_RealTimeScreen_RtcTime.OnPressPtr      = 0;

  lbl_RealTimeScreen_Date.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreen_Date.Order          = 17;
  lbl_RealTimeScreen_Date.Left           = 4;
  lbl_RealTimeScreen_Date.Top            = 2;
  lbl_RealTimeScreen_Date.Width          = 44;
  lbl_RealTimeScreen_Date.Height         = 14;
  lbl_RealTimeScreen_Date.Visible        = 1;
  lbl_RealTimeScreen_Date.Active         = 0;
  lbl_RealTimeScreen_Date.Caption        = lbl_RealTimeScreen_Date_Caption;
  lbl_RealTimeScreen_Date.FontName       = Helvetica11x14_Bold;
  lbl_RealTimeScreen_Date.Font_Color     = 0xFFFF;
  lbl_RealTimeScreen_Date.OnUpPtr         = 0;
  lbl_RealTimeScreen_Date.OnDownPtr       = 0;
  lbl_RealTimeScreen_Date.OnClickPtr      = 0;
  lbl_RealTimeScreen_Date.OnPressPtr      = 0;

  lbl_RealTimeScreenPvOcVolt_Name.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenPvOcVolt_Name.Order          = 18;
  lbl_RealTimeScreenPvOcVolt_Name.Left           = 18;
  lbl_RealTimeScreenPvOcVolt_Name.Top            = 140;
  lbl_RealTimeScreenPvOcVolt_Name.Width          = 38;
  lbl_RealTimeScreenPvOcVolt_Name.Height         = 14;
  lbl_RealTimeScreenPvOcVolt_Name.Visible        = 1;
  lbl_RealTimeScreenPvOcVolt_Name.Active         = 0;
  lbl_RealTimeScreenPvOcVolt_Name.Caption        = lbl_RealTimeScreenPvOcVolt_Name_Caption;
  lbl_RealTimeScreenPvOcVolt_Name.FontName       = Helvetica11x14_Regular;
  lbl_RealTimeScreenPvOcVolt_Name.Font_Color     = 0x2124;
  lbl_RealTimeScreenPvOcVolt_Name.OnUpPtr         = 0;
  lbl_RealTimeScreenPvOcVolt_Name.OnDownPtr       = 0;
  lbl_RealTimeScreenPvOcVolt_Name.OnClickPtr      = 0;
  lbl_RealTimeScreenPvOcVolt_Name.OnPressPtr      = 0;

  lbl_RealTimeScreenPvPower_Name.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenPvPower_Name.Order          = 19;
  lbl_RealTimeScreenPvPower_Name.Left           = 18;
  lbl_RealTimeScreenPvPower_Name.Top            = 160;
  lbl_RealTimeScreenPvPower_Name.Width          = 54;
  lbl_RealTimeScreenPvPower_Name.Height         = 14;
  lbl_RealTimeScreenPvPower_Name.Visible        = 1;
  lbl_RealTimeScreenPvPower_Name.Active         = 0;
  lbl_RealTimeScreenPvPower_Name.Caption        = lbl_RealTimeScreenPvPower_Name_Caption;
  lbl_RealTimeScreenPvPower_Name.FontName       = Helvetica11x14_Regular;
  lbl_RealTimeScreenPvPower_Name.Font_Color     = 0x2124;
  lbl_RealTimeScreenPvPower_Name.OnUpPtr         = 0;
  lbl_RealTimeScreenPvPower_Name.OnDownPtr       = 0;
  lbl_RealTimeScreenPvPower_Name.OnClickPtr      = 0;
  lbl_RealTimeScreenPvPower_Name.OnPressPtr      = 0;

  lbl_RealTimeScreenDailyOc_Name.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenDailyOc_Name.Order          = 20;
  lbl_RealTimeScreenDailyOc_Name.Left           = 18;
  lbl_RealTimeScreenDailyOc_Name.Top            = 121;
  lbl_RealTimeScreenDailyOc_Name.Width          = 40;
  lbl_RealTimeScreenDailyOc_Name.Height         = 14;
  lbl_RealTimeScreenDailyOc_Name.Visible        = 1;
  lbl_RealTimeScreenDailyOc_Name.Active         = 0;
  lbl_RealTimeScreenDailyOc_Name.Caption        = lbl_RealTimeScreenDailyOc_Name_Caption;
  lbl_RealTimeScreenDailyOc_Name.FontName       = Helvetica11x14_Regular;
  lbl_RealTimeScreenDailyOc_Name.Font_Color     = 0x2124;
  lbl_RealTimeScreenDailyOc_Name.OnUpPtr         = 0;
  lbl_RealTimeScreenDailyOc_Name.OnDownPtr       = 0;
  lbl_RealTimeScreenDailyOc_Name.OnClickPtr      = 0;
  lbl_RealTimeScreenDailyOc_Name.OnPressPtr      = 0;

  lbl_RealTimeScreenBatTemp_Name.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenBatTemp_Name.Order          = 21;
  lbl_RealTimeScreenBatTemp_Name.Left           = 18;
  lbl_RealTimeScreenBatTemp_Name.Top            = 178;
  lbl_RealTimeScreenBatTemp_Name.Width          = 89;
  lbl_RealTimeScreenBatTemp_Name.Height         = 14;
  lbl_RealTimeScreenBatTemp_Name.Visible        = 1;
  lbl_RealTimeScreenBatTemp_Name.Active         = 0;
  lbl_RealTimeScreenBatTemp_Name.Caption        = lbl_RealTimeScreenBatTemp_Name_Caption;
  lbl_RealTimeScreenBatTemp_Name.FontName       = Helvetica11x14_Regular;
  lbl_RealTimeScreenBatTemp_Name.Font_Color     = 0x2124;
  lbl_RealTimeScreenBatTemp_Name.OnUpPtr         = 0;
  lbl_RealTimeScreenBatTemp_Name.OnDownPtr       = 0;
  lbl_RealTimeScreenBatTemp_Name.OnClickPtr      = 0;
  lbl_RealTimeScreenBatTemp_Name.OnPressPtr      = 0;

  lbl_RealTimeScreenTotalOc_Value.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenTotalOc_Value.Order          = 22;
  lbl_RealTimeScreenTotalOc_Value.Left           = 250;
  lbl_RealTimeScreenTotalOc_Value.Top            = 121;
  lbl_RealTimeScreenTotalOc_Value.Width          = 69;
  lbl_RealTimeScreenTotalOc_Value.Height         = 14;
  lbl_RealTimeScreenTotalOc_Value.Visible        = 1;
  lbl_RealTimeScreenTotalOc_Value.Active         = 0;
  lbl_RealTimeScreenTotalOc_Value.Caption        = lbl_RealTimeScreenTotalOc_Value_Caption;
  lbl_RealTimeScreenTotalOc_Value.FontName       = Helvetica11x14_Bold;
  lbl_RealTimeScreenTotalOc_Value.Font_Color     = 0x0000;
  lbl_RealTimeScreenTotalOc_Value.OnUpPtr         = 0;
  lbl_RealTimeScreenTotalOc_Value.OnDownPtr       = 0;
  lbl_RealTimeScreenTotalOc_Value.OnClickPtr      = 0;
  lbl_RealTimeScreenTotalOc_Value.OnPressPtr      = 0;

  lbl_RealTimeScreenPvOcVolt_Value.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenPvOcVolt_Value.Order          = 23;
  lbl_RealTimeScreenPvOcVolt_Value.Left           = 265;
  lbl_RealTimeScreenPvOcVolt_Value.Top            = 140;
  lbl_RealTimeScreenPvOcVolt_Value.Width          = 52;
  lbl_RealTimeScreenPvOcVolt_Value.Height         = 14;
  lbl_RealTimeScreenPvOcVolt_Value.Visible        = 1;
  lbl_RealTimeScreenPvOcVolt_Value.Active         = 0;
  lbl_RealTimeScreenPvOcVolt_Value.Caption        = lbl_RealTimeScreenPvOcVolt_Value_Caption;
  lbl_RealTimeScreenPvOcVolt_Value.FontName       = Helvetica11x14_Bold;
  lbl_RealTimeScreenPvOcVolt_Value.Font_Color     = 0x2124;
  lbl_RealTimeScreenPvOcVolt_Value.OnUpPtr         = 0;
  lbl_RealTimeScreenPvOcVolt_Value.OnDownPtr       = 0;
  lbl_RealTimeScreenPvOcVolt_Value.OnClickPtr      = 0;
  lbl_RealTimeScreenPvOcVolt_Value.OnPressPtr      = 0;

  lbl_RealTimeScreenPvPower_Value.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenPvPower_Value.Order          = 24;
  lbl_RealTimeScreenPvPower_Value.Left           = 260;
  lbl_RealTimeScreenPvPower_Value.Top            = 160;
  lbl_RealTimeScreenPvPower_Value.Width          = 55;
  lbl_RealTimeScreenPvPower_Value.Height         = 14;
  lbl_RealTimeScreenPvPower_Value.Visible        = 1;
  lbl_RealTimeScreenPvPower_Value.Active         = 0;
  lbl_RealTimeScreenPvPower_Value.Caption        = lbl_RealTimeScreenPvPower_Value_Caption;
  lbl_RealTimeScreenPvPower_Value.FontName       = Helvetica11x14_Bold;
  lbl_RealTimeScreenPvPower_Value.Font_Color     = 0x2124;
  lbl_RealTimeScreenPvPower_Value.OnUpPtr         = 0;
  lbl_RealTimeScreenPvPower_Value.OnDownPtr       = 0;
  lbl_RealTimeScreenPvPower_Value.OnClickPtr      = 0;
  lbl_RealTimeScreenPvPower_Value.OnPressPtr      = 0;

  lbl_RealTimeScreenBatTemp_Value.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenBatTemp_Value.Order          = 25;
  lbl_RealTimeScreenBatTemp_Value.Left           = 255;
  lbl_RealTimeScreenBatTemp_Value.Top            = 178;
  lbl_RealTimeScreenBatTemp_Value.Width          = 52;
  lbl_RealTimeScreenBatTemp_Value.Height         = 14;
  lbl_RealTimeScreenBatTemp_Value.Visible        = 1;
  lbl_RealTimeScreenBatTemp_Value.Active         = 0;
  lbl_RealTimeScreenBatTemp_Value.Caption        = lbl_RealTimeScreenBatTemp_Value_Caption;
  lbl_RealTimeScreenBatTemp_Value.FontName       = Helvetica11x14_Bold;
  lbl_RealTimeScreenBatTemp_Value.Font_Color     = 0x2124;
  lbl_RealTimeScreenBatTemp_Value.OnUpPtr         = 0;
  lbl_RealTimeScreenBatTemp_Value.OnDownPtr       = 0;
  lbl_RealTimeScreenBatTemp_Value.OnClickPtr      = 0;
  lbl_RealTimeScreenBatTemp_Value.OnPressPtr      = 0;

  lbl_RealTimeScreenPvAmps_Name.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenPvAmps_Name.Order          = 26;
  lbl_RealTimeScreenPvAmps_Name.Left           = 8;
  lbl_RealTimeScreenPvAmps_Name.Top            = 71;
  lbl_RealTimeScreenPvAmps_Name.Width          = 49;
  lbl_RealTimeScreenPvAmps_Name.Height         = 16;
  lbl_RealTimeScreenPvAmps_Name.Visible        = 1;
  lbl_RealTimeScreenPvAmps_Name.Active         = 0;
  lbl_RealTimeScreenPvAmps_Name.Caption        = lbl_RealTimeScreenPvAmps_Name_Caption;
  lbl_RealTimeScreenPvAmps_Name.FontName       = Helvetica13x16_Regular;
  lbl_RealTimeScreenPvAmps_Name.Font_Color     = 0x2124;
  lbl_RealTimeScreenPvAmps_Name.OnUpPtr         = 0;
  lbl_RealTimeScreenPvAmps_Name.OnDownPtr       = 0;
  lbl_RealTimeScreenPvAmps_Name.OnClickPtr      = 0;
  lbl_RealTimeScreenPvAmps_Name.OnPressPtr      = 0;

  lbl_RealTimeScreenPvAmps_Value.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenPvAmps_Value.Order          = 27;
  lbl_RealTimeScreenPvAmps_Value.Left           = 63;
  lbl_RealTimeScreenPvAmps_Value.Top            = 82;
  lbl_RealTimeScreenPvAmps_Value.Width          = 89;
  lbl_RealTimeScreenPvAmps_Value.Height         = 30;
  lbl_RealTimeScreenPvAmps_Value.Visible        = 1;
  lbl_RealTimeScreenPvAmps_Value.Active         = 0;
  lbl_RealTimeScreenPvAmps_Value.Caption        = lbl_RealTimeScreenPvAmps_Value_Caption;
  lbl_RealTimeScreenPvAmps_Value.FontName       = Helvetica24x27_Regular;
  lbl_RealTimeScreenPvAmps_Value.Font_Color     = 0x2124;
  lbl_RealTimeScreenPvAmps_Value.OnUpPtr         = 0;
  lbl_RealTimeScreenPvAmps_Value.OnDownPtr       = 0;
  lbl_RealTimeScreenPvAmps_Value.OnClickPtr      = 0;
  lbl_RealTimeScreenPvAmps_Value.OnPressPtr      = 0;

  Label1.OwnerScreen     = &RealTimeScreen;
  Label1.Order          = 28;
  Label1.Left           = 238;
  Label1.Top            = 120;
  Label1.Width          = -6;
  Label1.Height         = 0;
  Label1.Visible        = 1;
  Label1.Active         = 0;
  Label1.Caption        = Label1_Caption;
  Label1.FontName       = LCDMono10x17_Bold;
  Label1.Font_Color     = 0x0000;
  Label1.OnUpPtr         = 0;
  Label1.OnDownPtr       = 0;
  Label1.OnClickPtr      = 0;
  Label1.OnPressPtr      = 0;

  lbl_RealTimeScreen_FirmwareVersion.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreen_FirmwareVersion.Order          = 29;
  lbl_RealTimeScreen_FirmwareVersion.Left           = 113;
  lbl_RealTimeScreen_FirmwareVersion.Top            = 1;
  lbl_RealTimeScreen_FirmwareVersion.Width          = 43;
  lbl_RealTimeScreen_FirmwareVersion.Height         = 17;
  lbl_RealTimeScreen_FirmwareVersion.Visible        = 1;
  lbl_RealTimeScreen_FirmwareVersion.Active         = 0;
  lbl_RealTimeScreen_FirmwareVersion.Caption        = lbl_RealTimeScreen_FirmwareVersion_Caption;
  lbl_RealTimeScreen_FirmwareVersion.FontName       = Arial_Black11x15_Bold;
  lbl_RealTimeScreen_FirmwareVersion.Font_Color     = 0x2124;
  lbl_RealTimeScreen_FirmwareVersion.OnUpPtr         = 0;
  lbl_RealTimeScreen_FirmwareVersion.OnDownPtr       = 0;
  lbl_RealTimeScreen_FirmwareVersion.OnClickPtr      = 0;
  lbl_RealTimeScreen_FirmwareVersion.OnPressPtr      = 0;

  lbl_RealTimeScreen_FltBlk.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreen_FltBlk.Order          = 30;
  lbl_RealTimeScreen_FltBlk.Left           = 210;
  lbl_RealTimeScreen_FltBlk.Top            = 2;
  lbl_RealTimeScreen_FltBlk.Width          = 57;
  lbl_RealTimeScreen_FltBlk.Height         = 14;
  lbl_RealTimeScreen_FltBlk.Visible        = 1;
  lbl_RealTimeScreen_FltBlk.Active         = 0;
  lbl_RealTimeScreen_FltBlk.Caption        = lbl_RealTimeScreen_FltBlk_Caption;
  lbl_RealTimeScreen_FltBlk.FontName       = Helvetica11x14_Bold;
  lbl_RealTimeScreen_FltBlk.Font_Color     = 0xFFFF;
  
  
  lbl_RealTimeScreen_FltBlk.OnUpPtr         = 0;
  lbl_RealTimeScreen_FltBlk.OnDownPtr       = 0;
  lbl_RealTimeScreen_FltBlk.OnClickPtr      = 0;
  lbl_RealTimeScreen_FltBlk.OnPressPtr      = 0;

  lbl_RealTimeScreen_HvMv.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreen_HvMv.Order          = 31;
  lbl_RealTimeScreen_HvMv.Left           = 90;
  lbl_RealTimeScreen_HvMv.Top            = 2;
  lbl_RealTimeScreen_HvMv.Width          = 13;
  lbl_RealTimeScreen_HvMv.Height         = 14;
  lbl_RealTimeScreen_HvMv.Visible        = 1;
  lbl_RealTimeScreen_HvMv.Active         = 0;
  lbl_RealTimeScreen_HvMv.Caption        = lbl_RealTimeScreen_HvMv_Caption;
  lbl_RealTimeScreen_HvMv.FontName       = Helvetica11x14_Bold;
  lbl_RealTimeScreen_HvMv.Font_Color     = 0x0000;
  lbl_RealTimeScreen_HvMv.OnUpPtr         = 0;
  lbl_RealTimeScreen_HvMv.OnDownPtr       = 0;
  lbl_RealTimeScreen_HvMv.OnClickPtr      = 0;
  lbl_RealTimeScreen_HvMv.OnPressPtr      = 0;

  lbl_RealTimeScreenDailyOc_Value.OwnerScreen     = &RealTimeScreen;
  lbl_RealTimeScreenDailyOc_Value.Order          = 32;
  lbl_RealTimeScreenDailyOc_Value.Left           = 175;
  lbl_RealTimeScreenDailyOc_Value.Top            = 121;
  lbl_RealTimeScreenDailyOc_Value.Width          = 42;
  lbl_RealTimeScreenDailyOc_Value.Height         = 14;
  lbl_RealTimeScreenDailyOc_Value.Visible        = 1;
  lbl_RealTimeScreenDailyOc_Value.Active         = 0;
  lbl_RealTimeScreenDailyOc_Value.Caption        = lbl_RealTimeScreenDailyOc_Value_Caption;
  lbl_RealTimeScreenDailyOc_Value.FontName       = Helvetica11x14_Bold;
  lbl_RealTimeScreenDailyOc_Value.Font_Color     = 0x0000;
  lbl_RealTimeScreenDailyOc_Value.OnUpPtr         = 0;
  lbl_RealTimeScreenDailyOc_Value.OnDownPtr       = 0;
  lbl_RealTimeScreenDailyOc_Value.OnClickPtr      = 0;
  lbl_RealTimeScreenDailyOc_Value.OnPressPtr      = 0;

  Line3.OwnerScreen     = &RealTimeScreen;
  Line3.Order          = 33;
  Line3.First_Point_X  = 9;
  Line3.First_Point_Y  = 137;
  Line3.Second_Point_X = 309;
  Line3.Second_Point_Y = 137;
  Line3.Visible        = 1;
  Line3.Pen_Width      = 1;
  Line3.Color          = 0x0000;

  Line4.OwnerScreen     = &RealTimeScreen;
  Line4.Order          = 34;
  Line4.First_Point_X  = 9;
  Line4.First_Point_Y  = 156;
  Line4.Second_Point_X = 309;
  Line4.Second_Point_Y = 156;
  Line4.Visible        = 1;
  Line4.Pen_Width      = 1;
  Line4.Color          = 0x0000;

  Line5.OwnerScreen     = &RealTimeScreen;
  Line5.Order          = 35;
  Line5.First_Point_X  = 9;
  Line5.First_Point_Y  = 176;
  Line5.Second_Point_X = 309;
  Line5.Second_Point_Y = 176;
  Line5.Visible        = 1;
  Line5.Pen_Width      = 1;
  Line5.Color          = 0x0000;

  Label6.OwnerScreen     = &RealTimeScreen;
  Label6.Order          = 36;
  Label6.Left           = 149;
  Label6.Top            = 2;
  Label6.Width          = 23;
  Label6.Height         = 14;
  Label6.Visible        = 1;
  Label6.Active         = 1;
  Label6.Caption        = Label6_Caption;
  Label6.FontName       = Helvetica11x14_Bold;
  Label6.Font_Color     = 0xF567;
  Label6.OnUpPtr         = 0;
  Label6.OnDownPtr       = 0;
  Label6.OnClickPtr      = 0;
  Label6.OnPressPtr      = 0;

  Line9.OwnerScreen     = &RealTimeScreen;
  Line9.Order          = 37;
  Line9.First_Point_X  = 2;
  Line9.First_Point_Y  = 16;
  Line9.Second_Point_X = 316;
  Line9.Second_Point_Y = 16;
  Line9.Visible        = 1;
  Line9.Pen_Width      = 2;
  Line9.Color          = 0xFFFF;

  btn_MainMenuScreen_Settings.OwnerScreen     = &MainMenuScreen;
  btn_MainMenuScreen_Settings.Order           = 0;
  btn_MainMenuScreen_Settings.Left            = 60;
  btn_MainMenuScreen_Settings.Top             = 45;
  btn_MainMenuScreen_Settings.Width           = 200;
  btn_MainMenuScreen_Settings.Height          = 55;
  btn_MainMenuScreen_Settings.Pen_Width       = 1;
  btn_MainMenuScreen_Settings.Pen_Color       = 0x0000;
  btn_MainMenuScreen_Settings.Visible         = 1;
  btn_MainMenuScreen_Settings.Active          = 1;
  btn_MainMenuScreen_Settings.Transparent     = 1;
  btn_MainMenuScreen_Settings.Caption         = btn_MainMenuScreen_Settings_Caption;
  btn_MainMenuScreen_Settings.TextAlign             = _taCenter;
  btn_MainMenuScreen_Settings.FontName        = Helvetica16x19_Bold;
  btn_MainMenuScreen_Settings.PressColEnabled = 1;
  btn_MainMenuScreen_Settings.Font_Color      = 0x0000;
  btn_MainMenuScreen_Settings.Gradient        = 1;
  btn_MainMenuScreen_Settings.Gradient_Orientation    = 0;
  btn_MainMenuScreen_Settings.Gradient_Start_Color    = 0xFFFF;
  btn_MainMenuScreen_Settings.Gradient_End_Color      = 0xFFFF;
  btn_MainMenuScreen_Settings.Color           = 0xC618;
  btn_MainMenuScreen_Settings.Press_Color     = 0x8410;
  btn_MainMenuScreen_Settings.Corner_Radius      = 0;
  btn_MainMenuScreen_Settings.OnUpPtr         = 0;
  btn_MainMenuScreen_Settings.OnDownPtr       = 0;
  btn_MainMenuScreen_Settings.OnClickPtr      = btn_MainMenuScreen_SettingsOnClick;
  btn_MainMenuScreen_Settings.OnPressPtr      = 0;

  btn_MainMenuScreen_Information.OwnerScreen     = &MainMenuScreen;
  btn_MainMenuScreen_Information.Order           = 1;
  btn_MainMenuScreen_Information.Left            = 60;
  btn_MainMenuScreen_Information.Top             = 110;
  btn_MainMenuScreen_Information.Width           = 200;
  btn_MainMenuScreen_Information.Height          = 55;
  btn_MainMenuScreen_Information.Pen_Width       = 1;
  btn_MainMenuScreen_Information.Pen_Color       = 0x0000;
  btn_MainMenuScreen_Information.Visible         = 1;
  btn_MainMenuScreen_Information.Active          = 1;
  btn_MainMenuScreen_Information.Transparent     = 1;
  btn_MainMenuScreen_Information.Caption         = btn_MainMenuScreen_Information_Caption;
  btn_MainMenuScreen_Information.TextAlign             = _taCenter;
  btn_MainMenuScreen_Information.FontName        = Helvetica16x19_Bold;
  btn_MainMenuScreen_Information.PressColEnabled = 1;
  btn_MainMenuScreen_Information.Font_Color      = 0x0000;
  btn_MainMenuScreen_Information.Gradient        = 1;
  btn_MainMenuScreen_Information.Gradient_Orientation    = 0;
  btn_MainMenuScreen_Information.Gradient_Start_Color    = 0xFFFF;
  btn_MainMenuScreen_Information.Gradient_End_Color      = 0xFFFF;
  btn_MainMenuScreen_Information.Color           = 0xC618;
  btn_MainMenuScreen_Information.Press_Color     = 0x8410;
  btn_MainMenuScreen_Information.Corner_Radius      = 0;
  btn_MainMenuScreen_Information.OnUpPtr         = 0;
  btn_MainMenuScreen_Information.OnDownPtr       = 0;
  btn_MainMenuScreen_Information.OnClickPtr      = btn_MainMenuScreen_InformationOnClick;
  btn_MainMenuScreen_Information.OnPressPtr      = 0;

  btn_MainMenuScreen_Errors.OwnerScreen     = &MainMenuScreen;
  btn_MainMenuScreen_Errors.Order           = 2;
  btn_MainMenuScreen_Errors.Left            = 60;
  btn_MainMenuScreen_Errors.Top             = 175;
  btn_MainMenuScreen_Errors.Width           = 200;
  btn_MainMenuScreen_Errors.Height          = 55;
  btn_MainMenuScreen_Errors.Pen_Width       = 1;
  btn_MainMenuScreen_Errors.Pen_Color       = 0x0000;
  btn_MainMenuScreen_Errors.Visible         = 1;
  btn_MainMenuScreen_Errors.Active          = 1;
  btn_MainMenuScreen_Errors.Transparent     = 1;
  btn_MainMenuScreen_Errors.Caption         = btn_MainMenuScreen_Errors_Caption;
  btn_MainMenuScreen_Errors.TextAlign             = _taCenter;
  btn_MainMenuScreen_Errors.FontName        = Helvetica16x19_Bold;
  btn_MainMenuScreen_Errors.PressColEnabled = 1;
  btn_MainMenuScreen_Errors.Font_Color      = 0x0000;
  btn_MainMenuScreen_Errors.Gradient        = 1;
  btn_MainMenuScreen_Errors.Gradient_Orientation    = 0;
  btn_MainMenuScreen_Errors.Gradient_Start_Color    = 0xFFFF;
  btn_MainMenuScreen_Errors.Gradient_End_Color      = 0xFFFF;
  btn_MainMenuScreen_Errors.Color           = 0xC618;
  btn_MainMenuScreen_Errors.Press_Color     = 0x8410;
  btn_MainMenuScreen_Errors.Corner_Radius      = 0;
  btn_MainMenuScreen_Errors.OnUpPtr         = 0;
  btn_MainMenuScreen_Errors.OnDownPtr       = 0;
  btn_MainMenuScreen_Errors.OnClickPtr      = btn_MainMenuScreen_ErrorsOnClick;
  btn_MainMenuScreen_Errors.OnPressPtr      = 0;

  btn_MainMenuScreen_RealTimeScreen.OwnerScreen     = &MainMenuScreen;
  btn_MainMenuScreen_RealTimeScreen.Order           = 3;
  btn_MainMenuScreen_RealTimeScreen.Left            = 5;
  btn_MainMenuScreen_RealTimeScreen.Top             = 5;
  btn_MainMenuScreen_RealTimeScreen.Width           = 60;
  btn_MainMenuScreen_RealTimeScreen.Height          = 33;
  btn_MainMenuScreen_RealTimeScreen.Pen_Width       = 1;
  btn_MainMenuScreen_RealTimeScreen.Pen_Color       = 0x0000;
  btn_MainMenuScreen_RealTimeScreen.Visible         = 1;
  btn_MainMenuScreen_RealTimeScreen.Active          = 1;
  btn_MainMenuScreen_RealTimeScreen.Transparent     = 1;
  btn_MainMenuScreen_RealTimeScreen.Caption         = btn_MainMenuScreen_RealTimeScreen_Caption;
  btn_MainMenuScreen_RealTimeScreen.TextAlign             = _taCenter;
  btn_MainMenuScreen_RealTimeScreen.FontName        = Helvetica11x14_Bold;
  btn_MainMenuScreen_RealTimeScreen.PressColEnabled = 1;
  btn_MainMenuScreen_RealTimeScreen.Font_Color      = 0x0000;
  btn_MainMenuScreen_RealTimeScreen.Gradient        = 1;
  btn_MainMenuScreen_RealTimeScreen.Gradient_Orientation    = 0;
  btn_MainMenuScreen_RealTimeScreen.Gradient_Start_Color    = 0xFFFF;
  btn_MainMenuScreen_RealTimeScreen.Gradient_End_Color      = 0xFFFF;
  btn_MainMenuScreen_RealTimeScreen.Color           = 0xC618;
  btn_MainMenuScreen_RealTimeScreen.Press_Color     = 0x8410;
  btn_MainMenuScreen_RealTimeScreen.Corner_Radius      = 0;
  btn_MainMenuScreen_RealTimeScreen.OnUpPtr         = 0;
  btn_MainMenuScreen_RealTimeScreen.OnDownPtr       = 0;
  btn_MainMenuScreen_RealTimeScreen.OnClickPtr      = btn_MainMenuScreen_RealTimeScreenOnClick;
  btn_MainMenuScreen_RealTimeScreen.OnPressPtr      = 0;

  lbl_MainMenuScreen_ScreenTitle.OwnerScreen     = &MainMenuScreen;
  lbl_MainMenuScreen_ScreenTitle.Order          = 4;
  lbl_MainMenuScreen_ScreenTitle.Left           = 100;
  lbl_MainMenuScreen_ScreenTitle.Top            = 10;
  lbl_MainMenuScreen_ScreenTitle.Width          = 125;
  lbl_MainMenuScreen_ScreenTitle.Height         = 26;
  lbl_MainMenuScreen_ScreenTitle.Visible        = 1;
  lbl_MainMenuScreen_ScreenTitle.Active         = 0;
  lbl_MainMenuScreen_ScreenTitle.Caption        = lbl_MainMenuScreen_ScreenTitle_Caption;
  lbl_MainMenuScreen_ScreenTitle.FontName       = Helvetica21x24_Bold;
  lbl_MainMenuScreen_ScreenTitle.Font_Color     = 0xF79E;
  lbl_MainMenuScreen_ScreenTitle.OnUpPtr         = 0;
  lbl_MainMenuScreen_ScreenTitle.OnDownPtr       = 0;
  lbl_MainMenuScreen_ScreenTitle.OnClickPtr      = 0;
  lbl_MainMenuScreen_ScreenTitle.OnPressPtr      = 0;

  btn_SettingsMenuScreen_Setpoints.OwnerScreen     = &SettingsMenuScreen;
  btn_SettingsMenuScreen_Setpoints.Order           = 0;
  btn_SettingsMenuScreen_Setpoints.Left            = 60;
  btn_SettingsMenuScreen_Setpoints.Top             = 45;
  btn_SettingsMenuScreen_Setpoints.Width           = 200;
  btn_SettingsMenuScreen_Setpoints.Height          = 55;
  btn_SettingsMenuScreen_Setpoints.Pen_Width       = 1;
  btn_SettingsMenuScreen_Setpoints.Pen_Color       = 0x0000;
  btn_SettingsMenuScreen_Setpoints.Visible         = 1;
  btn_SettingsMenuScreen_Setpoints.Active          = 1;
  btn_SettingsMenuScreen_Setpoints.Transparent     = 1;
  btn_SettingsMenuScreen_Setpoints.Caption         = btn_SettingsMenuScreen_Setpoints_Caption;
  btn_SettingsMenuScreen_Setpoints.TextAlign             = _taCenter;
  btn_SettingsMenuScreen_Setpoints.FontName        = Helvetica16x19_Bold;
  btn_SettingsMenuScreen_Setpoints.PressColEnabled = 1;
  btn_SettingsMenuScreen_Setpoints.Font_Color      = 0x0000;
  btn_SettingsMenuScreen_Setpoints.Gradient        = 1;
  btn_SettingsMenuScreen_Setpoints.Gradient_Orientation    = 0;
  btn_SettingsMenuScreen_Setpoints.Gradient_Start_Color    = 0xFFFF;
  btn_SettingsMenuScreen_Setpoints.Gradient_End_Color      = 0xFFFF;
  btn_SettingsMenuScreen_Setpoints.Color           = 0xC618;
  btn_SettingsMenuScreen_Setpoints.Press_Color     = 0x8410;
  btn_SettingsMenuScreen_Setpoints.Corner_Radius      = 1;
  btn_SettingsMenuScreen_Setpoints.OnUpPtr         = 0;
  btn_SettingsMenuScreen_Setpoints.OnDownPtr       = 0;
  btn_SettingsMenuScreen_Setpoints.OnClickPtr      = btn_SettingsMenuScreen_SetpointsOnClick;
  btn_SettingsMenuScreen_Setpoints.OnPressPtr      = 0;

  btn_SettingsMenuScreen_TimeAndDate.OwnerScreen     = &SettingsMenuScreen;
  btn_SettingsMenuScreen_TimeAndDate.Order           = 1;
  btn_SettingsMenuScreen_TimeAndDate.Left            = 60;
  btn_SettingsMenuScreen_TimeAndDate.Top             = 110;
  btn_SettingsMenuScreen_TimeAndDate.Width           = 200;
  btn_SettingsMenuScreen_TimeAndDate.Height          = 55;
  btn_SettingsMenuScreen_TimeAndDate.Pen_Width       = 1;
  btn_SettingsMenuScreen_TimeAndDate.Pen_Color       = 0x0000;
  btn_SettingsMenuScreen_TimeAndDate.Visible         = 1;
  btn_SettingsMenuScreen_TimeAndDate.Active          = 1;
  btn_SettingsMenuScreen_TimeAndDate.Transparent     = 1;
  btn_SettingsMenuScreen_TimeAndDate.Caption         = btn_SettingsMenuScreen_TimeAndDate_Caption;
  btn_SettingsMenuScreen_TimeAndDate.TextAlign             = _taCenter;
  btn_SettingsMenuScreen_TimeAndDate.FontName        = Helvetica16x19_Bold;
  btn_SettingsMenuScreen_TimeAndDate.PressColEnabled = 1;
  btn_SettingsMenuScreen_TimeAndDate.Font_Color      = 0x0000;
  btn_SettingsMenuScreen_TimeAndDate.Gradient        = 1;
  btn_SettingsMenuScreen_TimeAndDate.Gradient_Orientation    = 0;
  btn_SettingsMenuScreen_TimeAndDate.Gradient_Start_Color    = 0xFFFF;
  btn_SettingsMenuScreen_TimeAndDate.Gradient_End_Color      = 0xFFFF;
  btn_SettingsMenuScreen_TimeAndDate.Color           = 0xC618;
  btn_SettingsMenuScreen_TimeAndDate.Press_Color     = 0x8410;
  btn_SettingsMenuScreen_TimeAndDate.Corner_Radius      = 1;
  btn_SettingsMenuScreen_TimeAndDate.OnUpPtr         = 0;
  btn_SettingsMenuScreen_TimeAndDate.OnDownPtr       = 0;
  btn_SettingsMenuScreen_TimeAndDate.OnClickPtr      = btn_SettingsMenuScreen_TimeAndDateOnClick;
  btn_SettingsMenuScreen_TimeAndDate.OnPressPtr      = 0;

  btn_SettingsMenuScreen_CanBusInfo.OwnerScreen     = &SettingsMenuScreen;
  btn_SettingsMenuScreen_CanBusInfo.Order           = 2;
  btn_SettingsMenuScreen_CanBusInfo.Left            = 59;
  btn_SettingsMenuScreen_CanBusInfo.Top             = 174;
  btn_SettingsMenuScreen_CanBusInfo.Width           = 200;
  btn_SettingsMenuScreen_CanBusInfo.Height          = 55;
  btn_SettingsMenuScreen_CanBusInfo.Pen_Width       = 1;
  btn_SettingsMenuScreen_CanBusInfo.Pen_Color       = 0x0000;
  btn_SettingsMenuScreen_CanBusInfo.Visible         = 1;
  btn_SettingsMenuScreen_CanBusInfo.Active          = 1;
  btn_SettingsMenuScreen_CanBusInfo.Transparent     = 1;
  btn_SettingsMenuScreen_CanBusInfo.Caption         = btn_SettingsMenuScreen_CanBusInfo_Caption;
  btn_SettingsMenuScreen_CanBusInfo.TextAlign             = _taCenter;
  btn_SettingsMenuScreen_CanBusInfo.FontName        = Helvetica16x19_Bold;
  btn_SettingsMenuScreen_CanBusInfo.PressColEnabled = 1;
  btn_SettingsMenuScreen_CanBusInfo.Font_Color      = 0x0000;
  btn_SettingsMenuScreen_CanBusInfo.Gradient        = 1;
  btn_SettingsMenuScreen_CanBusInfo.Gradient_Orientation    = 0;
  btn_SettingsMenuScreen_CanBusInfo.Gradient_Start_Color    = 0xFFFF;
  btn_SettingsMenuScreen_CanBusInfo.Gradient_End_Color      = 0xFFFF;
  btn_SettingsMenuScreen_CanBusInfo.Color           = 0xC618;
  btn_SettingsMenuScreen_CanBusInfo.Press_Color     = 0x8410;
  btn_SettingsMenuScreen_CanBusInfo.Corner_Radius      = 1;
  btn_SettingsMenuScreen_CanBusInfo.OnUpPtr         = 0;
  btn_SettingsMenuScreen_CanBusInfo.OnDownPtr       = 0;
  btn_SettingsMenuScreen_CanBusInfo.OnClickPtr      = btn_SettingsMenuScreen_CanBusInfoOnClick;
  btn_SettingsMenuScreen_CanBusInfo.OnPressPtr      = 0;

  lbl_SettingsMenuScreen_ScreenTitle.OwnerScreen     = &SettingsMenuScreen;
  lbl_SettingsMenuScreen_ScreenTitle.Order          = 3;
  lbl_SettingsMenuScreen_ScreenTitle.Left           = 106;
  lbl_SettingsMenuScreen_ScreenTitle.Top            = 10;
  lbl_SettingsMenuScreen_ScreenTitle.Width          = 108;
  lbl_SettingsMenuScreen_ScreenTitle.Height         = 26;
  lbl_SettingsMenuScreen_ScreenTitle.Visible        = 1;
  lbl_SettingsMenuScreen_ScreenTitle.Active         = 0;
  lbl_SettingsMenuScreen_ScreenTitle.Caption        = lbl_SettingsMenuScreen_ScreenTitle_Caption;
  lbl_SettingsMenuScreen_ScreenTitle.FontName       = Helvetica21x24_Bold;
  lbl_SettingsMenuScreen_ScreenTitle.Font_Color     = 0xF79E;
  lbl_SettingsMenuScreen_ScreenTitle.OnUpPtr         = 0;
  lbl_SettingsMenuScreen_ScreenTitle.OnDownPtr       = 0;
  lbl_SettingsMenuScreen_ScreenTitle.OnClickPtr      = 0;
  lbl_SettingsMenuScreen_ScreenTitle.OnPressPtr      = 0;

  btn_SettingsMenuScreen_Menu.OwnerScreen     = &SettingsMenuScreen;
  btn_SettingsMenuScreen_Menu.Order           = 4;
  btn_SettingsMenuScreen_Menu.Left            = 5;
  btn_SettingsMenuScreen_Menu.Top             = 5;
  btn_SettingsMenuScreen_Menu.Width           = 60;
  btn_SettingsMenuScreen_Menu.Height          = 33;
  btn_SettingsMenuScreen_Menu.Pen_Width       = 1;
  btn_SettingsMenuScreen_Menu.Pen_Color       = 0x0000;
  btn_SettingsMenuScreen_Menu.Visible         = 1;
  btn_SettingsMenuScreen_Menu.Active          = 1;
  btn_SettingsMenuScreen_Menu.Transparent     = 1;
  btn_SettingsMenuScreen_Menu.Caption         = btn_SettingsMenuScreen_Menu_Caption;
  btn_SettingsMenuScreen_Menu.TextAlign             = _taCenter;
  btn_SettingsMenuScreen_Menu.FontName        = Helvetica11x14_Bold;
  btn_SettingsMenuScreen_Menu.PressColEnabled = 1;
  btn_SettingsMenuScreen_Menu.Font_Color      = 0x0000;
  btn_SettingsMenuScreen_Menu.Gradient        = 1;
  btn_SettingsMenuScreen_Menu.Gradient_Orientation    = 0;
  btn_SettingsMenuScreen_Menu.Gradient_Start_Color    = 0xFFFF;
  btn_SettingsMenuScreen_Menu.Gradient_End_Color      = 0xFFFF;
  btn_SettingsMenuScreen_Menu.Color           = 0xC618;
  btn_SettingsMenuScreen_Menu.Press_Color     = 0x8410;
  btn_SettingsMenuScreen_Menu.Corner_Radius      = 1;
  btn_SettingsMenuScreen_Menu.OnUpPtr         = 0;
  btn_SettingsMenuScreen_Menu.OnDownPtr       = 0;
  btn_SettingsMenuScreen_Menu.OnClickPtr      = btn_SettingsMenuScreen_MenuOnClick;
  btn_SettingsMenuScreen_Menu.OnPressPtr      = 0;

  Diagram4_StartupImage.OwnerScreen     = &SplashScreen;
  Diagram4_StartupImage.Order          = 0;
  Diagram4_StartupImage.Left           = 0;
  Diagram4_StartupImage.Top            = 0;
  Diagram4_StartupImage.Width          = 320;
  Diagram4_StartupImage.Height         = 239;
  Diagram4_StartupImage.Picture_Type        = 1;
  Diagram4_StartupImage.Picture_Ratio  = 1;
  Diagram4_StartupImage.Picture_Name   = SplashScreen_jpg;
  Diagram4_StartupImage.Visible        = 1;
  Diagram4_StartupImage.Active         = 0;
  Diagram4_StartupImage.OnUpPtr         = 0;
  Diagram4_StartupImage.OnDownPtr       = 0;
  Diagram4_StartupImage.OnClickPtr      = 0;
  Diagram4_StartupImage.OnPressPtr      = 0;

  boxRound_SetpointsScreen1_OcVoltSelectionBox.OwnerScreen     = &SetpointsScreen1;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Order           = 0;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Left            = 2;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Top             = 83;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Width           = 316;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Height          = 36;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Pen_Width       = 0;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Pen_Color       = 0x0000;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Visible         = 0;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Active          = 0;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Transparent     = 1;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Gradient        = 0;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Gradient_Orientation    = 0;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Gradient_Start_Color    = 0xFFFF;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Gradient_End_Color      = 0xFFFF;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Color           = 0xF567;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.PressColEnabled     = 1;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Press_Color     = 0x8410;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.Corner_Radius      = 0;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.OnUpPtr         = 0;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.OnDownPtr       = 0;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.OnClickPtr      = 0;
  boxRound_SetpointsScreen1_OcVoltSelectionBox.OnPressPtr      = 0;

  boxRound_SetpointsScreen1_BatVoltSelectionBox.OwnerScreen     = &SetpointsScreen1;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Order           = 1;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Left            = 2;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Top             = 45;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Width           = 316;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Height          = 36;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Pen_Width       = 0;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Pen_Color       = 0x0000;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Visible         = 1;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Active          = 0;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Transparent     = 1;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Gradient        = 0;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Gradient_Orientation    = 0;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Gradient_Start_Color    = 0xFFFF;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Gradient_End_Color      = 0xFFFF;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Color           = 0xF567;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.PressColEnabled     = 1;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Press_Color     = 0x8410;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.Corner_Radius      = 0;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.OnUpPtr         = 0;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.OnDownPtr       = 0;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.OnClickPtr      = 0;
  boxRound_SetpointsScreen1_BatVoltSelectionBox.OnPressPtr      = 0;

  btn_SetpointsScreen1_Edit.OwnerScreen     = &SetpointsScreen1;
  btn_SetpointsScreen1_Edit.Order           = 2;
  btn_SetpointsScreen1_Edit.Left            = 2;
  btn_SetpointsScreen1_Edit.Top             = 198;
  btn_SetpointsScreen1_Edit.Width           = 76;
  btn_SetpointsScreen1_Edit.Height          = 39;
  btn_SetpointsScreen1_Edit.Pen_Width       = 1;
  btn_SetpointsScreen1_Edit.Pen_Color       = 0x0000;
  btn_SetpointsScreen1_Edit.Visible         = 1;
  btn_SetpointsScreen1_Edit.Active          = 1;
  btn_SetpointsScreen1_Edit.Transparent     = 1;
  btn_SetpointsScreen1_Edit.Caption         = btn_SetpointsScreen1_Edit_Caption;
  btn_SetpointsScreen1_Edit.TextAlign             = _taCenter;
  btn_SetpointsScreen1_Edit.FontName        = Helvetica16x19_Bold;
  btn_SetpointsScreen1_Edit.PressColEnabled = 1;
  btn_SetpointsScreen1_Edit.Font_Color      = 0x0000;
  btn_SetpointsScreen1_Edit.Gradient        = 1;
  btn_SetpointsScreen1_Edit.Gradient_Orientation    = 0;
  btn_SetpointsScreen1_Edit.Gradient_Start_Color    = 0xF567;
  btn_SetpointsScreen1_Edit.Gradient_End_Color      = 0xF567;
  btn_SetpointsScreen1_Edit.Color           = 0xC618;
  btn_SetpointsScreen1_Edit.Press_Color     = 0x8410;
  btn_SetpointsScreen1_Edit.Corner_Radius      = 0;
  btn_SetpointsScreen1_Edit.OnUpPtr         = 0;
  btn_SetpointsScreen1_Edit.OnDownPtr       = 0;
  btn_SetpointsScreen1_Edit.OnClickPtr      = btn_SetpointsScreen1_EditOnClick;
  btn_SetpointsScreen1_Edit.OnPressPtr      = 0;

  btn_SetpointsScreen1_Down.OwnerScreen     = &SetpointsScreen1;
  btn_SetpointsScreen1_Down.Order           = 3;
  btn_SetpointsScreen1_Down.Left            = 161;
  btn_SetpointsScreen1_Down.Top             = 198;
  btn_SetpointsScreen1_Down.Width           = 78;
  btn_SetpointsScreen1_Down.Height          = 39;
  btn_SetpointsScreen1_Down.Pen_Width       = 1;
  btn_SetpointsScreen1_Down.Pen_Color       = 0x0000;
  btn_SetpointsScreen1_Down.Visible         = 1;
  btn_SetpointsScreen1_Down.Active          = 1;
  btn_SetpointsScreen1_Down.Transparent     = 1;
  btn_SetpointsScreen1_Down.Caption         = btn_SetpointsScreen1_Down_Caption;
  btn_SetpointsScreen1_Down.TextAlign             = _taCenter;
  btn_SetpointsScreen1_Down.FontName        = Helvetica16x19_Bold;
  btn_SetpointsScreen1_Down.PressColEnabled = 1;
  btn_SetpointsScreen1_Down.Font_Color      = 0x0000;
  btn_SetpointsScreen1_Down.Gradient        = 1;
  btn_SetpointsScreen1_Down.Gradient_Orientation    = 0;
  btn_SetpointsScreen1_Down.Gradient_Start_Color    = 0xFFFF;
  btn_SetpointsScreen1_Down.Gradient_End_Color      = 0xFFFF;
  btn_SetpointsScreen1_Down.Color           = 0xC618;
  btn_SetpointsScreen1_Down.Press_Color     = 0x8410;
  btn_SetpointsScreen1_Down.Corner_Radius      = 0;
  btn_SetpointsScreen1_Down.OnUpPtr         = 0;
  btn_SetpointsScreen1_Down.OnDownPtr       = 0;
  btn_SetpointsScreen1_Down.OnClickPtr      = btn_SetpointsScreen1_DownOnClick;
  btn_SetpointsScreen1_Down.OnPressPtr      = 0;

  btn_SetpointsScreen1_Next.OwnerScreen     = &SetpointsScreen1;
  btn_SetpointsScreen1_Next.Order           = 4;
  btn_SetpointsScreen1_Next.Left            = 242;
  btn_SetpointsScreen1_Next.Top             = 198;
  btn_SetpointsScreen1_Next.Width           = 76;
  btn_SetpointsScreen1_Next.Height          = 39;
  btn_SetpointsScreen1_Next.Pen_Width       = 1;
  btn_SetpointsScreen1_Next.Pen_Color       = 0x0000;
  btn_SetpointsScreen1_Next.Visible         = 1;
  btn_SetpointsScreen1_Next.Active          = 1;
  btn_SetpointsScreen1_Next.Transparent     = 1;
  btn_SetpointsScreen1_Next.Caption         = btn_SetpointsScreen1_Next_Caption;
  btn_SetpointsScreen1_Next.TextAlign             = _taCenter;
  btn_SetpointsScreen1_Next.FontName        = Helvetica16x19_Bold;
  btn_SetpointsScreen1_Next.PressColEnabled = 1;
  btn_SetpointsScreen1_Next.Font_Color      = 0x0000;
  btn_SetpointsScreen1_Next.Gradient        = 1;
  btn_SetpointsScreen1_Next.Gradient_Orientation    = 0;
  btn_SetpointsScreen1_Next.Gradient_Start_Color    = 0x5E88;
  btn_SetpointsScreen1_Next.Gradient_End_Color      = 0x5E88;
  btn_SetpointsScreen1_Next.Color           = 0xC618;
  btn_SetpointsScreen1_Next.Press_Color     = 0x8410;
  btn_SetpointsScreen1_Next.Corner_Radius      = 0;
  btn_SetpointsScreen1_Next.OnUpPtr         = 0;
  btn_SetpointsScreen1_Next.OnDownPtr       = 0;
  btn_SetpointsScreen1_Next.OnClickPtr      = btn_SetpointsScreen1_NextOnClick;
  btn_SetpointsScreen1_Next.OnPressPtr      = 0;

  lbl_SetpointsScreen1_ScreenTitle.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1_ScreenTitle.Order          = 5;
  lbl_SetpointsScreen1_ScreenTitle.Left           = 103;
  lbl_SetpointsScreen1_ScreenTitle.Top            = 10;
  lbl_SetpointsScreen1_ScreenTitle.Width          = 129;
  lbl_SetpointsScreen1_ScreenTitle.Height         = 26;
  lbl_SetpointsScreen1_ScreenTitle.Visible        = 1;
  lbl_SetpointsScreen1_ScreenTitle.Active         = 0;
  lbl_SetpointsScreen1_ScreenTitle.Caption        = lbl_SetpointsScreen1_ScreenTitle_Caption;
  lbl_SetpointsScreen1_ScreenTitle.FontName       = Helvetica21x24_Bold;
  lbl_SetpointsScreen1_ScreenTitle.Font_Color     = 0xF79E;
  lbl_SetpointsScreen1_ScreenTitle.OnUpPtr         = 0;
  lbl_SetpointsScreen1_ScreenTitle.OnDownPtr       = 0;
  lbl_SetpointsScreen1_ScreenTitle.OnClickPtr      = 0;
  lbl_SetpointsScreen1_ScreenTitle.OnPressPtr      = 0;

  lbl_SetpointsScreen1BatVolt_Name.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1BatVolt_Name.Order          = 6;
  lbl_SetpointsScreen1BatVolt_Name.Left           = 10;
  lbl_SetpointsScreen1BatVolt_Name.Top            = 53;
  lbl_SetpointsScreen1BatVolt_Name.Width          = 107;
  lbl_SetpointsScreen1BatVolt_Name.Height         = 24;
  lbl_SetpointsScreen1BatVolt_Name.Visible        = 1;
  lbl_SetpointsScreen1BatVolt_Name.Active         = 0;
  lbl_SetpointsScreen1BatVolt_Name.Caption        = lbl_SetpointsScreen1BatVolt_Name_Caption;
  lbl_SetpointsScreen1BatVolt_Name.FontName       = Helvetica19x22_Regular;
  lbl_SetpointsScreen1BatVolt_Name.Font_Color     = 0x0000;
  lbl_SetpointsScreen1BatVolt_Name.OnUpPtr         = 0;
  lbl_SetpointsScreen1BatVolt_Name.OnDownPtr       = 0;
  lbl_SetpointsScreen1BatVolt_Name.OnClickPtr      = 0;
  lbl_SetpointsScreen1BatVolt_Name.OnPressPtr      = 0;

  lbl_SetpointsScreen1OcVolt_Name.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1OcVolt_Name.Order          = 7;
  lbl_SetpointsScreen1OcVolt_Name.Left           = 10;
  lbl_SetpointsScreen1OcVolt_Name.Top            = 90;
  lbl_SetpointsScreen1OcVolt_Name.Width          = 107;
  lbl_SetpointsScreen1OcVolt_Name.Height         = 24;
  lbl_SetpointsScreen1OcVolt_Name.Visible        = 1;
  lbl_SetpointsScreen1OcVolt_Name.Active         = 0;
  lbl_SetpointsScreen1OcVolt_Name.Caption        = lbl_SetpointsScreen1OcVolt_Name_Caption;
  lbl_SetpointsScreen1OcVolt_Name.FontName       = Helvetica19x22_Regular;
  lbl_SetpointsScreen1OcVolt_Name.Font_Color     = 0x0000;
  lbl_SetpointsScreen1OcVolt_Name.OnUpPtr         = 0;
  lbl_SetpointsScreen1OcVolt_Name.OnDownPtr       = 0;
  lbl_SetpointsScreen1OcVolt_Name.OnClickPtr      = 0;
  lbl_SetpointsScreen1OcVolt_Name.OnPressPtr      = 0;

  lbl_SetpointsScreen1BatVolt_Value.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1BatVolt_Value.Order          = 8;
  lbl_SetpointsScreen1BatVolt_Value.Left           = 220;
  lbl_SetpointsScreen1BatVolt_Value.Top            = 47;
  lbl_SetpointsScreen1BatVolt_Value.Width          = 111;
  lbl_SetpointsScreen1BatVolt_Value.Height         = 34;
  lbl_SetpointsScreen1BatVolt_Value.Visible        = 1;
  lbl_SetpointsScreen1BatVolt_Value.Active         = 0;
  lbl_SetpointsScreen1BatVolt_Value.Caption        = lbl_SetpointsScreen1BatVolt_Value_Caption;
  lbl_SetpointsScreen1BatVolt_Value.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen1BatVolt_Value.Font_Color     = 0x2124;
  lbl_SetpointsScreen1BatVolt_Value.OnUpPtr         = 0;
  lbl_SetpointsScreen1BatVolt_Value.OnDownPtr       = 0;
  lbl_SetpointsScreen1BatVolt_Value.OnClickPtr      = 0;
  lbl_SetpointsScreen1BatVolt_Value.OnPressPtr      = 0;

  lbl_SetpointsScreen1OCVolt_Value.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1OCVolt_Value.Order          = 9;
  lbl_SetpointsScreen1OCVolt_Value.Left           = 220;
  lbl_SetpointsScreen1OCVolt_Value.Top            = 85;
  lbl_SetpointsScreen1OCVolt_Value.Width          = 111;
  lbl_SetpointsScreen1OCVolt_Value.Height         = 34;
  lbl_SetpointsScreen1OCVolt_Value.Visible        = 1;
  lbl_SetpointsScreen1OCVolt_Value.Active         = 0;
  lbl_SetpointsScreen1OCVolt_Value.Caption        = lbl_SetpointsScreen1OCVolt_Value_Caption;
  lbl_SetpointsScreen1OCVolt_Value.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen1OCVolt_Value.Font_Color     = 0x2124;
  lbl_SetpointsScreen1OCVolt_Value.OnUpPtr         = 0;
  lbl_SetpointsScreen1OCVolt_Value.OnDownPtr       = 0;
  lbl_SetpointsScreen1OCVolt_Value.OnClickPtr      = 0;
  lbl_SetpointsScreen1OCVolt_Value.OnPressPtr      = 0;

  lbl_SetpointsScreen1_PageNumber.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1_PageNumber.Order          = 10;
  lbl_SetpointsScreen1_PageNumber.Left           = 297;
  lbl_SetpointsScreen1_PageNumber.Top            = 28;
  lbl_SetpointsScreen1_PageNumber.Width          = 19;
  lbl_SetpointsScreen1_PageNumber.Height         = 16;
  lbl_SetpointsScreen1_PageNumber.Visible        = 1;
  lbl_SetpointsScreen1_PageNumber.Active         = 0;
  lbl_SetpointsScreen1_PageNumber.Caption        = lbl_SetpointsScreen1_PageNumber_Caption;
  lbl_SetpointsScreen1_PageNumber.FontName       = Helvetica13x16_Regular;
  lbl_SetpointsScreen1_PageNumber.Font_Color     = 0xFFFF;
  lbl_SetpointsScreen1_PageNumber.OnUpPtr         = 0;
  lbl_SetpointsScreen1_PageNumber.OnDownPtr       = 0;
  lbl_SetpointsScreen1_PageNumber.OnClickPtr      = 0;
  lbl_SetpointsScreen1_PageNumber.OnPressPtr      = 0;

  btn_SetpointsScreen1_Up.OwnerScreen     = &SetpointsScreen1;
  btn_SetpointsScreen1_Up.Order           = 11;
  btn_SetpointsScreen1_Up.Left            = 81;
  btn_SetpointsScreen1_Up.Top             = 198;
  btn_SetpointsScreen1_Up.Width           = 78;
  btn_SetpointsScreen1_Up.Height          = 39;
  btn_SetpointsScreen1_Up.Pen_Width       = 1;
  btn_SetpointsScreen1_Up.Pen_Color       = 0x0000;
  btn_SetpointsScreen1_Up.Visible         = 1;
  btn_SetpointsScreen1_Up.Active          = 1;
  btn_SetpointsScreen1_Up.Transparent     = 1;
  btn_SetpointsScreen1_Up.Caption         = btn_SetpointsScreen1_Up_Caption;
  btn_SetpointsScreen1_Up.TextAlign             = _taCenter;
  btn_SetpointsScreen1_Up.FontName        = Helvetica16x19_Bold;
  btn_SetpointsScreen1_Up.PressColEnabled = 1;
  btn_SetpointsScreen1_Up.Font_Color      = 0x0000;
  btn_SetpointsScreen1_Up.Gradient        = 1;
  btn_SetpointsScreen1_Up.Gradient_Orientation    = 0;
  btn_SetpointsScreen1_Up.Gradient_Start_Color    = 0xFFFF;
  btn_SetpointsScreen1_Up.Gradient_End_Color      = 0xFFFF;
  btn_SetpointsScreen1_Up.Color           = 0xC618;
  btn_SetpointsScreen1_Up.Press_Color     = 0x8410;
  btn_SetpointsScreen1_Up.Corner_Radius      = 0;
  btn_SetpointsScreen1_Up.OnUpPtr         = 0;
  btn_SetpointsScreen1_Up.OnDownPtr       = 0;
  btn_SetpointsScreen1_Up.OnClickPtr      = btn_SetpointsScreen1_UpOnClick;
  btn_SetpointsScreen1_Up.OnPressPtr      = 0;

  boxRound_SetpointsScreen1_SelectionBoxMpVolt.OwnerScreen     = &SetpointsScreen1;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Order           = 12;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Left            = 2;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Top             = 121;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Width           = 316;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Height          = 36;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Pen_Width       = 0;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Pen_Color       = 0x0000;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Visible         = 0;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Active          = 0;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Transparent     = 1;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Gradient        = 0;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Gradient_Orientation    = 0;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Gradient_Start_Color    = 0xFFFF;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Gradient_End_Color      = 0xFFFF;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Color           = 0xF567;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.PressColEnabled     = 1;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Press_Color     = 0x8410;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.Corner_Radius      = 0;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.OnUpPtr         = 0;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.OnDownPtr       = 0;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.OnClickPtr      = 0;
  boxRound_SetpointsScreen1_SelectionBoxMpVolt.OnPressPtr      = 0;

  lbl_SetpointsScreen1MpVolt_Name.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1MpVolt_Name.Order          = 13;
  lbl_SetpointsScreen1MpVolt_Name.Left           = 10;
  lbl_SetpointsScreen1MpVolt_Name.Top            = 128;
  lbl_SetpointsScreen1MpVolt_Name.Width          = 107;
  lbl_SetpointsScreen1MpVolt_Name.Height         = 24;
  lbl_SetpointsScreen1MpVolt_Name.Visible        = 1;
  lbl_SetpointsScreen1MpVolt_Name.Active         = 0;
  lbl_SetpointsScreen1MpVolt_Name.Caption        = lbl_SetpointsScreen1MpVolt_Name_Caption;
  lbl_SetpointsScreen1MpVolt_Name.FontName       = Helvetica19x22_Regular;
  lbl_SetpointsScreen1MpVolt_Name.Font_Color     = 0x0000;
  lbl_SetpointsScreen1MpVolt_Name.OnUpPtr         = 0;
  lbl_SetpointsScreen1MpVolt_Name.OnDownPtr       = 0;
  lbl_SetpointsScreen1MpVolt_Name.OnClickPtr      = 0;
  lbl_SetpointsScreen1MpVolt_Name.OnPressPtr      = 0;

  lbl_SetpointsScreen1MpVolt_Value.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1MpVolt_Value.Order          = 14;
  lbl_SetpointsScreen1MpVolt_Value.Left           = 220;
  lbl_SetpointsScreen1MpVolt_Value.Top            = 123;
  lbl_SetpointsScreen1MpVolt_Value.Width          = 111;
  lbl_SetpointsScreen1MpVolt_Value.Height         = 34;
  lbl_SetpointsScreen1MpVolt_Value.Visible        = 1;
  lbl_SetpointsScreen1MpVolt_Value.Active         = 0;
  lbl_SetpointsScreen1MpVolt_Value.Caption        = lbl_SetpointsScreen1MpVolt_Value_Caption;
  lbl_SetpointsScreen1MpVolt_Value.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen1MpVolt_Value.Font_Color     = 0x2124;
  lbl_SetpointsScreen1MpVolt_Value.OnUpPtr         = 0;
  lbl_SetpointsScreen1MpVolt_Value.OnDownPtr       = 0;
  lbl_SetpointsScreen1MpVolt_Value.OnClickPtr      = 0;
  lbl_SetpointsScreen1MpVolt_Value.OnPressPtr      = 0;

  boxRound_SetpointsScreen1_SelectionBoxTempComp.OwnerScreen     = &SetpointsScreen1;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Order           = 15;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Left            = 2;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Top             = 159;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Width           = 316;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Height          = 36;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Pen_Width       = 0;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Pen_Color       = 0x0000;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Visible         = 0;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Active          = 0;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Transparent     = 1;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Gradient        = 0;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Gradient_Orientation    = 0;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Gradient_Start_Color    = 0xFFFF;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Gradient_End_Color      = 0xFFFF;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Color           = 0xF567;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.PressColEnabled     = 1;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Press_Color     = 0x8410;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.Corner_Radius      = 0;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.OnUpPtr         = 0;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.OnDownPtr       = 0;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.OnClickPtr      = 0;
  boxRound_SetpointsScreen1_SelectionBoxTempComp.OnPressPtr      = 0;

  lbl_SetpointsScreen1TempComp_Name.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1TempComp_Name.Order          = 16;
  lbl_SetpointsScreen1TempComp_Name.Left           = 10;
  lbl_SetpointsScreen1TempComp_Name.Top            = 166;
  lbl_SetpointsScreen1TempComp_Name.Width          = 113;
  lbl_SetpointsScreen1TempComp_Name.Height         = 24;
  lbl_SetpointsScreen1TempComp_Name.Visible        = 1;
  lbl_SetpointsScreen1TempComp_Name.Active         = 0;
  lbl_SetpointsScreen1TempComp_Name.Caption        = lbl_SetpointsScreen1TempComp_Name_Caption;
  lbl_SetpointsScreen1TempComp_Name.FontName       = Helvetica19x22_Regular;
  lbl_SetpointsScreen1TempComp_Name.Font_Color     = 0x0000;
  lbl_SetpointsScreen1TempComp_Name.OnUpPtr         = 0;
  lbl_SetpointsScreen1TempComp_Name.OnDownPtr       = 0;
  lbl_SetpointsScreen1TempComp_Name.OnClickPtr      = 0;
  lbl_SetpointsScreen1TempComp_Name.OnPressPtr      = 0;

  lbl_SetpointsScreen1TempComp_Value.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1TempComp_Value.Order          = 17;
  lbl_SetpointsScreen1TempComp_Value.Left           = 170;
  lbl_SetpointsScreen1TempComp_Value.Top            = 161;
  lbl_SetpointsScreen1TempComp_Value.Width          = 114;
  lbl_SetpointsScreen1TempComp_Value.Height         = 34;
  lbl_SetpointsScreen1TempComp_Value.Visible        = 1;
  lbl_SetpointsScreen1TempComp_Value.Active         = 0;
  lbl_SetpointsScreen1TempComp_Value.Caption        = lbl_SetpointsScreen1TempComp_Value_Caption;
  lbl_SetpointsScreen1TempComp_Value.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen1TempComp_Value.Font_Color     = 0x2124;
  lbl_SetpointsScreen1TempComp_Value.OnUpPtr         = 0;
  lbl_SetpointsScreen1TempComp_Value.OnDownPtr       = 0;
  lbl_SetpointsScreen1TempComp_Value.OnClickPtr      = 0;
  lbl_SetpointsScreen1TempComp_Value.OnPressPtr      = 0;
  
  lbl_SetpointsScreen1BatVolt_Desig.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1BatVolt_Desig.Order          = 18;
  lbl_SetpointsScreen1BatVolt_Desig.Left           = 290;
  lbl_SetpointsScreen1BatVolt_Desig.Top            = 47;
  lbl_SetpointsScreen1BatVolt_Desig.Width          = 24;
  lbl_SetpointsScreen1BatVolt_Desig.Height         = 34;
  lbl_SetpointsScreen1BatVolt_Desig.Visible        = 1;
  lbl_SetpointsScreen1BatVolt_Desig.Active         = 0;
  lbl_SetpointsScreen1BatVolt_Desig.Caption        = lbl_SetpointsScreen1BatVolt_Desig_Caption;
  lbl_SetpointsScreen1BatVolt_Desig.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen1BatVolt_Desig.Font_Color     = 0x0000;
  lbl_SetpointsScreen1BatVolt_Desig.OnUpPtr         = 0;
  lbl_SetpointsScreen1BatVolt_Desig.OnDownPtr       = 0;
  lbl_SetpointsScreen1BatVolt_Desig.OnClickPtr      = 0;
  lbl_SetpointsScreen1BatVolt_Desig.OnPressPtr      = 0;
  
  lbl_SetpointsScreen1OcVolt_Desig.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1OcVolt_Desig.Order          = 19;
  lbl_SetpointsScreen1OcVolt_Desig.Left           = 290;
  lbl_SetpointsScreen1OcVolt_Desig.Top            = 85;
  lbl_SetpointsScreen1OcVolt_Desig.Width          = 24;
  lbl_SetpointsScreen1OcVolt_Desig.Height         = 34;
  lbl_SetpointsScreen1OcVolt_Desig.Visible        = 1;
  lbl_SetpointsScreen1OcVolt_Desig.Active         = 0;
  lbl_SetpointsScreen1OcVolt_Desig.Caption        = lbl_SetpointsScreen1OcVolt_Desig_Caption;
  lbl_SetpointsScreen1OcVolt_Desig.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen1OcVolt_Desig.Font_Color     = 0x0000;
  lbl_SetpointsScreen1OcVolt_Desig.OnUpPtr         = 0;
  lbl_SetpointsScreen1OcVolt_Desig.OnDownPtr       = 0;
  lbl_SetpointsScreen1OcVolt_Desig.OnClickPtr      = 0;
  lbl_SetpointsScreen1OcVolt_Desig.OnPressPtr      = 0;
  
  lbl_SetpointsScreen1MpVolt_Desig.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1MpVolt_Desig.Order          = 20;
  lbl_SetpointsScreen1MpVolt_Desig.Left           = 290;
  lbl_SetpointsScreen1MpVolt_Desig.Top            = 123;
  lbl_SetpointsScreen1MpVolt_Desig.Width          = 24;
  lbl_SetpointsScreen1MpVolt_Desig.Height         = 34;
  lbl_SetpointsScreen1MpVolt_Desig.Visible        = 1;
  lbl_SetpointsScreen1MpVolt_Desig.Active         = 0;
  lbl_SetpointsScreen1MpVolt_Desig.Caption        = lbl_SetpointsScreen1MpVolt_Desig_Caption;
  lbl_SetpointsScreen1MpVolt_Desig.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen1MpVolt_Desig.Font_Color     = 0x0000;
  lbl_SetpointsScreen1MpVolt_Desig.OnUpPtr         = 0;
  lbl_SetpointsScreen1MpVolt_Desig.OnDownPtr       = 0;
  lbl_SetpointsScreen1MpVolt_Desig.OnClickPtr      = 0;
  lbl_SetpointsScreen1MpVolt_Desig.OnPressPtr      = 0;
  
  lbl_SetpointsScreen1TempComp_Desig.OwnerScreen     = &SetpointsScreen1;
  lbl_SetpointsScreen1TempComp_Desig.Order          = 21;
  lbl_SetpointsScreen1TempComp_Desig.Left           = 245;
  lbl_SetpointsScreen1TempComp_Desig.Top            = 161;
  lbl_SetpointsScreen1TempComp_Desig.Width          = 24;
  lbl_SetpointsScreen1TempComp_Desig.Height         = 34;
  lbl_SetpointsScreen1TempComp_Desig.Visible        = 1;
  lbl_SetpointsScreen1TempComp_Desig.Active         = 0;
  lbl_SetpointsScreen1TempComp_Desig.Caption        = lbl_SetpointsScreen1TempComp_Desig_Caption;
  lbl_SetpointsScreen1TempComp_Desig.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen1TempComp_Desig.Font_Color     = 0x0000;
  lbl_SetpointsScreen1TempComp_Desig.OnUpPtr         = 0;
  lbl_SetpointsScreen1TempComp_Desig.OnDownPtr       = 0;
  lbl_SetpointsScreen1TempComp_Desig.OnClickPtr      = 0;
  lbl_SetpointsScreen1TempComp_Desig.OnPressPtr      = 0;
  
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.OwnerScreen     = &SetpointsScreen2;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Order           = 0;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Left            = 2;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Top             = 159;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Width           = 316;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Height          = 36;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Pen_Width       = 1;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Pen_Color       = 0x0000;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Visible         = 0;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Active          = 0;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Transparent     = 1;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Gradient        = 0;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Gradient_Orientation    = 0;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Gradient_Start_Color    = 0xFFFF;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Gradient_End_Color      = 0xFFFF;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Color           = 0xF567;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.PressColEnabled     = 1;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Press_Color     = 0x8410;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.Corner_Radius      = 0;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.OnUpPtr         = 0;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.OnDownPtr       = 0;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.OnClickPtr      = 0;
  boxRound_SetpointsScreen2_BulkResetVoltSelectionBox.OnPressPtr      = 0;

  boxRound_SetpointsScreen2_FloatVoltSelectionBox.OwnerScreen     = &SetpointsScreen2;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Order           = 1;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Left            = 2;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Top             = 121;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Width           = 316;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Height          = 36;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Pen_Width       = 1;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Pen_Color       = 0x0000;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Visible         = 1;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Active          = 0;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Transparent     = 1;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Gradient        = 0;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Gradient_Orientation    = 0;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Gradient_Start_Color    = 0xFFFF;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Gradient_End_Color      = 0xFFFF;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Color           = 0xF567;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.PressColEnabled     = 1;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Press_Color     = 0x8410;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.Corner_Radius      = 0;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.OnUpPtr         = 0;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.OnDownPtr       = 0;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.OnClickPtr      = 0;
  boxRound_SetpointsScreen2_FloatVoltSelectionBox.OnPressPtr      = 0;

  boxRound_SetpointsScreen2_BulkVoltSelectionBox.OwnerScreen     = &SetpointsScreen2;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Order           = 2;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Left            = 2;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Top             = 45;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Width           = 316;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Height          = 36;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Pen_Width       = 1;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Pen_Color       = 0x0000;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Visible         = 0;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Active          = 0;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Transparent     = 1;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Gradient        = 0;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Gradient_Orientation    = 0;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Gradient_Start_Color    = 0xFFFF;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Gradient_End_Color      = 0xFFFF;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Color           = 0xF567;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.PressColEnabled     = 1;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Press_Color     = 0x8410;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.Corner_Radius      = 0;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.OnUpPtr         = 0;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.OnDownPtr       = 0;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.OnClickPtr      = 0;
  boxRound_SetpointsScreen2_BulkVoltSelectionBox.OnPressPtr      = 0;

  btn_SetpointsScreen2_Edit.OwnerScreen     = &SetpointsScreen2;
  btn_SetpointsScreen2_Edit.Order           = 3;
  btn_SetpointsScreen2_Edit.Left            = 2;
  btn_SetpointsScreen2_Edit.Top             = 198;
  btn_SetpointsScreen2_Edit.Width           = 76;
  btn_SetpointsScreen2_Edit.Height          = 39;
  btn_SetpointsScreen2_Edit.Pen_Width       = 1;
  btn_SetpointsScreen2_Edit.Pen_Color       = 0x0000;
  btn_SetpointsScreen2_Edit.Visible         = 1;
  btn_SetpointsScreen2_Edit.Active          = 1;
  btn_SetpointsScreen2_Edit.Transparent     = 1;
  btn_SetpointsScreen2_Edit.Caption         = btn_SetpointsScreen2_Edit_Caption;
  btn_SetpointsScreen2_Edit.TextAlign             = _taCenter;
  btn_SetpointsScreen2_Edit.FontName        = Helvetica16x19_Bold;
  btn_SetpointsScreen2_Edit.PressColEnabled = 1;
  btn_SetpointsScreen2_Edit.Font_Color      = 0x0000;
  btn_SetpointsScreen2_Edit.Gradient        = 1;
  btn_SetpointsScreen2_Edit.Gradient_Orientation    = 0;
  btn_SetpointsScreen2_Edit.Gradient_Start_Color    = 0xF567;
  btn_SetpointsScreen2_Edit.Gradient_End_Color      = 0xF567;
  btn_SetpointsScreen2_Edit.Color           = 0xC618;
  btn_SetpointsScreen2_Edit.Press_Color     = 0x8410;
  btn_SetpointsScreen2_Edit.Corner_Radius      = 0;
  btn_SetpointsScreen2_Edit.OnUpPtr         = 0;
  btn_SetpointsScreen2_Edit.OnDownPtr       = 0;
  btn_SetpointsScreen2_Edit.OnClickPtr      = btn_SetpointsScreen2_EditOnClick;
  btn_SetpointsScreen2_Edit.OnPressPtr      = 0;

  btn_SetpointsScreen2_Down.OwnerScreen     = &SetpointsScreen2;
  btn_SetpointsScreen2_Down.Order           = 4;
  btn_SetpointsScreen2_Down.Left            = 161;
  btn_SetpointsScreen2_Down.Top             = 198;
  btn_SetpointsScreen2_Down.Width           = 78;
  btn_SetpointsScreen2_Down.Height          = 39;
  btn_SetpointsScreen2_Down.Pen_Width       = 1;
  btn_SetpointsScreen2_Down.Pen_Color       = 0x0000;
  btn_SetpointsScreen2_Down.Visible         = 1;
  btn_SetpointsScreen2_Down.Active          = 1;
  btn_SetpointsScreen2_Down.Transparent     = 1;
  btn_SetpointsScreen2_Down.Caption         = btn_SetpointsScreen2_Down_Caption;
  btn_SetpointsScreen2_Down.TextAlign             = _taCenter;
  btn_SetpointsScreen2_Down.FontName        = Helvetica16x19_Bold;
  btn_SetpointsScreen2_Down.PressColEnabled = 1;
  btn_SetpointsScreen2_Down.Font_Color      = 0x0000;
  btn_SetpointsScreen2_Down.Gradient        = 1;
  btn_SetpointsScreen2_Down.Gradient_Orientation    = 0;
  btn_SetpointsScreen2_Down.Gradient_Start_Color    = 0xFFFF;
  btn_SetpointsScreen2_Down.Gradient_End_Color      = 0xFFFF;
  btn_SetpointsScreen2_Down.Color           = 0xC618;
  btn_SetpointsScreen2_Down.Press_Color     = 0x8410;
  btn_SetpointsScreen2_Down.Corner_Radius      = 0;
  btn_SetpointsScreen2_Down.OnUpPtr         = 0;
  btn_SetpointsScreen2_Down.OnDownPtr       = 0;
  btn_SetpointsScreen2_Down.OnClickPtr      = btn_SetpointsScreen2_DownOnClick;
  btn_SetpointsScreen2_Down.OnPressPtr      = 0;

  btn_SetpointsScreen2_Apply.OwnerScreen     = &SetpointsScreen2;
  btn_SetpointsScreen2_Apply.Order           = 5;
  btn_SetpointsScreen2_Apply.Left            = 242;
  btn_SetpointsScreen2_Apply.Top             = 198;
  btn_SetpointsScreen2_Apply.Width           = 76;
  btn_SetpointsScreen2_Apply.Height          = 39;
  btn_SetpointsScreen2_Apply.Pen_Width       = 1;
  btn_SetpointsScreen2_Apply.Pen_Color       = 0x0000;
  btn_SetpointsScreen2_Apply.Visible         = 1;
  btn_SetpointsScreen2_Apply.Active          = 1;
  btn_SetpointsScreen2_Apply.Transparent     = 1;
  btn_SetpointsScreen2_Apply.Caption         = btn_SetpointsScreen2_Apply_Caption;
  btn_SetpointsScreen2_Apply.TextAlign             = _taCenter;
  btn_SetpointsScreen2_Apply.FontName        = Helvetica16x19_Bold;
  btn_SetpointsScreen2_Apply.PressColEnabled = 1;
  btn_SetpointsScreen2_Apply.Font_Color      = 0x0000;
  btn_SetpointsScreen2_Apply.Gradient        = 1;
  btn_SetpointsScreen2_Apply.Gradient_Orientation    = 0;
  btn_SetpointsScreen2_Apply.Gradient_Start_Color    = 0x5E88;
  btn_SetpointsScreen2_Apply.Gradient_End_Color      = 0x5E88;
  btn_SetpointsScreen2_Apply.Color           = 0xC618;
  btn_SetpointsScreen2_Apply.Press_Color     = 0x8410;
  btn_SetpointsScreen2_Apply.Corner_Radius      = 0;
  btn_SetpointsScreen2_Apply.OnUpPtr         = 0;
  btn_SetpointsScreen2_Apply.OnDownPtr       = 0;
  btn_SetpointsScreen2_Apply.OnClickPtr      = btn_SetpointsScreen2_ApplyOnClick;
  btn_SetpointsScreen2_Apply.OnPressPtr      = 0;

  lbl_SetpointsScreen2BulkVolt_Name.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2BulkVolt_Name.Order          = 6;
  lbl_SetpointsScreen2BulkVolt_Name.Left           = 10;
  lbl_SetpointsScreen2BulkVolt_Name.Top            = 52;
  lbl_SetpointsScreen2BulkVolt_Name.Width          = 67;
  lbl_SetpointsScreen2BulkVolt_Name.Height         = 24;
  lbl_SetpointsScreen2BulkVolt_Name.Visible        = 1;
  lbl_SetpointsScreen2BulkVolt_Name.Active         = 0;
  lbl_SetpointsScreen2BulkVolt_Name.Caption        = lbl_SetpointsScreen2BulkVolt_Name_Caption;
  lbl_SetpointsScreen2BulkVolt_Name.FontName       = Helvetica19x22_Regular;
  lbl_SetpointsScreen2BulkVolt_Name.Font_Color     = 0x0000;
  lbl_SetpointsScreen2BulkVolt_Name.OnUpPtr         = 0;
  lbl_SetpointsScreen2BulkVolt_Name.OnDownPtr       = 0;
  lbl_SetpointsScreen2BulkVolt_Name.OnClickPtr      = 0;
  lbl_SetpointsScreen2BulkVolt_Name.OnPressPtr      = 0;

  btn_SetpointsScreen2_Back.OwnerScreen     = &SetpointsScreen2;
  btn_SetpointsScreen2_Back.Order           = 7;
  btn_SetpointsScreen2_Back.Left            = 2;
  btn_SetpointsScreen2_Back.Top             = 3;
  btn_SetpointsScreen2_Back.Width           = 76;
  btn_SetpointsScreen2_Back.Height          = 39;
  btn_SetpointsScreen2_Back.Pen_Width       = 1;
  btn_SetpointsScreen2_Back.Pen_Color       = 0x0000;
  btn_SetpointsScreen2_Back.Visible         = 1;
  btn_SetpointsScreen2_Back.Active          = 1;
  btn_SetpointsScreen2_Back.Transparent     = 1;
  btn_SetpointsScreen2_Back.Caption         = btn_SetpointsScreen2_Back_Caption;
  btn_SetpointsScreen2_Back.TextAlign             = _taCenter;
  btn_SetpointsScreen2_Back.FontName        = Helvetica16x19_Bold;
  btn_SetpointsScreen2_Back.PressColEnabled = 1;
  btn_SetpointsScreen2_Back.Font_Color      = 0x0000;
  btn_SetpointsScreen2_Back.Gradient        = 1;
  btn_SetpointsScreen2_Back.Gradient_Orientation    = 0;
  btn_SetpointsScreen2_Back.Gradient_Start_Color    = 0xD9E7;
  btn_SetpointsScreen2_Back.Gradient_End_Color      = 0xD9E7;
  btn_SetpointsScreen2_Back.Color           = 0xC618;
  btn_SetpointsScreen2_Back.Press_Color     = 0x8410;
  btn_SetpointsScreen2_Back.Corner_Radius      = 0;
  btn_SetpointsScreen2_Back.OnUpPtr         = 0;
  btn_SetpointsScreen2_Back.OnDownPtr       = 0;
  btn_SetpointsScreen2_Back.OnClickPtr      = btn_SetpointsScreen2_BackOnClick;
  btn_SetpointsScreen2_Back.OnPressPtr      = 0;

  lbl_SetpointsScreen2_ScreenTitle.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2_ScreenTitle.Order          = 8;
  lbl_SetpointsScreen2_ScreenTitle.Left           = 103;
  lbl_SetpointsScreen2_ScreenTitle.Top            = 10;
  lbl_SetpointsScreen2_ScreenTitle.Width          = 129;
  lbl_SetpointsScreen2_ScreenTitle.Height         = 26;
  lbl_SetpointsScreen2_ScreenTitle.Visible        = 1;
  lbl_SetpointsScreen2_ScreenTitle.Active         = 0;
  lbl_SetpointsScreen2_ScreenTitle.Caption        = lbl_SetpointsScreen2_ScreenTitle_Caption;
  lbl_SetpointsScreen2_ScreenTitle.FontName       = Helvetica21x24_Bold;
  lbl_SetpointsScreen2_ScreenTitle.Font_Color     = 0xF79E;
  lbl_SetpointsScreen2_ScreenTitle.OnUpPtr         = 0;
  lbl_SetpointsScreen2_ScreenTitle.OnDownPtr       = 0;
  lbl_SetpointsScreen2_ScreenTitle.OnClickPtr      = 0;
  lbl_SetpointsScreen2_ScreenTitle.OnPressPtr      = 0;

  lbl_SetpointsScreen2FloatVolt_Name.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2FloatVolt_Name.Order          = 9;
  lbl_SetpointsScreen2FloatVolt_Name.Left           = 10;
  lbl_SetpointsScreen2FloatVolt_Name.Top            = 128;
  lbl_SetpointsScreen2FloatVolt_Name.Width          = 49;
  lbl_SetpointsScreen2FloatVolt_Name.Height         = 24;
  lbl_SetpointsScreen2FloatVolt_Name.Visible        = 1;
  lbl_SetpointsScreen2FloatVolt_Name.Active         = 0;
  lbl_SetpointsScreen2FloatVolt_Name.Caption        = lbl_SetpointsScreen2FloatVolt_Name_Caption;
  lbl_SetpointsScreen2FloatVolt_Name.FontName       = Helvetica19x22_Regular;
  lbl_SetpointsScreen2FloatVolt_Name.Font_Color     = 0x0000;
  lbl_SetpointsScreen2FloatVolt_Name.OnUpPtr         = 0;
  lbl_SetpointsScreen2FloatVolt_Name.OnDownPtr       = 0;
  lbl_SetpointsScreen2FloatVolt_Name.OnClickPtr      = 0;
  lbl_SetpointsScreen2FloatVolt_Name.OnPressPtr      = 0;

  lbl_SetpointsScreen2BulkResetVolt_Name.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2BulkResetVolt_Name.Order          = 10;
  lbl_SetpointsScreen2BulkResetVolt_Name.Left           = 10;
  lbl_SetpointsScreen2BulkResetVolt_Name.Top            = 166;
  lbl_SetpointsScreen2BulkResetVolt_Name.Width          = 69;
  lbl_SetpointsScreen2BulkResetVolt_Name.Height         = 24;
  lbl_SetpointsScreen2BulkResetVolt_Name.Visible        = 1;
  lbl_SetpointsScreen2BulkResetVolt_Name.Active         = 0;
  lbl_SetpointsScreen2BulkResetVolt_Name.Caption        = lbl_SetpointsScreen2BulkResetVolt_Name_Caption;
  lbl_SetpointsScreen2BulkResetVolt_Name.FontName       = Helvetica19x22_Regular;
  lbl_SetpointsScreen2BulkResetVolt_Name.Font_Color     = 0x0000;
  lbl_SetpointsScreen2BulkResetVolt_Name.OnUpPtr         = 0;
  lbl_SetpointsScreen2BulkResetVolt_Name.OnDownPtr       = 0;
  lbl_SetpointsScreen2BulkResetVolt_Name.OnClickPtr      = 0;
  lbl_SetpointsScreen2BulkResetVolt_Name.OnPressPtr      = 0;

  lbl_SetpointsScreen2BulkVolt_Value.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2BulkVolt_Value.Order          = 11;
  lbl_SetpointsScreen2BulkVolt_Value.Left           = 220;
  lbl_SetpointsScreen2BulkVolt_Value.Top            = 47;
  lbl_SetpointsScreen2BulkVolt_Value.Width          = 111;
  lbl_SetpointsScreen2BulkVolt_Value.Height         = 34;
  lbl_SetpointsScreen2BulkVolt_Value.Visible        = 1;
  lbl_SetpointsScreen2BulkVolt_Value.Active         = 0;
  lbl_SetpointsScreen2BulkVolt_Value.Caption        = lbl_SetpointsScreen2BulkVolt_Value_Caption;
  lbl_SetpointsScreen2BulkVolt_Value.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen2BulkVolt_Value.Font_Color     = 0x2124;
  lbl_SetpointsScreen2BulkVolt_Value.OnUpPtr         = 0;
  lbl_SetpointsScreen2BulkVolt_Value.OnDownPtr       = 0;
  lbl_SetpointsScreen2BulkVolt_Value.OnClickPtr      = 0;
  lbl_SetpointsScreen2BulkVolt_Value.OnPressPtr      = 0;

  lbl_SetpointsScreen2BulkResetVolt_Value.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2BulkResetVolt_Value.Order          = 12;
  lbl_SetpointsScreen2BulkResetVolt_Value.Left           = 220;
  lbl_SetpointsScreen2BulkResetVolt_Value.Top            = 161;
  lbl_SetpointsScreen2BulkResetVolt_Value.Width          = 111;
  lbl_SetpointsScreen2BulkResetVolt_Value.Height         = 34;
  lbl_SetpointsScreen2BulkResetVolt_Value.Visible        = 1;
  lbl_SetpointsScreen2BulkResetVolt_Value.Active         = 0;
  lbl_SetpointsScreen2BulkResetVolt_Value.Caption        = lbl_SetpointsScreen2BulkResetVolt_Value_Caption;
  lbl_SetpointsScreen2BulkResetVolt_Value.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen2BulkResetVolt_Value.Font_Color     = 0x2124;
  lbl_SetpointsScreen2BulkResetVolt_Value.OnUpPtr         = 0;
  lbl_SetpointsScreen2BulkResetVolt_Value.OnDownPtr       = 0;
  lbl_SetpointsScreen2BulkResetVolt_Value.OnClickPtr      = 0;
  lbl_SetpointsScreen2BulkResetVolt_Value.OnPressPtr      = 0;

  lbl_SetpointsScreen2_PageNumber.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2_PageNumber.Order          = 13;
  lbl_SetpointsScreen2_PageNumber.Left           = 297;
  lbl_SetpointsScreen2_PageNumber.Top            = 28;
  lbl_SetpointsScreen2_PageNumber.Width          = 19;
  lbl_SetpointsScreen2_PageNumber.Height         = 16;
  lbl_SetpointsScreen2_PageNumber.Visible        = 1;
  lbl_SetpointsScreen2_PageNumber.Active         = 0;
  lbl_SetpointsScreen2_PageNumber.Caption        = lbl_SetpointsScreen2_PageNumber_Caption;
  lbl_SetpointsScreen2_PageNumber.FontName       = Helvetica13x16_Regular;
  lbl_SetpointsScreen2_PageNumber.Font_Color     = 0xF79E;
  lbl_SetpointsScreen2_PageNumber.OnUpPtr         = 0;
  lbl_SetpointsScreen2_PageNumber.OnDownPtr       = 0;
  lbl_SetpointsScreen2_PageNumber.OnClickPtr      = 0;
  lbl_SetpointsScreen2_PageNumber.OnPressPtr      = 0;

  btn_SetpointsScreen2_Up.OwnerScreen     = &SetpointsScreen2;
  btn_SetpointsScreen2_Up.Order           = 14;
  btn_SetpointsScreen2_Up.Left            = 81;
  btn_SetpointsScreen2_Up.Top             = 198;
  btn_SetpointsScreen2_Up.Width           = 78;
  btn_SetpointsScreen2_Up.Height          = 39;
  btn_SetpointsScreen2_Up.Pen_Width       = 1;
  btn_SetpointsScreen2_Up.Pen_Color       = 0x0000;
  btn_SetpointsScreen2_Up.Visible         = 1;
  btn_SetpointsScreen2_Up.Active          = 1;
  btn_SetpointsScreen2_Up.Transparent     = 1;
  btn_SetpointsScreen2_Up.Caption         = btn_SetpointsScreen2_Up_Caption;
  btn_SetpointsScreen2_Up.TextAlign             = _taCenter;
  btn_SetpointsScreen2_Up.FontName        = Helvetica16x19_Bold;
  btn_SetpointsScreen2_Up.PressColEnabled = 1;
  btn_SetpointsScreen2_Up.Font_Color      = 0x0000;
  btn_SetpointsScreen2_Up.Gradient        = 1;
  btn_SetpointsScreen2_Up.Gradient_Orientation    = 0;
  btn_SetpointsScreen2_Up.Gradient_Start_Color    = 0xFFFF;
  btn_SetpointsScreen2_Up.Gradient_End_Color      = 0xFFFF;
  btn_SetpointsScreen2_Up.Color           = 0xC618;
  btn_SetpointsScreen2_Up.Press_Color     = 0x8410;
  btn_SetpointsScreen2_Up.Corner_Radius      = 0;
  btn_SetpointsScreen2_Up.OnUpPtr         = 0;
  btn_SetpointsScreen2_Up.OnDownPtr       = 0;
  btn_SetpointsScreen2_Up.OnClickPtr      = btn_SetpointsScreen2_UpOnClick;
  btn_SetpointsScreen2_Up.OnPressPtr      = 0;

  boxRound_SetpointsScreen2_BulkTimeSelectionBox.OwnerScreen     = &SetpointsScreen2;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Order           = 15;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Left            = 2;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Top             = 83;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Width           = 316;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Height          = 36;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Pen_Width       = 1;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Pen_Color       = 0x0000;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Visible         = 0;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Active          = 0;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Transparent     = 1;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Gradient        = 0;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Gradient_Orientation    = 0;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Gradient_Start_Color    = 0xFFFF;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Gradient_End_Color      = 0xFFFF;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Color           = 0xF567;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.PressColEnabled     = 1;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Press_Color     = 0x8410;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.Corner_Radius      = 0;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.OnUpPtr         = 0;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.OnDownPtr       = 0;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.OnClickPtr      = 0;
  boxRound_SetpointsScreen2_BulkTimeSelectionBox.OnPressPtr      = 0;

  lbl_SetpointsScreen2BulkTime_Name.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2BulkTime_Name.Order          = 16;
  lbl_SetpointsScreen2BulkTime_Name.Left           = 10;
  lbl_SetpointsScreen2BulkTime_Name.Top            = 90;
  lbl_SetpointsScreen2BulkTime_Name.Width          = 116;
  lbl_SetpointsScreen2BulkTime_Name.Height         = 24;
  lbl_SetpointsScreen2BulkTime_Name.Visible        = 1;
  lbl_SetpointsScreen2BulkTime_Name.Active         = 0;
  lbl_SetpointsScreen2BulkTime_Name.Caption        = lbl_SetpointsScreen2BulkTime_Name_Caption;
  lbl_SetpointsScreen2BulkTime_Name.FontName       = Helvetica19x22_Regular;
  lbl_SetpointsScreen2BulkTime_Name.Font_Color     = 0x0000;
  lbl_SetpointsScreen2BulkTime_Name.OnUpPtr         = 0;
  lbl_SetpointsScreen2BulkTime_Name.OnDownPtr       = 0;
  lbl_SetpointsScreen2BulkTime_Name.OnClickPtr      = 0;
  lbl_SetpointsScreen2BulkTime_Name.OnPressPtr      = 0;

  lbl_SetpointsScreen2BulkTime_Value.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2BulkTime_Value.Order          = 17;
  lbl_SetpointsScreen2BulkTime_Value.Left           = 220;
  lbl_SetpointsScreen2BulkTime_Value.Top            = 85;
  lbl_SetpointsScreen2BulkTime_Value.Width          = 116;
  lbl_SetpointsScreen2BulkTime_Value.Height         = 34;
  lbl_SetpointsScreen2BulkTime_Value.Visible        = 1;
  lbl_SetpointsScreen2BulkTime_Value.Active         = 0;
  lbl_SetpointsScreen2BulkTime_Value.Caption        = lbl_SetpointsScreen2BulkTime_Value_Caption;
  lbl_SetpointsScreen2BulkTime_Value.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen2BulkTime_Value.Font_Color     = 0x2124;
  lbl_SetpointsScreen2BulkTime_Value.OnUpPtr         = 0;
  lbl_SetpointsScreen2BulkTime_Value.OnDownPtr       = 0;
  lbl_SetpointsScreen2BulkTime_Value.OnClickPtr      = 0;
  lbl_SetpointsScreen2BulkTime_Value.OnPressPtr      = 0;

  lbl_SetpointsScreen2FloatVolt_Value.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2FloatVolt_Value.Order          = 18;
  lbl_SetpointsScreen2FloatVolt_Value.Left           = 220;
  lbl_SetpointsScreen2FloatVolt_Value.Top            = 123;
  lbl_SetpointsScreen2FloatVolt_Value.Width          = 111;
  lbl_SetpointsScreen2FloatVolt_Value.Height         = 34;
  lbl_SetpointsScreen2FloatVolt_Value.Visible        = 1;
  lbl_SetpointsScreen2FloatVolt_Value.Active         = 0;
  lbl_SetpointsScreen2FloatVolt_Value.Caption        = lbl_SetpointsScreen2FloatVolt_Value_Caption;
  lbl_SetpointsScreen2FloatVolt_Value.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen2FloatVolt_Value.Font_Color     = 0x2124;
  lbl_SetpointsScreen2FloatVolt_Value.OnUpPtr         = 0;
  lbl_SetpointsScreen2FloatVolt_Value.OnDownPtr       = 0;
  lbl_SetpointsScreen2FloatVolt_Value.OnClickPtr      = 0;
  lbl_SetpointsScreen2FloatVolt_Value.OnPressPtr      = 0;
  
  lbl_SetpointsScreen2BulkVolt_Desig.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2BulkVolt_Desig.Order          = 19;
  lbl_SetpointsScreen2BulkVolt_Desig.Left           = 290;
  lbl_SetpointsScreen2BulkVolt_Desig.Top            = 47;
  lbl_SetpointsScreen2BulkVolt_Desig.Width          = 24;
  lbl_SetpointsScreen2BulkVolt_Desig.Height         = 34;
  lbl_SetpointsScreen2BulkVolt_Desig.Visible        = 1;
  lbl_SetpointsScreen2BulkVolt_Desig.Active         = 0;
  lbl_SetpointsScreen2BulkVolt_Desig.Caption        = lbl_SetpointsScreen2BulkVolt_Desig_Caption;
  lbl_SetpointsScreen2BulkVolt_Desig.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen2BulkVolt_Desig.Font_Color     = 0x0000;
  lbl_SetpointsScreen2BulkVolt_Desig.OnUpPtr         = 0;
  lbl_SetpointsScreen2BulkVolt_Desig.OnDownPtr       = 0;
  lbl_SetpointsScreen2BulkVolt_Desig.OnClickPtr      = 0;
  lbl_SetpointsScreen2BulkVolt_Desig.OnPressPtr      = 0;

  lbl_SetpointsScreen2BulkTime_Desig.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2BulkTime_Desig.Order          = 20;
  lbl_SetpointsScreen2BulkTime_Desig.Left           = 287;
  lbl_SetpointsScreen2BulkTime_Desig.Top            = 85;
  lbl_SetpointsScreen2BulkTime_Desig.Width          = 24;
  lbl_SetpointsScreen2BulkTime_Desig.Height         = 34;
  lbl_SetpointsScreen2BulkTime_Desig.Visible        = 1;
  lbl_SetpointsScreen2BulkTime_Desig.Active         = 0;
  lbl_SetpointsScreen2BulkTime_Desig.Caption        = lbl_SetpointsScreen2BulkTime_Desig_Caption;
  lbl_SetpointsScreen2BulkTime_Desig.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen2BulkTime_Desig.Font_Color     = 0x0000;
  lbl_SetpointsScreen2BulkTime_Desig.OnUpPtr         = 0;
  lbl_SetpointsScreen2BulkTime_Desig.OnDownPtr       = 0;
  lbl_SetpointsScreen2BulkTime_Desig.OnClickPtr      = 0;
  lbl_SetpointsScreen2BulkTime_Desig.OnPressPtr      = 0;

  lbl_SetpointsScreen2FloatVolt_Desig.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2FloatVolt_Desig.Order          = 21;
  lbl_SetpointsScreen2FloatVolt_Desig.Left           = 290;
  lbl_SetpointsScreen2FloatVolt_Desig.Top            = 123;
  lbl_SetpointsScreen2FloatVolt_Desig.Width          = 24;
  lbl_SetpointsScreen2FloatVolt_Desig.Height         = 34;
  lbl_SetpointsScreen2FloatVolt_Desig.Visible        = 1;
  lbl_SetpointsScreen2FloatVolt_Desig.Active         = 0;
  lbl_SetpointsScreen2FloatVolt_Desig.Caption        = lbl_SetpointsScreen2FloatVolt_Desig_Caption;
  lbl_SetpointsScreen2FloatVolt_Desig.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen2FloatVolt_Desig.Font_Color     = 0x0000;
  lbl_SetpointsScreen2FloatVolt_Desig.OnUpPtr         = 0;
  lbl_SetpointsScreen2FloatVolt_Desig.OnDownPtr       = 0;
  lbl_SetpointsScreen2FloatVolt_Desig.OnClickPtr      = 0;
  lbl_SetpointsScreen2FloatVolt_Desig.OnPressPtr      = 0;

  lbl_SetpointsScreen2BulkResetVolt_Desig.OwnerScreen     = &SetpointsScreen2;
  lbl_SetpointsScreen2BulkResetVolt_Desig.Order          = 22;
  lbl_SetpointsScreen2BulkResetVolt_Desig.Left           = 290;
  lbl_SetpointsScreen2BulkResetVolt_Desig.Top            = 161;
  lbl_SetpointsScreen2BulkResetVolt_Desig.Width          = 24;
  lbl_SetpointsScreen2BulkResetVolt_Desig.Height         = 34;
  lbl_SetpointsScreen2BulkResetVolt_Desig.Visible        = 1;
  lbl_SetpointsScreen2BulkResetVolt_Desig.Active         = 0;
  lbl_SetpointsScreen2BulkResetVolt_Desig.Caption        = lbl_SetpointsScreen2BulkResetVolt_Desig_Caption;
  lbl_SetpointsScreen2BulkResetVolt_Desig.FontName       = Helvetica28x32_Regular;
  lbl_SetpointsScreen2BulkResetVolt_Desig.Font_Color     = 0x0000;
  lbl_SetpointsScreen2BulkResetVolt_Desig.OnUpPtr         = 0;
  lbl_SetpointsScreen2BulkResetVolt_Desig.OnDownPtr       = 0;
  lbl_SetpointsScreen2BulkResetVolt_Desig.OnClickPtr      = 0;
  lbl_SetpointsScreen2BulkResetVolt_Desig.OnPressPtr      = 0;

  boxRound_SetpointsEditScreen_BackgroundPanel.OwnerScreen     = &SetpointsEditScreen;
  boxRound_SetpointsEditScreen_BackgroundPanel.Order           = 0;
  boxRound_SetpointsEditScreen_BackgroundPanel.Left            = 2;
  boxRound_SetpointsEditScreen_BackgroundPanel.Top             = 45;
  boxRound_SetpointsEditScreen_BackgroundPanel.Width           = 316;
  boxRound_SetpointsEditScreen_BackgroundPanel.Height          = 150;
  boxRound_SetpointsEditScreen_BackgroundPanel.Pen_Width       = 0;
  boxRound_SetpointsEditScreen_BackgroundPanel.Pen_Color       = 0x0000;
  boxRound_SetpointsEditScreen_BackgroundPanel.Visible         = 1;
  boxRound_SetpointsEditScreen_BackgroundPanel.Active          = 0;
  boxRound_SetpointsEditScreen_BackgroundPanel.Transparent     = 1;
  boxRound_SetpointsEditScreen_BackgroundPanel.Gradient        = 0;
  boxRound_SetpointsEditScreen_BackgroundPanel.Gradient_Orientation    = 0;
  boxRound_SetpointsEditScreen_BackgroundPanel.Gradient_Start_Color    = 0xFFFF;
  boxRound_SetpointsEditScreen_BackgroundPanel.Gradient_End_Color      = 0xFFFF;
  boxRound_SetpointsEditScreen_BackgroundPanel.Color           = 0xFFFF;
  boxRound_SetpointsEditScreen_BackgroundPanel.PressColEnabled     = 1;
  boxRound_SetpointsEditScreen_BackgroundPanel.Press_Color     = 0x8410;
  boxRound_SetpointsEditScreen_BackgroundPanel.Corner_Radius      = 0;
  boxRound_SetpointsEditScreen_BackgroundPanel.OnUpPtr         = 0;
  boxRound_SetpointsEditScreen_BackgroundPanel.OnDownPtr       = 0;
  boxRound_SetpointsEditScreen_BackgroundPanel.OnClickPtr      = 0;
  boxRound_SetpointsEditScreen_BackgroundPanel.OnPressPtr      = 0;

  lbl_SetpointsEditScreen_DigType.OwnerScreen     = &SetpointsEditScreen;
  lbl_SetpointsEditScreen_DigType.Order          = 1;
  lbl_SetpointsEditScreen_DigType.Left           = 283;
  lbl_SetpointsEditScreen_DigType.Top            = 52;
  lbl_SetpointsEditScreen_DigType.Width          = 32;
  lbl_SetpointsEditScreen_DigType.Height         = 14;
  lbl_SetpointsEditScreen_DigType.Visible        = 1;
  lbl_SetpointsEditScreen_DigType.Active         = 1;
  lbl_SetpointsEditScreen_DigType.Caption        = lbl_SetpointsEditScreen_DigType_Caption;
  lbl_SetpointsEditScreen_DigType.FontName       = Helvetica11x14_Bold;
  lbl_SetpointsEditScreen_DigType.Font_Color     = 0x0000;
  lbl_SetpointsEditScreen_DigType.OnUpPtr         = 0;
  lbl_SetpointsEditScreen_DigType.OnDownPtr       = 0;
  lbl_SetpointsEditScreen_DigType.OnClickPtr      = 0;
  lbl_SetpointsEditScreen_DigType.OnPressPtr      = 0;

  lbl_SetpointsEditScreen_Digit5.OwnerScreen     = &SetpointsEditScreen;
  lbl_SetpointsEditScreen_Digit5.Order          = 2;
  lbl_SetpointsEditScreen_Digit5.Left           = 255;
  lbl_SetpointsEditScreen_Digit5.Top            = 70;
  lbl_SetpointsEditScreen_Digit5.Width          = 60;
  lbl_SetpointsEditScreen_Digit5.Height         = 129;
  lbl_SetpointsEditScreen_Digit5.Visible        = 1;
  lbl_SetpointsEditScreen_Digit5.Active         = 1;
  lbl_SetpointsEditScreen_Digit5.Caption        = lbl_SetpointsEditScreen_Digit5_Caption;
  lbl_SetpointsEditScreen_Digit5.FontName       = Helvetica106x116_Regular;
  lbl_SetpointsEditScreen_Digit5.Font_Color     = 0x0000;
  lbl_SetpointsEditScreen_Digit5.OnUpPtr         = 0;
  lbl_SetpointsEditScreen_Digit5.OnDownPtr       = 0;
  lbl_SetpointsEditScreen_Digit5.OnClickPtr      = lbl_SetpointsEditScreen_Digit5OnClick;
  lbl_SetpointsEditScreen_Digit5.OnPressPtr      = 0;

  lbl_SetpointsEditScreen_Digit4.OwnerScreen     = &SetpointsEditScreen;
  lbl_SetpointsEditScreen_Digit4.Order          = 3;
  lbl_SetpointsEditScreen_Digit4.Left           = 198;
  lbl_SetpointsEditScreen_Digit4.Top            = 70;
  lbl_SetpointsEditScreen_Digit4.Width          = 60;
  lbl_SetpointsEditScreen_Digit4.Height         = 129;
  lbl_SetpointsEditScreen_Digit4.Visible        = 1;
  lbl_SetpointsEditScreen_Digit4.Active         = 1;
  lbl_SetpointsEditScreen_Digit4.Caption        = lbl_SetpointsEditScreen_Digit4_Caption;
  lbl_SetpointsEditScreen_Digit4.FontName       = Helvetica106x116_Regular;
  lbl_SetpointsEditScreen_Digit4.Font_Color     = 0x0000;
  lbl_SetpointsEditScreen_Digit4.OnUpPtr         = 0;
  lbl_SetpointsEditScreen_Digit4.OnDownPtr       = 0;
  lbl_SetpointsEditScreen_Digit4.OnClickPtr      = lbl_SetpointsEditScreen_Digit4OnClick;
  lbl_SetpointsEditScreen_Digit4.OnPressPtr      = 0;

  lbl_SetpointsEditScreen_Decimal.OwnerScreen     = &SetpointsEditScreen;
  lbl_SetpointsEditScreen_Decimal.Order          = 4;
  lbl_SetpointsEditScreen_Decimal.Left           = 176;
  lbl_SetpointsEditScreen_Decimal.Top            = 70;
  lbl_SetpointsEditScreen_Decimal.Width          = 30;
  lbl_SetpointsEditScreen_Decimal.Height         = 129;
  lbl_SetpointsEditScreen_Decimal.Visible        = 1;
  lbl_SetpointsEditScreen_Decimal.Active         = 0;
  lbl_SetpointsEditScreen_Decimal.Caption        = lbl_SetpointsEditScreen_Decimal_Caption;
  lbl_SetpointsEditScreen_Decimal.FontName       = Helvetica106x116_Regular;
  lbl_SetpointsEditScreen_Decimal.Font_Color     = 0x0000;
  lbl_SetpointsEditScreen_Decimal.OnUpPtr         = 0;
  lbl_SetpointsEditScreen_Decimal.OnDownPtr       = 0;
  lbl_SetpointsEditScreen_Decimal.OnClickPtr      = 0;
  lbl_SetpointsEditScreen_Decimal.OnPressPtr      = 0;

  lbl_SetpointsEditScreen_Digit3.OwnerScreen     = &SetpointsEditScreen;
  lbl_SetpointsEditScreen_Digit3.Order          = 5;
  lbl_SetpointsEditScreen_Digit3.Left           = 126;
  lbl_SetpointsEditScreen_Digit3.Top            = 70;
  lbl_SetpointsEditScreen_Digit3.Width          = 60;
  lbl_SetpointsEditScreen_Digit3.Height         = 129;
  lbl_SetpointsEditScreen_Digit3.Visible        = 1;
  lbl_SetpointsEditScreen_Digit3.Active         = 1;
  lbl_SetpointsEditScreen_Digit3.Caption        = lbl_SetpointsEditScreen_Digit3_Caption;
  lbl_SetpointsEditScreen_Digit3.FontName       = Helvetica106x116_Regular;
  lbl_SetpointsEditScreen_Digit3.Font_Color     = 0x0000;
  lbl_SetpointsEditScreen_Digit3.OnUpPtr         = 0;
  lbl_SetpointsEditScreen_Digit3.OnDownPtr       = 0;
  lbl_SetpointsEditScreen_Digit3.OnClickPtr      = lbl_SetpointsEditScreen_Digit3OnClick;
  lbl_SetpointsEditScreen_Digit3.OnPressPtr      = 0;

  lbl_SetpointsEditScreen_Digit2.OwnerScreen     = &SetpointsEditScreen;
  lbl_SetpointsEditScreen_Digit2.Order          = 6;
  lbl_SetpointsEditScreen_Digit2.Left           = 65;
  lbl_SetpointsEditScreen_Digit2.Top            = 70;
  lbl_SetpointsEditScreen_Digit2.Width          = 60;
  lbl_SetpointsEditScreen_Digit2.Height         = 129;
  lbl_SetpointsEditScreen_Digit2.Visible        = 1;
  lbl_SetpointsEditScreen_Digit2.Active         = 1;
  lbl_SetpointsEditScreen_Digit2.Caption        = lbl_SetpointsEditScreen_Digit2_Caption;
  lbl_SetpointsEditScreen_Digit2.FontName       = Helvetica106x116_Regular;
  lbl_SetpointsEditScreen_Digit2.Font_Color     = 0x0000;
  lbl_SetpointsEditScreen_Digit2.OnUpPtr         = 0;
  lbl_SetpointsEditScreen_Digit2.OnDownPtr       = 0;
  lbl_SetpointsEditScreen_Digit2.OnClickPtr      = lbl_SetpointsEditScreen_Digit2OnClick;
  lbl_SetpointsEditScreen_Digit2.OnPressPtr      = 0;

  lbl_SetpointsEditScreen_Digit1.OwnerScreen     = &SetpointsEditScreen;
  lbl_SetpointsEditScreen_Digit1.Order          = 7;
  lbl_SetpointsEditScreen_Digit1.Left           = 10;
  lbl_SetpointsEditScreen_Digit1.Top            = 70;
  lbl_SetpointsEditScreen_Digit1.Width          = 60;
  lbl_SetpointsEditScreen_Digit1.Height         = 129;
  lbl_SetpointsEditScreen_Digit1.Visible        = 1;
  lbl_SetpointsEditScreen_Digit1.Active         = 1;
  lbl_SetpointsEditScreen_Digit1.Caption        = lbl_SetpointsEditScreen_Digit1_Caption;
  lbl_SetpointsEditScreen_Digit1.FontName       = Helvetica106x116_Regular;
  lbl_SetpointsEditScreen_Digit1.Font_Color     = 0x0000;
  lbl_SetpointsEditScreen_Digit1.OnUpPtr         = 0;
  lbl_SetpointsEditScreen_Digit1.OnDownPtr       = 0;
  lbl_SetpointsEditScreen_Digit1.OnClickPtr      = lbl_SetpointsEditScreen_Digit1OnClick;
  lbl_SetpointsEditScreen_Digit1.OnPressPtr      = 0;

  btn_SetpointsEditScreen_Accept.OwnerScreen     = &SetpointsEditScreen;
  btn_SetpointsEditScreen_Accept.Order           = 8;
  btn_SetpointsEditScreen_Accept.Left            = 242;
  btn_SetpointsEditScreen_Accept.Top             = 198;
  btn_SetpointsEditScreen_Accept.Width           = 76;
  btn_SetpointsEditScreen_Accept.Height          = 39;
  btn_SetpointsEditScreen_Accept.Pen_Width       = 0;
  btn_SetpointsEditScreen_Accept.Pen_Color       = 0x0000;
  btn_SetpointsEditScreen_Accept.Visible         = 1;
  btn_SetpointsEditScreen_Accept.Active          = 1;
  btn_SetpointsEditScreen_Accept.Transparent     = 1;
  btn_SetpointsEditScreen_Accept.Caption         = btn_SetpointsEditScreen_Accept_Caption;
  btn_SetpointsEditScreen_Accept.TextAlign             = _taCenter;
  btn_SetpointsEditScreen_Accept.FontName        = Helvetica16x19_Bold;
  btn_SetpointsEditScreen_Accept.PressColEnabled = 1;
  btn_SetpointsEditScreen_Accept.Font_Color      = 0x0000;
  btn_SetpointsEditScreen_Accept.Gradient        = 1;
  btn_SetpointsEditScreen_Accept.Gradient_Orientation    = 0;
  btn_SetpointsEditScreen_Accept.Gradient_Start_Color    = 0x5E88;
  btn_SetpointsEditScreen_Accept.Gradient_End_Color      = 0x5E88;
  btn_SetpointsEditScreen_Accept.Color           = 0xC618;
  btn_SetpointsEditScreen_Accept.Press_Color     = 0x8410;
  btn_SetpointsEditScreen_Accept.Corner_Radius      = 0;
  btn_SetpointsEditScreen_Accept.OnUpPtr         = 0;
  btn_SetpointsEditScreen_Accept.OnDownPtr       = 0;
  btn_SetpointsEditScreen_Accept.OnClickPtr      = btn_SetpointsEditScreen_AcceptOnClick;
  btn_SetpointsEditScreen_Accept.OnPressPtr      = 0;

  btn_SetpointsEditScreen_Down.OwnerScreen     = &SetpointsEditScreen;
  btn_SetpointsEditScreen_Down.Order           = 9;
  btn_SetpointsEditScreen_Down.Left            = 161;
  btn_SetpointsEditScreen_Down.Top             = 198;
  btn_SetpointsEditScreen_Down.Width           = 78;
  btn_SetpointsEditScreen_Down.Height          = 39;
  btn_SetpointsEditScreen_Down.Pen_Width       = 0;
  btn_SetpointsEditScreen_Down.Pen_Color       = 0x0000;
  btn_SetpointsEditScreen_Down.Visible         = 1;
  btn_SetpointsEditScreen_Down.Active          = 1;
  btn_SetpointsEditScreen_Down.Transparent     = 1;
  btn_SetpointsEditScreen_Down.Caption         = btn_SetpointsEditScreen_Down_Caption;
  btn_SetpointsEditScreen_Down.TextAlign             = _taCenter;
  btn_SetpointsEditScreen_Down.FontName        = Helvetica16x19_Bold;
  btn_SetpointsEditScreen_Down.PressColEnabled = 1;
  btn_SetpointsEditScreen_Down.Font_Color      = 0x0000;
  btn_SetpointsEditScreen_Down.Gradient        = 1;
  btn_SetpointsEditScreen_Down.Gradient_Orientation    = 0;
  btn_SetpointsEditScreen_Down.Gradient_Start_Color    = 0xFFFF;
  btn_SetpointsEditScreen_Down.Gradient_End_Color      = 0xFFFF;
  btn_SetpointsEditScreen_Down.Color           = 0xC618;
  btn_SetpointsEditScreen_Down.Press_Color     = 0x8410;
  btn_SetpointsEditScreen_Down.Corner_Radius      = 0;
  btn_SetpointsEditScreen_Down.OnUpPtr         = 0;
  btn_SetpointsEditScreen_Down.OnDownPtr       = 0;
  btn_SetpointsEditScreen_Down.OnClickPtr      = btn_SetpointsEditScreen_DownOnClick;
  btn_SetpointsEditScreen_Down.OnPressPtr      = 0;

  btn_SetpointsEditScreen_Next.OwnerScreen     = &SetpointsEditScreen;
  btn_SetpointsEditScreen_Next.Order           = 10;
  btn_SetpointsEditScreen_Next.Left            = 2;
  btn_SetpointsEditScreen_Next.Top             = 198;
  btn_SetpointsEditScreen_Next.Width           = 76;
  btn_SetpointsEditScreen_Next.Height          = 39;
  btn_SetpointsEditScreen_Next.Pen_Width       = 0;
  btn_SetpointsEditScreen_Next.Pen_Color       = 0x0000;
  btn_SetpointsEditScreen_Next.Visible         = 1;
  btn_SetpointsEditScreen_Next.Active          = 1;
  btn_SetpointsEditScreen_Next.Transparent     = 1;
  btn_SetpointsEditScreen_Next.Caption         = btn_SetpointsEditScreen_Next_Caption;
  btn_SetpointsEditScreen_Next.TextAlign             = _taCenter;
  btn_SetpointsEditScreen_Next.FontName        = Helvetica16x19_Bold;
  btn_SetpointsEditScreen_Next.PressColEnabled = 1;
  btn_SetpointsEditScreen_Next.Font_Color      = 0x0000;
  btn_SetpointsEditScreen_Next.Gradient        = 1;
  btn_SetpointsEditScreen_Next.Gradient_Orientation    = 0;
  btn_SetpointsEditScreen_Next.Gradient_Start_Color    = 0xF567;
  btn_SetpointsEditScreen_Next.Gradient_End_Color      = 0xF567;
  btn_SetpointsEditScreen_Next.Color           = 0xC618;
  btn_SetpointsEditScreen_Next.Press_Color     = 0x8410;
  btn_SetpointsEditScreen_Next.Corner_Radius      = 0;
  btn_SetpointsEditScreen_Next.OnUpPtr         = 0;
  btn_SetpointsEditScreen_Next.OnDownPtr       = 0;
  btn_SetpointsEditScreen_Next.OnClickPtr      = btn_SetpointsEditScreen_NextOnClick;
  btn_SetpointsEditScreen_Next.OnPressPtr      = 0;

  btn_SetpointsEditScreen_Cancel.OwnerScreen     = &SetpointsEditScreen;
  btn_SetpointsEditScreen_Cancel.Order           = 11;
  btn_SetpointsEditScreen_Cancel.Left            = 2;
  btn_SetpointsEditScreen_Cancel.Top             = 3;
  btn_SetpointsEditScreen_Cancel.Width           = 76;
  btn_SetpointsEditScreen_Cancel.Height          = 39;
  btn_SetpointsEditScreen_Cancel.Pen_Width       = 1;
  btn_SetpointsEditScreen_Cancel.Pen_Color       = 0x0000;
  btn_SetpointsEditScreen_Cancel.Visible         = 1;
  btn_SetpointsEditScreen_Cancel.Active          = 1;
  btn_SetpointsEditScreen_Cancel.Transparent     = 1;
  btn_SetpointsEditScreen_Cancel.Caption         = btn_SetpointsEditScreen_Cancel_Caption;
  btn_SetpointsEditScreen_Cancel.TextAlign             = _taCenter;
  btn_SetpointsEditScreen_Cancel.FontName        = Helvetica16x19_Bold;
  btn_SetpointsEditScreen_Cancel.PressColEnabled = 1;
  btn_SetpointsEditScreen_Cancel.Font_Color      = 0x0000;
  btn_SetpointsEditScreen_Cancel.Gradient        = 1;
  btn_SetpointsEditScreen_Cancel.Gradient_Orientation    = 0;
  btn_SetpointsEditScreen_Cancel.Gradient_Start_Color    = 0xFFFF;
  btn_SetpointsEditScreen_Cancel.Gradient_End_Color      = 0xFFFF;
  btn_SetpointsEditScreen_Cancel.Color           = 0xC618;
  btn_SetpointsEditScreen_Cancel.Press_Color     = 0x8410;
  btn_SetpointsEditScreen_Cancel.Corner_Radius      = 0;
  btn_SetpointsEditScreen_Cancel.OnUpPtr         = 0;
  btn_SetpointsEditScreen_Cancel.OnDownPtr       = 0;
  btn_SetpointsEditScreen_Cancel.OnClickPtr      = btn_SetpointsEditScreen_CancelOnClick;
  btn_SetpointsEditScreen_Cancel.OnPressPtr      = 0;

  lbl_SetpointsEditScreen_ScreenTitle.OwnerScreen     = &SetpointsEditScreen;
  lbl_SetpointsEditScreen_ScreenTitle.Order          = 12;
  lbl_SetpointsEditScreen_ScreenTitle.Left           = 105;
  lbl_SetpointsEditScreen_ScreenTitle.Top            = 10;
  lbl_SetpointsEditScreen_ScreenTitle.Width          = 196;
  lbl_SetpointsEditScreen_ScreenTitle.Height         = 26;
  lbl_SetpointsEditScreen_ScreenTitle.Visible        = 1;
  lbl_SetpointsEditScreen_ScreenTitle.Active         = 0;
  lbl_SetpointsEditScreen_ScreenTitle.Caption        = lbl_SetpointsEditScreen_ScreenTitle_Caption;
  lbl_SetpointsEditScreen_ScreenTitle.FontName       = Helvetica21x24_Bold;
  lbl_SetpointsEditScreen_ScreenTitle.Font_Color     = 0xF79E;
  lbl_SetpointsEditScreen_ScreenTitle.OnUpPtr         = 0;
  lbl_SetpointsEditScreen_ScreenTitle.OnDownPtr       = 0;
  lbl_SetpointsEditScreen_ScreenTitle.OnClickPtr      = 0;
  lbl_SetpointsEditScreen_ScreenTitle.OnPressPtr      = 0;

  btn_SetpointsEditScreen_Up.OwnerScreen     = &SetpointsEditScreen;
  btn_SetpointsEditScreen_Up.Order           = 13;
  btn_SetpointsEditScreen_Up.Left            = 81;
  btn_SetpointsEditScreen_Up.Top             = 198;
  btn_SetpointsEditScreen_Up.Width           = 78;
  btn_SetpointsEditScreen_Up.Height          = 39;
  btn_SetpointsEditScreen_Up.Pen_Width       = 0;
  btn_SetpointsEditScreen_Up.Pen_Color       = 0x0000;
  btn_SetpointsEditScreen_Up.Visible         = 1;
  btn_SetpointsEditScreen_Up.Active          = 1;
  btn_SetpointsEditScreen_Up.Transparent     = 1;
  btn_SetpointsEditScreen_Up.Caption         = btn_SetpointsEditScreen_Up_Caption;
  btn_SetpointsEditScreen_Up.TextAlign             = _taCenter;
  btn_SetpointsEditScreen_Up.FontName        = Helvetica16x19_Bold;
  btn_SetpointsEditScreen_Up.PressColEnabled = 1;
  btn_SetpointsEditScreen_Up.Font_Color      = 0x0000;
  btn_SetpointsEditScreen_Up.Gradient        = 1;
  btn_SetpointsEditScreen_Up.Gradient_Orientation    = 0;
  btn_SetpointsEditScreen_Up.Gradient_Start_Color    = 0xFFFF;
  btn_SetpointsEditScreen_Up.Gradient_End_Color      = 0xFFFF;
  btn_SetpointsEditScreen_Up.Color           = 0xC618;
  btn_SetpointsEditScreen_Up.Press_Color     = 0x8410;
  btn_SetpointsEditScreen_Up.Corner_Radius      = 0;
  btn_SetpointsEditScreen_Up.OnUpPtr         = 0;
  btn_SetpointsEditScreen_Up.OnDownPtr       = 0;
  btn_SetpointsEditScreen_Up.OnClickPtr      = btn_SetpointsEditScreen_UpOnClick;
  btn_SetpointsEditScreen_Up.OnPressPtr      = 0;

  lbl_TimeDateEditScreen_ScreenTitle.OwnerScreen     = &TimeDateEditScreen;
  lbl_TimeDateEditScreen_ScreenTitle.Order          = 0;
  lbl_TimeDateEditScreen_ScreenTitle.Left           = 100;
  lbl_TimeDateEditScreen_ScreenTitle.Top            = 20;
  lbl_TimeDateEditScreen_ScreenTitle.Width          = 129;
  lbl_TimeDateEditScreen_ScreenTitle.Height         = 26;
  lbl_TimeDateEditScreen_ScreenTitle.Visible        = 1;
  lbl_TimeDateEditScreen_ScreenTitle.Active         = 1;
  lbl_TimeDateEditScreen_ScreenTitle.Caption        = lbl_TimeDateEditScreen_ScreenTitle_Caption;
  lbl_TimeDateEditScreen_ScreenTitle.FontName       = Helvetica21x24_Bold;
  lbl_TimeDateEditScreen_ScreenTitle.Font_Color     = 0xF79E;
  lbl_TimeDateEditScreen_ScreenTitle.OnUpPtr         = 0;
  lbl_TimeDateEditScreen_ScreenTitle.OnDownPtr       = 0;
  lbl_TimeDateEditScreen_ScreenTitle.OnClickPtr      = 0;
  lbl_TimeDateEditScreen_ScreenTitle.OnPressPtr      = 0;

  btn_TimeDateEditScreen_TimeSelect.OwnerScreen     = &TimeDateEditScreen;
  btn_TimeDateEditScreen_TimeSelect.Order           = 1;
  btn_TimeDateEditScreen_TimeSelect.Left            = 60;
  btn_TimeDateEditScreen_TimeSelect.Top             = 65;
  btn_TimeDateEditScreen_TimeSelect.Width           = 200;
  btn_TimeDateEditScreen_TimeSelect.Height          = 55;
  btn_TimeDateEditScreen_TimeSelect.Pen_Width       = 1;
  btn_TimeDateEditScreen_TimeSelect.Pen_Color       = 0x0000;
  btn_TimeDateEditScreen_TimeSelect.Visible         = 1;
  btn_TimeDateEditScreen_TimeSelect.Active          = 1;
  btn_TimeDateEditScreen_TimeSelect.Transparent     = 1;
  btn_TimeDateEditScreen_TimeSelect.Caption         = btn_TimeDateEditScreen_TimeSelect_Caption;
  btn_TimeDateEditScreen_TimeSelect.TextAlign             = _taCenter;
  btn_TimeDateEditScreen_TimeSelect.FontName        = Helvetica16x19_Bold;
  btn_TimeDateEditScreen_TimeSelect.PressColEnabled = 1;
  btn_TimeDateEditScreen_TimeSelect.Font_Color      = 0x0000;
  btn_TimeDateEditScreen_TimeSelect.Gradient        = 1;
  btn_TimeDateEditScreen_TimeSelect.Gradient_Orientation    = 0;
  btn_TimeDateEditScreen_TimeSelect.Gradient_Start_Color    = 0xFFFF;
  btn_TimeDateEditScreen_TimeSelect.Gradient_End_Color      = 0xFFFF;
  btn_TimeDateEditScreen_TimeSelect.Color           = 0xC618;
  btn_TimeDateEditScreen_TimeSelect.Press_Color     = 0x8410;
  btn_TimeDateEditScreen_TimeSelect.Corner_Radius      = 0;
  btn_TimeDateEditScreen_TimeSelect.OnUpPtr         = 0;
  btn_TimeDateEditScreen_TimeSelect.OnDownPtr       = 0;
  btn_TimeDateEditScreen_TimeSelect.OnClickPtr      = btn_TimeDateEditScreen_TimeSelectOnClick;
  btn_TimeDateEditScreen_TimeSelect.OnPressPtr      = 0;

  btn_TimeDateEditScreen_DateSelect.OwnerScreen     = &TimeDateEditScreen;
  btn_TimeDateEditScreen_DateSelect.Order           = 2;
  btn_TimeDateEditScreen_DateSelect.Left            = 60;
  btn_TimeDateEditScreen_DateSelect.Top             = 130;
  btn_TimeDateEditScreen_DateSelect.Width           = 200;
  btn_TimeDateEditScreen_DateSelect.Height          = 55;
  btn_TimeDateEditScreen_DateSelect.Pen_Width       = 1;
  btn_TimeDateEditScreen_DateSelect.Pen_Color       = 0x0000;
  btn_TimeDateEditScreen_DateSelect.Visible         = 1;
  btn_TimeDateEditScreen_DateSelect.Active          = 1;
  btn_TimeDateEditScreen_DateSelect.Transparent     = 1;
  btn_TimeDateEditScreen_DateSelect.Caption         = btn_TimeDateEditScreen_DateSelect_Caption;
  btn_TimeDateEditScreen_DateSelect.TextAlign             = _taCenter;
  btn_TimeDateEditScreen_DateSelect.FontName        = Helvetica16x19_Bold;
  btn_TimeDateEditScreen_DateSelect.PressColEnabled = 1;
  btn_TimeDateEditScreen_DateSelect.Font_Color      = 0x0000;
  btn_TimeDateEditScreen_DateSelect.Gradient        = 1;
  btn_TimeDateEditScreen_DateSelect.Gradient_Orientation    = 0;
  btn_TimeDateEditScreen_DateSelect.Gradient_Start_Color    = 0xFFFF;
  btn_TimeDateEditScreen_DateSelect.Gradient_End_Color      = 0xFFFF;
  btn_TimeDateEditScreen_DateSelect.Color           = 0xC618;
  btn_TimeDateEditScreen_DateSelect.Press_Color     = 0x8410;
  btn_TimeDateEditScreen_DateSelect.Corner_Radius      = 0;
  btn_TimeDateEditScreen_DateSelect.OnUpPtr         = 0;
  btn_TimeDateEditScreen_DateSelect.OnDownPtr       = 0;
  btn_TimeDateEditScreen_DateSelect.OnClickPtr      = btn_TimeDateEditScreen_DateSelectOnClick;
  btn_TimeDateEditScreen_DateSelect.OnPressPtr      = 0;

  Diagram8_Label68.OwnerScreen     = &TimeDateEditScreen;
  Diagram8_Label68.Order          = 3;
  Diagram8_Label68.Left           = 98;
  Diagram8_Label68.Top            = 172;
  Diagram8_Label68.Width          = -7;
  Diagram8_Label68.Height         = 50;
  Diagram8_Label68.Visible        = 1;
  Diagram8_Label68.Active         = 1;
  Diagram8_Label68.Caption        = Diagram8_Label68_Caption;
  Diagram8_Label68.FontName       = Tahoma25x25_Bold;
  Diagram8_Label68.Font_Color     = 0x0000;
  Diagram8_Label68.OnUpPtr         = 0;
  Diagram8_Label68.OnDownPtr       = 0;
  Diagram8_Label68.OnClickPtr      = 0;
  Diagram8_Label68.OnPressPtr      = 0;

  btn_TimedDateEditScreen_Back.OwnerScreen     = &TimeDateEditScreen;
  btn_TimedDateEditScreen_Back.Order           = 4;
  btn_TimedDateEditScreen_Back.Left            = 5;
  btn_TimedDateEditScreen_Back.Top             = 5;
  btn_TimedDateEditScreen_Back.Width           = 60;
  btn_TimedDateEditScreen_Back.Height          = 33;
  btn_TimedDateEditScreen_Back.Pen_Width       = 1;
  btn_TimedDateEditScreen_Back.Pen_Color       = 0x0000;
  btn_TimedDateEditScreen_Back.Visible         = 1;
  btn_TimedDateEditScreen_Back.Active          = 1;
  btn_TimedDateEditScreen_Back.Transparent     = 1;
  btn_TimedDateEditScreen_Back.Caption         = btn_TimedDateEditScreen_Back_Caption;
  btn_TimedDateEditScreen_Back.TextAlign             = _taCenter;
  btn_TimedDateEditScreen_Back.FontName        = Helvetica11x14_Bold;
  btn_TimedDateEditScreen_Back.PressColEnabled = 1;
  btn_TimedDateEditScreen_Back.Font_Color      = 0x0000;
  btn_TimedDateEditScreen_Back.Gradient        = 1;
  btn_TimedDateEditScreen_Back.Gradient_Orientation    = 0;
  btn_TimedDateEditScreen_Back.Gradient_Start_Color    = 0xFFFF;
  btn_TimedDateEditScreen_Back.Gradient_End_Color      = 0xFFFF;
  btn_TimedDateEditScreen_Back.Color           = 0xC618;
  btn_TimedDateEditScreen_Back.Press_Color     = 0x8410;
  btn_TimedDateEditScreen_Back.Corner_Radius      = 0;
  btn_TimedDateEditScreen_Back.OnUpPtr         = 0;
  btn_TimedDateEditScreen_Back.OnDownPtr       = 0;
  btn_TimedDateEditScreen_Back.OnClickPtr      = btn_TimedDateEditScreen_BackOnClick;
  btn_TimedDateEditScreen_Back.OnPressPtr      = 0;

  boxRound_TimeEditScreen_BackgroundPanel.OwnerScreen     = &TimeEditScreen;
  boxRound_TimeEditScreen_BackgroundPanel.Order           = 0;
  boxRound_TimeEditScreen_BackgroundPanel.Left            = 2;
  boxRound_TimeEditScreen_BackgroundPanel.Top             = 44;
  boxRound_TimeEditScreen_BackgroundPanel.Width           = 316;
  boxRound_TimeEditScreen_BackgroundPanel.Height          = 151;
  boxRound_TimeEditScreen_BackgroundPanel.Pen_Width       = 0;
  boxRound_TimeEditScreen_BackgroundPanel.Pen_Color       = 0x0000;
  boxRound_TimeEditScreen_BackgroundPanel.Visible         = 1;
  boxRound_TimeEditScreen_BackgroundPanel.Active          = 0;
  boxRound_TimeEditScreen_BackgroundPanel.Transparent     = 1;
  boxRound_TimeEditScreen_BackgroundPanel.Gradient        = 0;
  boxRound_TimeEditScreen_BackgroundPanel.Gradient_Orientation    = 0;
  boxRound_TimeEditScreen_BackgroundPanel.Gradient_Start_Color    = 0xFFFF;
  boxRound_TimeEditScreen_BackgroundPanel.Gradient_End_Color      = 0xFFFF;
  boxRound_TimeEditScreen_BackgroundPanel.Color           = 0xFFFF;
  boxRound_TimeEditScreen_BackgroundPanel.PressColEnabled     = 1;
  boxRound_TimeEditScreen_BackgroundPanel.Press_Color     = 0x8410;
  boxRound_TimeEditScreen_BackgroundPanel.Corner_Radius      = 0;
  boxRound_TimeEditScreen_BackgroundPanel.OnUpPtr         = 0;
  boxRound_TimeEditScreen_BackgroundPanel.OnDownPtr       = 0;
  boxRound_TimeEditScreen_BackgroundPanel.OnClickPtr      = 0;
  boxRound_TimeEditScreen_BackgroundPanel.OnPressPtr      = 0;

  lbl_TimeEditScreen_ScreenTitle.OwnerScreen     = &TimeEditScreen;
  lbl_TimeEditScreen_ScreenTitle.Order          = 1;
  lbl_TimeEditScreen_ScreenTitle.Left           = 125;
  lbl_TimeEditScreen_ScreenTitle.Top            = 10;
  lbl_TimeEditScreen_ScreenTitle.Width          = 100;
  lbl_TimeEditScreen_ScreenTitle.Height         = 26;
  lbl_TimeEditScreen_ScreenTitle.Visible        = 1;
  lbl_TimeEditScreen_ScreenTitle.Active         = 1;
  lbl_TimeEditScreen_ScreenTitle.Caption        = lbl_TimeEditScreen_ScreenTitle_Caption;
  lbl_TimeEditScreen_ScreenTitle.FontName       = Helvetica21x24_Bold;
  lbl_TimeEditScreen_ScreenTitle.Font_Color     = 0xF79E;
  lbl_TimeEditScreen_ScreenTitle.OnUpPtr         = 0;
  lbl_TimeEditScreen_ScreenTitle.OnDownPtr       = 0;
  lbl_TimeEditScreen_ScreenTitle.OnClickPtr      = 0;
  lbl_TimeEditScreen_ScreenTitle.OnPressPtr      = 0;

  btn_TimedEditScreen_Accept.OwnerScreen     = &TimeEditScreen;
  btn_TimedEditScreen_Accept.Order           = 2;
  btn_TimedEditScreen_Accept.Left            = 242;
  btn_TimedEditScreen_Accept.Top             = 198;
  btn_TimedEditScreen_Accept.Width           = 76;
  btn_TimedEditScreen_Accept.Height          = 39;
  btn_TimedEditScreen_Accept.Pen_Width       = 0;
  btn_TimedEditScreen_Accept.Pen_Color       = 0x0000;
  btn_TimedEditScreen_Accept.Visible         = 1;
  btn_TimedEditScreen_Accept.Active          = 1;
  btn_TimedEditScreen_Accept.Transparent     = 1;
  btn_TimedEditScreen_Accept.Caption         = btn_TimedEditScreen_Accept_Caption;
  btn_TimedEditScreen_Accept.TextAlign             = _taCenter;
  btn_TimedEditScreen_Accept.FontName        = Helvetica16x19_Bold;
  btn_TimedEditScreen_Accept.PressColEnabled = 1;
  btn_TimedEditScreen_Accept.Font_Color      = 0x0000;
  btn_TimedEditScreen_Accept.Gradient        = 1;
  btn_TimedEditScreen_Accept.Gradient_Orientation    = 0;
  btn_TimedEditScreen_Accept.Gradient_Start_Color    = 0x5E88;
  btn_TimedEditScreen_Accept.Gradient_End_Color      = 0x5E88;
  btn_TimedEditScreen_Accept.Color           = 0xC618;
  btn_TimedEditScreen_Accept.Press_Color     = 0x8410;
  btn_TimedEditScreen_Accept.Corner_Radius      = 0;
  btn_TimedEditScreen_Accept.OnUpPtr         = 0;
  btn_TimedEditScreen_Accept.OnDownPtr       = 0;
  btn_TimedEditScreen_Accept.OnClickPtr      = btn_TimedEditScreen_AcceptOnClick;
  btn_TimedEditScreen_Accept.OnPressPtr      = 0;

  btn_TimedEditScreen_Down.OwnerScreen     = &TimeEditScreen;
  btn_TimedEditScreen_Down.Order           = 3;
  btn_TimedEditScreen_Down.Left            = 161;
  btn_TimedEditScreen_Down.Top             = 198;
  btn_TimedEditScreen_Down.Width           = 78;
  btn_TimedEditScreen_Down.Height          = 39;
  btn_TimedEditScreen_Down.Pen_Width       = 0;
  btn_TimedEditScreen_Down.Pen_Color       = 0x0000;
  btn_TimedEditScreen_Down.Visible         = 1;
  btn_TimedEditScreen_Down.Active          = 1;
  btn_TimedEditScreen_Down.Transparent     = 1;
  btn_TimedEditScreen_Down.Caption         = btn_TimedEditScreen_Down_Caption;
  btn_TimedEditScreen_Down.TextAlign             = _taCenter;
  btn_TimedEditScreen_Down.FontName        = Helvetica16x19_Bold;
  btn_TimedEditScreen_Down.PressColEnabled = 1;
  btn_TimedEditScreen_Down.Font_Color      = 0x0000;
  btn_TimedEditScreen_Down.Gradient        = 1;
  btn_TimedEditScreen_Down.Gradient_Orientation    = 0;
  btn_TimedEditScreen_Down.Gradient_Start_Color    = 0xFFFF;
  btn_TimedEditScreen_Down.Gradient_End_Color      = 0xFFFF;
  btn_TimedEditScreen_Down.Color           = 0xC618;
  btn_TimedEditScreen_Down.Press_Color     = 0x8410;
  btn_TimedEditScreen_Down.Corner_Radius      = 0;
  btn_TimedEditScreen_Down.OnUpPtr         = 0;
  btn_TimedEditScreen_Down.OnDownPtr       = btn_TimedEditScreen_DownOnDown;
  btn_TimedEditScreen_Down.OnClickPtr      = btn_TimedEditScreen_DownOnClick;
  btn_TimedEditScreen_Down.OnPressPtr      = btn_TimedEditScreen_DownOnPress;

  btn_TimedEditScreen_Next.OwnerScreen     = &TimeEditScreen;
  btn_TimedEditScreen_Next.Order           = 4;
  btn_TimedEditScreen_Next.Left            = 2;
  btn_TimedEditScreen_Next.Top             = 198;
  btn_TimedEditScreen_Next.Width           = 76;
  btn_TimedEditScreen_Next.Height          = 39;
  btn_TimedEditScreen_Next.Pen_Width       = 0;
  btn_TimedEditScreen_Next.Pen_Color       = 0x0000;
  btn_TimedEditScreen_Next.Visible         = 1;
  btn_TimedEditScreen_Next.Active          = 1;
  btn_TimedEditScreen_Next.Transparent     = 1;
  btn_TimedEditScreen_Next.Caption         = btn_TimedEditScreen_Next_Caption;
  btn_TimedEditScreen_Next.TextAlign             = _taCenter;
  btn_TimedEditScreen_Next.FontName        = Helvetica16x19_Bold;
  btn_TimedEditScreen_Next.PressColEnabled = 1;
  btn_TimedEditScreen_Next.Font_Color      = 0x0000;
  btn_TimedEditScreen_Next.Gradient        = 1;
  btn_TimedEditScreen_Next.Gradient_Orientation    = 0;
  btn_TimedEditScreen_Next.Gradient_Start_Color    = 0xF567;
  btn_TimedEditScreen_Next.Gradient_End_Color      = 0xF567;
  btn_TimedEditScreen_Next.Color           = 0xC618;
  btn_TimedEditScreen_Next.Press_Color     = 0x8410;
  btn_TimedEditScreen_Next.Corner_Radius      = 0;
  btn_TimedEditScreen_Next.OnUpPtr         = 0;
  btn_TimedEditScreen_Next.OnDownPtr       = 0;
  btn_TimedEditScreen_Next.OnClickPtr      = btn_TimedEditScreen_NextOnClick;
  btn_TimedEditScreen_Next.OnPressPtr      = 0;

  btn_TimedEditScreen_Back.OwnerScreen     = &TimeEditScreen;
  btn_TimedEditScreen_Back.Order           = 5;
  btn_TimedEditScreen_Back.Left            = 2;
  btn_TimedEditScreen_Back.Top             = 3;
  btn_TimedEditScreen_Back.Width           = 76;
  btn_TimedEditScreen_Back.Height          = 38;
  btn_TimedEditScreen_Back.Pen_Width       = 0;
  btn_TimedEditScreen_Back.Pen_Color       = 0x0000;
  btn_TimedEditScreen_Back.Visible         = 1;
  btn_TimedEditScreen_Back.Active          = 1;
  btn_TimedEditScreen_Back.Transparent     = 1;
  btn_TimedEditScreen_Back.Caption         = btn_TimedEditScreen_Back_Caption;
  btn_TimedEditScreen_Back.TextAlign             = _taCenter;
  btn_TimedEditScreen_Back.FontName        = Helvetica11x14_Bold;
  btn_TimedEditScreen_Back.PressColEnabled = 1;
  btn_TimedEditScreen_Back.Font_Color      = 0x0000;
  btn_TimedEditScreen_Back.Gradient        = 1;
  btn_TimedEditScreen_Back.Gradient_Orientation    = 0;
  btn_TimedEditScreen_Back.Gradient_Start_Color    = 0xFFFF;
  btn_TimedEditScreen_Back.Gradient_End_Color      = 0xFFFF;
  btn_TimedEditScreen_Back.Color           = 0xC618;
  btn_TimedEditScreen_Back.Press_Color     = 0x8410;
  btn_TimedEditScreen_Back.Corner_Radius      = 0;
  btn_TimedEditScreen_Back.OnUpPtr         = 0;
  btn_TimedEditScreen_Back.OnDownPtr       = 0;
  btn_TimedEditScreen_Back.OnClickPtr      = btn_TimedEditScreen_BackOnClick;
  btn_TimedEditScreen_Back.OnPressPtr      = 0;

  btn_TimedEditScreen_Up.OwnerScreen     = &TimeEditScreen;
  btn_TimedEditScreen_Up.Order           = 6;
  btn_TimedEditScreen_Up.Left            = 81;
  btn_TimedEditScreen_Up.Top             = 198;
  btn_TimedEditScreen_Up.Width           = 78;
  btn_TimedEditScreen_Up.Height          = 39;
  btn_TimedEditScreen_Up.Pen_Width       = 0;
  btn_TimedEditScreen_Up.Pen_Color       = 0x0000;
  btn_TimedEditScreen_Up.Visible         = 1;
  btn_TimedEditScreen_Up.Active          = 1;
  btn_TimedEditScreen_Up.Transparent     = 1;
  btn_TimedEditScreen_Up.Caption         = btn_TimedEditScreen_Up_Caption;
  btn_TimedEditScreen_Up.TextAlign             = _taCenter;
  btn_TimedEditScreen_Up.FontName        = Helvetica16x19_Bold;
  btn_TimedEditScreen_Up.PressColEnabled = 1;
  btn_TimedEditScreen_Up.Font_Color      = 0x0000;
  btn_TimedEditScreen_Up.Gradient        = 1;
  btn_TimedEditScreen_Up.Gradient_Orientation    = 0;
  btn_TimedEditScreen_Up.Gradient_Start_Color    = 0xFFFF;
  btn_TimedEditScreen_Up.Gradient_End_Color      = 0xFFFF;
  btn_TimedEditScreen_Up.Color           = 0xC618;
  btn_TimedEditScreen_Up.Press_Color     = 0x8410;
  btn_TimedEditScreen_Up.Corner_Radius      = 0;
  btn_TimedEditScreen_Up.OnUpPtr         = 0;
  btn_TimedEditScreen_Up.OnDownPtr       = btn_TimedEditScreen_UpOnDown;
  btn_TimedEditScreen_Up.OnClickPtr      = btn_TimedEditScreen_UpOnClick;
  btn_TimedEditScreen_Up.OnPressPtr      = btn_TimedEditScreen_UpOnPress;

  lbl_TimeEditScreen_Hours.OwnerScreen     = &TimeEditScreen;
  lbl_TimeEditScreen_Hours.Order          = 7;
  lbl_TimeEditScreen_Hours.Left           = 7;
  lbl_TimeEditScreen_Hours.Top            = 83;
  lbl_TimeEditScreen_Hours.Width          = 81;
  lbl_TimeEditScreen_Hours.Height         = 88;
  lbl_TimeEditScreen_Hours.Visible        = 1;
  lbl_TimeEditScreen_Hours.Active         = 1;
  lbl_TimeEditScreen_Hours.Caption        = lbl_TimeEditScreen_Hours_Caption;
  lbl_TimeEditScreen_Hours.FontName       = Helvetica69x81_Bold;
  lbl_TimeEditScreen_Hours.Font_Color     = 0xF800;
  lbl_TimeEditScreen_Hours.OnUpPtr         = 0;
  lbl_TimeEditScreen_Hours.OnDownPtr       = 0;
  lbl_TimeEditScreen_Hours.OnClickPtr      = lbl_TimeEditScreen_HoursOnClick;
  lbl_TimeEditScreen_Hours.OnPressPtr      = 0;

  lbl_TimeEditScreen_Colon1.OwnerScreen     = &TimeEditScreen;
  lbl_TimeEditScreen_Colon1.Order          = 8;
  lbl_TimeEditScreen_Colon1.Left           = 88;
  lbl_TimeEditScreen_Colon1.Top            = 78;
  lbl_TimeEditScreen_Colon1.Width          = 24;
  lbl_TimeEditScreen_Colon1.Height         = 88;
  lbl_TimeEditScreen_Colon1.Visible        = 1;
  lbl_TimeEditScreen_Colon1.Active         = 0;
  lbl_TimeEditScreen_Colon1.Caption        = lbl_TimeEditScreen_Colon1_Caption;
  lbl_TimeEditScreen_Colon1.FontName       = Helvetica69x81_Bold;
  lbl_TimeEditScreen_Colon1.Font_Color     = 0x0000;
  lbl_TimeEditScreen_Colon1.OnUpPtr         = 0;
  lbl_TimeEditScreen_Colon1.OnDownPtr       = 0;
  lbl_TimeEditScreen_Colon1.OnClickPtr      = 0;
  lbl_TimeEditScreen_Colon1.OnPressPtr      = 0;

  lbl_TimeEditScreen_Minutes.OwnerScreen     = &TimeEditScreen;
  lbl_TimeEditScreen_Minutes.Order          = 9;
  lbl_TimeEditScreen_Minutes.Left           = 122;
  lbl_TimeEditScreen_Minutes.Top            = 83;
  lbl_TimeEditScreen_Minutes.Width          = 81;
  lbl_TimeEditScreen_Minutes.Height         = 88;
  lbl_TimeEditScreen_Minutes.Visible        = 1;
  lbl_TimeEditScreen_Minutes.Active         = 1;
  lbl_TimeEditScreen_Minutes.Caption        = lbl_TimeEditScreen_Minutes_Caption;
  lbl_TimeEditScreen_Minutes.FontName       = Helvetica69x81_Bold;
  lbl_TimeEditScreen_Minutes.Font_Color     = 0x0000;
  lbl_TimeEditScreen_Minutes.OnUpPtr         = 0;
  lbl_TimeEditScreen_Minutes.OnDownPtr       = 0;
  lbl_TimeEditScreen_Minutes.OnClickPtr      = lbl_TimeEditScreen_MinutesOnClick;
  lbl_TimeEditScreen_Minutes.OnPressPtr      = 0;

  lbl_TimeEditScreen_Colon2.OwnerScreen     = &TimeEditScreen;
  lbl_TimeEditScreen_Colon2.Order          = 10;
  lbl_TimeEditScreen_Colon2.Left           = 199;
  lbl_TimeEditScreen_Colon2.Top            = 78;
  lbl_TimeEditScreen_Colon2.Width          = 24;
  lbl_TimeEditScreen_Colon2.Height         = 88;
  lbl_TimeEditScreen_Colon2.Visible        = 1;
  lbl_TimeEditScreen_Colon2.Active         = 0;
  lbl_TimeEditScreen_Colon2.Caption        = lbl_TimeEditScreen_Colon2_Caption;
  lbl_TimeEditScreen_Colon2.FontName       = Helvetica69x81_Bold;
  lbl_TimeEditScreen_Colon2.Font_Color     = 0x0000;
  lbl_TimeEditScreen_Colon2.OnUpPtr         = 0;
  lbl_TimeEditScreen_Colon2.OnDownPtr       = 0;
  lbl_TimeEditScreen_Colon2.OnClickPtr      = 0;
  lbl_TimeEditScreen_Colon2.OnPressPtr      = 0;

  lbl_TimeEditScreen_Seconds.OwnerScreen     = &TimeEditScreen;
  lbl_TimeEditScreen_Seconds.Order          = 11;
  lbl_TimeEditScreen_Seconds.Left           = 231;
  lbl_TimeEditScreen_Seconds.Top            = 83;
  lbl_TimeEditScreen_Seconds.Width          = 81;
  lbl_TimeEditScreen_Seconds.Height         = 88;
  lbl_TimeEditScreen_Seconds.Visible        = 1;
  lbl_TimeEditScreen_Seconds.Active         = 1;
  lbl_TimeEditScreen_Seconds.Caption        = lbl_TimeEditScreen_Seconds_Caption;
  lbl_TimeEditScreen_Seconds.FontName       = Helvetica69x81_Bold;
  lbl_TimeEditScreen_Seconds.Font_Color     = 0x0000;
  lbl_TimeEditScreen_Seconds.OnUpPtr         = 0;
  lbl_TimeEditScreen_Seconds.OnDownPtr       = 0;
  lbl_TimeEditScreen_Seconds.OnClickPtr      = lbl_TimeEditScreen_SecondsOnClick;
  lbl_TimeEditScreen_Seconds.OnPressPtr      = 0;

  boxRound_InformationScreen_BackgroundPanel.OwnerScreen     = &InformationScreen;
  boxRound_InformationScreen_BackgroundPanel.Order           = 0;
  boxRound_InformationScreen_BackgroundPanel.Left            = 2;
  boxRound_InformationScreen_BackgroundPanel.Top             = 44;
  boxRound_InformationScreen_BackgroundPanel.Width           = 316;
  boxRound_InformationScreen_BackgroundPanel.Height          = 148;
  boxRound_InformationScreen_BackgroundPanel.Pen_Width       = 0;
  boxRound_InformationScreen_BackgroundPanel.Pen_Color       = 0x0000;
  boxRound_InformationScreen_BackgroundPanel.Visible         = 1;
  boxRound_InformationScreen_BackgroundPanel.Active          = 0;
  boxRound_InformationScreen_BackgroundPanel.Transparent     = 1;
  boxRound_InformationScreen_BackgroundPanel.Gradient        = 0;
  boxRound_InformationScreen_BackgroundPanel.Gradient_Orientation    = 0;
  boxRound_InformationScreen_BackgroundPanel.Gradient_Start_Color    = 0xFFFF;
  boxRound_InformationScreen_BackgroundPanel.Gradient_End_Color      = 0xFFFF;
  boxRound_InformationScreen_BackgroundPanel.Color           = 0xFFFF;
  boxRound_InformationScreen_BackgroundPanel.PressColEnabled     = 1;
  boxRound_InformationScreen_BackgroundPanel.Press_Color     = 0x8410;
  boxRound_InformationScreen_BackgroundPanel.Corner_Radius      = 0;
  boxRound_InformationScreen_BackgroundPanel.OnUpPtr         = 0;
  boxRound_InformationScreen_BackgroundPanel.OnDownPtr       = 0;
  boxRound_InformationScreen_BackgroundPanel.OnClickPtr      = 0;
  boxRound_InformationScreen_BackgroundPanel.OnPressPtr      = 0;

  btn_InformationScreen_RealTime.OwnerScreen     = &InformationScreen;
  btn_InformationScreen_RealTime.Order           = 1;
  btn_InformationScreen_RealTime.Left            = 161;
  btn_InformationScreen_RealTime.Top             = 193;
  btn_InformationScreen_RealTime.Width           = 157;
  btn_InformationScreen_RealTime.Height          = 45;
  btn_InformationScreen_RealTime.Pen_Width       = 0;
  btn_InformationScreen_RealTime.Pen_Color       = 0x0000;
  btn_InformationScreen_RealTime.Visible         = 1;
  btn_InformationScreen_RealTime.Active          = 1;
  btn_InformationScreen_RealTime.Transparent     = 1;
  btn_InformationScreen_RealTime.Caption         = btn_InformationScreen_RealTime_Caption;
  btn_InformationScreen_RealTime.TextAlign             = _taCenter;
  btn_InformationScreen_RealTime.FontName        = Helvetica16x19_Bold;
  btn_InformationScreen_RealTime.PressColEnabled = 1;
  btn_InformationScreen_RealTime.Font_Color      = 0x0000;
  btn_InformationScreen_RealTime.Gradient        = 1;
  btn_InformationScreen_RealTime.Gradient_Orientation    = 0;
  btn_InformationScreen_RealTime.Gradient_Start_Color    = 0xFFFF;
  btn_InformationScreen_RealTime.Gradient_End_Color      = 0xFFFF;
  btn_InformationScreen_RealTime.Color           = 0xC618;
  btn_InformationScreen_RealTime.Press_Color     = 0x8410;
  btn_InformationScreen_RealTime.Corner_Radius      = 0;
  btn_InformationScreen_RealTime.OnUpPtr         = 0;
  btn_InformationScreen_RealTime.OnDownPtr       = 0;
  btn_InformationScreen_RealTime.OnClickPtr      = btn_InformationScreen_RealTimeOnClick;
  btn_InformationScreen_RealTime.OnPressPtr      = 0;

  btn_InformationScreen_Menu.OwnerScreen     = &InformationScreen;
  btn_InformationScreen_Menu.Order           = 2;
  btn_InformationScreen_Menu.Left            = 2;
  btn_InformationScreen_Menu.Top             = 193;
  btn_InformationScreen_Menu.Width           = 157;
  btn_InformationScreen_Menu.Height          = 45;
  btn_InformationScreen_Menu.Pen_Width       = 0;
  btn_InformationScreen_Menu.Pen_Color       = 0x0000;
  btn_InformationScreen_Menu.Visible         = 1;
  btn_InformationScreen_Menu.Active          = 1;
  btn_InformationScreen_Menu.Transparent     = 1;
  btn_InformationScreen_Menu.Caption         = btn_InformationScreen_Menu_Caption;
  btn_InformationScreen_Menu.TextAlign             = _taCenter;
  btn_InformationScreen_Menu.FontName        = Helvetica16x19_Bold;
  btn_InformationScreen_Menu.PressColEnabled = 1;
  btn_InformationScreen_Menu.Font_Color      = 0x0000;
  btn_InformationScreen_Menu.Gradient        = 1;
  btn_InformationScreen_Menu.Gradient_Orientation    = 0;
  btn_InformationScreen_Menu.Gradient_Start_Color    = 0xFFFF;
  btn_InformationScreen_Menu.Gradient_End_Color      = 0xFFFF;
  btn_InformationScreen_Menu.Color           = 0xC618;
  btn_InformationScreen_Menu.Press_Color     = 0x8410;
  btn_InformationScreen_Menu.Corner_Radius      = 0;
  btn_InformationScreen_Menu.OnUpPtr         = 0;
  btn_InformationScreen_Menu.OnDownPtr       = 0;
  btn_InformationScreen_Menu.OnClickPtr      = btn_InformationScreen_MenuOnClick;
  btn_InformationScreen_Menu.OnPressPtr      = 0;

  lbl_InformationScreen_ScreenTitle.OwnerScreen     = &InformationScreen;
  lbl_InformationScreen_ScreenTitle.Order          = 3;
  lbl_InformationScreen_ScreenTitle.Left           = 90;
  lbl_InformationScreen_ScreenTitle.Top            = 10;
  lbl_InformationScreen_ScreenTitle.Width          = 138;
  lbl_InformationScreen_ScreenTitle.Height         = 26;
  lbl_InformationScreen_ScreenTitle.Visible        = 1;
  lbl_InformationScreen_ScreenTitle.Active         = 0;
  lbl_InformationScreen_ScreenTitle.Caption        = lbl_InformationScreen_ScreenTitle_Caption;
  lbl_InformationScreen_ScreenTitle.FontName       = Helvetica21x24_Bold;
  lbl_InformationScreen_ScreenTitle.Font_Color     = 0xF79E;
  lbl_InformationScreen_ScreenTitle.OnUpPtr         = 0;
  lbl_InformationScreen_ScreenTitle.OnDownPtr       = 0;
  lbl_InformationScreen_ScreenTitle.OnClickPtr      = 0;
  lbl_InformationScreen_ScreenTitle.OnPressPtr      = 0;

  lbl_InformationScreenSerialNumber_Name.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenSerialNumber_Name.Order          = 4;
  lbl_InformationScreenSerialNumber_Name.Left           = 10;
  lbl_InformationScreenSerialNumber_Name.Top            = 48;
  lbl_InformationScreenSerialNumber_Name.Width          = 117;
  lbl_InformationScreenSerialNumber_Name.Height         = 20;
  lbl_InformationScreenSerialNumber_Name.Visible        = 1;
  lbl_InformationScreenSerialNumber_Name.Active         = 0;
  lbl_InformationScreenSerialNumber_Name.Caption        = lbl_InformationScreenSerialNumber_Name_Caption;
  lbl_InformationScreenSerialNumber_Name.FontName       = Helvetica16x19_Bold;
  lbl_InformationScreenSerialNumber_Name.Font_Color     = 0x0000;
  lbl_InformationScreenSerialNumber_Name.OnUpPtr         = 0;
  lbl_InformationScreenSerialNumber_Name.OnDownPtr       = 0;
  lbl_InformationScreenSerialNumber_Name.OnClickPtr      = 0;
  lbl_InformationScreenSerialNumber_Name.OnPressPtr      = 0;

  lbl_InformationScreenProductModel_Name.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenProductModel_Name.Order          = 5;
  lbl_InformationScreenProductModel_Name.Left           = 10;
  lbl_InformationScreenProductModel_Name.Top            = 68;
  lbl_InformationScreenProductModel_Name.Width          = 120;
  lbl_InformationScreenProductModel_Name.Height         = 20;
  lbl_InformationScreenProductModel_Name.Visible        = 1;
  lbl_InformationScreenProductModel_Name.Active         = 0;
  lbl_InformationScreenProductModel_Name.Caption        = lbl_InformationScreenProductModel_Name_Caption;
  lbl_InformationScreenProductModel_Name.FontName       = Helvetica16x19_Bold;
  lbl_InformationScreenProductModel_Name.Font_Color     = 0x0000;
  lbl_InformationScreenProductModel_Name.OnUpPtr         = 0;
  lbl_InformationScreenProductModel_Name.OnDownPtr       = 0;
  lbl_InformationScreenProductModel_Name.OnClickPtr      = 0;
  lbl_InformationScreenProductModel_Name.OnPressPtr      = 0;

  lbl_InformationScreenHardwareVer_Name.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenHardwareVer_Name.Order          = 6;
  lbl_InformationScreenHardwareVer_Name.Left           = 10;
  lbl_InformationScreenHardwareVer_Name.Top            = 88;
  lbl_InformationScreenHardwareVer_Name.Width          = 146;
  lbl_InformationScreenHardwareVer_Name.Height         = 20;
  lbl_InformationScreenHardwareVer_Name.Visible        = 1;
  lbl_InformationScreenHardwareVer_Name.Active         = 0;
  lbl_InformationScreenHardwareVer_Name.Caption        = lbl_InformationScreenHardwareVer_Name_Caption;
  lbl_InformationScreenHardwareVer_Name.FontName       = Helvetica16x19_Bold;
  lbl_InformationScreenHardwareVer_Name.Font_Color     = 0x0000;
  lbl_InformationScreenHardwareVer_Name.OnUpPtr         = 0;
  lbl_InformationScreenHardwareVer_Name.OnDownPtr       = 0;
  lbl_InformationScreenHardwareVer_Name.OnClickPtr      = 0;
  lbl_InformationScreenHardwareVer_Name.OnPressPtr      = 0;

  lbl_InformationScreenSerialNumber_Value.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenSerialNumber_Value.Order          = 7;
  lbl_InformationScreenSerialNumber_Value.Left           = 240;
  lbl_InformationScreenSerialNumber_Value.Top            = 48;
  lbl_InformationScreenSerialNumber_Value.Width          = 73;
  lbl_InformationScreenSerialNumber_Value.Height         = 20;
  lbl_InformationScreenSerialNumber_Value.Visible        = 1;
  lbl_InformationScreenSerialNumber_Value.Active         = 0;
  lbl_InformationScreenSerialNumber_Value.Caption        = lbl_InformationScreenSerialNumber_Value_Caption;
  lbl_InformationScreenSerialNumber_Value.FontName       = Helvetica16x18_Regular;
  lbl_InformationScreenSerialNumber_Value.Font_Color     = 0x0000;
  lbl_InformationScreenSerialNumber_Value.OnUpPtr         = 0;
  lbl_InformationScreenSerialNumber_Value.OnDownPtr       = 0;
  lbl_InformationScreenSerialNumber_Value.OnClickPtr      = 0;
  lbl_InformationScreenSerialNumber_Value.OnPressPtr      = 0;

  lbl_InformationScreenProductModel_Value.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenProductModel_Value.Order          = 8;
  lbl_InformationScreenProductModel_Value.Left           = 240;
  lbl_InformationScreenProductModel_Value.Top            = 68;
  lbl_InformationScreenProductModel_Value.Width          = 73;
  lbl_InformationScreenProductModel_Value.Height         = 20;
  lbl_InformationScreenProductModel_Value.Visible        = 1;
  lbl_InformationScreenProductModel_Value.Active         = 0;
  lbl_InformationScreenProductModel_Value.Caption        = lbl_InformationScreenProductModel_Value_Caption;
  lbl_InformationScreenProductModel_Value.FontName       = Helvetica16x18_Regular;
  lbl_InformationScreenProductModel_Value.Font_Color     = 0x0000;
  lbl_InformationScreenProductModel_Value.OnUpPtr         = 0;
  lbl_InformationScreenProductModel_Value.OnDownPtr       = 0;
  lbl_InformationScreenProductModel_Value.OnClickPtr      = 0;
  lbl_InformationScreenProductModel_Value.OnPressPtr      = 0;

  lbl_InformationScreenHardwareVer_Value.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenHardwareVer_Value.Order          = 9;
  lbl_InformationScreenHardwareVer_Value.Left           = 240;
  lbl_InformationScreenHardwareVer_Value.Top            = 88;
  lbl_InformationScreenHardwareVer_Value.Width          = 73;
  lbl_InformationScreenHardwareVer_Value.Height         = 20;
  lbl_InformationScreenHardwareVer_Value.Visible        = 1;
  lbl_InformationScreenHardwareVer_Value.Active         = 0;
  lbl_InformationScreenHardwareVer_Value.Caption        = lbl_InformationScreenHardwareVer_Value_Caption;
  lbl_InformationScreenHardwareVer_Value.FontName       = Helvetica16x18_Regular;
  lbl_InformationScreenHardwareVer_Value.Font_Color     = 0x0000;
  lbl_InformationScreenHardwareVer_Value.OnUpPtr         = 0;
  lbl_InformationScreenHardwareVer_Value.OnDownPtr       = 0;
  lbl_InformationScreenHardwareVer_Value.OnClickPtr      = 0;
  lbl_InformationScreenHardwareVer_Value.OnPressPtr      = 0;

  lbl_InformationScreenFirmwareVer_Name.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenFirmwareVer_Name.Order          = 10;
  lbl_InformationScreenFirmwareVer_Name.Left           = 10;
  lbl_InformationScreenFirmwareVer_Name.Top            = 108;
  lbl_InformationScreenFirmwareVer_Name.Width          = 144;
  lbl_InformationScreenFirmwareVer_Name.Height         = 20;
  lbl_InformationScreenFirmwareVer_Name.Visible        = 1;
  lbl_InformationScreenFirmwareVer_Name.Active         = 0;
  lbl_InformationScreenFirmwareVer_Name.Caption        = lbl_InformationScreenFirmwareVer_Name_Caption;
  lbl_InformationScreenFirmwareVer_Name.FontName       = Helvetica16x19_Bold;
  lbl_InformationScreenFirmwareVer_Name.Font_Color     = 0x0000;
  lbl_InformationScreenFirmwareVer_Name.OnUpPtr         = 0;
  lbl_InformationScreenFirmwareVer_Name.OnDownPtr       = 0;
  lbl_InformationScreenFirmwareVer_Name.OnClickPtr      = 0;
  lbl_InformationScreenFirmwareVer_Name.OnPressPtr      = 0;

  lbl_InformationScreenFirmwareVer_Value.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenFirmwareVer_Value.Order          = 11;
  lbl_InformationScreenFirmwareVer_Value.Left           = 240;
  lbl_InformationScreenFirmwareVer_Value.Top            = 108;
  lbl_InformationScreenFirmwareVer_Value.Width          = 73;
  lbl_InformationScreenFirmwareVer_Value.Height         = 20;
  lbl_InformationScreenFirmwareVer_Value.Visible        = 1;
  lbl_InformationScreenFirmwareVer_Value.Active         = 0;
  lbl_InformationScreenFirmwareVer_Value.Caption        = lbl_InformationScreenFirmwareVer_Value_Caption;
  lbl_InformationScreenFirmwareVer_Value.FontName       = Helvetica16x18_Regular;
  lbl_InformationScreenFirmwareVer_Value.Font_Color     = 0x0000;
  lbl_InformationScreenFirmwareVer_Value.OnUpPtr         = 0;
  lbl_InformationScreenFirmwareVer_Value.OnDownPtr       = 0;
  lbl_InformationScreenFirmwareVer_Value.OnClickPtr      = 0;
  lbl_InformationScreenFirmwareVer_Value.OnPressPtr      = 0;

  lbl_InformationScreenNominalVolt_Name.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenNominalVolt_Name.Order          = 12;
  lbl_InformationScreenNominalVolt_Name.Left           = 10;
  lbl_InformationScreenNominalVolt_Name.Top            = 128;
  lbl_InformationScreenNominalVolt_Name.Width          = 135;
  lbl_InformationScreenNominalVolt_Name.Height         = 20;
  lbl_InformationScreenNominalVolt_Name.Visible        = 1;
  lbl_InformationScreenNominalVolt_Name.Active         = 0;
  lbl_InformationScreenNominalVolt_Name.Caption        = lbl_InformationScreenNominalVolt_Name_Caption;
  lbl_InformationScreenNominalVolt_Name.FontName       = Helvetica16x19_Bold;
  lbl_InformationScreenNominalVolt_Name.Font_Color     = 0x0000;
  lbl_InformationScreenNominalVolt_Name.OnUpPtr         = 0;
  lbl_InformationScreenNominalVolt_Name.OnDownPtr       = 0;
  lbl_InformationScreenNominalVolt_Name.OnClickPtr      = 0;
  lbl_InformationScreenNominalVolt_Name.OnPressPtr      = 0;

  lbl_InformationScreenNominalVolt_Value.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenNominalVolt_Value.Order          = 13;
  lbl_InformationScreenNominalVolt_Value.Left           = 240;
  lbl_InformationScreenNominalVolt_Value.Top            = 128;
  lbl_InformationScreenNominalVolt_Value.Width          = 73;
  lbl_InformationScreenNominalVolt_Value.Height         = 20;
  lbl_InformationScreenNominalVolt_Value.Visible        = 1;
  lbl_InformationScreenNominalVolt_Value.Active         = 0;
  lbl_InformationScreenNominalVolt_Value.Caption        = lbl_InformationScreenNominalVolt_Value_Caption;
  lbl_InformationScreenNominalVolt_Value.FontName       = Helvetica16x18_Regular;
  lbl_InformationScreenNominalVolt_Value.Font_Color     = 0x0000;
  lbl_InformationScreenNominalVolt_Value.OnUpPtr         = 0;
  lbl_InformationScreenNominalVolt_Value.OnDownPtr       = 0;
  lbl_InformationScreenNominalVolt_Value.OnClickPtr      = 0;
  lbl_InformationScreenNominalVolt_Value.OnPressPtr      = 0;

  lbl_InformationScreenStatusCodeA_Name.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenStatusCodeA_Name.Order          = 14;
  lbl_InformationScreenStatusCodeA_Name.Left           = 10;
  lbl_InformationScreenStatusCodeA_Name.Top            = 148;
  lbl_InformationScreenStatusCodeA_Name.Width          = 118;
  lbl_InformationScreenStatusCodeA_Name.Height         = 20;
  lbl_InformationScreenStatusCodeA_Name.Visible        = 1;
  lbl_InformationScreenStatusCodeA_Name.Active         = 0;
  lbl_InformationScreenStatusCodeA_Name.Caption        = lbl_InformationScreenStatusCodeA_Name_Caption;
  lbl_InformationScreenStatusCodeA_Name.FontName       = Helvetica16x19_Bold;
  lbl_InformationScreenStatusCodeA_Name.Font_Color     = 0x0000;
  lbl_InformationScreenStatusCodeA_Name.OnUpPtr         = 0;
  lbl_InformationScreenStatusCodeA_Name.OnDownPtr       = 0;
  lbl_InformationScreenStatusCodeA_Name.OnClickPtr      = 0;
  lbl_InformationScreenStatusCodeA_Name.OnPressPtr      = 0;

  lbl_InformationScreenStatusCodeA_Value.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenStatusCodeA_Value.Order          = 15;
  lbl_InformationScreenStatusCodeA_Value.Left           = 240;
  lbl_InformationScreenStatusCodeA_Value.Top            = 148;
  lbl_InformationScreenStatusCodeA_Value.Width          = 73;
  lbl_InformationScreenStatusCodeA_Value.Height         = 20;
  lbl_InformationScreenStatusCodeA_Value.Visible        = 1;
  lbl_InformationScreenStatusCodeA_Value.Active         = 0;
  lbl_InformationScreenStatusCodeA_Value.Caption        = lbl_InformationScreenStatusCodeA_Value_Caption;
  lbl_InformationScreenStatusCodeA_Value.FontName       = Helvetica16x18_Regular;
  lbl_InformationScreenStatusCodeA_Value.Font_Color     = 0x0000;
  lbl_InformationScreenStatusCodeA_Value.OnUpPtr         = 0;
  lbl_InformationScreenStatusCodeA_Value.OnDownPtr       = 0;
  lbl_InformationScreenStatusCodeA_Value.OnClickPtr      = 0;
  lbl_InformationScreenStatusCodeA_Value.OnPressPtr      = 0;

  lbl_InformationScreenStatusCodeB_Name.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenStatusCodeB_Name.Order          = 16;
  lbl_InformationScreenStatusCodeB_Name.Left           = 10;
  lbl_InformationScreenStatusCodeB_Name.Top            = 168;
  lbl_InformationScreenStatusCodeB_Name.Width          = 118;
  lbl_InformationScreenStatusCodeB_Name.Height         = 20;
  lbl_InformationScreenStatusCodeB_Name.Visible        = 1;
  lbl_InformationScreenStatusCodeB_Name.Active         = 0;
  lbl_InformationScreenStatusCodeB_Name.Caption        = lbl_InformationScreenStatusCodeB_Name_Caption;
  lbl_InformationScreenStatusCodeB_Name.FontName       = Helvetica16x19_Bold;
  lbl_InformationScreenStatusCodeB_Name.Font_Color     = 0x0000;
  lbl_InformationScreenStatusCodeB_Name.OnUpPtr         = 0;
  lbl_InformationScreenStatusCodeB_Name.OnDownPtr       = 0;
  lbl_InformationScreenStatusCodeB_Name.OnClickPtr      = 0;
  lbl_InformationScreenStatusCodeB_Name.OnPressPtr      = 0;

  lbl_InformationScreenStatusCodeB_Value.OwnerScreen     = &InformationScreen;
  lbl_InformationScreenStatusCodeB_Value.Order          = 17;
  lbl_InformationScreenStatusCodeB_Value.Left           = 240;
  lbl_InformationScreenStatusCodeB_Value.Top            = 168;
  lbl_InformationScreenStatusCodeB_Value.Width          = 73;
  lbl_InformationScreenStatusCodeB_Value.Height         = 20;
  lbl_InformationScreenStatusCodeB_Value.Visible        = 1;
  lbl_InformationScreenStatusCodeB_Value.Active         = 0;
  lbl_InformationScreenStatusCodeB_Value.Caption        = lbl_InformationScreenStatusCodeB_Value_Caption;
  lbl_InformationScreenStatusCodeB_Value.FontName       = Helvetica16x18_Regular;
  lbl_InformationScreenStatusCodeB_Value.Font_Color     = 0x0000;
  lbl_InformationScreenStatusCodeB_Value.OnUpPtr         = 0;
  lbl_InformationScreenStatusCodeB_Value.OnDownPtr       = 0;
  lbl_InformationScreenStatusCodeB_Value.OnClickPtr      = 0;
  lbl_InformationScreenStatusCodeB_Value.OnPressPtr      = 0;

  boxRound_CanBusInfoScreen_BackgroundPanel.OwnerScreen     = &CanBusInfoScreen;
  boxRound_CanBusInfoScreen_BackgroundPanel.Order           = 0;
  boxRound_CanBusInfoScreen_BackgroundPanel.Left            = 2;
  boxRound_CanBusInfoScreen_BackgroundPanel.Top             = 44;
  boxRound_CanBusInfoScreen_BackgroundPanel.Width           = 316;
  boxRound_CanBusInfoScreen_BackgroundPanel.Height          = 147;
  boxRound_CanBusInfoScreen_BackgroundPanel.Pen_Width       = 0;
  boxRound_CanBusInfoScreen_BackgroundPanel.Pen_Color       = 0x0000;
  boxRound_CanBusInfoScreen_BackgroundPanel.Visible         = 1;
  boxRound_CanBusInfoScreen_BackgroundPanel.Active          = 0;
  boxRound_CanBusInfoScreen_BackgroundPanel.Transparent     = 1;
  boxRound_CanBusInfoScreen_BackgroundPanel.Gradient        = 0;
  boxRound_CanBusInfoScreen_BackgroundPanel.Gradient_Orientation    = 0;
  boxRound_CanBusInfoScreen_BackgroundPanel.Gradient_Start_Color    = 0xFFFF;
  boxRound_CanBusInfoScreen_BackgroundPanel.Gradient_End_Color      = 0xFFFF;
  boxRound_CanBusInfoScreen_BackgroundPanel.Color           = 0xFFFF;
  boxRound_CanBusInfoScreen_BackgroundPanel.PressColEnabled     = 1;
  boxRound_CanBusInfoScreen_BackgroundPanel.Press_Color     = 0x8410;
  boxRound_CanBusInfoScreen_BackgroundPanel.Corner_Radius      = 0;
  boxRound_CanBusInfoScreen_BackgroundPanel.OnUpPtr         = 0;
  boxRound_CanBusInfoScreen_BackgroundPanel.OnDownPtr       = 0;
  boxRound_CanBusInfoScreen_BackgroundPanel.OnClickPtr      = 0;
  boxRound_CanBusInfoScreen_BackgroundPanel.OnPressPtr      = 0;

  lbl_CanBusInfoScreen_ScreenTitle.OwnerScreen     = &CanBusInfoScreen;
  lbl_CanBusInfoScreen_ScreenTitle.Order          = 1;
  lbl_CanBusInfoScreen_ScreenTitle.Left           = 90;
  lbl_CanBusInfoScreen_ScreenTitle.Top            = 10;
  lbl_CanBusInfoScreen_ScreenTitle.Width          = 141;
  lbl_CanBusInfoScreen_ScreenTitle.Height         = 26;
  lbl_CanBusInfoScreen_ScreenTitle.Visible        = 1;
  lbl_CanBusInfoScreen_ScreenTitle.Active         = 0;
  lbl_CanBusInfoScreen_ScreenTitle.Caption        = lbl_CanBusInfoScreen_ScreenTitle_Caption;
  lbl_CanBusInfoScreen_ScreenTitle.FontName       = Helvetica21x24_Bold;
  lbl_CanBusInfoScreen_ScreenTitle.Font_Color     = 0xF79E;
  lbl_CanBusInfoScreen_ScreenTitle.OnUpPtr         = 0;
  lbl_CanBusInfoScreen_ScreenTitle.OnDownPtr       = 0;
  lbl_CanBusInfoScreen_ScreenTitle.OnClickPtr      = 0;
  lbl_CanBusInfoScreen_ScreenTitle.OnPressPtr      = 0;

  lbl_CanBusInfoScreenModbusId_Name.OwnerScreen     = &CanBusInfoScreen;
  lbl_CanBusInfoScreenModbusId_Name.Order          = 2;
  lbl_CanBusInfoScreenModbusId_Name.Left           = 7;
  lbl_CanBusInfoScreenModbusId_Name.Top            = 54;
  lbl_CanBusInfoScreenModbusId_Name.Width          = 118;
  lbl_CanBusInfoScreenModbusId_Name.Height         = 24;
  lbl_CanBusInfoScreenModbusId_Name.Visible        = 1;
  lbl_CanBusInfoScreenModbusId_Name.Active         = 0;
  lbl_CanBusInfoScreenModbusId_Name.Caption        = lbl_CanBusInfoScreenModbusId_Name_Caption;
  lbl_CanBusInfoScreenModbusId_Name.FontName       = Helvetica19x22_Bold;
  lbl_CanBusInfoScreenModbusId_Name.Font_Color     = 0x0000;
  lbl_CanBusInfoScreenModbusId_Name.OnUpPtr         = 0;
  lbl_CanBusInfoScreenModbusId_Name.OnDownPtr       = 0;
  lbl_CanBusInfoScreenModbusId_Name.OnClickPtr      = 0;
  lbl_CanBusInfoScreenModbusId_Name.OnPressPtr      = 0;

  lbl_CanBusInfoScreenModbusBaud_Name.OwnerScreen     = &CanBusInfoScreen;
  lbl_CanBusInfoScreenModbusBaud_Name.Order          = 3;
  lbl_CanBusInfoScreenModbusBaud_Name.Left           = 7;
  lbl_CanBusInfoScreenModbusBaud_Name.Top            = 83;
  lbl_CanBusInfoScreenModbusBaud_Name.Width          = 135;
  lbl_CanBusInfoScreenModbusBaud_Name.Height         = 24;
  lbl_CanBusInfoScreenModbusBaud_Name.Visible        = 1;
  lbl_CanBusInfoScreenModbusBaud_Name.Active         = 0;
  lbl_CanBusInfoScreenModbusBaud_Name.Caption        = lbl_CanBusInfoScreenModbusBaud_Name_Caption;
  lbl_CanBusInfoScreenModbusBaud_Name.FontName       = Helvetica19x22_Bold;
  lbl_CanBusInfoScreenModbusBaud_Name.Font_Color     = 0x0000;
  lbl_CanBusInfoScreenModbusBaud_Name.OnUpPtr         = 0;
  lbl_CanBusInfoScreenModbusBaud_Name.OnDownPtr       = 0;
  lbl_CanBusInfoScreenModbusBaud_Name.OnClickPtr      = 0;
  lbl_CanBusInfoScreenModbusBaud_Name.OnPressPtr      = 0;

  lbl_CanBusInfoScreenCanBaseId_Name.OwnerScreen     = &CanBusInfoScreen;
  lbl_CanBusInfoScreenCanBaseId_Name.Order          = 4;
  lbl_CanBusInfoScreenCanBaseId_Name.Left           = 7;
  lbl_CanBusInfoScreenCanBaseId_Name.Top            = 109;
  lbl_CanBusInfoScreenCanBaseId_Name.Width          = 115;
  lbl_CanBusInfoScreenCanBaseId_Name.Height         = 24;
  lbl_CanBusInfoScreenCanBaseId_Name.Visible        = 1;
  lbl_CanBusInfoScreenCanBaseId_Name.Active         = 0;
  lbl_CanBusInfoScreenCanBaseId_Name.Caption        = lbl_CanBusInfoScreenCanBaseId_Name_Caption;
  lbl_CanBusInfoScreenCanBaseId_Name.FontName       = Helvetica19x22_Bold;
  lbl_CanBusInfoScreenCanBaseId_Name.Font_Color     = 0x0000;
  lbl_CanBusInfoScreenCanBaseId_Name.OnUpPtr         = 0;
  lbl_CanBusInfoScreenCanBaseId_Name.OnDownPtr       = 0;
  lbl_CanBusInfoScreenCanBaseId_Name.OnClickPtr      = 0;
  lbl_CanBusInfoScreenCanBaseId_Name.OnPressPtr      = 0;

  lbl_CanBusInfoScreenModbusId_Value.OwnerScreen     = &CanBusInfoScreen;
  lbl_CanBusInfoScreenModbusId_Value.Order          = 5;
  lbl_CanBusInfoScreenModbusId_Value.Left           = 220;
  lbl_CanBusInfoScreenModbusId_Value.Top            = 54;
  lbl_CanBusInfoScreenModbusId_Value.Width          = 89;
  lbl_CanBusInfoScreenModbusId_Value.Height         = 24;
  lbl_CanBusInfoScreenModbusId_Value.Visible        = 1;
  lbl_CanBusInfoScreenModbusId_Value.Active         = 0;
  lbl_CanBusInfoScreenModbusId_Value.Caption        = lbl_CanBusInfoScreenModbusId_Value_Caption;
  lbl_CanBusInfoScreenModbusId_Value.FontName       = Helvetica19x22_Regular;
  lbl_CanBusInfoScreenModbusId_Value.Font_Color     = 0xF800;
  lbl_CanBusInfoScreenModbusId_Value.OnUpPtr         = 0;
  lbl_CanBusInfoScreenModbusId_Value.OnDownPtr       = 0;
  lbl_CanBusInfoScreenModbusId_Value.OnClickPtr      = 0;
  lbl_CanBusInfoScreenModbusId_Value.OnPressPtr      = 0;

  lbl_CanBusInfoScreenModbusBaud_Value.OwnerScreen     = &CanBusInfoScreen;
  lbl_CanBusInfoScreenModbusBaud_Value.Order          = 6;
  lbl_CanBusInfoScreenModbusBaud_Value.Left           = 220;
  lbl_CanBusInfoScreenModbusBaud_Value.Top            = 81;
  lbl_CanBusInfoScreenModbusBaud_Value.Width          = 88;
  lbl_CanBusInfoScreenModbusBaud_Value.Height         = 24;
  lbl_CanBusInfoScreenModbusBaud_Value.Visible        = 1;
  lbl_CanBusInfoScreenModbusBaud_Value.Active         = 0;
  lbl_CanBusInfoScreenModbusBaud_Value.Caption        = lbl_CanBusInfoScreenModbusBaud_Value_Caption;
  lbl_CanBusInfoScreenModbusBaud_Value.FontName       = Helvetica19x22_Regular;
  lbl_CanBusInfoScreenModbusBaud_Value.Font_Color     = 0xF800;
  lbl_CanBusInfoScreenModbusBaud_Value.OnUpPtr         = 0;
  lbl_CanBusInfoScreenModbusBaud_Value.OnDownPtr       = 0;
  lbl_CanBusInfoScreenModbusBaud_Value.OnClickPtr      = 0;
  lbl_CanBusInfoScreenModbusBaud_Value.OnPressPtr      = 0;

  lbl_CanBusInfoScreenCanBaseId_Value.OwnerScreen     = &CanBusInfoScreen;
  lbl_CanBusInfoScreenCanBaseId_Value.Order          = 7;
  lbl_CanBusInfoScreenCanBaseId_Value.Left           = 220;
  lbl_CanBusInfoScreenCanBaseId_Value.Top            = 109;
  lbl_CanBusInfoScreenCanBaseId_Value.Width          = 89;
  lbl_CanBusInfoScreenCanBaseId_Value.Height         = 24;
  lbl_CanBusInfoScreenCanBaseId_Value.Visible        = 1;
  lbl_CanBusInfoScreenCanBaseId_Value.Active         = 0;
  lbl_CanBusInfoScreenCanBaseId_Value.Caption        = lbl_CanBusInfoScreenCanBaseId_Value_Caption;
  lbl_CanBusInfoScreenCanBaseId_Value.FontName       = Helvetica19x22_Regular;
  lbl_CanBusInfoScreenCanBaseId_Value.Font_Color     = 0xF800;
  lbl_CanBusInfoScreenCanBaseId_Value.OnUpPtr         = 0;
  lbl_CanBusInfoScreenCanBaseId_Value.OnDownPtr       = 0;
  lbl_CanBusInfoScreenCanBaseId_Value.OnClickPtr      = 0;
  lbl_CanBusInfoScreenCanBaseId_Value.OnPressPtr      = 0;

  lbl_CanBusInfoScreenCanBaud_Name.OwnerScreen     = &CanBusInfoScreen;
  lbl_CanBusInfoScreenCanBaud_Name.Order          = 8;
  lbl_CanBusInfoScreenCanBaud_Name.Left           = 7;
  lbl_CanBusInfoScreenCanBaud_Name.Top            = 136;
  lbl_CanBusInfoScreenCanBaud_Name.Width          = 131;
  lbl_CanBusInfoScreenCanBaud_Name.Height         = 24;
  lbl_CanBusInfoScreenCanBaud_Name.Visible        = 1;
  lbl_CanBusInfoScreenCanBaud_Name.Active         = 0;
  lbl_CanBusInfoScreenCanBaud_Name.Caption        = lbl_CanBusInfoScreenCanBaud_Name_Caption;
  lbl_CanBusInfoScreenCanBaud_Name.FontName       = Helvetica19x22_Bold;
  lbl_CanBusInfoScreenCanBaud_Name.Font_Color     = 0x0000;
  lbl_CanBusInfoScreenCanBaud_Name.OnUpPtr         = 0;
  lbl_CanBusInfoScreenCanBaud_Name.OnDownPtr       = 0;
  lbl_CanBusInfoScreenCanBaud_Name.OnClickPtr      = 0;
  lbl_CanBusInfoScreenCanBaud_Name.OnPressPtr      = 0;

  lbl_CanBusInfoScreenCanBaud_Value.OwnerScreen     = &CanBusInfoScreen;
  lbl_CanBusInfoScreenCanBaud_Value.Order          = 9;
  lbl_CanBusInfoScreenCanBaud_Value.Left           = 220;
  lbl_CanBusInfoScreenCanBaud_Value.Top            = 136;
  lbl_CanBusInfoScreenCanBaud_Value.Width          = 88;
  lbl_CanBusInfoScreenCanBaud_Value.Height         = 24;
  lbl_CanBusInfoScreenCanBaud_Value.Visible        = 1;
  lbl_CanBusInfoScreenCanBaud_Value.Active         = 0;
  lbl_CanBusInfoScreenCanBaud_Value.Caption        = lbl_CanBusInfoScreenCanBaud_Value_Caption;
  lbl_CanBusInfoScreenCanBaud_Value.FontName       = Helvetica19x22_Regular;
  lbl_CanBusInfoScreenCanBaud_Value.Font_Color     = 0xF800;
  lbl_CanBusInfoScreenCanBaud_Value.OnUpPtr         = 0;
  lbl_CanBusInfoScreenCanBaud_Value.OnDownPtr       = 0;
  lbl_CanBusInfoScreenCanBaud_Value.OnClickPtr      = 0;
  lbl_CanBusInfoScreenCanBaud_Value.OnPressPtr      = 0;

  lbl_CanBusInfoScreenColumn5Empty_Name.OwnerScreen     = &CanBusInfoScreen;
  lbl_CanBusInfoScreenColumn5Empty_Name.Order          = 10;
  lbl_CanBusInfoScreenColumn5Empty_Name.Left           = 7;
  lbl_CanBusInfoScreenColumn5Empty_Name.Top            = 163;
  lbl_CanBusInfoScreenColumn5Empty_Name.Width          = 116;
  lbl_CanBusInfoScreenColumn5Empty_Name.Height         = 24;
  lbl_CanBusInfoScreenColumn5Empty_Name.Visible        = 1;
  lbl_CanBusInfoScreenColumn5Empty_Name.Active         = 0;
  lbl_CanBusInfoScreenColumn5Empty_Name.Caption        = lbl_CanBusInfoScreenColumn5Empty_Name_Caption;
  lbl_CanBusInfoScreenColumn5Empty_Name.FontName       = Helvetica19x22_Bold;
  lbl_CanBusInfoScreenColumn5Empty_Name.Font_Color     = 0x0000;
  lbl_CanBusInfoScreenColumn5Empty_Name.OnUpPtr         = 0;
  lbl_CanBusInfoScreenColumn5Empty_Name.OnDownPtr       = 0;
  lbl_CanBusInfoScreenColumn5Empty_Name.OnClickPtr      = 0;
  lbl_CanBusInfoScreenColumn5Empty_Name.OnPressPtr      = 0;

  lbl_CanBusInfoScreenColumnEmpty_Value.OwnerScreen     = &CanBusInfoScreen;
  lbl_CanBusInfoScreenColumnEmpty_Value.Order          = 11;
  lbl_CanBusInfoScreenColumnEmpty_Value.Left           = 219;
  lbl_CanBusInfoScreenColumnEmpty_Value.Top            = 162;
  lbl_CanBusInfoScreenColumnEmpty_Value.Width          = 82;
  lbl_CanBusInfoScreenColumnEmpty_Value.Height         = 24;
  lbl_CanBusInfoScreenColumnEmpty_Value.Visible        = 1;
  lbl_CanBusInfoScreenColumnEmpty_Value.Active         = 0;
  lbl_CanBusInfoScreenColumnEmpty_Value.Caption        = lbl_CanBusInfoScreenColumnEmpty_Value_Caption;
  lbl_CanBusInfoScreenColumnEmpty_Value.FontName       = Helvetica19x22_Regular;
  lbl_CanBusInfoScreenColumnEmpty_Value.Font_Color     = 0xF800;
  lbl_CanBusInfoScreenColumnEmpty_Value.OnUpPtr         = 0;
  lbl_CanBusInfoScreenColumnEmpty_Value.OnDownPtr       = 0;
  lbl_CanBusInfoScreenColumnEmpty_Value.OnClickPtr      = 0;
  lbl_CanBusInfoScreenColumnEmpty_Value.OnPressPtr      = 0;

  btn_CanBusInfoScreen_RealTime.OwnerScreen     = &CanBusInfoScreen;
  btn_CanBusInfoScreen_RealTime.Order           = 12;
  btn_CanBusInfoScreen_RealTime.Left            = 161;
  btn_CanBusInfoScreen_RealTime.Top             = 193;
  btn_CanBusInfoScreen_RealTime.Width           = 157;
  btn_CanBusInfoScreen_RealTime.Height          = 45;
  btn_CanBusInfoScreen_RealTime.Pen_Width       = 0;
  btn_CanBusInfoScreen_RealTime.Pen_Color       = 0x0000;
  btn_CanBusInfoScreen_RealTime.Visible         = 1;
  btn_CanBusInfoScreen_RealTime.Active          = 1;
  btn_CanBusInfoScreen_RealTime.Transparent     = 1;
  btn_CanBusInfoScreen_RealTime.Caption         = btn_CanBusInfoScreen_RealTime_Caption;
  btn_CanBusInfoScreen_RealTime.TextAlign             = _taCenter;
  btn_CanBusInfoScreen_RealTime.FontName        = Helvetica16x19_Bold;
  btn_CanBusInfoScreen_RealTime.PressColEnabled = 1;
  btn_CanBusInfoScreen_RealTime.Font_Color      = 0x0000;
  btn_CanBusInfoScreen_RealTime.Gradient        = 1;
  btn_CanBusInfoScreen_RealTime.Gradient_Orientation    = 0;
  btn_CanBusInfoScreen_RealTime.Gradient_Start_Color    = 0xFFFF;
  btn_CanBusInfoScreen_RealTime.Gradient_End_Color      = 0xFFFF;
  btn_CanBusInfoScreen_RealTime.Color           = 0xC618;
  btn_CanBusInfoScreen_RealTime.Press_Color     = 0x8410;
  btn_CanBusInfoScreen_RealTime.Corner_Radius      = 0;
  btn_CanBusInfoScreen_RealTime.OnUpPtr         = 0;
  btn_CanBusInfoScreen_RealTime.OnDownPtr       = 0;
  btn_CanBusInfoScreen_RealTime.OnClickPtr      = btn_CanBusInfoScreen_RealTimeOnClick;
  btn_CanBusInfoScreen_RealTime.OnPressPtr      = 0;

  btn_CanBusInfoScreen_SettingsMenu.OwnerScreen     = &CanBusInfoScreen;
  btn_CanBusInfoScreen_SettingsMenu.Order           = 13;
  btn_CanBusInfoScreen_SettingsMenu.Left            = 2;
  btn_CanBusInfoScreen_SettingsMenu.Top             = 193;
  btn_CanBusInfoScreen_SettingsMenu.Width           = 157;
  btn_CanBusInfoScreen_SettingsMenu.Height          = 45;
  btn_CanBusInfoScreen_SettingsMenu.Pen_Width       = 0;
  btn_CanBusInfoScreen_SettingsMenu.Pen_Color       = 0x0000;
  btn_CanBusInfoScreen_SettingsMenu.Visible         = 1;
  btn_CanBusInfoScreen_SettingsMenu.Active          = 1;
  btn_CanBusInfoScreen_SettingsMenu.Transparent     = 1;
  btn_CanBusInfoScreen_SettingsMenu.Caption         = btn_CanBusInfoScreen_SettingsMenu_Caption;
  btn_CanBusInfoScreen_SettingsMenu.TextAlign             = _taCenter;
  btn_CanBusInfoScreen_SettingsMenu.FontName        = Helvetica16x19_Bold;
  btn_CanBusInfoScreen_SettingsMenu.PressColEnabled = 1;
  btn_CanBusInfoScreen_SettingsMenu.Font_Color      = 0x0000;
  btn_CanBusInfoScreen_SettingsMenu.Gradient        = 1;
  btn_CanBusInfoScreen_SettingsMenu.Gradient_Orientation    = 0;
  btn_CanBusInfoScreen_SettingsMenu.Gradient_Start_Color    = 0xFFFF;
  btn_CanBusInfoScreen_SettingsMenu.Gradient_End_Color      = 0xFFFF;
  btn_CanBusInfoScreen_SettingsMenu.Color           = 0xC618;
  btn_CanBusInfoScreen_SettingsMenu.Press_Color     = 0x8410;
  btn_CanBusInfoScreen_SettingsMenu.Corner_Radius      = 0;
  btn_CanBusInfoScreen_SettingsMenu.OnUpPtr         = 0;
  btn_CanBusInfoScreen_SettingsMenu.OnDownPtr       = 0;
  btn_CanBusInfoScreen_SettingsMenu.OnClickPtr      = btn_CanBusInfoScreen_SettingsMenuOnClick;
  btn_CanBusInfoScreen_SettingsMenu.OnPressPtr      = 0;

  Line8.OwnerScreen     = &CanBusInfoScreen;
  Line8.Order          = 14;
  Line8.First_Point_X  = 7;
  Line8.First_Point_Y  = 79;
  Line8.Second_Point_X = 312;
  Line8.Second_Point_Y = 79;
  Line8.Visible        = 1;
  Line8.Pen_Width      = 1;
  Line8.Color          = 0x0000;

  Line2.OwnerScreen     = &CanBusInfoScreen;
  Line2.Order          = 15;
  Line2.First_Point_X  = 7;
  Line2.First_Point_Y  = 106;
  Line2.Second_Point_X = 312;
  Line2.Second_Point_Y = 106;
  Line2.Visible        = 1;
  Line2.Pen_Width      = 1;
  Line2.Color          = 0x0000;

  Line6.OwnerScreen     = &CanBusInfoScreen;
  Line6.Order          = 16;
  Line6.First_Point_X  = 7;
  Line6.First_Point_Y  = 134;
  Line6.Second_Point_X = 312;
  Line6.Second_Point_Y = 134;
  Line6.Visible        = 1;
  Line6.Pen_Width      = 1;
  Line6.Color          = 0x0000;

  Line7.OwnerScreen     = &CanBusInfoScreen;
  Line7.Order          = 17;
  Line7.First_Point_X  = 7;
  Line7.First_Point_Y  = 160;
  Line7.Second_Point_X = 312;
  Line7.Second_Point_Y = 160;
  Line7.Visible        = 1;
  Line7.Pen_Width      = 1;
  Line7.Color          = 0x0000;

  boxRound_DateEditScreen_BackgroundPanel.OwnerScreen     = &DateEditScreen;
  boxRound_DateEditScreen_BackgroundPanel.Order           = 0;
  boxRound_DateEditScreen_BackgroundPanel.Left            = 2;
  boxRound_DateEditScreen_BackgroundPanel.Top             = 44;
  boxRound_DateEditScreen_BackgroundPanel.Width           = 316;
  boxRound_DateEditScreen_BackgroundPanel.Height          = 151;
  boxRound_DateEditScreen_BackgroundPanel.Pen_Width       = 0;
  boxRound_DateEditScreen_BackgroundPanel.Pen_Color       = 0x0000;
  boxRound_DateEditScreen_BackgroundPanel.Visible         = 1;
  boxRound_DateEditScreen_BackgroundPanel.Active          = 0;
  boxRound_DateEditScreen_BackgroundPanel.Transparent     = 1;
  boxRound_DateEditScreen_BackgroundPanel.Gradient        = 0;
  boxRound_DateEditScreen_BackgroundPanel.Gradient_Orientation    = 0;
  boxRound_DateEditScreen_BackgroundPanel.Gradient_Start_Color    = 0xFFFF;
  boxRound_DateEditScreen_BackgroundPanel.Gradient_End_Color      = 0xFFFF;
  boxRound_DateEditScreen_BackgroundPanel.Color           = 0xFFFF;
  boxRound_DateEditScreen_BackgroundPanel.PressColEnabled     = 1;
  boxRound_DateEditScreen_BackgroundPanel.Press_Color     = 0x8410;
  boxRound_DateEditScreen_BackgroundPanel.Corner_Radius      = 0;
  boxRound_DateEditScreen_BackgroundPanel.OnUpPtr         = 0;
  boxRound_DateEditScreen_BackgroundPanel.OnDownPtr       = 0;
  boxRound_DateEditScreen_BackgroundPanel.OnClickPtr      = 0;
  boxRound_DateEditScreen_BackgroundPanel.OnPressPtr      = 0;

  lbl_DateEditScreen_ScreenTitle.OwnerScreen     = &DateEditScreen;
  lbl_DateEditScreen_ScreenTitle.Order          = 1;
  lbl_DateEditScreen_ScreenTitle.Left           = 125;
  lbl_DateEditScreen_ScreenTitle.Top            = 10;
  lbl_DateEditScreen_ScreenTitle.Width          = 107;
  lbl_DateEditScreen_ScreenTitle.Height         = 26;
  lbl_DateEditScreen_ScreenTitle.Visible        = 1;
  lbl_DateEditScreen_ScreenTitle.Active         = 1;
  lbl_DateEditScreen_ScreenTitle.Caption        = lbl_DateEditScreen_ScreenTitle_Caption;
  lbl_DateEditScreen_ScreenTitle.FontName       = Helvetica21x24_Bold;
  lbl_DateEditScreen_ScreenTitle.Font_Color     = 0xF79E;
  lbl_DateEditScreen_ScreenTitle.OnUpPtr         = 0;
  lbl_DateEditScreen_ScreenTitle.OnDownPtr       = 0;
  lbl_DateEditScreen_ScreenTitle.OnClickPtr      = 0;
  lbl_DateEditScreen_ScreenTitle.OnPressPtr      = 0;

  btn_DatedEditScreen_Accept.OwnerScreen     = &DateEditScreen;
  btn_DatedEditScreen_Accept.Order           = 2;
  btn_DatedEditScreen_Accept.Left            = 242;
  btn_DatedEditScreen_Accept.Top             = 198;
  btn_DatedEditScreen_Accept.Width           = 76;
  btn_DatedEditScreen_Accept.Height          = 39;
  btn_DatedEditScreen_Accept.Pen_Width       = 0;
  btn_DatedEditScreen_Accept.Pen_Color       = 0x0000;
  btn_DatedEditScreen_Accept.Visible         = 1;
  btn_DatedEditScreen_Accept.Active          = 1;
  btn_DatedEditScreen_Accept.Transparent     = 1;
  btn_DatedEditScreen_Accept.Caption         = btn_DatedEditScreen_Accept_Caption;
  btn_DatedEditScreen_Accept.TextAlign             = _taCenter;
  btn_DatedEditScreen_Accept.FontName        = Helvetica16x19_Bold;
  btn_DatedEditScreen_Accept.PressColEnabled = 1;
  btn_DatedEditScreen_Accept.Font_Color      = 0x0000;
  btn_DatedEditScreen_Accept.Gradient        = 1;
  btn_DatedEditScreen_Accept.Gradient_Orientation    = 0;
  btn_DatedEditScreen_Accept.Gradient_Start_Color    = 0x5E88;
  btn_DatedEditScreen_Accept.Gradient_End_Color      = 0x5E88;
  btn_DatedEditScreen_Accept.Color           = 0xC618;
  btn_DatedEditScreen_Accept.Press_Color     = 0x8410;
  btn_DatedEditScreen_Accept.Corner_Radius      = 0;
  btn_DatedEditScreen_Accept.OnUpPtr         = 0;
  btn_DatedEditScreen_Accept.OnDownPtr       = 0;
  btn_DatedEditScreen_Accept.OnClickPtr      = btn_DatedEditScreen_AcceptOnClick;
  btn_DatedEditScreen_Accept.OnPressPtr      = 0;

  btn_DatedEditScreen_Down.OwnerScreen     = &DateEditScreen;
  btn_DatedEditScreen_Down.Order           = 3;
  btn_DatedEditScreen_Down.Left            = 161;
  btn_DatedEditScreen_Down.Top             = 198;
  btn_DatedEditScreen_Down.Width           = 78;
  btn_DatedEditScreen_Down.Height          = 39;
  btn_DatedEditScreen_Down.Pen_Width       = 0;
  btn_DatedEditScreen_Down.Pen_Color       = 0x0000;
  btn_DatedEditScreen_Down.Visible         = 1;
  btn_DatedEditScreen_Down.Active          = 1;
  btn_DatedEditScreen_Down.Transparent     = 1;
  btn_DatedEditScreen_Down.Caption         = btn_DatedEditScreen_Down_Caption;
  btn_DatedEditScreen_Down.TextAlign             = _taCenter;
  btn_DatedEditScreen_Down.FontName        = Helvetica16x19_Bold;
  btn_DatedEditScreen_Down.PressColEnabled = 1;
  btn_DatedEditScreen_Down.Font_Color      = 0x0000;
  btn_DatedEditScreen_Down.Gradient        = 1;
  btn_DatedEditScreen_Down.Gradient_Orientation    = 0;
  btn_DatedEditScreen_Down.Gradient_Start_Color    = 0xFFFF;
  btn_DatedEditScreen_Down.Gradient_End_Color      = 0xFFFF;
  btn_DatedEditScreen_Down.Color           = 0xC618;
  btn_DatedEditScreen_Down.Press_Color     = 0x8410;
  btn_DatedEditScreen_Down.Corner_Radius      = 0;
  btn_DatedEditScreen_Down.OnUpPtr         = 0;
  btn_DatedEditScreen_Down.OnDownPtr       = 0;
  btn_DatedEditScreen_Down.OnClickPtr      = btn_DatedEditScreen_DownOnClick;
  btn_DatedEditScreen_Down.OnPressPtr      = btn_DatedEditScreen_DownOnPress;

  btn_DateEditScreen_Next.OwnerScreen     = &DateEditScreen;
  btn_DateEditScreen_Next.Order           = 4;
  btn_DateEditScreen_Next.Left            = 2;
  btn_DateEditScreen_Next.Top             = 198;
  btn_DateEditScreen_Next.Width           = 76;
  btn_DateEditScreen_Next.Height          = 39;
  btn_DateEditScreen_Next.Pen_Width       = 0;
  btn_DateEditScreen_Next.Pen_Color       = 0x0000;
  btn_DateEditScreen_Next.Visible         = 1;
  btn_DateEditScreen_Next.Active          = 1;
  btn_DateEditScreen_Next.Transparent     = 1;
  btn_DateEditScreen_Next.Caption         = btn_DateEditScreen_Next_Caption;
  btn_DateEditScreen_Next.TextAlign             = _taCenter;
  btn_DateEditScreen_Next.FontName        = Helvetica16x19_Bold;
  btn_DateEditScreen_Next.PressColEnabled = 1;
  btn_DateEditScreen_Next.Font_Color      = 0x0000;
  btn_DateEditScreen_Next.Gradient        = 1;
  btn_DateEditScreen_Next.Gradient_Orientation    = 0;
  btn_DateEditScreen_Next.Gradient_Start_Color    = 0xF567;
  btn_DateEditScreen_Next.Gradient_End_Color      = 0xF567;
  btn_DateEditScreen_Next.Color           = 0xC618;
  btn_DateEditScreen_Next.Press_Color     = 0x8410;
  btn_DateEditScreen_Next.Corner_Radius      = 0;
  btn_DateEditScreen_Next.OnUpPtr         = 0;
  btn_DateEditScreen_Next.OnDownPtr       = 0;
  btn_DateEditScreen_Next.OnClickPtr      = btn_DateEditScreen_NextOnClick;
  btn_DateEditScreen_Next.OnPressPtr      = 0;

  btn_DatedEditScreen_Back.OwnerScreen     = &DateEditScreen;
  btn_DatedEditScreen_Back.Order           = 5;
  btn_DatedEditScreen_Back.Left            = 2;
  btn_DatedEditScreen_Back.Top             = 3;
  btn_DatedEditScreen_Back.Width           = 76;
  btn_DatedEditScreen_Back.Height          = 38;
  btn_DatedEditScreen_Back.Pen_Width       = 0;
  btn_DatedEditScreen_Back.Pen_Color       = 0x0000;
  btn_DatedEditScreen_Back.Visible         = 1;
  btn_DatedEditScreen_Back.Active          = 1;
  btn_DatedEditScreen_Back.Transparent     = 1;
  btn_DatedEditScreen_Back.Caption         = btn_DatedEditScreen_Back_Caption;
  btn_DatedEditScreen_Back.TextAlign             = _taCenter;
  btn_DatedEditScreen_Back.FontName        = Helvetica16x19_Bold;
  btn_DatedEditScreen_Back.PressColEnabled = 1;
  btn_DatedEditScreen_Back.Font_Color      = 0x0000;
  btn_DatedEditScreen_Back.Gradient        = 1;
  btn_DatedEditScreen_Back.Gradient_Orientation    = 0;
  btn_DatedEditScreen_Back.Gradient_Start_Color    = 0xFFFF;
  btn_DatedEditScreen_Back.Gradient_End_Color      = 0xFFFF;
  btn_DatedEditScreen_Back.Color           = 0xC618;
  btn_DatedEditScreen_Back.Press_Color     = 0x8410;
  btn_DatedEditScreen_Back.Corner_Radius      = 0;
  btn_DatedEditScreen_Back.OnUpPtr         = 0;
  btn_DatedEditScreen_Back.OnDownPtr       = 0;
  btn_DatedEditScreen_Back.OnClickPtr      = btn_DatedEditScreen_BackOnClick;
  btn_DatedEditScreen_Back.OnPressPtr      = 0;

  btn_DateEditScreen_Up.OwnerScreen     = &DateEditScreen;
  btn_DateEditScreen_Up.Order           = 6;
  btn_DateEditScreen_Up.Left            = 81;
  btn_DateEditScreen_Up.Top             = 198;
  btn_DateEditScreen_Up.Width           = 78;
  btn_DateEditScreen_Up.Height          = 39;
  btn_DateEditScreen_Up.Pen_Width       = 0;
  btn_DateEditScreen_Up.Pen_Color       = 0x0000;
  btn_DateEditScreen_Up.Visible         = 1;
  btn_DateEditScreen_Up.Active          = 1;
  btn_DateEditScreen_Up.Transparent     = 1;
  btn_DateEditScreen_Up.Caption         = btn_DateEditScreen_Up_Caption;
  btn_DateEditScreen_Up.TextAlign             = _taCenter;
  btn_DateEditScreen_Up.FontName        = Helvetica16x19_Bold;
  btn_DateEditScreen_Up.PressColEnabled = 1;
  btn_DateEditScreen_Up.Font_Color      = 0x0000;
  btn_DateEditScreen_Up.Gradient        = 1;
  btn_DateEditScreen_Up.Gradient_Orientation    = 0;
  btn_DateEditScreen_Up.Gradient_Start_Color    = 0xFFFF;
  btn_DateEditScreen_Up.Gradient_End_Color      = 0xFFFF;
  btn_DateEditScreen_Up.Color           = 0xC618;
  btn_DateEditScreen_Up.Press_Color     = 0x8410;
  btn_DateEditScreen_Up.Corner_Radius      = 0;
  btn_DateEditScreen_Up.OnUpPtr         = 0;
  btn_DateEditScreen_Up.OnDownPtr       = 0;
  btn_DateEditScreen_Up.OnClickPtr      = btn_DateEditScreen_UpOnClick;
  btn_DateEditScreen_Up.OnPressPtr      = btn_DateEditScreen_UpOnPress;

  lbl_DateEditScreen_Day.OwnerScreen     = &DateEditScreen;
  lbl_DateEditScreen_Day.Order          = 7;
  lbl_DateEditScreen_Day.Left           = 17;
  lbl_DateEditScreen_Day.Top            = 83;
  lbl_DateEditScreen_Day.Width          = 81;
  lbl_DateEditScreen_Day.Height         = 88;
  lbl_DateEditScreen_Day.Visible        = 1;
  lbl_DateEditScreen_Day.Active         = 1;
  lbl_DateEditScreen_Day.Caption        = lbl_DateEditScreen_Day_Caption;
  lbl_DateEditScreen_Day.FontName       = Helvetica69x81_Bold;
  lbl_DateEditScreen_Day.Font_Color     = 0x0000;
  lbl_DateEditScreen_Day.OnUpPtr         = 0;
  lbl_DateEditScreen_Day.OnDownPtr       = 0;
  lbl_DateEditScreen_Day.OnClickPtr      = lbl_DateEditScreen_DayOnClick;
  lbl_DateEditScreen_Day.OnPressPtr      = 0;

  lbl_DateEditScreen_ForwardSlash1.OwnerScreen     = &DateEditScreen;
  lbl_DateEditScreen_ForwardSlash1.Order          = 8;
  lbl_DateEditScreen_ForwardSlash1.Left           = 101;
  lbl_DateEditScreen_ForwardSlash1.Top            = 83;
  lbl_DateEditScreen_ForwardSlash1.Width          = 20;
  lbl_DateEditScreen_ForwardSlash1.Height         = 88;
  lbl_DateEditScreen_ForwardSlash1.Visible        = 1;
  lbl_DateEditScreen_ForwardSlash1.Active         = 0;
  lbl_DateEditScreen_ForwardSlash1.Caption        = lbl_DateEditScreen_ForwardSlash1_Caption;
  lbl_DateEditScreen_ForwardSlash1.FontName       = Helvetica69x81_Bold;
  lbl_DateEditScreen_ForwardSlash1.Font_Color     = 0x0000;
  lbl_DateEditScreen_ForwardSlash1.OnUpPtr         = 0;
  lbl_DateEditScreen_ForwardSlash1.OnDownPtr       = 0;
  lbl_DateEditScreen_ForwardSlash1.OnClickPtr      = 0;
  lbl_DateEditScreen_ForwardSlash1.OnPressPtr      = 0;

  lbl_DateEditScreen_Month.OwnerScreen     = &DateEditScreen;
  lbl_DateEditScreen_Month.Order          = 9;
  lbl_DateEditScreen_Month.Left           = 126;
  lbl_DateEditScreen_Month.Top            = 83;
  lbl_DateEditScreen_Month.Width          = 81;
  lbl_DateEditScreen_Month.Height         = 88;
  lbl_DateEditScreen_Month.Visible        = 1;
  lbl_DateEditScreen_Month.Active         = 1;
  lbl_DateEditScreen_Month.Caption        = lbl_DateEditScreen_Month_Caption;
  lbl_DateEditScreen_Month.FontName       = Helvetica69x81_Bold;
  lbl_DateEditScreen_Month.Font_Color     = 0x0000;
  lbl_DateEditScreen_Month.OnUpPtr         = 0;
  lbl_DateEditScreen_Month.OnDownPtr       = 0;
  lbl_DateEditScreen_Month.OnClickPtr      = lbl_DateEditScreen_MonthOnClick;
  lbl_DateEditScreen_Month.OnPressPtr      = 0;

  lbl_DateEditScreen_ForwardSlash2.OwnerScreen     = &DateEditScreen;
  lbl_DateEditScreen_ForwardSlash2.Order          = 10;
  lbl_DateEditScreen_ForwardSlash2.Left           = 211;
  lbl_DateEditScreen_ForwardSlash2.Top            = 83;
  lbl_DateEditScreen_ForwardSlash2.Width          = 20;
  lbl_DateEditScreen_ForwardSlash2.Height         = 88;
  lbl_DateEditScreen_ForwardSlash2.Visible        = 1;
  lbl_DateEditScreen_ForwardSlash2.Active         = 0;
  lbl_DateEditScreen_ForwardSlash2.Caption        = lbl_DateEditScreen_ForwardSlash2_Caption;
  lbl_DateEditScreen_ForwardSlash2.FontName       = Helvetica69x81_Bold;
  lbl_DateEditScreen_ForwardSlash2.Font_Color     = 0x0000;
  lbl_DateEditScreen_ForwardSlash2.OnUpPtr         = 0;
  lbl_DateEditScreen_ForwardSlash2.OnDownPtr       = 0;
  lbl_DateEditScreen_ForwardSlash2.OnClickPtr      = 0;
  lbl_DateEditScreen_ForwardSlash2.OnPressPtr      = 0;

  lbl_DateEditScreen_Year.OwnerScreen     = &DateEditScreen;
  lbl_DateEditScreen_Year.Order          = 11;
  lbl_DateEditScreen_Year.Left           = 235;
  lbl_DateEditScreen_Year.Top            = 83;
  lbl_DateEditScreen_Year.Width          = 81;
  lbl_DateEditScreen_Year.Height         = 88;
  lbl_DateEditScreen_Year.Visible        = 1;
  lbl_DateEditScreen_Year.Active         = 1;
  lbl_DateEditScreen_Year.Caption        = lbl_DateEditScreen_Year_Caption;
  lbl_DateEditScreen_Year.FontName       = Helvetica69x81_Bold;
  lbl_DateEditScreen_Year.Font_Color     = 0x0000;
  lbl_DateEditScreen_Year.OnUpPtr         = 0;
  lbl_DateEditScreen_Year.OnDownPtr       = 0;
  lbl_DateEditScreen_Year.OnClickPtr      = lbl_DateEditScreen_YearOnClick;
  lbl_DateEditScreen_Year.OnPressPtr      = 0;

  boxRound_ErrorScreen_BackgroundPanel2.OwnerScreen     = &ErrorScreen;
  boxRound_ErrorScreen_BackgroundPanel2.Order           = 0;
  boxRound_ErrorScreen_BackgroundPanel2.Left            = 161;
  boxRound_ErrorScreen_BackgroundPanel2.Top             = 47;
  boxRound_ErrorScreen_BackgroundPanel2.Width           = 157;
  boxRound_ErrorScreen_BackgroundPanel2.Height          = 144;
  boxRound_ErrorScreen_BackgroundPanel2.Pen_Width       = 0;
  boxRound_ErrorScreen_BackgroundPanel2.Pen_Color       = 0x0000;
  boxRound_ErrorScreen_BackgroundPanel2.Visible         = 1;
  boxRound_ErrorScreen_BackgroundPanel2.Active          = 0;
  boxRound_ErrorScreen_BackgroundPanel2.Transparent     = 1;
  boxRound_ErrorScreen_BackgroundPanel2.Gradient        = 0;
  boxRound_ErrorScreen_BackgroundPanel2.Gradient_Orientation    = 0;
  boxRound_ErrorScreen_BackgroundPanel2.Gradient_Start_Color    = 0xFFFF;
  boxRound_ErrorScreen_BackgroundPanel2.Gradient_End_Color      = 0xFFFF;
  boxRound_ErrorScreen_BackgroundPanel2.Color           = 0xFFFF;
  boxRound_ErrorScreen_BackgroundPanel2.PressColEnabled     = 1;
  boxRound_ErrorScreen_BackgroundPanel2.Press_Color     = 0x8410;
  boxRound_ErrorScreen_BackgroundPanel2.Corner_Radius      = 0;
  boxRound_ErrorScreen_BackgroundPanel2.OnUpPtr         = 0;
  boxRound_ErrorScreen_BackgroundPanel2.OnDownPtr       = 0;
  boxRound_ErrorScreen_BackgroundPanel2.OnClickPtr      = 0;
  boxRound_ErrorScreen_BackgroundPanel2.OnPressPtr      = 0;

  boxRound_ErrorScreen_BackgroundPanel1.OwnerScreen     = &ErrorScreen;
  boxRound_ErrorScreen_BackgroundPanel1.Order           = 1;
  boxRound_ErrorScreen_BackgroundPanel1.Left            = 2;
  boxRound_ErrorScreen_BackgroundPanel1.Top             = 47;
  boxRound_ErrorScreen_BackgroundPanel1.Width           = 157;
  boxRound_ErrorScreen_BackgroundPanel1.Height          = 144;
  boxRound_ErrorScreen_BackgroundPanel1.Pen_Width       = 0;
  boxRound_ErrorScreen_BackgroundPanel1.Pen_Color       = 0x0000;
  boxRound_ErrorScreen_BackgroundPanel1.Visible         = 1;
  boxRound_ErrorScreen_BackgroundPanel1.Active          = 0;
  boxRound_ErrorScreen_BackgroundPanel1.Transparent     = 1;
  boxRound_ErrorScreen_BackgroundPanel1.Gradient        = 0;
  boxRound_ErrorScreen_BackgroundPanel1.Gradient_Orientation    = 0;
  boxRound_ErrorScreen_BackgroundPanel1.Gradient_Start_Color    = 0xFFFF;
  boxRound_ErrorScreen_BackgroundPanel1.Gradient_End_Color      = 0xFFFF;
  boxRound_ErrorScreen_BackgroundPanel1.Color           = 0xFFFF;
  boxRound_ErrorScreen_BackgroundPanel1.PressColEnabled     = 1;
  boxRound_ErrorScreen_BackgroundPanel1.Press_Color     = 0x8410;
  boxRound_ErrorScreen_BackgroundPanel1.Corner_Radius      = 0;
  boxRound_ErrorScreen_BackgroundPanel1.OnUpPtr         = 0;
  boxRound_ErrorScreen_BackgroundPanel1.OnDownPtr       = 0;
  boxRound_ErrorScreen_BackgroundPanel1.OnClickPtr      = 0;
  boxRound_ErrorScreen_BackgroundPanel1.OnPressPtr      = 0;

  btn_ErrorScreen_ConfirmErrors.OwnerScreen     = &ErrorScreen;
  btn_ErrorScreen_ConfirmErrors.Order           = 2;
  btn_ErrorScreen_ConfirmErrors.Left            = 161;
  btn_ErrorScreen_ConfirmErrors.Top             = 193;
  btn_ErrorScreen_ConfirmErrors.Width           = 157;
  btn_ErrorScreen_ConfirmErrors.Height          = 45;
  btn_ErrorScreen_ConfirmErrors.Pen_Width       = 0;
  btn_ErrorScreen_ConfirmErrors.Pen_Color       = 0x0000;
  btn_ErrorScreen_ConfirmErrors.Visible         = 1;
  btn_ErrorScreen_ConfirmErrors.Active          = 1;
  btn_ErrorScreen_ConfirmErrors.Transparent     = 1;
  btn_ErrorScreen_ConfirmErrors.Caption         = btn_ErrorScreen_ConfirmErrors_Caption;
  btn_ErrorScreen_ConfirmErrors.TextAlign             = _taCenter;
  btn_ErrorScreen_ConfirmErrors.FontName        = Helvetica16x19_Bold;
  btn_ErrorScreen_ConfirmErrors.PressColEnabled = 1;
  btn_ErrorScreen_ConfirmErrors.Font_Color      = 0x0000;
  btn_ErrorScreen_ConfirmErrors.Gradient        = 1;
  btn_ErrorScreen_ConfirmErrors.Gradient_Orientation    = 0;
  btn_ErrorScreen_ConfirmErrors.Gradient_Start_Color    = 0x5E88;
  btn_ErrorScreen_ConfirmErrors.Gradient_End_Color      = 0x5E88;
  btn_ErrorScreen_ConfirmErrors.Color           = 0xC618;
  btn_ErrorScreen_ConfirmErrors.Press_Color     = 0x8410;
  btn_ErrorScreen_ConfirmErrors.Corner_Radius      = 0;
  btn_ErrorScreen_ConfirmErrors.OnUpPtr         = 0;
  btn_ErrorScreen_ConfirmErrors.OnDownPtr       = 0;
  btn_ErrorScreen_ConfirmErrors.OnClickPtr      = btn_ErrorScreen_ConfirmErrorsOnClick;
  btn_ErrorScreen_ConfirmErrors.OnPressPtr      = 0;

  btn_ErrorScreen_Menu.OwnerScreen     = &ErrorScreen;
  btn_ErrorScreen_Menu.Order           = 3;
  btn_ErrorScreen_Menu.Left            = 2;
  btn_ErrorScreen_Menu.Top             = 193;
  btn_ErrorScreen_Menu.Width           = 157;
  btn_ErrorScreen_Menu.Height          = 45;
  btn_ErrorScreen_Menu.Pen_Width       = 0;
  btn_ErrorScreen_Menu.Pen_Color       = 0x0000;
  btn_ErrorScreen_Menu.Visible         = 1;
  btn_ErrorScreen_Menu.Active          = 1;
  btn_ErrorScreen_Menu.Transparent     = 1;
  btn_ErrorScreen_Menu.Caption         = btn_ErrorScreen_Menu_Caption;
  btn_ErrorScreen_Menu.TextAlign             = _taCenter;
  btn_ErrorScreen_Menu.FontName        = Helvetica16x19_Bold;
  btn_ErrorScreen_Menu.PressColEnabled = 1;
  btn_ErrorScreen_Menu.Font_Color      = 0x0000;
  btn_ErrorScreen_Menu.Gradient        = 1;
  btn_ErrorScreen_Menu.Gradient_Orientation    = 0;
  btn_ErrorScreen_Menu.Gradient_Start_Color    = 0xFFFF;
  btn_ErrorScreen_Menu.Gradient_End_Color      = 0xFFFF;
  btn_ErrorScreen_Menu.Color           = 0xC618;
  btn_ErrorScreen_Menu.Press_Color     = 0x8410;
  btn_ErrorScreen_Menu.Corner_Radius      = 0;
  btn_ErrorScreen_Menu.OnUpPtr         = 0;
  btn_ErrorScreen_Menu.OnDownPtr       = 0;
  btn_ErrorScreen_Menu.OnClickPtr      = btn_ErrorScreen_MenuOnClick;
  btn_ErrorScreen_Menu.OnPressPtr      = 0;

  lbl_ErrorScreen_ScreenTitle.OwnerScreen     = &ErrorScreen;
  lbl_ErrorScreen_ScreenTitle.Order          = 4;
  lbl_ErrorScreen_ScreenTitle.Left           = 100;
  lbl_ErrorScreen_ScreenTitle.Top            = 10;
  lbl_ErrorScreen_ScreenTitle.Width          = 119;
  lbl_ErrorScreen_ScreenTitle.Height         = 34;
  lbl_ErrorScreen_ScreenTitle.Visible        = 1;
  lbl_ErrorScreen_ScreenTitle.Active         = 0;
  lbl_ErrorScreen_ScreenTitle.Caption        = lbl_ErrorScreen_ScreenTitle_Caption;
  lbl_ErrorScreen_ScreenTitle.FontName       = Helvetica26x32_Bold;
  lbl_ErrorScreen_ScreenTitle.Font_Color     = 0xF79E;
  lbl_ErrorScreen_ScreenTitle.OnUpPtr         = 0;
  lbl_ErrorScreen_ScreenTitle.OnDownPtr       = 0;
  lbl_ErrorScreen_ScreenTitle.OnClickPtr      = 0;
  lbl_ErrorScreen_ScreenTitle.OnPressPtr      = 0;

  lbl_ErrorScreen_Pos1.OwnerScreen     = &ErrorScreen;
  lbl_ErrorScreen_Pos1.Order          = 5;
  lbl_ErrorScreen_Pos1.Left           = 15;
  lbl_ErrorScreen_Pos1.Top            = 64;
  lbl_ErrorScreen_Pos1.Width          = 128;
  lbl_ErrorScreen_Pos1.Height         = 20;
  lbl_ErrorScreen_Pos1.Visible        = 1;
  lbl_ErrorScreen_Pos1.Active         = 0;
  lbl_ErrorScreen_Pos1.Caption        = lbl_ErrorScreen_Pos1_Caption;
  lbl_ErrorScreen_Pos1.FontName       = Helvetica16x19_Bold;
  lbl_ErrorScreen_Pos1.Font_Color     = 0x001F;
  lbl_ErrorScreen_Pos1.OnUpPtr         = 0;
  lbl_ErrorScreen_Pos1.OnDownPtr       = 0;
  lbl_ErrorScreen_Pos1.OnClickPtr      = 0;
  lbl_ErrorScreen_Pos1.OnPressPtr      = 0;

  lbl_ErrorScreen_Pos2.OwnerScreen     = &ErrorScreen;
  lbl_ErrorScreen_Pos2.Order          = 6;
  lbl_ErrorScreen_Pos2.Left           = 15;
  lbl_ErrorScreen_Pos2.Top            = 89;
  lbl_ErrorScreen_Pos2.Width          = 128;
  lbl_ErrorScreen_Pos2.Height         = 20;
  lbl_ErrorScreen_Pos2.Visible        = 1;
  lbl_ErrorScreen_Pos2.Active         = 0;
  lbl_ErrorScreen_Pos2.Caption        = lbl_ErrorScreen_Pos2_Caption;
  lbl_ErrorScreen_Pos2.FontName       = Helvetica16x19_Bold;
  lbl_ErrorScreen_Pos2.Font_Color     = 0x0400;
  lbl_ErrorScreen_Pos2.OnUpPtr         = 0;
  lbl_ErrorScreen_Pos2.OnDownPtr       = 0;
  lbl_ErrorScreen_Pos2.OnClickPtr      = 0;
  lbl_ErrorScreen_Pos2.OnPressPtr      = 0;

  lbl_ErrorScreen_Pos3.OwnerScreen     = &ErrorScreen;
  lbl_ErrorScreen_Pos3.Order          = 7;
  lbl_ErrorScreen_Pos3.Left           = 15;
  lbl_ErrorScreen_Pos3.Top            = 114;
  lbl_ErrorScreen_Pos3.Width          = 128;
  lbl_ErrorScreen_Pos3.Height         = 20;
  lbl_ErrorScreen_Pos3.Visible        = 1;
  lbl_ErrorScreen_Pos3.Active         = 0;
  lbl_ErrorScreen_Pos3.Caption        = lbl_ErrorScreen_Pos3_Caption;
  lbl_ErrorScreen_Pos3.FontName       = Helvetica16x19_Bold;
  lbl_ErrorScreen_Pos3.Font_Color     = 0x0400;
  lbl_ErrorScreen_Pos3.OnUpPtr         = 0;
  lbl_ErrorScreen_Pos3.OnDownPtr       = 0;
  lbl_ErrorScreen_Pos3.OnClickPtr      = 0;
  lbl_ErrorScreen_Pos3.OnPressPtr      = 0;

  lbl_ErrorScreen_Pos4.OwnerScreen     = &ErrorScreen;
  lbl_ErrorScreen_Pos4.Order          = 8;
  lbl_ErrorScreen_Pos4.Left           = 15;
  lbl_ErrorScreen_Pos4.Top            = 139;
  lbl_ErrorScreen_Pos4.Width          = 128;
  lbl_ErrorScreen_Pos4.Height         = 20;
  lbl_ErrorScreen_Pos4.Visible        = 1;
  lbl_ErrorScreen_Pos4.Active         = 0;
  lbl_ErrorScreen_Pos4.Caption        = lbl_ErrorScreen_Pos4_Caption;
  lbl_ErrorScreen_Pos4.FontName       = Helvetica16x19_Bold;
  lbl_ErrorScreen_Pos4.Font_Color     = 0x0400;
  lbl_ErrorScreen_Pos4.OnUpPtr         = 0;
  lbl_ErrorScreen_Pos4.OnDownPtr       = 0;
  lbl_ErrorScreen_Pos4.OnClickPtr      = 0;
  lbl_ErrorScreen_Pos4.OnPressPtr      = 0;

  lbl_ErrorScreen_Pos6.OwnerScreen     = &ErrorScreen;
  lbl_ErrorScreen_Pos6.Order          = 9;
  lbl_ErrorScreen_Pos6.Left           = 174;
  lbl_ErrorScreen_Pos6.Top            = 64;
  lbl_ErrorScreen_Pos6.Width          = 128;
  lbl_ErrorScreen_Pos6.Height         = 20;
  lbl_ErrorScreen_Pos6.Visible        = 1;
  lbl_ErrorScreen_Pos6.Active         = 0;
  lbl_ErrorScreen_Pos6.Caption        = lbl_ErrorScreen_Pos6_Caption;
  lbl_ErrorScreen_Pos6.FontName       = Helvetica16x19_Bold;
  lbl_ErrorScreen_Pos6.Font_Color     = 0x0400;
  lbl_ErrorScreen_Pos6.OnUpPtr         = 0;
  lbl_ErrorScreen_Pos6.OnDownPtr       = 0;
  lbl_ErrorScreen_Pos6.OnClickPtr      = 0;
  lbl_ErrorScreen_Pos6.OnPressPtr      = 0;

  lbl_ErrorScreen_Pos7.OwnerScreen     = &ErrorScreen;
  lbl_ErrorScreen_Pos7.Order          = 10;
  lbl_ErrorScreen_Pos7.Left           = 174;
  lbl_ErrorScreen_Pos7.Top            = 89;
  lbl_ErrorScreen_Pos7.Width          = 128;
  lbl_ErrorScreen_Pos7.Height         = 20;
  lbl_ErrorScreen_Pos7.Visible        = 1;
  lbl_ErrorScreen_Pos7.Active         = 0;
  lbl_ErrorScreen_Pos7.Caption        = lbl_ErrorScreen_Pos7_Caption;
  lbl_ErrorScreen_Pos7.FontName       = Helvetica16x19_Bold;
  lbl_ErrorScreen_Pos7.Font_Color     = 0x0400;
  lbl_ErrorScreen_Pos7.OnUpPtr         = 0;
  lbl_ErrorScreen_Pos7.OnDownPtr       = 0;
  lbl_ErrorScreen_Pos7.OnClickPtr      = 0;
  lbl_ErrorScreen_Pos7.OnPressPtr      = 0;

  lbl_ErrorScreen_Pos8.OwnerScreen     = &ErrorScreen;
  lbl_ErrorScreen_Pos8.Order          = 11;
  lbl_ErrorScreen_Pos8.Left           = 174;
  lbl_ErrorScreen_Pos8.Top            = 114;
  lbl_ErrorScreen_Pos8.Width          = 128;
  lbl_ErrorScreen_Pos8.Height         = 20;
  lbl_ErrorScreen_Pos8.Visible        = 1;
  lbl_ErrorScreen_Pos8.Active         = 0;
  lbl_ErrorScreen_Pos8.Caption        = lbl_ErrorScreen_Pos8_Caption;
  lbl_ErrorScreen_Pos8.FontName       = Helvetica16x19_Bold;
  lbl_ErrorScreen_Pos8.Font_Color     = 0x0400;
  lbl_ErrorScreen_Pos8.OnUpPtr         = 0;
  lbl_ErrorScreen_Pos8.OnDownPtr       = 0;
  lbl_ErrorScreen_Pos8.OnClickPtr      = 0;
  lbl_ErrorScreen_Pos8.OnPressPtr      = 0;

  lbl_ErrorScreen_Pos9.OwnerScreen     = &ErrorScreen;
  lbl_ErrorScreen_Pos9.Order          = 12;
  lbl_ErrorScreen_Pos9.Left           = 174;
  lbl_ErrorScreen_Pos9.Top            = 139;
  lbl_ErrorScreen_Pos9.Width          = 128;
  lbl_ErrorScreen_Pos9.Height         = 20;
  lbl_ErrorScreen_Pos9.Visible        = 1;
  lbl_ErrorScreen_Pos9.Active         = 0;
  lbl_ErrorScreen_Pos9.Caption        = lbl_ErrorScreen_Pos9_Caption;
  lbl_ErrorScreen_Pos9.FontName       = Helvetica16x19_Bold;
  lbl_ErrorScreen_Pos9.Font_Color     = 0x0400;
  lbl_ErrorScreen_Pos9.OnUpPtr         = 0;
  lbl_ErrorScreen_Pos9.OnDownPtr       = 0;
  lbl_ErrorScreen_Pos9.OnClickPtr      = 0;
  lbl_ErrorScreen_Pos9.OnPressPtr      = 0;

  lbl_ErrorScreen_Pos5.OwnerScreen     = &ErrorScreen;
  lbl_ErrorScreen_Pos5.Order          = 13;
  lbl_ErrorScreen_Pos5.Left           = 15;
  lbl_ErrorScreen_Pos5.Top            = 164;
  lbl_ErrorScreen_Pos5.Width          = 128;
  lbl_ErrorScreen_Pos5.Height         = 20;
  lbl_ErrorScreen_Pos5.Visible        = 1;
  lbl_ErrorScreen_Pos5.Active         = 0;
  lbl_ErrorScreen_Pos5.Caption        = lbl_ErrorScreen_Pos5_Caption;
  lbl_ErrorScreen_Pos5.FontName       = Helvetica16x19_Bold;
  lbl_ErrorScreen_Pos5.Font_Color     = 0x0400;
  lbl_ErrorScreen_Pos5.OnUpPtr         = 0;
  lbl_ErrorScreen_Pos5.OnDownPtr       = 0;
  lbl_ErrorScreen_Pos5.OnClickPtr      = 0;
  lbl_ErrorScreen_Pos5.OnPressPtr      = 0;

  lbl_ErrorScreen_Pos10.OwnerScreen     = &ErrorScreen;
  lbl_ErrorScreen_Pos10.Order          = 14;
  lbl_ErrorScreen_Pos10.Left           = 174;
  lbl_ErrorScreen_Pos10.Top            = 164;
  lbl_ErrorScreen_Pos10.Width          = 128;
  lbl_ErrorScreen_Pos10.Height         = 20;
  lbl_ErrorScreen_Pos10.Visible        = 1;
  lbl_ErrorScreen_Pos10.Active         = 0;
  lbl_ErrorScreen_Pos10.Caption        = lbl_ErrorScreen_Pos10_Caption;
  lbl_ErrorScreen_Pos10.FontName       = Helvetica16x19_Bold;
  lbl_ErrorScreen_Pos10.Font_Color     = 0x0400;
  lbl_ErrorScreen_Pos10.OnUpPtr         = 0;
  lbl_ErrorScreen_Pos10.OnDownPtr       = 0;
  lbl_ErrorScreen_Pos10.OnClickPtr      = 0;
  lbl_ErrorScreen_Pos10.OnPressPtr      = 0;

  BoxRound1.OwnerScreen     = &BatterySettingsScreen;
  BoxRound1.Order           = 0;
  BoxRound1.Left            = 0;
  BoxRound1.Top             = 0;
  BoxRound1.Width           = 321;
  BoxRound1.Height          = 116;
  BoxRound1.Pen_Width       = 1;
  BoxRound1.Pen_Color       = 0x0000;
  BoxRound1.Visible         = 1;
  BoxRound1.Active          = 0;
  BoxRound1.Transparent     = 1;
  BoxRound1.Gradient        = 0;
  BoxRound1.Gradient_Orientation    = 0;
  BoxRound1.Gradient_Start_Color    = 0xFFFF;
  BoxRound1.Gradient_End_Color      = 0xCE79;
  BoxRound1.Color           = 0xFFFF;
  BoxRound1.PressColEnabled     = 1;
  BoxRound1.Press_Color     = 0x8410;
  BoxRound1.Corner_Radius      = 5;
  BoxRound1.OnUpPtr         = 0;
  BoxRound1.OnDownPtr       = 0;
  BoxRound1.OnClickPtr      = 0;
  BoxRound1.OnPressPtr      = 0;

  ButtonRound1.OwnerScreen     = &BatterySettingsScreen;
  ButtonRound1.Order           = 1;
  ButtonRound1.Left            = 241;
  ButtonRound1.Top             = 195;
  ButtonRound1.Width           = 81;
  ButtonRound1.Height          = 47;
  ButtonRound1.Pen_Width       = 1;
  ButtonRound1.Pen_Color       = 0x0000;
  ButtonRound1.Visible         = 1;
  ButtonRound1.Active          = 1;
  ButtonRound1.Transparent     = 1;
  ButtonRound1.Caption         = ButtonRound1_Caption;
  ButtonRound1.TextAlign             = _taCenter;
  ButtonRound1.FontName        = Arial_Black16x23_Bold;
  ButtonRound1.PressColEnabled = 1;
  ButtonRound1.Font_Color      = 0x0000;
  ButtonRound1.Gradient        = 1;
  ButtonRound1.Gradient_Orientation    = 0;
  ButtonRound1.Gradient_Start_Color    = 0xFFFF;
  ButtonRound1.Gradient_End_Color      = 0x07E0;
  ButtonRound1.Color           = 0xC618;
  ButtonRound1.Press_Color     = 0x8410;
  ButtonRound1.Corner_Radius      = 5;
  ButtonRound1.OnUpPtr         = 0;
  ButtonRound1.OnDownPtr       = 0;
  ButtonRound1.OnClickPtr      = btn_TimedEditScreen_AcceptOnClick;
  ButtonRound1.OnPressPtr      = 0;

  ButtonRound2.OwnerScreen     = &BatterySettingsScreen;
  ButtonRound2.Order           = 2;
  ButtonRound2.Left            = 161;
  ButtonRound2.Top             = 195;
  ButtonRound2.Width           = 81;
  ButtonRound2.Height          = 47;
  ButtonRound2.Pen_Width       = 1;
  ButtonRound2.Pen_Color       = 0x0000;
  ButtonRound2.Visible         = 1;
  ButtonRound2.Active          = 1;
  ButtonRound2.Transparent     = 1;
  ButtonRound2.Caption         = ButtonRound2_Caption;
  ButtonRound2.TextAlign             = _taCenter;
  ButtonRound2.FontName        = Arial_Black16x23_Bold;
  ButtonRound2.PressColEnabled = 1;
  ButtonRound2.Font_Color      = 0x0000;
  ButtonRound2.Gradient        = 1;
  ButtonRound2.Gradient_Orientation    = 0;
  ButtonRound2.Gradient_Start_Color    = 0xFFFF;
  ButtonRound2.Gradient_End_Color      = 0x73AE;
  ButtonRound2.Color           = 0xC618;
  ButtonRound2.Press_Color     = 0x8410;
  ButtonRound2.Corner_Radius      = 5;
  ButtonRound2.OnUpPtr         = 0;
  ButtonRound2.OnDownPtr       = btn_TimedEditScreen_DownOnDown;
  ButtonRound2.OnClickPtr      = btn_TimedEditScreen_DownOnClick;
  ButtonRound2.OnPressPtr      = btn_TimedEditScreen_DownOnPress;

  ButtonRound3.OwnerScreen     = &BatterySettingsScreen;
  ButtonRound3.Order           = 3;
  ButtonRound3.Left            = 0;
  ButtonRound3.Top             = 195;
  ButtonRound3.Width           = 81;
  ButtonRound3.Height          = 47;
  ButtonRound3.Pen_Width       = 1;
  ButtonRound3.Pen_Color       = 0x0000;
  ButtonRound3.Visible         = 1;
  ButtonRound3.Active          = 1;
  ButtonRound3.Transparent     = 1;
  ButtonRound3.Caption         = ButtonRound3_Caption;
  ButtonRound3.TextAlign             = _taCenter;
  ButtonRound3.FontName        = Arial_Black16x23_Bold;
  ButtonRound3.PressColEnabled = 1;
  ButtonRound3.Font_Color      = 0x0000;
  ButtonRound3.Gradient        = 1;
  ButtonRound3.Gradient_Orientation    = 0;
  ButtonRound3.Gradient_Start_Color    = 0xFFFF;
  ButtonRound3.Gradient_End_Color      = 0xF800;
  ButtonRound3.Color           = 0xC618;
  ButtonRound3.Press_Color     = 0x8410;
  ButtonRound3.Corner_Radius      = 5;
  ButtonRound3.OnUpPtr         = 0;
  ButtonRound3.OnDownPtr       = 0;
  ButtonRound3.OnClickPtr      = btn_TimedEditScreen_NextOnClick;
  ButtonRound3.OnPressPtr      = 0;

  ButtonRound4.OwnerScreen     = &BatterySettingsScreen;
  ButtonRound4.Order           = 4;
  ButtonRound4.Left            = 81;
  ButtonRound4.Top             = 195;
  ButtonRound4.Width           = 81;
  ButtonRound4.Height          = 47;
  ButtonRound4.Pen_Width       = 1;
  ButtonRound4.Pen_Color       = 0x0000;
  ButtonRound4.Visible         = 1;
  ButtonRound4.Active          = 1;
  ButtonRound4.Transparent     = 1;
  ButtonRound4.Caption         = ButtonRound4_Caption;
  ButtonRound4.TextAlign             = _taCenter;
  ButtonRound4.FontName        = Arial_Black16x23_Bold;
  ButtonRound4.PressColEnabled = 1;
  ButtonRound4.Font_Color      = 0x0000;
  ButtonRound4.Gradient        = 1;
  ButtonRound4.Gradient_Orientation    = 0;
  ButtonRound4.Gradient_Start_Color    = 0xFFFF;
  ButtonRound4.Gradient_End_Color      = 0x73AE;
  ButtonRound4.Color           = 0xC618;
  ButtonRound4.Press_Color     = 0x8410;
  ButtonRound4.Corner_Radius      = 5;
  ButtonRound4.OnUpPtr         = 0;
  ButtonRound4.OnDownPtr       = btn_TimedEditScreen_UpOnDown;
  ButtonRound4.OnClickPtr      = btn_TimedEditScreen_UpOnClick;
  ButtonRound4.OnPressPtr      = btn_TimedEditScreen_UpOnPress;

  RadioButton1.OwnerScreen     = &BatterySettingsScreen;
  RadioButton1.Order           = 5;
  RadioButton1.Left            = 5;
  RadioButton1.Top             = 0;
  RadioButton1.Width           = 254;
  RadioButton1.Height          = 25;
  RadioButton1.Pen_Width       = 1;
  RadioButton1.Pen_Color       = 0x0000;
  RadioButton1.Visible         = 1;
  RadioButton1.Active          = 1;
  RadioButton1.Checked          = 1;
  RadioButton1.Transparent     = 1;
  RadioButton1.Caption         = RadioButton1_Caption;
  RadioButton1.TextAlign            = _taLeft;
  RadioButton1.FontName        = Arial_Black16x23_Regular;
  RadioButton1.PressColEnabled = 1;
  RadioButton1.Font_Color      = 0x0000;
  RadioButton1.Gradient        = 0;
  RadioButton1.Gradient_Orientation    = 0;
  RadioButton1.Gradient_Start_Color    = 0xFFFF;
  RadioButton1.Gradient_End_Color      = 0xC618;
  RadioButton1.Color           = 0x07E0;
  RadioButton1.Press_Color     = 0xC618;
  RadioButton1.Background_Color = 0xFFFF;
  RadioButton1.OnUpPtr         = 0;
  RadioButton1.OnDownPtr       = 0;
  RadioButton1.OnClickPtr      = 0;
  RadioButton1.OnPressPtr      = 0;

  RadioButton2.OwnerScreen     = &BatterySettingsScreen;
  RadioButton2.Order           = 6;
  RadioButton2.Left            = 5;
  RadioButton2.Top             = 27;
  RadioButton2.Width           = 240;
  RadioButton2.Height          = 25;
  RadioButton2.Pen_Width       = 1;
  RadioButton2.Pen_Color       = 0x0000;
  RadioButton2.Visible         = 1;
  RadioButton2.Active          = 1;
  RadioButton2.Checked          = 0;
  RadioButton2.Transparent     = 1;
  RadioButton2.Caption         = RadioButton2_Caption;
  RadioButton2.TextAlign            = _taLeft;
  RadioButton2.FontName        = Arial_Black16x23_Regular;
  RadioButton2.PressColEnabled = 1;
  RadioButton2.Font_Color      = 0x0000;
  RadioButton2.Gradient        = 1;
  RadioButton2.Gradient_Orientation    = 0;
  RadioButton2.Gradient_Start_Color    = 0xFFFF;
  RadioButton2.Gradient_End_Color      = 0xC618;
  RadioButton2.Color           = 0xC618;
  RadioButton2.Press_Color     = 0xC618;
  RadioButton2.Background_Color = 0xFFFF;
  RadioButton2.OnUpPtr         = 0;
  RadioButton2.OnDownPtr       = 0;
  RadioButton2.OnClickPtr      = 0;
  RadioButton2.OnPressPtr      = 0;

  RadioButton3.OwnerScreen     = &BatterySettingsScreen;
  RadioButton3.Order           = 7;
  RadioButton3.Left            = 5;
  RadioButton3.Top             = 81;
  RadioButton3.Width           = 188;
  RadioButton3.Height          = 25;
  RadioButton3.Pen_Width       = 1;
  RadioButton3.Pen_Color       = 0x0000;
  RadioButton3.Visible         = 1;
  RadioButton3.Active          = 1;
  RadioButton3.Checked          = 0;
  RadioButton3.Transparent     = 1;
  RadioButton3.Caption         = RadioButton3_Caption;
  RadioButton3.TextAlign            = _taLeft;
  RadioButton3.FontName        = Arial_Black16x23_Regular;
  RadioButton3.PressColEnabled = 1;
  RadioButton3.Font_Color      = 0x0000;
  RadioButton3.Gradient        = 1;
  RadioButton3.Gradient_Orientation    = 0;
  RadioButton3.Gradient_Start_Color    = 0xFFFF;
  RadioButton3.Gradient_End_Color      = 0xC618;
  RadioButton3.Color           = 0xC618;
  RadioButton3.Press_Color     = 0xC618;
  RadioButton3.Background_Color = 0xFFFF;
  RadioButton3.OnUpPtr         = 0;
  RadioButton3.OnDownPtr       = 0;
  RadioButton3.OnClickPtr      = 0;
  RadioButton3.OnPressPtr      = 0;

  RadioButton4.OwnerScreen     = &BatterySettingsScreen;
  RadioButton4.Order           = 8;
  RadioButton4.Left            = 5;
  RadioButton4.Top             = 54;
  RadioButton4.Width           = 270;
  RadioButton4.Height          = 25;
  RadioButton4.Pen_Width       = 1;
  RadioButton4.Pen_Color       = 0x0000;
  RadioButton4.Visible         = 1;
  RadioButton4.Active          = 1;
  RadioButton4.Checked          = 0;
  RadioButton4.Transparent     = 1;
  RadioButton4.Caption         = RadioButton4_Caption;
  RadioButton4.TextAlign            = _taLeft;
  RadioButton4.FontName        = Arial_Black16x23_Regular;
  RadioButton4.PressColEnabled = 1;
  RadioButton4.Font_Color      = 0x0000;
  RadioButton4.Gradient        = 1;
  RadioButton4.Gradient_Orientation    = 0;
  RadioButton4.Gradient_Start_Color    = 0xFFFF;
  RadioButton4.Gradient_End_Color      = 0xC618;
  RadioButton4.Color           = 0xC618;
  RadioButton4.Press_Color     = 0xC618;
  RadioButton4.Background_Color = 0xFFFF;
  RadioButton4.OnUpPtr         = 0;
  RadioButton4.OnDownPtr       = 0;
  RadioButton4.OnClickPtr      = 0;
  RadioButton4.OnPressPtr      = 0;

  BoxRound2.OwnerScreen     = &BatterySettingsScreen;
  BoxRound2.Order           = 9;
  BoxRound2.Left            = 177;
  BoxRound2.Top             = 116;
  BoxRound2.Width           = 144;
  BoxRound2.Height          = 79;
  BoxRound2.Pen_Width       = 1;
  BoxRound2.Pen_Color       = 0x0000;
  BoxRound2.Visible         = 1;
  BoxRound2.Active          = 1;
  BoxRound2.Transparent     = 1;
  BoxRound2.Gradient        = 0;
  BoxRound2.Gradient_Orientation    = 0;
  BoxRound2.Gradient_Start_Color    = 0xFFFF;
  BoxRound2.Gradient_End_Color      = 0xC618;
  BoxRound2.Color           = 0xE73C;
  BoxRound2.PressColEnabled     = 1;
  BoxRound2.Press_Color     = 0x8410;
  BoxRound2.Corner_Radius      = 3;
  BoxRound2.OnUpPtr         = 0;
  BoxRound2.OnDownPtr       = 0;
  BoxRound2.OnClickPtr      = 0;
  BoxRound2.OnPressPtr      = 0;

  Label2.OwnerScreen     = &BatterySettingsScreen;
  Label2.Order          = 10;
  Label2.Left           = 180;
  Label2.Top            = 126;
  Label2.Width          = 122;
  Label2.Height         = 88;
  Label2.Visible        = 1;
  Label2.Active         = 1;
  Label2.Caption        = Label2_Caption;
  Label2.FontName       = Helvetica69x81_Bold;
  Label2.Font_Color     = 0x0000;
  Label2.OnUpPtr         = 0;
  Label2.OnDownPtr       = 0;
  Label2.OnClickPtr      = 0;
  Label2.OnPressPtr      = 0;

  Label3.OwnerScreen     = &BatterySettingsScreen;
  Label3.Order          = 11;
  Label3.Left           = 1;
  Label3.Top            = 120;
  Label3.Width          = 174;
  Label3.Height         = 29;
  Label3.Visible        = 1;
  Label3.Active         = 1;
  Label3.Caption        = Label3_Caption;
  Label3.FontName       = Arial_Black19x27_Regular;
  Label3.Font_Color     = 0xFFFF;
  Label3.OnUpPtr         = 0;
  Label3.OnDownPtr       = 0;
  Label3.OnClickPtr      = 0;
  Label3.OnPressPtr      = 0;

  Label4.OwnerScreen     = &BatterySettingsScreen;
  Label4.Order          = 12;
  Label4.Left           = 46;
  Label4.Top            = 146;
  Label4.Width          = 83;
  Label4.Height         = 29;
  Label4.Visible        = 1;
  Label4.Active         = 1;
  Label4.Caption        = Label4_Caption;
  Label4.FontName       = Arial_Black19x27_Regular;
  Label4.Font_Color     = 0xFFFF;
  Label4.OnUpPtr         = 0;
  Label4.OnDownPtr       = 0;
  Label4.OnClickPtr      = 0;
  Label4.OnPressPtr      = 0;

  Label5.OwnerScreen     = &BatterySettingsScreen;
  Label5.Order          = 13;
  Label5.Left           = 301;
  Label5.Top            = 155;
  Label5.Width          = 17;
  Label5.Height         = 32;
  Label5.Visible        = 1;
  Label5.Active         = 1;
  Label5.Caption        = Label5_Caption;
  Label5.FontName       = Arial_Black21x30_Regular;
  Label5.Font_Color     = 0x0000;
  Label5.OnUpPtr         = 0;
  Label5.OnDownPtr       = 0;
  Label5.OnClickPtr      = 0;
  Label5.OnPressPtr      = 0;

  lbl_PincodeScreen_Instruction.OwnerScreen     = &PincodeScreen;
  lbl_PincodeScreen_Instruction.Order          = 0;
  lbl_PincodeScreen_Instruction.Left           = 90;
  lbl_PincodeScreen_Instruction.Top            = 0;
  lbl_PincodeScreen_Instruction.Width          = 157;
  lbl_PincodeScreen_Instruction.Height         = 25;
  lbl_PincodeScreen_Instruction.Visible        = 0;
  lbl_PincodeScreen_Instruction.Active         = 0;
  lbl_PincodeScreen_Instruction.Caption        = lbl_PincodeScreen_Instruction_Caption;
  lbl_PincodeScreen_Instruction.FontName       = Arial_Black16x23_Regular;
  lbl_PincodeScreen_Instruction.Font_Color     = 0xFFFF;
  lbl_PincodeScreen_Instruction.OnUpPtr         = 0;
  lbl_PincodeScreen_Instruction.OnDownPtr       = 0;
  lbl_PincodeScreen_Instruction.OnClickPtr      = 0;
  lbl_PincodeScreen_Instruction.OnPressPtr      = 0;

  btn_PincodeScreen_Delete.OwnerScreen     = &PincodeScreen;
  btn_PincodeScreen_Delete.Order           = 1;
  btn_PincodeScreen_Delete.Left            = 1;
  btn_PincodeScreen_Delete.Top             = 196;
  btn_PincodeScreen_Delete.Width           = 106;
  btn_PincodeScreen_Delete.Height          = 43;
  btn_PincodeScreen_Delete.Pen_Width       = 1;
  btn_PincodeScreen_Delete.Pen_Color       = 0x0000;
  btn_PincodeScreen_Delete.Visible         = 1;
  btn_PincodeScreen_Delete.Active          = 1;
  btn_PincodeScreen_Delete.Transparent     = 1;
  btn_PincodeScreen_Delete.Caption         = btn_PincodeScreen_Delete_Caption;
  btn_PincodeScreen_Delete.TextAlign             = _taCenter;
  btn_PincodeScreen_Delete.FontName        = Helvetica16x19_Bold;
  btn_PincodeScreen_Delete.PressColEnabled = 1;
  btn_PincodeScreen_Delete.Font_Color      = 0x0000;
  btn_PincodeScreen_Delete.Gradient        = 1;
  btn_PincodeScreen_Delete.Gradient_Orientation    = 0;
  btn_PincodeScreen_Delete.Gradient_Start_Color    = 0xD9E7;
  btn_PincodeScreen_Delete.Gradient_End_Color      = 0xD9E7;
  btn_PincodeScreen_Delete.Color           = 0xC618;
  btn_PincodeScreen_Delete.Press_Color     = 0x8410;
  btn_PincodeScreen_Delete.Corner_Radius      = 0;
  btn_PincodeScreen_Delete.OnUpPtr         = 0;
  btn_PincodeScreen_Delete.OnDownPtr       = btn_PincodeScreen_DeleteOnDown;
  btn_PincodeScreen_Delete.OnClickPtr      = 0;
  btn_PincodeScreen_Delete.OnPressPtr      = 0;

  btn_PincodeScreen_Enter.OwnerScreen     = &PincodeScreen;
  btn_PincodeScreen_Enter.Order           = 2;
  btn_PincodeScreen_Enter.Left            = 213;
  btn_PincodeScreen_Enter.Top             = 196;
  btn_PincodeScreen_Enter.Width           = 106;
  btn_PincodeScreen_Enter.Height          = 43;
  btn_PincodeScreen_Enter.Pen_Width       = 1;
  btn_PincodeScreen_Enter.Pen_Color       = 0x0000;
  btn_PincodeScreen_Enter.Visible         = 1;
  btn_PincodeScreen_Enter.Active          = 1;
  btn_PincodeScreen_Enter.Transparent     = 1;
  btn_PincodeScreen_Enter.Caption         = btn_PincodeScreen_Enter_Caption;
  btn_PincodeScreen_Enter.TextAlign             = _taCenter;
  btn_PincodeScreen_Enter.FontName        = Helvetica16x19_Bold;
  btn_PincodeScreen_Enter.PressColEnabled = 1;
  btn_PincodeScreen_Enter.Font_Color      = 0x0000;
  btn_PincodeScreen_Enter.Gradient        = 1;
  btn_PincodeScreen_Enter.Gradient_Orientation    = 0;
  btn_PincodeScreen_Enter.Gradient_Start_Color    = 0x5E88;
  btn_PincodeScreen_Enter.Gradient_End_Color      = 0x5E88;
  btn_PincodeScreen_Enter.Color           = 0xC618;
  btn_PincodeScreen_Enter.Press_Color     = 0x8410;
  btn_PincodeScreen_Enter.Corner_Radius      = 0;
  btn_PincodeScreen_Enter.OnUpPtr         = 0;
  btn_PincodeScreen_Enter.OnDownPtr       = btn_PincodeScreen_EnterOnDown;
  btn_PincodeScreen_Enter.OnClickPtr      = 0;
  btn_PincodeScreen_Enter.OnPressPtr      = 0;

  btn_PincodeScreen_Num1.OwnerScreen     = &PincodeScreen;
  btn_PincodeScreen_Num1.Order           = 3;
  btn_PincodeScreen_Num1.Left            = 1;
  btn_PincodeScreen_Num1.Top             = 67;
  btn_PincodeScreen_Num1.Width           = 106;
  btn_PincodeScreen_Num1.Height          = 43;
  btn_PincodeScreen_Num1.Pen_Width       = 1;
  btn_PincodeScreen_Num1.Pen_Color       = 0x0000;
  btn_PincodeScreen_Num1.Visible         = 1;
  btn_PincodeScreen_Num1.Active          = 1;
  btn_PincodeScreen_Num1.Transparent     = 1;
  btn_PincodeScreen_Num1.Caption         = btn_PincodeScreen_Num1_Caption;
  btn_PincodeScreen_Num1.TextAlign             = _taCenter;
  btn_PincodeScreen_Num1.FontName        = Arial_Black27x38_Regular;
  btn_PincodeScreen_Num1.PressColEnabled = 1;
  btn_PincodeScreen_Num1.Font_Color      = 0x0000;
  btn_PincodeScreen_Num1.Gradient        = 1;
  btn_PincodeScreen_Num1.Gradient_Orientation    = 0;
  btn_PincodeScreen_Num1.Gradient_Start_Color    = 0xFFFF;
  btn_PincodeScreen_Num1.Gradient_End_Color      = 0xFFFF;
  btn_PincodeScreen_Num1.Color           = 0xC618;
  btn_PincodeScreen_Num1.Press_Color     = 0x8410;
  btn_PincodeScreen_Num1.Corner_Radius      = 0;
  btn_PincodeScreen_Num1.OnUpPtr         = 0;
  btn_PincodeScreen_Num1.OnDownPtr       = btn_PincodeScreen_Num1OnDown;
  btn_PincodeScreen_Num1.OnClickPtr      = 0;
  btn_PincodeScreen_Num1.OnPressPtr      = 0;

  btn_PincodeScreen_Num4.OwnerScreen     = &PincodeScreen;
  btn_PincodeScreen_Num4.Order           = 4;
  btn_PincodeScreen_Num4.Left            = 1;
  btn_PincodeScreen_Num4.Top             = 110;
  btn_PincodeScreen_Num4.Width           = 106;
  btn_PincodeScreen_Num4.Height          = 43;
  btn_PincodeScreen_Num4.Pen_Width       = 1;
  btn_PincodeScreen_Num4.Pen_Color       = 0x0000;
  btn_PincodeScreen_Num4.Visible         = 1;
  btn_PincodeScreen_Num4.Active          = 1;
  btn_PincodeScreen_Num4.Transparent     = 1;
  btn_PincodeScreen_Num4.Caption         = btn_PincodeScreen_Num4_Caption;
  btn_PincodeScreen_Num4.TextAlign             = _taCenter;
  btn_PincodeScreen_Num4.FontName        = Arial_Black27x38_Regular;
  btn_PincodeScreen_Num4.PressColEnabled = 1;
  btn_PincodeScreen_Num4.Font_Color      = 0x0000;
  btn_PincodeScreen_Num4.Gradient        = 1;
  btn_PincodeScreen_Num4.Gradient_Orientation    = 0;
  btn_PincodeScreen_Num4.Gradient_Start_Color    = 0xFFFF;
  btn_PincodeScreen_Num4.Gradient_End_Color      = 0xFFFF;
  btn_PincodeScreen_Num4.Color           = 0xC618;
  btn_PincodeScreen_Num4.Press_Color     = 0x8410;
  btn_PincodeScreen_Num4.Corner_Radius      = 0;
  btn_PincodeScreen_Num4.OnUpPtr         = 0;
  btn_PincodeScreen_Num4.OnDownPtr       = btn_PincodeScreen_Num4OnDown;
  btn_PincodeScreen_Num4.OnClickPtr      = 0;
  btn_PincodeScreen_Num4.OnPressPtr      = 0;

  btn_PincodeScreen_Num7.OwnerScreen     = &PincodeScreen;
  btn_PincodeScreen_Num7.Order           = 5;
  btn_PincodeScreen_Num7.Left            = 1;
  btn_PincodeScreen_Num7.Top             = 153;
  btn_PincodeScreen_Num7.Width           = 106;
  btn_PincodeScreen_Num7.Height          = 43;
  btn_PincodeScreen_Num7.Pen_Width       = 1;
  btn_PincodeScreen_Num7.Pen_Color       = 0x0000;
  btn_PincodeScreen_Num7.Visible         = 1;
  btn_PincodeScreen_Num7.Active          = 1;
  btn_PincodeScreen_Num7.Transparent     = 1;
  btn_PincodeScreen_Num7.Caption         = btn_PincodeScreen_Num7_Caption;
  btn_PincodeScreen_Num7.TextAlign             = _taCenter;
  btn_PincodeScreen_Num7.FontName        = Arial_Black27x38_Regular;
  btn_PincodeScreen_Num7.PressColEnabled = 1;
  btn_PincodeScreen_Num7.Font_Color      = 0x0000;
  btn_PincodeScreen_Num7.Gradient        = 1;
  btn_PincodeScreen_Num7.Gradient_Orientation    = 0;
  btn_PincodeScreen_Num7.Gradient_Start_Color    = 0xFFFF;
  btn_PincodeScreen_Num7.Gradient_End_Color      = 0xFFFF;
  btn_PincodeScreen_Num7.Color           = 0xC618;
  btn_PincodeScreen_Num7.Press_Color     = 0x8410;
  btn_PincodeScreen_Num7.Corner_Radius      = 0;
  btn_PincodeScreen_Num7.OnUpPtr         = 0;
  btn_PincodeScreen_Num7.OnDownPtr       = btn_PincodeScreen_Num7OnDown;
  btn_PincodeScreen_Num7.OnClickPtr      = 0;
  btn_PincodeScreen_Num7.OnPressPtr      = 0;

  btn_PincodeScreen_Num0.OwnerScreen     = &PincodeScreen;
  btn_PincodeScreen_Num0.Order           = 6;
  btn_PincodeScreen_Num0.Left            = 107;
  btn_PincodeScreen_Num0.Top             = 196;
  btn_PincodeScreen_Num0.Width           = 106;
  btn_PincodeScreen_Num0.Height          = 43;
  btn_PincodeScreen_Num0.Pen_Width       = 1;
  btn_PincodeScreen_Num0.Pen_Color       = 0x0000;
  btn_PincodeScreen_Num0.Visible         = 1;
  btn_PincodeScreen_Num0.Active          = 1;
  btn_PincodeScreen_Num0.Transparent     = 1;
  btn_PincodeScreen_Num0.Caption         = btn_PincodeScreen_Num0_Caption;
  btn_PincodeScreen_Num0.TextAlign             = _taCenter;
  btn_PincodeScreen_Num0.FontName        = Arial_Black27x38_Regular;
  btn_PincodeScreen_Num0.PressColEnabled = 1;
  btn_PincodeScreen_Num0.Font_Color      = 0x0000;
  btn_PincodeScreen_Num0.Gradient        = 1;
  btn_PincodeScreen_Num0.Gradient_Orientation    = 0;
  btn_PincodeScreen_Num0.Gradient_Start_Color    = 0xFFFF;
  btn_PincodeScreen_Num0.Gradient_End_Color      = 0xFFFF;
  btn_PincodeScreen_Num0.Color           = 0xC618;
  btn_PincodeScreen_Num0.Press_Color     = 0x8410;
  btn_PincodeScreen_Num0.Corner_Radius      = 0;
  btn_PincodeScreen_Num0.OnUpPtr         = 0;
  btn_PincodeScreen_Num0.OnDownPtr       = btn_PincodeScreen_Num0OnDown;
  btn_PincodeScreen_Num0.OnClickPtr      = 0;
  btn_PincodeScreen_Num0.OnPressPtr      = 0;

  btn_PincodeScreen_Num8.OwnerScreen     = &PincodeScreen;
  btn_PincodeScreen_Num8.Order           = 7;
  btn_PincodeScreen_Num8.Left            = 107;
  btn_PincodeScreen_Num8.Top             = 153;
  btn_PincodeScreen_Num8.Width           = 106;
  btn_PincodeScreen_Num8.Height          = 43;
  btn_PincodeScreen_Num8.Pen_Width       = 1;
  btn_PincodeScreen_Num8.Pen_Color       = 0x0000;
  btn_PincodeScreen_Num8.Visible         = 1;
  btn_PincodeScreen_Num8.Active          = 1;
  btn_PincodeScreen_Num8.Transparent     = 1;
  btn_PincodeScreen_Num8.Caption         = btn_PincodeScreen_Num8_Caption;
  btn_PincodeScreen_Num8.TextAlign             = _taCenter;
  btn_PincodeScreen_Num8.FontName        = Arial_Black27x38_Regular;
  btn_PincodeScreen_Num8.PressColEnabled = 1;
  btn_PincodeScreen_Num8.Font_Color      = 0x0000;
  btn_PincodeScreen_Num8.Gradient        = 1;
  btn_PincodeScreen_Num8.Gradient_Orientation    = 0;
  btn_PincodeScreen_Num8.Gradient_Start_Color    = 0xFFFF;
  btn_PincodeScreen_Num8.Gradient_End_Color      = 0xFFFF;
  btn_PincodeScreen_Num8.Color           = 0xC618;
  btn_PincodeScreen_Num8.Press_Color     = 0x8410;
  btn_PincodeScreen_Num8.Corner_Radius      = 0;
  btn_PincodeScreen_Num8.OnUpPtr         = 0;
  btn_PincodeScreen_Num8.OnDownPtr       = btn_PincodeScreen_Num8OnDown;
  btn_PincodeScreen_Num8.OnClickPtr      = 0;
  btn_PincodeScreen_Num8.OnPressPtr      = 0;

  btn_PincodeScreen_Num5.OwnerScreen     = &PincodeScreen;
  btn_PincodeScreen_Num5.Order           = 8;
  btn_PincodeScreen_Num5.Left            = 107;
  btn_PincodeScreen_Num5.Top             = 110;
  btn_PincodeScreen_Num5.Width           = 106;
  btn_PincodeScreen_Num5.Height          = 43;
  btn_PincodeScreen_Num5.Pen_Width       = 1;
  btn_PincodeScreen_Num5.Pen_Color       = 0x0000;
  btn_PincodeScreen_Num5.Visible         = 1;
  btn_PincodeScreen_Num5.Active          = 1;
  btn_PincodeScreen_Num5.Transparent     = 1;
  btn_PincodeScreen_Num5.Caption         = btn_PincodeScreen_Num5_Caption;
  btn_PincodeScreen_Num5.TextAlign             = _taCenter;
  btn_PincodeScreen_Num5.FontName        = Arial_Black27x38_Regular;
  btn_PincodeScreen_Num5.PressColEnabled = 1;
  btn_PincodeScreen_Num5.Font_Color      = 0x0000;
  btn_PincodeScreen_Num5.Gradient        = 1;
  btn_PincodeScreen_Num5.Gradient_Orientation    = 0;
  btn_PincodeScreen_Num5.Gradient_Start_Color    = 0xFFFF;
  btn_PincodeScreen_Num5.Gradient_End_Color      = 0xFFFF;
  btn_PincodeScreen_Num5.Color           = 0xC618;
  btn_PincodeScreen_Num5.Press_Color     = 0x8410;
  btn_PincodeScreen_Num5.Corner_Radius      = 0;
  btn_PincodeScreen_Num5.OnUpPtr         = 0;
  btn_PincodeScreen_Num5.OnDownPtr       = btn_PincodeScreen_Num5OnDown;
  btn_PincodeScreen_Num5.OnClickPtr      = 0;
  btn_PincodeScreen_Num5.OnPressPtr      = 0;

  btn_PincodeScreen_Num2.OwnerScreen     = &PincodeScreen;
  btn_PincodeScreen_Num2.Order           = 9;
  btn_PincodeScreen_Num2.Left            = 107;
  btn_PincodeScreen_Num2.Top             = 67;
  btn_PincodeScreen_Num2.Width           = 106;
  btn_PincodeScreen_Num2.Height          = 43;
  btn_PincodeScreen_Num2.Pen_Width       = 1;
  btn_PincodeScreen_Num2.Pen_Color       = 0x0000;
  btn_PincodeScreen_Num2.Visible         = 1;
  btn_PincodeScreen_Num2.Active          = 1;
  btn_PincodeScreen_Num2.Transparent     = 1;
  btn_PincodeScreen_Num2.Caption         = btn_PincodeScreen_Num2_Caption;
  btn_PincodeScreen_Num2.TextAlign             = _taCenter;
  btn_PincodeScreen_Num2.FontName        = Arial_Black27x38_Regular;
  btn_PincodeScreen_Num2.PressColEnabled = 1;
  btn_PincodeScreen_Num2.Font_Color      = 0x0000;
  btn_PincodeScreen_Num2.Gradient        = 1;
  btn_PincodeScreen_Num2.Gradient_Orientation    = 0;
  btn_PincodeScreen_Num2.Gradient_Start_Color    = 0xFFFF;
  btn_PincodeScreen_Num2.Gradient_End_Color      = 0xFFFF;
  btn_PincodeScreen_Num2.Color           = 0xC618;
  btn_PincodeScreen_Num2.Press_Color     = 0x8410;
  btn_PincodeScreen_Num2.Corner_Radius      = 0;
  btn_PincodeScreen_Num2.OnUpPtr         = 0;
  btn_PincodeScreen_Num2.OnDownPtr       = btn_PincodeScreen_Num2OnDown;
  btn_PincodeScreen_Num2.OnClickPtr      = 0;
  btn_PincodeScreen_Num2.OnPressPtr      = 0;

  btn_PincodeScreen_Num3.OwnerScreen     = &PincodeScreen;
  btn_PincodeScreen_Num3.Order           = 10;
  btn_PincodeScreen_Num3.Left            = 213;
  btn_PincodeScreen_Num3.Top             = 67;
  btn_PincodeScreen_Num3.Width           = 106;
  btn_PincodeScreen_Num3.Height          = 43;
  btn_PincodeScreen_Num3.Pen_Width       = 1;
  btn_PincodeScreen_Num3.Pen_Color       = 0x0000;
  btn_PincodeScreen_Num3.Visible         = 1;
  btn_PincodeScreen_Num3.Active          = 1;
  btn_PincodeScreen_Num3.Transparent     = 1;
  btn_PincodeScreen_Num3.Caption         = btn_PincodeScreen_Num3_Caption;
  btn_PincodeScreen_Num3.TextAlign             = _taCenter;
  btn_PincodeScreen_Num3.FontName        = Arial_Black27x38_Regular;
  btn_PincodeScreen_Num3.PressColEnabled = 1;
  btn_PincodeScreen_Num3.Font_Color      = 0x0000;
  btn_PincodeScreen_Num3.Gradient        = 1;
  btn_PincodeScreen_Num3.Gradient_Orientation    = 0;
  btn_PincodeScreen_Num3.Gradient_Start_Color    = 0xFFFF;
  btn_PincodeScreen_Num3.Gradient_End_Color      = 0xFFFF;
  btn_PincodeScreen_Num3.Color           = 0xC618;
  btn_PincodeScreen_Num3.Press_Color     = 0x8410;
  btn_PincodeScreen_Num3.Corner_Radius      = 0;
  btn_PincodeScreen_Num3.OnUpPtr         = 0;
  btn_PincodeScreen_Num3.OnDownPtr       = btn_PincodeScreen_Num3OnDown;
  btn_PincodeScreen_Num3.OnClickPtr      = 0;
  btn_PincodeScreen_Num3.OnPressPtr      = 0;

  btn_PincodeScreen_Num6.OwnerScreen     = &PincodeScreen;
  btn_PincodeScreen_Num6.Order           = 11;
  btn_PincodeScreen_Num6.Left            = 213;
  btn_PincodeScreen_Num6.Top             = 110;
  btn_PincodeScreen_Num6.Width           = 106;
  btn_PincodeScreen_Num6.Height          = 43;
  btn_PincodeScreen_Num6.Pen_Width       = 1;
  btn_PincodeScreen_Num6.Pen_Color       = 0x0000;
  btn_PincodeScreen_Num6.Visible         = 1;
  btn_PincodeScreen_Num6.Active          = 1;
  btn_PincodeScreen_Num6.Transparent     = 1;
  btn_PincodeScreen_Num6.Caption         = btn_PincodeScreen_Num6_Caption;
  btn_PincodeScreen_Num6.TextAlign             = _taCenter;
  btn_PincodeScreen_Num6.FontName        = Arial_Black27x38_Regular;
  btn_PincodeScreen_Num6.PressColEnabled = 1;
  btn_PincodeScreen_Num6.Font_Color      = 0x0000;
  btn_PincodeScreen_Num6.Gradient        = 1;
  btn_PincodeScreen_Num6.Gradient_Orientation    = 0;
  btn_PincodeScreen_Num6.Gradient_Start_Color    = 0xFFFF;
  btn_PincodeScreen_Num6.Gradient_End_Color      = 0xFFFF;
  btn_PincodeScreen_Num6.Color           = 0xC618;
  btn_PincodeScreen_Num6.Press_Color     = 0x8410;
  btn_PincodeScreen_Num6.Corner_Radius      = 0;
  btn_PincodeScreen_Num6.OnUpPtr         = 0;
  btn_PincodeScreen_Num6.OnDownPtr       = btn_PincodeScreen_Num6OnDown;
  btn_PincodeScreen_Num6.OnClickPtr      = 0;
  btn_PincodeScreen_Num6.OnPressPtr      = 0;

  btn_PincodeScreen_Num9.OwnerScreen     = &PincodeScreen;
  btn_PincodeScreen_Num9.Order           = 12;
  btn_PincodeScreen_Num9.Left            = 213;
  btn_PincodeScreen_Num9.Top             = 153;
  btn_PincodeScreen_Num9.Width           = 106;
  btn_PincodeScreen_Num9.Height          = 43;
  btn_PincodeScreen_Num9.Pen_Width       = 1;
  btn_PincodeScreen_Num9.Pen_Color       = 0x0000;
  btn_PincodeScreen_Num9.Visible         = 1;
  btn_PincodeScreen_Num9.Active          = 1;
  btn_PincodeScreen_Num9.Transparent     = 1;
  btn_PincodeScreen_Num9.Caption         = btn_PincodeScreen_Num9_Caption;
  btn_PincodeScreen_Num9.TextAlign             = _taCenter;
  btn_PincodeScreen_Num9.FontName        = Arial_Black27x38_Regular;
  btn_PincodeScreen_Num9.PressColEnabled = 1;
  btn_PincodeScreen_Num9.Font_Color      = 0x0000;
  btn_PincodeScreen_Num9.Gradient        = 1;
  btn_PincodeScreen_Num9.Gradient_Orientation    = 0;
  btn_PincodeScreen_Num9.Gradient_Start_Color    = 0xFFFF;
  btn_PincodeScreen_Num9.Gradient_End_Color      = 0xFFFF;
  btn_PincodeScreen_Num9.Color           = 0xC618;
  btn_PincodeScreen_Num9.Press_Color     = 0x8410;
  btn_PincodeScreen_Num9.Corner_Radius      = 0;
  btn_PincodeScreen_Num9.OnUpPtr         = 0;
  btn_PincodeScreen_Num9.OnDownPtr       = btn_PincodeScreen_Num9OnDown;
  btn_PincodeScreen_Num9.OnClickPtr      = 0;
  btn_PincodeScreen_Num9.OnPressPtr      = 0;

  lbl_PincodeScreen_Dig1.OwnerScreen     = &PincodeScreen;
  lbl_PincodeScreen_Dig1.Order          = 13;
  lbl_PincodeScreen_Dig1.Left           = 45;
  lbl_PincodeScreen_Dig1.Top            = 8;
  lbl_PincodeScreen_Dig1.Width          = 22;
  lbl_PincodeScreen_Dig1.Height         = 66;
  lbl_PincodeScreen_Dig1.Visible        = 1;
  lbl_PincodeScreen_Dig1.Active         = 0;
  lbl_PincodeScreen_Dig1.Caption        = lbl_PincodeScreen_Dig1_Caption;
  lbl_PincodeScreen_Dig1.FontName       = Arial_Black43x60_Bold;
  lbl_PincodeScreen_Dig1.Font_Color     = 0xFFFF;
  lbl_PincodeScreen_Dig1.OnUpPtr         = 0;
  lbl_PincodeScreen_Dig1.OnDownPtr       = 0;
  lbl_PincodeScreen_Dig1.OnClickPtr      = 0;
  lbl_PincodeScreen_Dig1.OnPressPtr      = 0;

  lbl_PincodeScreen_Dig2.OwnerScreen     = &PincodeScreen;
  lbl_PincodeScreen_Dig2.Order          = 14;
  lbl_PincodeScreen_Dig2.Left           = 115;
  lbl_PincodeScreen_Dig2.Top            = 8;
  lbl_PincodeScreen_Dig2.Width          = 22;
  lbl_PincodeScreen_Dig2.Height         = 66;
  lbl_PincodeScreen_Dig2.Visible        = 1;
  lbl_PincodeScreen_Dig2.Active         = 0;
  lbl_PincodeScreen_Dig2.Caption        = lbl_PincodeScreen_Dig2_Caption;
  lbl_PincodeScreen_Dig2.FontName       = Arial_Black43x60_Bold;
  lbl_PincodeScreen_Dig2.Font_Color     = 0xFFFF;
  lbl_PincodeScreen_Dig2.OnUpPtr         = 0;
  lbl_PincodeScreen_Dig2.OnDownPtr       = 0;
  lbl_PincodeScreen_Dig2.OnClickPtr      = 0;
  lbl_PincodeScreen_Dig2.OnPressPtr      = 0;

  lbl_PincodeScreen_Dig3.OwnerScreen     = &PincodeScreen;
  lbl_PincodeScreen_Dig3.Order          = 15;
  lbl_PincodeScreen_Dig3.Left           = 185;
  lbl_PincodeScreen_Dig3.Top            = 8;
  lbl_PincodeScreen_Dig3.Width          = 22;
  lbl_PincodeScreen_Dig3.Height         = 66;
  lbl_PincodeScreen_Dig3.Visible        = 1;
  lbl_PincodeScreen_Dig3.Active         = 0;
  lbl_PincodeScreen_Dig3.Caption        = lbl_PincodeScreen_Dig3_Caption;
  lbl_PincodeScreen_Dig3.FontName       = Arial_Black43x60_Bold;
  lbl_PincodeScreen_Dig3.Font_Color     = 0xFFFF;
  lbl_PincodeScreen_Dig3.OnUpPtr         = 0;
  lbl_PincodeScreen_Dig3.OnDownPtr       = 0;
  lbl_PincodeScreen_Dig3.OnClickPtr      = 0;
  lbl_PincodeScreen_Dig3.OnPressPtr      = 0;

  lbl_PincodeScreen_Dig4.OwnerScreen     = &PincodeScreen;
  lbl_PincodeScreen_Dig4.Order          = 16;
  lbl_PincodeScreen_Dig4.Left           = 255;
  lbl_PincodeScreen_Dig4.Top            = 8;
  lbl_PincodeScreen_Dig4.Width          = 22;
  lbl_PincodeScreen_Dig4.Height         = 66;
  lbl_PincodeScreen_Dig4.Visible        = 1;
  lbl_PincodeScreen_Dig4.Active         = 0;
  lbl_PincodeScreen_Dig4.Caption        = lbl_PincodeScreen_Dig4_Caption;
  lbl_PincodeScreen_Dig4.FontName       = Arial_Black43x60_Bold;
  lbl_PincodeScreen_Dig4.Font_Color     = 0xFFFF;
  lbl_PincodeScreen_Dig4.OnUpPtr         = 0;
  lbl_PincodeScreen_Dig4.OnDownPtr       = 0;
  lbl_PincodeScreen_Dig4.OnClickPtr      = 0;
  lbl_PincodeScreen_Dig4.OnPressPtr      = 0;

  btn_NotificationScreen_Return.OwnerScreen     = &Notification_Screen;
  btn_NotificationScreen_Return.Order           = 0;
  btn_NotificationScreen_Return.Left            = 2;
  btn_NotificationScreen_Return.Top             = 193;
  btn_NotificationScreen_Return.Width           = 316;
  btn_NotificationScreen_Return.Height          = 45;
  btn_NotificationScreen_Return.Pen_Width       = 0;
  btn_NotificationScreen_Return.Pen_Color       = 0x0000;
  btn_NotificationScreen_Return.Visible         = 1;
  btn_NotificationScreen_Return.Active          = 1;
  btn_NotificationScreen_Return.Transparent     = 1;
  btn_NotificationScreen_Return.Caption         = btn_NotificationScreen_Return_Caption;
  btn_NotificationScreen_Return.TextAlign             = _taCenter;
  btn_NotificationScreen_Return.FontName        = Helvetica16x19_Bold;
  btn_NotificationScreen_Return.PressColEnabled = 1;
  btn_NotificationScreen_Return.Font_Color      = 0x0000;
  btn_NotificationScreen_Return.Gradient        = 1;
  btn_NotificationScreen_Return.Gradient_Orientation    = 0;
  btn_NotificationScreen_Return.Gradient_Start_Color    = 0xFFFF;
  btn_NotificationScreen_Return.Gradient_End_Color      = 0xFFFF;
  btn_NotificationScreen_Return.Color           = 0xFFFF;
  btn_NotificationScreen_Return.Press_Color     = 0x8410;
  btn_NotificationScreen_Return.Corner_Radius      = 0;
  btn_NotificationScreen_Return.OnUpPtr         = 0;
  btn_NotificationScreen_Return.OnDownPtr       = 0;
  btn_NotificationScreen_Return.OnClickPtr      = btn_NotificationScreen_ReturnOnClick;
  btn_NotificationScreen_Return.OnPressPtr      = 0;

  boxRound_NotificationScreenPanel.OwnerScreen     = &Notification_Screen;
  boxRound_NotificationScreenPanel.Order           = 1;
  boxRound_NotificationScreenPanel.Left            = 2;
  boxRound_NotificationScreenPanel.Top             = 2;
  boxRound_NotificationScreenPanel.Width           = 316;
  boxRound_NotificationScreenPanel.Height          = 189;
  boxRound_NotificationScreenPanel.Pen_Width       = 0;
  boxRound_NotificationScreenPanel.Pen_Color       = 0x0000;
  boxRound_NotificationScreenPanel.Visible         = 1;
  boxRound_NotificationScreenPanel.Active          = 0;
  boxRound_NotificationScreenPanel.Transparent     = 1;
  boxRound_NotificationScreenPanel.Gradient        = 0;
  boxRound_NotificationScreenPanel.Gradient_Orientation    = 0;
  boxRound_NotificationScreenPanel.Gradient_Start_Color    = 0xFFFF;
  boxRound_NotificationScreenPanel.Gradient_End_Color      = 0xFFFF;
  boxRound_NotificationScreenPanel.Color           = 0xFFFF;
  boxRound_NotificationScreenPanel.PressColEnabled     = 1;
  boxRound_NotificationScreenPanel.Press_Color     = 0x8410;
  boxRound_NotificationScreenPanel.Corner_Radius      = 0;
  boxRound_NotificationScreenPanel.OnUpPtr         = 0;
  boxRound_NotificationScreenPanel.OnDownPtr       = 0;
  boxRound_NotificationScreenPanel.OnClickPtr      = 0;
  boxRound_NotificationScreenPanel.OnPressPtr      = 0;

  lbl_NotificationScreen_InfoLabel.OwnerScreen     = &Notification_Screen;  //Warning Information
  lbl_NotificationScreen_InfoLabel.Order          = 2;
  lbl_NotificationScreen_InfoLabel.Left           = 35;
  lbl_NotificationScreen_InfoLabel.Top            = 100;
  lbl_NotificationScreen_InfoLabel.Width          = 230;
  lbl_NotificationScreen_InfoLabel.Height         = 19;
  lbl_NotificationScreen_InfoLabel.Visible        = 1;
  lbl_NotificationScreen_InfoLabel.Active         = 0;
  lbl_NotificationScreen_InfoLabel.Caption        = lbl_NotificationScreen_InfoLabel_Caption;
  lbl_NotificationScreen_InfoLabel.FontName       = Helvetica16x19_Bold;
  lbl_NotificationScreen_InfoLabel.Font_Color     = 0x0000;
  lbl_NotificationScreen_InfoLabel.OnUpPtr         = 0;
  lbl_NotificationScreen_InfoLabel.OnDownPtr       = 0;
  lbl_NotificationScreen_InfoLabel.OnClickPtr      = 0;
  lbl_NotificationScreen_InfoLabel.OnPressPtr      = 0;

  btn_NotificationScreen_Menu.OwnerScreen     = &Notification_Screen;         //Return
  btn_NotificationScreen_Menu.Order           = 3;
  btn_NotificationScreen_Menu.Left            = 2;
  btn_NotificationScreen_Menu.Top             = 195;
  btn_NotificationScreen_Menu.Width           = 316;
  btn_NotificationScreen_Menu.Height          = 43;
  btn_NotificationScreen_Menu.Pen_Width       = 0;
  btn_NotificationScreen_Menu.Pen_Color       = 0x0000;
  btn_NotificationScreen_Menu.Visible         = 1;
  btn_NotificationScreen_Menu.Active          = 1;
  btn_NotificationScreen_Menu.Transparent     = 1;
  btn_NotificationScreen_Menu.Caption         = btn_NotificationScreen_Menu_Caption;
  btn_NotificationScreen_Menu.TextAlign             = _taCenter;
  btn_NotificationScreen_Menu.FontName        = Arial_Black16x23_Bold;
  btn_NotificationScreen_Menu.PressColEnabled = 1;
  btn_NotificationScreen_Menu.Font_Color      = 0x0000;
  btn_NotificationScreen_Menu.Gradient        = 0;
  btn_NotificationScreen_Menu.Gradient_Orientation    = 0;
  btn_NotificationScreen_Menu.Gradient_Start_Color    = 0xFFFF;
  btn_NotificationScreen_Menu.Gradient_End_Color      = 0xFFFF;
  btn_NotificationScreen_Menu.Color           = 0xFFFF;
  btn_NotificationScreen_Menu.Press_Color     = 0x8410;
  btn_NotificationScreen_Menu.Corner_Radius      = 0;
  btn_NotificationScreen_Menu.OnUpPtr         = 0;
  btn_NotificationScreen_Menu.OnDownPtr       = 0;
  btn_NotificationScreen_Menu.OnClickPtr      = btn_NotificationScreen_MenuOnClick;
  btn_NotificationScreen_Menu.OnPressPtr      = 0;

  lbl_NotificationScreen_Status.OwnerScreen     = &Notification_Screen;
  lbl_NotificationScreen_Status.Order          = 4;
  lbl_NotificationScreen_Status.Left           = 70;
  lbl_NotificationScreen_Status.Top            = 10;
  lbl_NotificationScreen_Status.Width          = 189;
  lbl_NotificationScreen_Status.Height         = 24;
  lbl_NotificationScreen_Status.Visible        = 0;
  lbl_NotificationScreen_Status.Active         = 0;
  lbl_NotificationScreen_Status.Caption        = lbl_NotificationScreen_Status_Caption;
  lbl_NotificationScreen_Status.FontName       = Helvetica19x22_Bold;
  lbl_NotificationScreen_Status.Font_Color     = 0x0000;
  lbl_NotificationScreen_Status.OnUpPtr         = 0;
  lbl_NotificationScreen_Status.OnDownPtr       = 0;
  lbl_NotificationScreen_Status.OnClickPtr      = 0;
  lbl_NotificationScreen_Status.OnPressPtr      = 0;

  lbl_NotificationScreen_WarningSetpoint.OwnerScreen     = &Notification_Screen;       // Subtitle
  lbl_NotificationScreen_WarningSetpoint.Order          = 5;
  lbl_NotificationScreen_WarningSetpoint.Left           = 110;
  lbl_NotificationScreen_WarningSetpoint.Top            = 70;
  lbl_NotificationScreen_WarningSetpoint.Width          = 158;
  lbl_NotificationScreen_WarningSetpoint.Height         = 19;
  lbl_NotificationScreen_WarningSetpoint.Visible        = 0;
  lbl_NotificationScreen_WarningSetpoint.Active         = 0;
  lbl_NotificationScreen_WarningSetpoint.Caption        = lbl_NotificationScreen_WarningSetpoint_Caption;
  lbl_NotificationScreen_WarningSetpoint.FontName       = Helvetica16x19_Bold;
  lbl_NotificationScreen_WarningSetpoint.Font_Color     = 0xD9E7;
  lbl_NotificationScreen_WarningSetpoint.OnUpPtr         = 0;
  lbl_NotificationScreen_WarningSetpoint.OnDownPtr       = 0;
  lbl_NotificationScreen_WarningSetpoint.OnClickPtr      = 0;
  lbl_NotificationScreen_WarningSetpoint.OnPressPtr      = 0;

  lbl_NotificationScreen_Warning.OwnerScreen     = &Notification_Screen;        // Title
  lbl_NotificationScreen_Warning.Order          = 6;
  lbl_NotificationScreen_Warning.Left           = 111;
  lbl_NotificationScreen_Warning.Top            = 10;
  lbl_NotificationScreen_Warning.Width          = 96;
  lbl_NotificationScreen_Warning.Height         = 24;
  lbl_NotificationScreen_Warning.Visible        = 0;
  lbl_NotificationScreen_Warning.Active         = 0;
  lbl_NotificationScreen_Warning.Caption        = lbl_NotificationScreen_Warning_Caption;
  lbl_NotificationScreen_Warning.FontName       = Helvetica19x22_Bold;
  lbl_NotificationScreen_Warning.Font_Color     = 0x0000;
  lbl_NotificationScreen_Warning.OnUpPtr         = 0;
  lbl_NotificationScreen_Warning.OnDownPtr       = 0;
  lbl_NotificationScreen_Warning.OnClickPtr      = 0;
  lbl_NotificationScreen_Warning.OnPressPtr      = 0;

  boxRound_OutputOnOffScreen_OnOffPanel.OwnerScreen     = &OutputOnOffScreen;
  boxRound_OutputOnOffScreen_OnOffPanel.Order           = 1;
  boxRound_OutputOnOffScreen_OnOffPanel.Left            = 202;
  boxRound_OutputOnOffScreen_OnOffPanel.Top             = 45;
  boxRound_OutputOnOffScreen_OnOffPanel.Width           = 100;
  boxRound_OutputOnOffScreen_OnOffPanel.Height          = 36;
  boxRound_OutputOnOffScreen_OnOffPanel.Pen_Width       = 1;
  boxRound_OutputOnOffScreen_OnOffPanel.Pen_Color       = 0x0000;
  boxRound_OutputOnOffScreen_OnOffPanel.Visible         = 1;
  boxRound_OutputOnOffScreen_OnOffPanel.Active          = 0;
  boxRound_OutputOnOffScreen_OnOffPanel.Transparent     = 1;
  boxRound_OutputOnOffScreen_OnOffPanel.Gradient        = 0;
  boxRound_OutputOnOffScreen_OnOffPanel.Gradient_Orientation    = 0;
  boxRound_OutputOnOffScreen_OnOffPanel.Gradient_Start_Color    = 0xFFFF;
  boxRound_OutputOnOffScreen_OnOffPanel.Gradient_End_Color      = 0xFFFF;
  boxRound_OutputOnOffScreen_OnOffPanel.Color           = 0x2124;
  boxRound_OutputOnOffScreen_OnOffPanel.PressColEnabled     = 1;
  boxRound_OutputOnOffScreen_OnOffPanel.Press_Color     = 0x8410;
  boxRound_OutputOnOffScreen_OnOffPanel.Corner_Radius      = 0;
  boxRound_OutputOnOffScreen_OnOffPanel.OnUpPtr         = 0;
  boxRound_OutputOnOffScreen_OnOffPanel.OnDownPtr       = 0;
  boxRound_OutputOnOffScreen_OnOffPanel.OnClickPtr      = 0;
  boxRound_OutputOnOffScreen_OnOffPanel.OnPressPtr      = 0;

  lbl_OutputOnOffScreen_ScreenTitle.OwnerScreen     = &OutputOnOffScreen;
  lbl_OutputOnOffScreen_ScreenTitle.Order          = 2;
  lbl_OutputOnOffScreen_ScreenTitle.Left           = 28;
  lbl_OutputOnOffScreen_ScreenTitle.Top            = 5;
  lbl_OutputOnOffScreen_ScreenTitle.Width          = 290;
  lbl_OutputOnOffScreen_ScreenTitle.Height         = 41;
  lbl_OutputOnOffScreen_ScreenTitle.Visible        = 1;
  lbl_OutputOnOffScreen_ScreenTitle.Active         = 0;
  lbl_OutputOnOffScreen_ScreenTitle.Caption        = lbl_OutputOnOffScreen_ScreenTitle_Caption;
  lbl_OutputOnOffScreen_ScreenTitle.FontName       = Arial_Black27x38_Bold;
  lbl_OutputOnOffScreen_ScreenTitle.Font_Color     = 0x0000;
  lbl_OutputOnOffScreen_ScreenTitle.OnUpPtr         = 0;
  lbl_OutputOnOffScreen_ScreenTitle.OnDownPtr       = 0;
  lbl_OutputOnOffScreen_ScreenTitle.OnClickPtr      = 0;
  lbl_OutputOnOffScreen_ScreenTitle.OnPressPtr      = 0;

  Line1.OwnerScreen     = &OutputOnOffScreen;
  Line1.Order          = 3;
  Line1.First_Point_X  = 127;
  Line1.First_Point_Y  = 257;
  Line1.Second_Point_X = 137;
  Line1.Second_Point_Y = 283;
  Line1.Visible        = 1;
  Line1.Pen_Width      = 1;
  Line1.Color          = 0x0000;

  btn_OutputOnOffScreen_Back.OwnerScreen     = &OutputOnOffScreen;
  btn_OutputOnOffScreen_Back.Order           = 4;
  btn_OutputOnOffScreen_Back.Left            = 202;
  btn_OutputOnOffScreen_Back.Top             = 185;
  btn_OutputOnOffScreen_Back.Width           = 100;
  btn_OutputOnOffScreen_Back.Height          = 36;
  btn_OutputOnOffScreen_Back.Pen_Width       = 1;
  btn_OutputOnOffScreen_Back.Pen_Color       = 0x0000;
  btn_OutputOnOffScreen_Back.Visible         = 1;
  btn_OutputOnOffScreen_Back.Active          = 1;
  btn_OutputOnOffScreen_Back.Transparent     = 1;
  btn_OutputOnOffScreen_Back.Caption         = btn_OutputOnOffScreen_Back_Caption;
  btn_OutputOnOffScreen_Back.TextAlign             = _taCenter;
  btn_OutputOnOffScreen_Back.FontName        = Helvetica16x19_Bold;
  btn_OutputOnOffScreen_Back.PressColEnabled = 1;
  btn_OutputOnOffScreen_Back.Font_Color      = 0xFFFF;
  btn_OutputOnOffScreen_Back.Gradient        = 1;
  btn_OutputOnOffScreen_Back.Gradient_Orientation    = 0;
  btn_OutputOnOffScreen_Back.Gradient_Start_Color    = 0x0000;
  btn_OutputOnOffScreen_Back.Gradient_End_Color      = 0x0000;
  btn_OutputOnOffScreen_Back.Color           = 0xC618;
  btn_OutputOnOffScreen_Back.Press_Color     = 0x8410;
  btn_OutputOnOffScreen_Back.Corner_Radius      = 0;
  btn_OutputOnOffScreen_Back.OnUpPtr         = 0;
  btn_OutputOnOffScreen_Back.OnDownPtr       = 0;
  btn_OutputOnOffScreen_Back.OnClickPtr      = btn_OutputOnOffScreen_BackOnClick;
  btn_OutputOnOffScreen_Back.OnPressPtr      = 0;

  btn_OutputOnOffScreen_EnableDisable.OwnerScreen     = &OutputOnOffScreen;
  btn_OutputOnOffScreen_EnableDisable.Order           = 5;
  btn_OutputOnOffScreen_EnableDisable.Left            = 18;
  btn_OutputOnOffScreen_EnableDisable.Top             = 94;
  btn_OutputOnOffScreen_EnableDisable.Width           = 284;
  btn_OutputOnOffScreen_EnableDisable.Height          = 76;
  btn_OutputOnOffScreen_EnableDisable.Pen_Width       = 1;
  btn_OutputOnOffScreen_EnableDisable.Pen_Color       = 0x0000;
  btn_OutputOnOffScreen_EnableDisable.Visible         = 1;
  btn_OutputOnOffScreen_EnableDisable.Active          = 1;
  btn_OutputOnOffScreen_EnableDisable.Transparent     = 1;
  btn_OutputOnOffScreen_EnableDisable.Caption         = btn_OutputOnOffScreen_EnableDisable_Caption;
  btn_OutputOnOffScreen_EnableDisable.TextAlign             = _taCenter;
  btn_OutputOnOffScreen_EnableDisable.FontName        = Helvetica19x22_Bold;
  btn_OutputOnOffScreen_EnableDisable.PressColEnabled = 0;
  btn_OutputOnOffScreen_EnableDisable.Font_Color      = 0x0000;
  btn_OutputOnOffScreen_EnableDisable.Gradient        = 1;
  btn_OutputOnOffScreen_EnableDisable.Gradient_Orientation    = 0;
  btn_OutputOnOffScreen_EnableDisable.Gradient_Start_Color    = 0xFFFF;
  btn_OutputOnOffScreen_EnableDisable.Gradient_End_Color      = 0xFFFF;
  btn_OutputOnOffScreen_EnableDisable.Color           = 0xC618;
  btn_OutputOnOffScreen_EnableDisable.Press_Color     = 0x8410;
  btn_OutputOnOffScreen_EnableDisable.Corner_Radius      = 0;
  btn_OutputOnOffScreen_EnableDisable.OnUpPtr         = 0;
  btn_OutputOnOffScreen_EnableDisable.OnDownPtr       = 0;
  btn_OutputOnOffScreen_EnableDisable.OnClickPtr      = btn_OutputOnOffScreen_EnableDisableOnClick;
  btn_OutputOnOffScreen_EnableDisable.OnPressPtr      = 0;

  lbl_OutputOnOffScreen_OutputOnOff.OwnerScreen     = &OutputOnOffScreen;
  lbl_OutputOnOffScreen_OutputOnOff.Order          = 6;
  lbl_OutputOnOffScreen_OutputOnOff.Left           = 225;
  lbl_OutputOnOffScreen_OutputOnOff.Top            = 43;
  lbl_OutputOnOffScreen_OutputOnOff.Width          = 28;
  lbl_OutputOnOffScreen_OutputOnOff.Height         = 41;
  lbl_OutputOnOffScreen_OutputOnOff.Visible        = 1;
  lbl_OutputOnOffScreen_OutputOnOff.Active         = 0;
  lbl_OutputOnOffScreen_OutputOnOff.Caption        = lbl_OutputOnOffScreen_OutputOnOff_Caption;
  lbl_OutputOnOffScreen_OutputOnOff.FontName       = Arial_Black27x38_Regular;
  lbl_OutputOnOffScreen_OutputOnOff.Font_Color     = 0x0000;
  lbl_OutputOnOffScreen_OutputOnOff.OnUpPtr         = 0;
  lbl_OutputOnOffScreen_OutputOnOff.OnDownPtr       = 0;
  lbl_OutputOnOffScreen_OutputOnOff.OnClickPtr      = 0;
  lbl_OutputOnOffScreen_OutputOnOff.OnPressPtr      = 0;
  
  lbl_OutputOnOffScreen_OutputState.OwnerScreen     = &OutputOnOffScreen;
  lbl_OutputOnOffScreen_OutputState.Order          = 7;
  lbl_OutputOnOffScreen_OutputState.Left           = 90;
  lbl_OutputOnOffScreen_OutputState.Top            = 56;
  lbl_OutputOnOffScreen_OutputState.Width          = 137;
  lbl_OutputOnOffScreen_OutputState.Height         = 20;
  lbl_OutputOnOffScreen_OutputState.Visible        = 1;
  lbl_OutputOnOffScreen_OutputState.Active         = 0;
  lbl_OutputOnOffScreen_OutputState.Caption        = lbl_OutputOnOffScreen_OutputState_Caption;
  lbl_OutputOnOffScreen_OutputState.FontName       = Helvetica16x18_Regular;
  lbl_OutputOnOffScreen_OutputState.Font_Color     = 0x0000;
  lbl_OutputOnOffScreen_OutputState.OnUpPtr         = 0;
  lbl_OutputOnOffScreen_OutputState.OnDownPtr       = 0;
  lbl_OutputOnOffScreen_OutputState.OnClickPtr      = 0;
  lbl_OutputOnOffScreen_OutputState.OnPressPtr      = 0;

  chk_OutputOnOffScreen_MidnightReset.OwnerScreen     = &OutputOnOffScreen;
  chk_OutputOnOffScreen_MidnightReset.Order           = 8;
  chk_OutputOnOffScreen_MidnightReset.Left            = 20;
  chk_OutputOnOffScreen_MidnightReset.Top             = 190;
  chk_OutputOnOffScreen_MidnightReset.Width           = 151;
  chk_OutputOnOffScreen_MidnightReset.Height          = 29;
  chk_OutputOnOffScreen_MidnightReset.Pen_Width       = 1;
  chk_OutputOnOffScreen_MidnightReset.Pen_Color       = 0x0000;
  chk_OutputOnOffScreen_MidnightReset.Visible         = 0;
  chk_OutputOnOffScreen_MidnightReset.Active          = 0;
  chk_OutputOnOffScreen_MidnightReset.Checked          = 1;
  chk_OutputOnOffScreen_MidnightReset.Transparent     = 1;
  chk_OutputOnOffScreen_MidnightReset.Caption         = chk_OutputOnOffScreen_MidnightReset_Caption;
  chk_OutputOnOffScreen_MidnightReset.TextAlign            = _taLeft;
  chk_OutputOnOffScreen_MidnightReset.FontName        = Helvetica13x16_Bold;
  chk_OutputOnOffScreen_MidnightReset.PressColEnabled = 1;
  chk_OutputOnOffScreen_MidnightReset.Font_Color      = 0x0000;
  chk_OutputOnOffScreen_MidnightReset.Gradient        = 1;
  chk_OutputOnOffScreen_MidnightReset.Gradient_Orientation    = 0;
  chk_OutputOnOffScreen_MidnightReset.Gradient_Start_Color    = 0xE71C;
  chk_OutputOnOffScreen_MidnightReset.Gradient_End_Color      = 0xE71C;
  chk_OutputOnOffScreen_MidnightReset.Color           = 0xC618;
  chk_OutputOnOffScreen_MidnightReset.Press_Color     = 0xC618;
  chk_OutputOnOffScreen_MidnightReset.Rounded          = 0;
  chk_OutputOnOffScreen_MidnightReset.Corner_Radius      = 0;
  chk_OutputOnOffScreen_MidnightReset.OnUpPtr         = 0;
  chk_OutputOnOffScreen_MidnightReset.OnDownPtr       = 0;
  chk_OutputOnOffScreen_MidnightReset.OnClickPtr      = chk_OutputOnOffScreen_MidnightOnClick;
  chk_OutputOnOffScreen_MidnightReset.OnPressPtr      = 0;
}

static char IsInsideObject (unsigned int X, unsigned int Y, unsigned int Left, unsigned int Top, unsigned int Width, unsigned int Height) { // static
  if ( (Left<= X) && (Left+ Width - 1 >= X) &&
       (Top <= Y)  && (Top + Height - 1 >= Y) )
    return 1;
  else
    return 0;
}


#define GetRoundButton(index)         CurrentScreen->Buttons_Round[index]
#define GetLabel(index)               CurrentScreen->Labels[index]
#define GetImage(index)               CurrentScreen->Images[index]
#define GetBox_Round(index)           CurrentScreen->Boxes_Round[index]
#define GetCBox_Round(index)          CurrentScreen->CBoxes_Round[index]
#define GetLine(index)                CurrentScreen->Lines[index]
#define GetCheckBox(index)           CurrentScreen->CheckBoxes[index]
#define GetRadioButton(index)           CurrentScreen->RadioButtons[index]

 void DeleteTrailingSpaces(char* str){
   char i;
   i = 0;
   while(1) {
   if(str[0] == ' ') {
      for(i = 0; i < strlen(str); i++) {
       str[i] = str[i+1];
      }
   }
   else
     break;
  }
 }

void DrawRoundButton(TButton_Round *Around_button) {
    if (Around_button->Visible == 1) {
      if (object_pressed == 1) {
        object_pressed = 0;
        TFT_Set_Brush(Around_button->Transparent, Around_button->Press_Color, Around_button->Gradient, Around_button->Gradient_Orientation,
                      Around_button->Gradient_End_Color, Around_button->Gradient_Start_Color);
      }
      else {
        TFT_Set_Brush(Around_button->Transparent, Around_button->Color, Around_button->Gradient, Around_button->Gradient_Orientation,
                      Around_button->Gradient_Start_Color, Around_button->Gradient_End_Color);
      }
      TFT_Set_Pen(Around_button->Pen_Color, Around_button->Pen_Width);
      if (Around_button->Height > Around_button->Width) {
        TFT_Rectangle_Round_Edges(Around_button->Left + 1, Around_button->Top + 1,
          Around_button->Left + Around_button->Width - 2,
          Around_button->Top + Around_button->Height - 2, Around_button->Corner_Radius);
      }
      else
        {
          TFT_Rectangle_Round_Edges(Around_button->Left + 1, Around_button->Top + 1,
            Around_button->Left + Around_button->Width - 2,
            Around_button->Top + Around_button->Height - 2, Around_button->Corner_Radius);
        }
      TFT_Set_Font(Around_button->FontName, Around_button->Font_Color, FO_HORIZONTAL);
    TFT_Write_Text_Return_Pos(Around_button->Caption, Around_button->Left, Around_button->Top);
    if (Around_button->TextAlign == _taLeft)
      TFT_Write_Text(Around_button->Caption, Around_button->Left + 4, (Around_button->Top + ((Around_button->Height - caption_height) / 2)));
    else if (Around_button->TextAlign == _taCenter)
      TFT_Write_Text(Around_button->Caption, (Around_button->Left + (Around_button->Width - caption_length) / 2), (Around_button->Top + ((Around_button->Height - caption_height) / 2)));
    else if (Around_button->TextAlign == _taRight)
      TFT_Write_Text(Around_button->Caption, Around_button->Left + (Around_button->Width - caption_length - 4), (Around_button->Top + (Around_button->Height - caption_height) / 2));
    }
}

void DrawLabel(TLabel *ALabel) {
  if (ALabel->Visible == 1) {
    TFT_Set_Font(ALabel->FontName, ALabel->Font_Color, FO_HORIZONTAL);
    TFT_Write_Text(ALabel->Caption, ALabel->Left, ALabel->Top);
  }
}

void DrawImage(TImage *AImage) {
  if (AImage->Visible) {
    TFT_Image_Jpeg(AImage->Left, AImage->Top, AImage->Picture_Name);
  }
}

void DrawRoundBox(TBox_Round *Around_box) {
    if (Around_box->Visible == 1) {
      if (object_pressed == 1) {
        object_pressed = 0;
        TFT_Set_Brush(Around_box->Transparent, Around_box->Press_Color, Around_box->Gradient, Around_box->Gradient_Orientation,
                      Around_box->Gradient_End_Color, Around_box->Gradient_Start_Color);
      }
      else {
        TFT_Set_Brush(Around_box->Transparent, Around_box->Color, Around_box->Gradient, Around_box->Gradient_Orientation,
                      Around_box->Gradient_Start_Color, Around_box->Gradient_End_Color);
      }
      TFT_Set_Pen(Around_box->Pen_Color, Around_box->Pen_Width);
      if (Around_box->Height > Around_box->Width) {
        TFT_Rectangle_Round_Edges(Around_box->Left + 1, Around_box->Top + 1,
          Around_box->Left + Around_box->Width - 2,
          Around_box->Top + Around_box->Height - 2, Around_box->Corner_Radius);
      }
      else
        {
          TFT_Rectangle_Round_Edges(Around_box->Left + 1, Around_box->Top + 1,
            Around_box->Left + Around_box->Width - 2,
            Around_box->Top + Around_box->Height - 2, Around_box->Corner_Radius);
        }
    }
}

void DrawCRoundBox(TCBox_Round *Around_box) {
    if (Around_box->Visible == 1) {
      if (object_pressed == 1) {
        object_pressed = 0;
        TFT_Set_Brush(Around_box->Transparent, Around_box->Press_Color, Around_box->Gradient, Around_box->Gradient_Orientation,
                      Around_box->Gradient_End_Color, Around_box->Gradient_Start_Color);
      }
      else {
        TFT_Set_Brush(Around_box->Transparent, Around_box->Color, Around_box->Gradient, Around_box->Gradient_Orientation,
                      Around_box->Gradient_Start_Color, Around_box->Gradient_End_Color);
      }
      TFT_Set_Pen(Around_box->Pen_Color, Around_box->Pen_Width);
      if (Around_box->Height > Around_box->Width) {
        TFT_Rectangle_Round_Edges(Around_box->Left + 1, Around_box->Top + 1,
          Around_box->Left + Around_box->Width - 2,
          Around_box->Top + Around_box->Height - 2, Around_box->Corner_Radius);
      }
      else
        {
          TFT_Rectangle_Round_Edges(Around_box->Left + 1, Around_box->Top + 1,
            Around_box->Left + Around_box->Width - 2,
            Around_box->Top + Around_box->Height - 2, Around_box->Corner_Radius);
        }
    }
}

void DrawLine(TLine *Aline) {
  if (Aline->Visible == 1) {
    TFT_Set_Pen(Aline->Color, Aline->Pen_Width);
    TFT_Line(Aline->First_Point_X, Aline->First_Point_Y, Aline->Second_Point_X, Aline->Second_Point_Y);
  }
}

void DrawCheckBox(TCheckBox *ACheckBox) {
  if (ACheckBox->Visible == 1) {
    if (object_pressed == 1) {
      object_pressed = 0;
      TFT_Set_Brush(ACheckBox->Transparent, ACheckBox->Press_Color, ACheckBox->Gradient, ACheckBox->Gradient_Orientation, ACheckBox->Gradient_End_Color, ACheckBox->Gradient_Start_Color);
    }
    else {
      TFT_Set_Brush(ACheckBox->Transparent, ACheckBox->Color, ACheckBox->Gradient, ACheckBox->Gradient_Orientation, ACheckBox->Gradient_Start_Color, ACheckBox->Gradient_End_Color);
    }
    TFT_Set_Pen(ACheckBox->Pen_Color, ACheckBox->Pen_Width);
    if (ACheckBox->TextAlign == _taLeft) {
             if (ACheckBox->Rounded == 1)
                TFT_Rectangle_Round_Edges(ACheckBox->Left, ACheckBox->Top, ACheckBox->Left + ACheckBox->Height, ACheckBox->Top + ACheckBox->Height - 1, ACheckBox->Corner_Radius);
                                           else
                TFT_Rectangle(ACheckBox->Left, ACheckBox->Top, ACheckBox->Left + ACheckBox->Height, ACheckBox->Top + ACheckBox->Height - 1);
            if (ACheckBox->Checked == 1) {
                      TFT_Set_Pen(ACheckBox->Pen_Color, ACheckBox->Height / 8);
                      TFT_Line(ACheckBox->Left  + ACheckBox->Height / 5 + 1,
                                             ACheckBox->Top   + ACheckBox->Height / 2 + 1,
                                             ACheckBox->Left  + ACheckBox->Height / 2 - 1,
                                             ACheckBox->Top   + ACheckBox->Height - ACheckBox->Height / 5 - 1);
                      TFT_Line(ACheckBox->Left  + ACheckBox->Height / 2 - ACheckBox->Pen_Width + 1,
                                             ACheckBox->Top   + ACheckBox->Height -  ACheckBox->Height / 5 - 1,
                                             ACheckBox->Left  + ACheckBox->Height - ACheckBox->Height / 5 - 1,
                                             ACheckBox->Top   + ACheckBox->Height / 5 + 1);
                  }
             TFT_Set_Font(ACheckBox->FontName, ACheckBox->Font_Color, FO_HORIZONTAL);
              TFT_Write_Text_Return_Pos(ACheckBox->Caption, ACheckBox->Left + ACheckBox->Height + 4, ACheckBox->Top);
              TFT_Write_Text(ACheckBox->Caption, ACheckBox->Left + ACheckBox->Height + 4, (ACheckBox->Top + ((ACheckBox->Height - caption_height) / 2)));
         }
    else if (ACheckBox->TextAlign == _taRight) {
            if (ACheckBox->Rounded == 1)
               TFT_Rectangle_Round_Edges(ACheckBox->Left + ACheckBox->Width - ACheckBox->Height  , ACheckBox->Top, ACheckBox->Left + ACheckBox->Width, ACheckBox->Top + ACheckBox->Height - 1, ACheckBox->Corner_Radius);
                                           else
               TFT_Rectangle(ACheckBox->Left + ACheckBox->Width - ACheckBox->Height  , ACheckBox->Top, ACheckBox->Left + ACheckBox->Width, ACheckBox->Top + ACheckBox->Height - 1);
           if (ACheckBox->Checked == 1) {
                    TFT_Set_Pen(ACheckBox->Pen_Color, ACheckBox->Height / 8);
                    TFT_Line(ACheckBox->Left  + ACheckBox->Width - ACheckBox->Height + ACheckBox->Height / 5 + 1,
                                           ACheckBox->Top +  ACheckBox->Height / 2 + 1,
                                           ACheckBox->Left + ACheckBox->Width  - ACheckBox->Height /2 - 1,
                                           ACheckBox->Top   + ACheckBox->Height - ACheckBox->Height / 5 - 1);
                    TFT_Line(ACheckBox->Left + ACheckBox->Width  - ACheckBox->Height /2 + 1,
                                           ACheckBox->Top   + ACheckBox->Height -  ACheckBox->Height / 5 - 1,
                                           ACheckBox->Left + ACheckBox->Width  - ACheckBox->Height / 5 - 1,
                                           ACheckBox->Top   + ACheckBox->Height / 5 + 1);
          }
             TFT_Set_Font(ACheckBox->FontName, ACheckBox->Font_Color, FO_HORIZONTAL);
             TFT_Write_Text_Return_Pos(ACheckBox->Caption, ACheckBox->Left + 3, ACheckBox->Top);
             TFT_Write_Text(ACheckBox->Caption, ACheckBox->Left + 3, ACheckBox->Top + (ACheckBox->Height - caption_height) / 2);
           }
        }
}

void DrawRadioButton(TRadioButton *ARadioButton) {
  int circleOffset = 0;
  if (ARadioButton->Visible == 1) {
  circleOffset = ARadioButton->Height / 5;
    TFT_Set_Pen(ARadioButton->Pen_Color, ARadioButton->Pen_Width);
    if (ARadioButton->TextAlign == _taLeft) {
             TFT_Set_Brush(ARadioButton->Transparent,ARadioButton->Background_Color,0,0,0,0);
             TFT_Circle(ARadioButton->Left + ARadioButton->Height / 2, ARadioButton->Top + ARadioButton->Height / 2, ARadioButton->Height / 2);
             if (ARadioButton->Checked == 1) {
                 if (object_pressed == 1) {
                    object_pressed = 0;
                    TFT_Set_Brush(ARadioButton->Transparent, ARadioButton->Press_Color, ARadioButton->Gradient, ARadioButton->Gradient_Orientation, ARadioButton->Gradient_End_Color, ARadioButton->Gradient_Start_Color);
                 }
                 else 
                   TFT_Set_Brush(ARadioButton->Transparent, ARadioButton->Color, ARadioButton->Gradient, ARadioButton->Gradient_Orientation, ARadioButton->Gradient_Start_Color, ARadioButton->Gradient_End_Color);
               TFT_Circle(ARadioButton->Left + ARadioButton->Height / 2 , ARadioButton->Top + ARadioButton->Height / 2, ARadioButton->Height / 2 - circleOffset);
             }
             TFT_Set_Font(ARadioButton->FontName, ARadioButton->Font_Color, FO_HORIZONTAL);
             TFT_Write_Text_Return_Pos(ARadioButton->Caption, ARadioButton->Left + ARadioButton->Height + 4, ARadioButton->Top);
             TFT_Write_Text(ARadioButton->Caption, ARadioButton->Left + ARadioButton->Height + 4, (ARadioButton->Top + ((ARadioButton->Height - caption_height) / 2)));
    }
    else if (ARadioButton->TextAlign == _taRight) {
             TFT_Set_Brush(ARadioButton->Transparent,ARadioButton->Background_Color,0,0,0,0);
             TFT_Circle(ARadioButton->Left  + ARadioButton->Width - ARadioButton->Height / 2, ARadioButton->Top + ARadioButton->Height / 2, ARadioButton->Height / 2);
             if (ARadioButton->Checked == 1) {
                 if (object_pressed == 1) {
                    object_pressed = 0;
                    TFT_Set_Brush(ARadioButton->Transparent, ARadioButton->Press_Color, ARadioButton->Gradient, ARadioButton->Gradient_Orientation, ARadioButton->Gradient_End_Color, ARadioButton->Gradient_Start_Color);
                 }
                 else 
                   TFT_Set_Brush(ARadioButton->Transparent, ARadioButton->Color, ARadioButton->Gradient, ARadioButton->Gradient_Orientation, ARadioButton->Gradient_Start_Color, ARadioButton->Gradient_End_Color);
                 TFT_Circle(ARadioButton->Left  + ARadioButton->Width - ARadioButton->Height / 2, ARadioButton->Top + ARadioButton->Height / 2, ARadioButton->Height / 2 - circleOffset);
             }
             TFT_Set_Font(ARadioButton->FontName, ARadioButton->Font_Color, FO_HORIZONTAL);
             TFT_Write_Text_Return_Pos(ARadioButton->Caption, ARadioButton->Left + 3, ARadioButton->Top);
             TFT_Write_Text(ARadioButton->Caption, ARadioButton->Left + 3, ARadioButton->Top + (ARadioButton->Height - caption_height) / 2);
    }
 }
}

void DrawScreen(TScreen *aScreen) {
 int order;
  unsigned short round_button_idx;
  TButton_Round *local_round_button;
  unsigned short label_idx;
  TLabel *local_label;
  unsigned short image_idx;
  TImage *local_image;
  unsigned short round_box_idx;
  TBox_Round *local_round_box;
  unsigned short round_cbox_idx;
  TCBox_Round *local_round_cbox;
  unsigned short line_idx;
  TLine *local_line;
  unsigned short checkBox_idx;
  TCheckBox *local_checkBox;
  unsigned short radio_button_idx;
  TRadioButton *local_radio_button;
  char save_bled, save_bled_direction;

  object_pressed = 0;
  order = 0;
  round_button_idx = 0;
  label_idx = 0;
  image_idx = 0;
  round_box_idx = 0;
  round_cbox_idx = 0;
  line_idx = 0;
  checkbox_idx = 0;
  radio_button_idx = 0;
  CurrentScreen = aScreen;

  if ((display_width != CurrentScreen->Width) || (display_height != CurrentScreen->Height)) {
    save_bled = TFT_BLED;
    save_bled_direction = TFT_BLED_Direction;
    TFT_BLED_Direction = 0;
    TFT_BLED           = 0;
    TFT_Set_Active(Set_Index, Write_Command, Write_Data);
    //TFT_Init(CurrentScreen->Width, CurrentScreen->Height);    //OLD Displays
    TFT_Init_ILI9341_8bit(CurrentScreen->Width, CurrentScreen->Height);    //NEW Displays
    TP_TFT_Init(CurrentScreen->Width, CurrentScreen->Height, 13, 12);                                  // Initialize touch panel
    TP_TFT_Set_ADC_Threshold(ADC_THRESHOLD);                              // Set touch panel ADC threshold
    TFT_Fill_Screen(CurrentScreen->Color);
    display_width = CurrentScreen->Width;
    display_height = CurrentScreen->Height;
    TFT_BLED           = save_bled;
    TFT_BLED_Direction = save_bled_direction;
  }
  else
    TFT_Fill_Screen(CurrentScreen->Color);


  while (order < CurrentScreen->ObjectsCount) {
    if (round_button_idx < CurrentScreen->Buttons_RoundCount) {
      local_round_button = GetRoundButton(round_button_idx);
      if (order == local_round_button->Order) {
        order++;
        round_button_idx++;
        DrawRoundButton(local_round_button);
      }
    }

    if (label_idx < CurrentScreen->LabelsCount) {
      local_label = GetLabel(label_idx);
      if (order == local_label->Order) {
        label_idx++;
        order++;
        DrawLabel(local_label);
      }
    }

    if (round_box_idx < CurrentScreen->Boxes_RoundCount) {
      local_round_box = GetBox_Round(round_box_idx);
      if (order == local_round_box->Order) {
        round_box_idx++;
        order++;
        DrawRoundBox(local_round_box);
      }
    }

    if (round_cbox_idx < CurrentScreen->CBoxes_RoundCount) {
      local_round_cbox = GetCBox_Round(round_cbox_idx);
      if (order == local_round_cbox->Order) {
        round_cbox_idx++;
        order++;
        DrawCRoundBox(local_round_cbox);
      }
    }

    if (line_idx  < CurrentScreen->LinesCount) {
      local_line = GetLine(line_idx);
      if (order == local_line->Order) {
        line_idx++;
        order++;
        DrawLine(local_line);
      }
    }

    if (image_idx  < CurrentScreen->ImagesCount) {
      local_image = GetImage(image_idx);
      if (order == local_image->Order) {
        image_idx++;
        order++;
        DrawImage(local_image);
      }
    }

    if (checkbox_idx  < CurrentScreen->CheckBoxesCount) {
      local_checkBox = GetCheckBox(checkbox_idx);
      if (order == local_checkBox->Order) {
        checkbox_idx++;
        order++;
        DrawCheckBox(local_checkBox);
      }
    }

    if (radio_button_idx  < CurrentScreen->RadioButtonsCount) {
      local_radio_button = GetRadioButton(radio_button_idx);
      if (order == local_radio_button->Order) {
        radio_button_idx++;
        order++;
        DrawRadioButton(local_radio_button);
      }
    }

  }
}

void Get_Object(unsigned int X, unsigned int Y) {
  round_button_order  = -1;
  label_order         = -1;
  image_order         = -1;
  box_round_order     = -1;
  cbox_round_order    = -1;
  checkBox_order    = -1;
  radio_button_order    = -1;
  //  Buttons with Round Edges
  for ( _object_count = 0 ; _object_count < CurrentScreen->Buttons_RoundCount ; _object_count++ ) {
    local_round_button = GetRoundButton(_object_count);
    if (local_round_button->Active == 1) {
      if (IsInsideObject(X, Y, local_round_button->Left, local_round_button->Top,
                         local_round_button->Width, local_round_button->Height) == 1) {
        round_button_order = local_round_button->Order;
        exec_round_button = local_round_button;
      }
    }
  }

  //  Labels
  for ( _object_count = 0 ; _object_count < CurrentScreen->LabelsCount ; _object_count++ ) {
    local_label = GetLabel(_object_count);
    if (local_label->Active == 1) {
      if (IsInsideObject(X, Y, local_label->Left, local_label->Top,
                         local_label->Width, local_label->Height) == 1) {
        label_order = local_label->Order;
        exec_label = local_label;
      }
    }
  }

  //  Images
  for ( _object_count = 0 ; _object_count < CurrentScreen->ImagesCount ; _object_count++ ) {
    local_image = GetImage(_object_count);
    if (local_image->Active == 1) {
      if (IsInsideObject(X, Y, local_image->Left, local_image->Top,
                         local_image->Width, local_image->Height) == 1) {
        image_order = local_image->Order;
        exec_image = local_image;
      }
    }
  }

  //  Boxes with Round Edges
  for ( _object_count = 0 ; _object_count < CurrentScreen->Boxes_RoundCount ; _object_count++ ) {
    local_round_box = GetBox_Round(_object_count);
    if (local_round_box->Active == 1) {
      if (IsInsideObject(X, Y, local_round_box->Left, local_round_box->Top,
                         local_round_box->Width, local_round_box->Height) == 1) {
        box_round_order = local_round_box->Order;
        exec_round_box = local_round_box;
      }
    }
  }

  //  CBoxes with Round Edges
  for ( _object_count = 0 ; _object_count < CurrentScreen->CBoxes_RoundCount ; _object_count++ ) {
    local_round_cbox = GetCBox_Round(_object_count);
    if (local_round_cbox->Active == 1) {
      if (IsInsideObject(X, Y, local_round_cbox->Left, local_round_cbox->Top,
                         local_round_cbox->Width, local_round_cbox->Height) == 1) {
        cbox_round_order = local_round_cbox->Order;
        exec_round_cbox = local_round_cbox;
      }
    }
  }

  // CheckBoxes
  for ( _object_count = 0 ; _object_count < CurrentScreen->CheckBoxesCount ; _object_count++ ) {
    local_checkBox = GetCheckBox(_object_count);
    if (local_checkBox->Active == 1) {
      if (IsInsideObject(X, Y, local_checkBox->Left, local_checkBox->Top,
                         local_checkBox->Width, local_checkBox->Height) == 1) {
        checkBox_order = local_checkBox->Order;
        exec_checkBox = local_checkBox;
      }
    }
  }

  // RadioButtons
  for ( _object_count = 0 ; _object_count < CurrentScreen->RadioButtonsCount ; _object_count++ ) {
    local_radio_button = GetRadioButton(_object_count);
    if (local_radio_button->Active == 1) {
      if (IsInsideObject(X, Y, local_radio_button->Left, local_radio_button->Top,
                         local_radio_button->Width, local_radio_button->Height) == 1) {
        radio_button_order = local_radio_button->Order;
        exec_radio_button = local_radio_button;
      }
    }
  }

  _object_count = -1;
  if (round_button_order > _object_count)
    _object_count = round_button_order;
  if (label_order >  _object_count )
    _object_count = label_order;
  if (image_order >  _object_count )
    _object_count = image_order;
  if (box_round_order >  _object_count )
    _object_count = box_round_order;
  if (cbox_round_order >  _object_count )
    _object_count = cbox_round_order;
  if (checkBox_order >  _object_count )
    _object_count = checkBox_order;
  if (radio_button_order >  _object_count )
    _object_count = radio_button_order;
}


static void Process_TP_Press(unsigned int X, unsigned int Y) {
  exec_round_button   = 0;
  exec_label          = 0;
  exec_image          = 0;
  exec_round_box      = 0;
  exec_round_cbox     = 0;
  exec_checkBox      = 0;
  exec_radio_button     = 0;

  Get_Object(X, Y);


  if (_object_count != -1) {
    if (_object_count == round_button_order) {
      if (exec_round_button->Active == 1) {
        if (exec_round_button->OnPressPtr != 0) {
          exec_round_button->OnPressPtr();
          return;
        }
      }
    }

    if (_object_count == label_order) {
      if (exec_label->Active == 1) {
        if (exec_label->OnPressPtr != 0) {
          exec_label->OnPressPtr();
          return;
        }
      }
    }

    if (_object_count == image_order) {
      if (exec_image->Active == 1) {
        if (exec_image->OnPressPtr != 0) {
          exec_image->OnPressPtr();
          return;
        }
      }
    }

    if (_object_count == box_round_order) {
      if (exec_round_box->Active == 1) {
        if (exec_round_box->OnPressPtr != 0) {
          exec_round_box->OnPressPtr();
          return;
        }
      }
    }

    if (_object_count == cbox_round_order) {
      if (exec_round_cbox->Active == 1) {
        if (exec_round_cbox->OnPressPtr != 0) {
          exec_round_cbox->OnPressPtr();
          return;
        }
      }
    }

    if (_object_count == checkBox_order) {
      if (exec_checkBox->Active == 1) {
        if (exec_checkBox->OnPressPtr != 0) {
          exec_checkBox->OnPressPtr();
          return;
        }
      }
    }

    if (_object_count == radio_button_order) {
      if (exec_radio_button->Active == 1) {
        if (exec_radio_button->OnPressPtr != 0) {
          exec_radio_button->OnPressPtr();
          return;
        }
      }
    }

  }
}

static void Process_TP_Up(unsigned int X, unsigned int Y) {

  switch (PressedObjectType) {
    // Round Button
    case 1: {
      if (PressedObject != 0) {
        exec_round_button = (TButton_Round*)PressedObject;
        if ((exec_round_button->PressColEnabled == 1) && (exec_round_button->OwnerScreen == CurrentScreen)) {
          DrawRoundButton(exec_round_button);
        }
        break;
      }
      break;
    }
    // Round Box
    case 7: {
      if (PressedObject != 0) {
        exec_round_box = (TBox_Round*)PressedObject;
        if ((exec_round_box->PressColEnabled == 1) && (exec_round_box->OwnerScreen == CurrentScreen)) {
          DrawRoundBox(exec_round_box);
        }
        break;
      }
      break;
    }
    // CRound Box
    case 15: {
      if (PressedObject != 0) {
        exec_round_cbox = (TCBox_Round*)PressedObject;
        if ((exec_round_cbox->PressColEnabled == 1) && (exec_round_cbox->OwnerScreen == CurrentScreen)) {
          DrawCRoundBox(exec_round_cbox);
        }
        break;
      }
      break;
    }
    // Check Box
    case 16: {
      if (PressedObject != 0) {
        exec_checkBox = (TCheckBox*)PressedObject;
        if ((exec_checkBox->PressColEnabled == 1) && (exec_checkBox->OwnerScreen == CurrentScreen)) {
          DrawCheckBox(exec_checkBox);
        }
        break;
      }
      break;
    }
    // RadioButton
    case 17: {
      if (PressedObject != 0) {
        exec_radio_button = (TRadioButton*)PressedObject;
        if ((exec_radio_button->PressColEnabled == 1) && (exec_radio_button->OwnerScreen == CurrentScreen)) {
          DrawRadioButton(exec_radio_button);
        }
        break;
      }
      break;
    }
  }

  exec_label          = 0;
  exec_image          = 0;

  Get_Object(X, Y);


  if (_object_count != -1) {
  // Buttons with Round Edges
    if (_object_count == round_button_order) {
      if (exec_round_button->Active == 1) {
        if (exec_round_button->OnUpPtr != 0)
          exec_round_button->OnUpPtr();
        if (PressedObject == (TPointer)exec_round_button)
          if (exec_round_button->OnClickPtr != 0)
            exec_round_button->OnClickPtr();
        PressedObject = 0;
        PressedObjectType = -1;
        return;
      }
    }

  // Labels
    if (_object_count == label_order) {
      if (exec_label->Active == 1) {
        if (exec_label->OnUpPtr != 0)
          exec_label->OnUpPtr();
        if (PressedObject == (TPointer)exec_label)
          if (exec_label->OnClickPtr != 0)
            exec_label->OnClickPtr();
        PressedObject = 0;
        PressedObjectType = -1;
        return;
      }
    }

  // Images
    if (_object_count == image_order) {
      if (exec_image->Active == 1) {
        if (exec_image->OnUpPtr != 0)
          exec_image->OnUpPtr();
        if (PressedObject == (TPointer)exec_image)
          if (exec_image->OnClickPtr != 0)
            exec_image->OnClickPtr();
        PressedObject = 0;
        PressedObjectType = -1;
        return;
      }
    }

  // Boxes with Round Edges
    if (_object_count == box_round_order) {
      if (exec_round_box->Active == 1) {
        if (exec_round_box->OnUpPtr != 0)
          exec_round_box->OnUpPtr();
        if (PressedObject == (TPointer)exec_round_box)
          if (exec_round_box->OnClickPtr != 0)
            exec_round_box->OnClickPtr();
        PressedObject = 0;
        PressedObjectType = -1;
        return;
      }
    }

  // CBoxes with Round Edges
    if (_object_count == cbox_round_order) {
      if (exec_round_cbox->Active == 1) {
        if (exec_round_cbox->OnUpPtr != 0)
          exec_round_cbox->OnUpPtr();
        if (PressedObject == (TPointer)exec_round_cbox)
          if (exec_round_cbox->OnClickPtr != 0)
            exec_round_cbox->OnClickPtr();
        PressedObject = 0;
        PressedObjectType = -1;
        return;
      }
    }

  // CheckBoxes
    if (_object_count == checkBox_order) {
      if (exec_checkBox->Active == 1) {
        if (exec_checkBox->OnUpPtr != 0)
          exec_checkBox->OnUpPtr();
        if (PressedObject == (TPointer)exec_checkBox) {
          if (exec_checkBox->Checked == 1)
            exec_checkBox->Checked = 0;
          else
            exec_checkBox->Checked = 1;
          DrawCheckBox(exec_checkBox);
          if (exec_checkBox->OnClickPtr != 0)
            exec_checkBox->OnClickPtr();
        }
        PressedObject = 0;
        PressedObjectType = -1;
        return;
      }
    }

  // RadioButtons
    if (_object_count == radio_button_order) {
      if (exec_radio_button->Active == 1) {
        if (exec_radio_button->OnUpPtr != 0)
          exec_radio_button->OnUpPtr();
        if (PressedObject == (TPointer)exec_radio_button)
          if (exec_radio_button->OnClickPtr != 0)
            exec_radio_button->OnClickPtr();
        PressedObject = 0;
        PressedObjectType = -1;
        return;
      }
    }

  }
  PressedObject = 0;
  PressedObjectType = -1;
}

static void Process_TP_Down(unsigned int X, unsigned int Y) {

  object_pressed      = 0;
  exec_round_button   = 0;
  exec_label          = 0;
  exec_image          = 0;
  exec_round_box      = 0;
  exec_round_cbox     = 0;
  exec_checkBox      = 0;
  exec_radio_button     = 0;

  Get_Object(X, Y);

  if (_object_count != -1) {
    if (_object_count == round_button_order) {
      if (exec_round_button->Active == 1) {
        if (exec_round_button->PressColEnabled == 1) {
          object_pressed = 1;
          DrawRoundButton(exec_round_button);
        }
        PressedObject = (TPointer)exec_round_button;
        PressedObjectType = 1;
        if (exec_round_button->OnDownPtr != 0) {
          exec_round_button->OnDownPtr();
          return;
        }
      }
    }

    if (_object_count == label_order) {
      if (exec_label->Active == 1) {
        PressedObject = (TPointer)exec_label;
        PressedObjectType = 2;
        if (exec_label->OnDownPtr != 0) {
          exec_label->OnDownPtr();
          return;
        }
      }
    }

    if (_object_count == image_order) {
      if (exec_image->Active == 1) {
        PressedObject = (TPointer)exec_image;
        PressedObjectType = 3;
        if (exec_image->OnDownPtr != 0) {
          exec_image->OnDownPtr();
          return;
        }
      }
    }

    if (_object_count == box_round_order) {
      if (exec_round_box->Active == 1) {
        if (exec_round_box->PressColEnabled == 1) {
          object_pressed = 1;
          DrawRoundBox(exec_round_box);
        }
        PressedObject = (TPointer)exec_round_box;
        PressedObjectType = 7;
        if (exec_round_box->OnDownPtr != 0) {
          exec_round_box->OnDownPtr();
          return;
        }
      }
    }

    if (_object_count == cbox_round_order) {
      if (exec_round_cbox->Active == 1) {
        if (exec_round_cbox->PressColEnabled == 1) {
          object_pressed = 1;
          DrawCRoundBox(exec_round_cbox);
        }
        PressedObject = (TPointer)exec_round_cbox;
        PressedObjectType = 15;
        if (exec_round_cbox->OnDownPtr != 0) {
          exec_round_cbox->OnDownPtr();
          return;
        }
      }
    }

    if (_object_count == checkBox_order) {
      if (exec_checkBox->Active == 1) {
        if (exec_checkBox->PressColEnabled == 1) {
          object_pressed = 1;
          DrawCheckBox(exec_checkBox);
        }
        PressedObject = (TPointer)exec_checkBox;
        PressedObjectType = 16;
        if (exec_checkBox->OnDownPtr != 0) {
          exec_checkBox->OnDownPtr();
          return;
        }
      }
    }

    if (_object_count == radio_button_order) {
      if (exec_radio_button->Active == 1) {
        if (exec_radio_button->PressColEnabled == 1) {
          object_pressed = 1;
          DrawRadioButton(exec_radio_button);
        }
        PressedObject = (TPointer)exec_radio_button;
        PressedObjectType = 17;
        if (exec_radio_button->OnDownPtr != 0) {
          exec_radio_button->OnDownPtr();
          return;
        }
      }
    }

  }
}

void Check_TP() {
  if (TP_TFT_Press_Detect()) {
    // After a PRESS is detected read X-Y and convert it to Display dimensions space
    if (TP_TFT_Get_Coordinates(&Xcoord, &Ycoord) == 0) {
      Process_TP_Press(Xcoord, Ycoord);
      if (PenDown == 0) {
        PenDown = 1;
        Process_TP_Down(Xcoord, Ycoord);
      }
    }
  }
  else if (PenDown == 1) {
    PenDown = 0;
    Process_TP_Up(Xcoord, Ycoord);
  }
}

void Init_MCU() {
  PMMODE = 0;
  PMAEN  = 0;
  PMCON  = 0;  // WRSP: Write Strobe Polarity bit
  PMMODEbits.MODE = 2;     // Master 2
  PMMODEbits.WAITB = 0;
  PMMODEbits.WAITM = 1;
  PMMODEbits.WAITE = 0;
  PMMODEbits.MODE16 = 1;   // 16 bit mode
  PMCONbits.CSF = 0;
  PMCONbits.PTRDEN = 1;
  PMCONbits.PTWREN = 1;
  PMCONbits.PMPEN = 1;
    //TP_TFT_Rotate_180(0);
  TP_TFT_Rotate_180(1);
  TFT_Rotate_180(1);
  TFT_Set_Active(Set_Index,Write_Command,Write_Data);
}

void Start_TP() {
  Init_MCU();

  InitializeTouchPanel();

  Delay_ms(1000);
  TFT_Fill_Screen(0);
  //Calibrate();
  TP_TFT_Set_Calibration_Consts(64, 905, 116, 855); //NEW Displays
  //TP_TFT_Set_Calibration_Consts(96, 922,92, 902);  //OLD Displays


  TFT_Fill_Screen(0);

  InitializeObjects();
  display_width = SplashScreen.Width;
  display_height = SplashScreen.Height;
  DrawScreen(&SplashScreen);
}