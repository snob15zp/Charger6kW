/*
 * FreeModbus Libary: BARE Port
 * Copyright (C) 2006 Christian Walter <wolti@sil.at>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * File: $Id: portserial.c,v 1.1 2006/08/22 21:35:13 wolti Exp $
 */

#include "port.h"
//#include <plib.h>      // Peripheral Library   // Modified by CJ 01_11_2012
#include "rs485.h"                               // Modified by CJ 01_11_2012
/* ----------------------- Modbus includes ----------------------------------*/
#include "mb.h"
#include "mbport.h"

sbit RS485_TX_ENABLE_A at LATD14_bit;      // Was LATD11_bit
sbit RS485_RX_ENABLE_A at LATD15_bit;      // Was LATD11_bit
/* ----------------------- static functions ---------------------------------*/
static void prvvUARTTxReadyISR( void );
static void prvvUARTRxISR( void );

/* ----------------------- Start implementation -----------------------------*/
void vMBPortSerialEnable( BOOL xRxEnable, BOOL xTxEnable )
{
    /* If xRXEnable enable serial receive interrupts. If xTxENable enable
     * transmitter empty interrupts.
     */
     // Modified by CJ 01_11_2012 ...
     if(xRxEnable == TRUE && xTxEnable == TRUE)
     {
        U2RXIE_bit = 1;  // EnableIntU2RX;
        U2TXIE_bit = 1;  // EnableIntU2TX;
     }
     else if(xRxEnable == TRUE && xTxEnable == FALSE)
     {
        U2RXIE_bit = 1;  // EnableIntU2RX;
        U2TXIE_bit = 0;  // DisableIntU2TX;
        RS485_RX_ENABLE_A = 0;
        RS485_TX_ENABLE_A = 0;
     }
     else if(xRxEnable == FALSE && xTxEnable == TRUE)
     {
        U2RXIE_bit = 0;  // DisableIntU2RX;
        U2TXIE_bit = 1;  // EnableIntU2TX;
        RS485_RX_ENABLE_A = 1;
        RS485_TX_ENABLE_A = 1;
        
        U2TXIF_bit = 1;
        //IFS1bits.U2TXIF = 1;
     }
     else if(xRxEnable == FALSE && xTxEnable == FALSE)
     {
        U2RXIE_bit = 0;  // DisableIntU2RX;
        U2TXIE_bit = 0;  // DisableIntU2TX;
     }
     // end modifications
}

BOOL xMBPortSerialInit( UCHAR ucPORT, ULONG ulBaudRate, UCHAR ucDataBits, eMBParity eParity )
{
   //if (ucDataBits = 7)
   //   RS485_Init(ulBaudRate, 80000, _UART_7BIT_NOPARITY, _UART_TWO_STOPBITS);
   //else
   
   switch (eParity)
   {
      case MB_PAR_NONE:
         RS485_Init(ulBaudRate, 80000, _UART_8BIT_NOPARITY, _UART_TWO_STOPBITS);
         break;
      case MB_PAR_ODD:
         RS485_Init(ulBaudRate, 80000, _UART_8BIT_ODDPARITY, _UART_ONE_STOPBIT);
         break;
      case MB_PAR_EVEN:
         RS485_Init(ulBaudRate, 80000, _UART_8BIT_EVENPARITY, _UART_ONE_STOPBIT);
         break;
   }
   
   RS485_InitRxTx();
   /*
        int pbClk;

        pbClk=SYSTEMConfig(SYS_FREQ, SYS_CFG_WAIT_STATES | SYS_CFG_PCACHE);
        if (ucPORT == 1){
                OpenUART1(UART_EN,                                           // Module is ON
                                  UART_RX_ENABLE | UART_TX_ENABLE,           // Enable TX & RX
                                  pbClk/16/ulBaudRate-1);                    //
                ConfigIntUART1(UART_INT_PR2 | UART_RX_INT_EN);
        }
        else if (ucPORT == 2){
                OpenUART2(UART_EN | UART_NO_PAR_8BIT | UART_2STOPBITS,       // Module is ON
                                  UART_RX_ENABLE | UART_TX_ENABLE,           // Enable TX & RX
                                  pbClk/16/ulBaudRate-1);                    //
                ConfigIntUART2(UART_INT_PR2 | UART_RX_INT_EN);
        }
        INTEnableSystemMultiVectoredInt();
   */
    return TRUE;
}

BOOL xMBPortSerialPutByte( CHAR ucByte )
{
    /* Put a byte in the UARTs transmit buffer. This function is called
     * by the protocol stack if pxMBFrameCBTransmitterEmpty( ) has been
     * called. */
    RS485_PutChar(ucByte); // putcUART2(ucByte);  // Modified by CJ 01_11_2012
    return TRUE;
}

BOOL xMBPortSerialGetByte( CHAR * pucByte )
{
    /* Return the byte in the UARTs receive buffer. This function is called
     * by the protocol stack after pxMBFrameCBByteReceived( ) has been called.
     */
    *pucByte = RS485_GetChar(); // *pucByte = ReadUART2(); // Modified by CJ 01_11_2012
    return TRUE;
}

/* Create an interrupt handler for the transmit buffer empty interrupt
 * (or an equivalent) for your target processor. This function should then
 * call pxMBFrameCBTransmitterEmpty( ) which tells the protocol stack that
 * a new character can be sent. The protocol stack will then call 
 * xMBPortSerialPutByte( ) to send the character.
 */

// UART 2 interrupt handler
// it is set at priority level 2

// Modified by CJ 01_11_2012 ...
/*
void __ISR(_UART2_VECTOR, ipl2) IntUart2Handler(void){

        // RX interrupt
        if(mU2RXGetIntFlag())
        {
                // Clear the RX interrupt Flag
            mU2RXClearIntFlag();
                pxMBFrameCBByteReceived(  );

        }

        // TX interrupt
        if ( mU2TXGetIntFlag() )
        {
                mU2TXClearIntFlag();
                pxMBFrameCBTransmitterEmpty(  );

        }
}
*/