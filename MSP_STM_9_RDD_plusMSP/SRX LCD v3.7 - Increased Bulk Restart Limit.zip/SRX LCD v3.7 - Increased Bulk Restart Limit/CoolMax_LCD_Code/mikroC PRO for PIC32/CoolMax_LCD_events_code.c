#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"

//--------------------- User code ---------------------//

//----------------- End of User code ------------------//

// Event Handlers
