#ifndef SCR_SETPOINTSEDITSCREEN_H
#define SCR_SETPOINTSEDITSCREEN_H

#define MAXIMUM_DIGITS 6
#define MAXIMUM_TITLE_SIZE 14


typedef struct
{
 unsigned char SetpointTitle[MAXIMUM_TITLE_SIZE];
 float RawFloatValue;
 unsigned char Dig1;
 unsigned char Dig2;
 unsigned char Dig3;
 unsigned char DecPt;
 unsigned char Dig4;
 unsigned char Dig5;
 unsigned int  DecimalPlaces;
 unsigned char DigType[5];
 unsigned char Time;
 unsigned char IsVolt;
 unsigned char IsTemp;
 unsigned char IsTime;
 
} scr_SetpointsEditScreen_Type;

enum SELECTED_DIGIT
{
 FirstDigit=0,
 SecondDigit,
 ThirdDigit,
 Decimal,
 FourthDigit,
 LastDigit
} ;

extern  scr_SetpointsEditScreen_Type scr_SetpointsEditScreen;

void UpdateSetpointsEditScreen(scr_SetpointsEditScreen_Type *Screen);
void Init_SetpointsEditScreen(scr_SetpointsEditScreen_Type *screen);
void Save_SetpointsEditScreen(scr_SetpointsEditScreen_Type *screen);

void NextDigitSelection();


#endif