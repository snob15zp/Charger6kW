#ifndef FRAM_H
#define FRAM_H

// 2 Mbit F-RAM chip
static const unsigned long FRAM_MEMORY_SIZE = 0x40000;

void FRAMInit();
int FRAMWriteBuffer(unsigned long memAddr, unsigned char *buffer, unsigned int length);
int FRAMReadBuffer(unsigned long memAddr, unsigned char *buffer, unsigned int len);



//void debug_programm_flash(void);

//unsigned char FRAMReadStatusRegister();
//void FRAMWriteStatusRegister(unsigned char reg);
//void FRAMReadDeviceID(unsigned char *deviceID);

#endif