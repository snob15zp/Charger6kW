#ifndef SCR_SETPOINTSSCREEN1_H
#define SCR_SETPOINTSSCREEN1_H

#include "CoolMax_LCD_objects.h"
#include "scr_SetpointsEditScreen.h"

#define SELECTED_NAME_COLOR CL_BLACK    //changed to CL_black
#define UNSELECTED_NAME_COLOR CL_BLACK

#define UNSELECTED_VALUE_COLOR CL_BLACK // orange colour type
#define SELECTED_VALUE_COLOR CL_BLACK   //changed to CL_black

#define BOX_COLOR 0xF7BE  //light grey eselected colour
#define SELECTED_BOX_COLOR 0xF567  //orange box colour when selected
#define SCREEN1COLOR 0x0623
#define MAX_LABELS_SETPOINTS1 4

typedef struct
{
 int initialised;
 float OcVolt;
 float MpVolt;
 float BatVolt;
 float TempComp;

 }scr_SetpointsScreen1_Type;

enum SELECTED_LABEL1
{
 FirstLabel=0,
 Label_a,
 Label_b,
 LastLabel
} ;

extern scr_SetpointsScreen1_Type scr_SetpointsScreen1;
 
void Init_SetpointsScreen1(scr_SetpointsScreen1_Type *Screen); // This is the only thing that needs updating on this screen.void Init_SetpointsScreen1(void);
void UpdateSetpointsScreen1(scr_SetpointsScreen1_Type *Screen);
void SelectLabel1(enum SELECTED_LABEL1 lbl);
void DeselectLabel1(enum SELECTED_LABEL1 lbl);
void SetpointEditTransfer(void);
void PassSetpointValues1(scr_SetpointsEditScreen_Type *Screen);
void GetSetpoints1MainStruct(void);
void SetSetpoints1MainStruct(void);
int VerifySetpointValues();
void DisplayNotificationWarning(char *warning, char *messageType);

void IncrementLabelSelection1(void);
void DecrementLabelSelection1(void);



#endif