#ifndef SCREEN_H
#define SCREEN_H


void ClearLbl( TLabel *_label, unsigned int backgnd_color);
void DrawLbl( TLabel *_label, char* labelStr, int len);
void DeselectRoundBox(TBox_Round *SelectionBox, int Color);
void SelectDigit(TLabel *Digit);
void DeselectDigit(TLabel *Digit);
void DeselectCode(TLabel *Code);
void SelectCode(TLabel *Code);
void ClearDigit(TLabel *value, unsigned int background_color);
void IncrementDigitValue(TLabel *value);
void DecrementDigitValue(TLabel *value);
void IncrementDigitValue6(TLabel *value);
void DecrementDigitValue6(TLabel *value);
void CenterNotificationLabel( TLabel *_label, char *text);


#define SELECTED_DIGIT_COLOR CL_RED
#define UNSELECTED_DIGIT_COLOR CL_BLACK
#define SELECTED_CODE_COLOR CL_RED
#define UNSELECTED_CODE_COLOR CL_WHITE

#define BACKGROUND_PANEL_COLOR 0xFFFF
#endif