// ----------------------------------------------------------------------------
// Filename    : general.h
// Project     : CoolmaxLCD (AERL Coolmax SR Maximizer 'Touch')
// Copyright   : (c) Australian Energy Research Laboratories (AERL) 2013
// Authours    : Adrian Edmonds, Carl Joyce & Pavle Krkeljas
// Website     : http://www.aerl.com.au
// Description : This header file contains global definitions for the AERL
//               Coolmax SR Maximizer 'Touch' Project.
// ----------------------------------------------------------------------------
#ifndef GENERAL_H
#define GENERAL_H

// ----------------------- Constant Definitions -------------------------------
#define MB_COIL_START        1
#define MB_DISCRETE_START    1
#define MB_INPUT_REG_START   1
#define MB_HOLDING_REG_START 1

#define MB_COIL_NUM          0      // Should be a multiple of 8 for byte array
#define MB_DISCRETE_NUM      96     // Should be a multiple of 8 for byte array
#define MB_INPUT_REG_NUM     64
#define MB_HOLDING_REG_NUM   176

#define MB_BITS_UCHAR        8U

#define DEBUG 1
#define NULL (void*) 0
#define NULL_STR_PTR 0

#define false 0
#define true (!false)   
#define double float 

#define PIN_OUTPUT 0
#define PIN_INPUT  1
#define LOW    0
#define HIGH   1

#define MAX_CHAN_DESC_STRING_LEN 16
#define VERSION_STRING "MIKRO V1.0"

#define NUM_BYTES(x) (sizeof(x) / sizeof(*x))
#define NUM_REGS(x) (sizeof(x) / sizeof(*x) / 2)

// ------------------------- Type Definitions ---------------------------------
typedef unsigned char uint8_t;
typedef unsigned int uint16_t;
typedef int int16_t;
typedef unsigned long uint32_t;
typedef unsigned long long uint64_t;
typedef long int32_t;
typedef float flt32_t;
typedef int size_t;

// ----------------------- External Definitions -------------------------------
extern unsigned char Password[5];
extern int PassCodeFlag;

// ----------------------------------------------------------------------------
#endif