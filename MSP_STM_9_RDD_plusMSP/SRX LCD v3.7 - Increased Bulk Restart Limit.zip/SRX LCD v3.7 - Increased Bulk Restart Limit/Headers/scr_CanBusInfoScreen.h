#ifndef SCR_CANBUSINFOSCREEN_H
#define SCR_CANBUSINFOSCREEN_H

#define MAX_COMMS_POINTS 5

enum COMMS_INFO_LABEL
{
 ModbusId=0,
 ModbusBaud,
 CanBaseId,
 CanbaseBaud,
 UnitMode
} ;

enum COMMS_ISSLAVE_LABEL
{
 Master = 0,
 Slave
};


enum COMMS_INFO_MODBUS_BAUD
{
 _1200=0,
 _2400,
 _4800,
 _9600,
 _19200,
 _38400,
 _57600
} ;

enum COMMS_INFO_CANBUS_BAUD
{
 _50=0,
 _100,
 _125,
 _250,
 _500,
 _1000,
} ;

typedef struct
{
unsigned char modBusId;
unsigned char canBaudRate;
unsigned int canBaseId;
unsigned int unitMode;
unsigned char modBusBaudRate;
} scr_CanBaseIfonScreen_Type;

extern scr_CanBaseIfonScreen_Type scr_CanBaseIfonScreen;
 
void UpdateCanBusInfoScreen(void);
void Init_CanBusInfoScreen(scr_CanBaseIfonScreen_Type *screen);
void GetCommsMainStruct(void);

#endif