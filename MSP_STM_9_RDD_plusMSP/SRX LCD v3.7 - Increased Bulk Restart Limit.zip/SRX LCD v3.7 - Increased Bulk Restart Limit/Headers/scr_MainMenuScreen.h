#ifndef SCR_MAINMENUSCREEN_H
#define SCR_MAINMENUSCREEN_H

void UpdateMainMenuScreen(void); // This is the only thing that needs updating on this screen.
void Init_MainMenuScreen(void);

#endif