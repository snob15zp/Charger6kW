#ifndef SCR_ERRORSCREEN_H
#define SCR_ERRORSCREEN_H

#define MAX_ALARMS 10

typedef struct
{
unsigned char ScreenTime;
unsigned char ErrorCode; // byte indicating what error codes to set
//add errors
 } scr_ErrorScreen_Type;

enum ALARM_LABELPOS
{
 Pos1=0,
 Pos2,
 Pos3,
 Pos4,
 Pos5,
 Pos6,
 Pos7,
 Pos8,
 Pos9,
 Pos10
 };
 
extern scr_ErrorScreen_Type scr_ErrorScreen;

void UpdateErrorScreen(void);
void Init_ErrorScreen(scr_ErrorScreen_Type *screen);
void RefreshErrorScreen();

#endif