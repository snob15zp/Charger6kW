#ifndef SCR_OUTPUTONOFFSCREEN_H
#define SCR_OUTPUTONOFFSCREEN_H


enum COOLMAX_OUTPUT_STATE
{
 Output_OFF = 0,
 Output_ON,
 DisablingOutput,
 EnablingOutput,
 Output_SHUTDOWN,
 Output_GROUNDFAULT,
 Undefined
} ;

extern int WriteOutputState;
extern int ReadSmartShutDownState;
extern int WriteSmartShutDownState;
extern enum COOLMAX_OUTPUT_STATE ReadOutputState;

void Init_OutputOnOffScreen(void);
void UpdateOutputOnOffScreen(void);
void DisplayEnableOutputButton(void);
void DisplayDisableOutputButton(void);
void DisplayShutdownOutputButton(void);
void DisplayPVMissingOutputButton(void);
void DisplayGroundFaultOutputButton(void);
void InitializeOnOffScreenDefaults(void);
//void UpdateSmartShutDownStateOnOffScreen(void);
void RefreshOutputControlStateEnableButton(void);

int IsMidnightResetEnabled();
int IsMidnight();

#endif