#ifndef SCR_NOTIFICATIONSCREEN_H
#define SCR_NOTIFICATIONSCREEN_H

#define MESSAGE_SIZE 32

#define STATUS_SCREEN_WARNING 0
//#define ERROR_SCREEN 1
#define STATUS_SCREEN_PASS 2


void Init_NotificationScreen(void);
void UpdateNotificationScreen(char *message);

extern int notificationScreenType;

#endif