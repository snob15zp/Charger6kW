#ifndef _FEATURES_H_
#define _FEATURES_H_

#define ENABLE_FRAM

#ifdef ENABLE_FRAM
#define ENABLE_LOG
//#define ENABLE_LOG_DEBUG
//#define ENABLE_MIDNIGHT_RESET
#endif

#endif // _FEATURES_H_