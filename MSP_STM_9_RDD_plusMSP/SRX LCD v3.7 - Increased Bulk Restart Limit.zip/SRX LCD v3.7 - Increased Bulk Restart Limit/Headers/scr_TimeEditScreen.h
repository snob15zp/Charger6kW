#ifndef SCR_TIMEEDITSCREEN_H
#define SCR_TIMEEDITSCREEN_H

#include "CoolMax_LCD_objects.h"
#include "rtc.h"

#define MAX_VALS 3
#define MAX_CHARS 3
#define TimeUnit 3

/*typedef struct
{
 unsigned char Hours;
 unsigned char Minutes;
 unsigned char Seconds;
 unsigned char Seperator1;
 unsigned char Seperator2;
} scr_TimeEditScreen_Type;  */


enum TIME_DIGITS
{
 HourValue=0,
 //Colon1,
 MinuteValue,
 //Colon2,
 SecondsValue
} ;


//extern time scr_TimeEditScreen;

void UpdateTimeEditScreen(time *t);
void Init_TimeEditScreen();
void Save_TimeEditScreen(void);
void IncrementTimeDigits(TLabel *Label);
void DecrementTimeDigits(TLabel *Label);

void NextTimeSelection(void);

#endif