#ifndef SCR_DATEEDITSCREEN_H
#define SCR_DATEEDITSCREEN_H

#include "CoolMax_LCD_objects.h"
#include "rtc.h"

#define DATE_VALS 3

typedef struct
{
 unsigned char Day;
 unsigned char Month;
 unsigned char Year;
 //unsigned char FirstSeperator;
 //unsigned char SecondSeperator;
 //unsigned char ScreenTime;
} scr_DateEditScreen_Type;

enum DATE_DIGITS
{
DayValue=0,
MonthValue,
YearValue
} ;


extern time scr_DateEditScreen;


void Init_DateEditScreen(time *t);
void Save_DateEditScreen(void);

void IncrementDateDigits(TLabel *Label);
void DecrementDateDigits(TLabel *Label);

void NextDateSelection(void);
void UpdateDateEditScreen(time *t);


#endif