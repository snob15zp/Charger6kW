// ----------------------------------------------------------------------------
// Filename    : rs485.h
// Created On  : 01/10/2012
// Last Modify : 27/11/2012
// Authours    : Adrian Edmonds, Carl Joyce & Pavle Krkeljas
// Company     : Australian Energy Research Laboratories (AERL)
// Website     : http://www.aerl.com.au
// Description : This file contains header definitions for the RS-485 driver
//               which is connected to UART 1 (i.e. 2nd Serial Port).
// ----------------------------------------------------------------------------
#ifndef _RS485_H_
#define _RS485_H_
// ----------------------------------------------------------------------------
void RS485_Init(unsigned long baudRate, unsigned long clkFreq,
                unsigned char parity, unsigned char stopBits);
void RS485_InitRxTx(void);
void RS485_FlushRx(void);
void RS485_FlushTx(void);
void RS485_PutChar(char c);
void RS485_PutString(char *s);
char RS485_GetChar(void);
char* RS485_GetString(void);
int RS485_kbhit(void);
int RS485_TxBufferFull(void);
// ----------------------------------------------------------------------------
#endif