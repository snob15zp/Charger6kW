#ifndef _COMMAND_H_
#define _COMMAND_H_

#define flash

extern char *paramList;    
extern int CtrlBreak;

void initCommandLine(void);

int GetDoubleParam(double *val,char * str);

void printp(char flash *format, ...);
void printf(char flash *format, ...);
void printd(char flash *format, ...);
void printe(char flash *format, ...);
void getParam(char flash *format, ...);

void PRINT(char c);

#endif     