/*
 * FreeModbus Libary: BARE Port
 * Copyright (C) 2006 Christian Walter <wolti@sil.at>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * File: $Id: port.h,v 1.1 2006/08/22 21:35:13 wolti Exp $
 */

#ifndef _PORT_H
#define _PORT_H

//#include <assert.h>                          // Modified by CJ 01_11_2012
//#include <inttypes.h>                        // Modified by CJ 01_11_2012
#include "general.h"                           // Modified by CJ 01_11_2012

#define assert(exp)                            // Modified by CJ 01_11_2012

#define INLINE                     inline
#define PR_BEGIN_EXTERN_C          extern "C" {
#define PR_END_EXTERN_C            }

#define ENTER_CRITICAL_SECTION( )  DisableInterrupts() //INTDisableInterrupts()             // Modified by CJ 01_11_2012
#define EXIT_CRITICAL_SECTION( )   EnableInterrupts() //INTEnableSystemMultiVectoredInt()   // Modified by CJ 01_11_2012

typedef uint8_t BOOL;

typedef unsigned char UCHAR;
typedef char CHAR;

typedef uint16_t USHORT;
typedef int16_t SHORT;
typedef uint32_t ULONG;
typedef int32_t LONG;

typedef flt32_t FLOAT;

#ifndef TRUE
#define TRUE            1
#endif

#ifndef FALSE
#define FALSE           0
#endif

#define SYS_FREQ                    (80000000L)
#define DESIRED_BAUDRATE            (9600)      //The desired BaudRate
#define PB_DIV                      8
#define PRESCALE                    256
#define TOGGLES_PER_SEC             1
#define T1_TICK                     (SYS_FREQ/PB_DIV/PRESCALE/TOGGLES_PER_SEC)

#endif