#include "scr_MainMenuScreen.h"
#include "scr_SettingsMenuScreen.h"
#include "scr_RealTimeScreen.h"
#include "scr_ErrorScreen.h"
#include "scr_InformationScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"

extern TScreen*  CurrentScreen;
extern Tscreen* PreviousScreen;

void Init_MainMenuScreen(void)
{
     if (CurrentScreen != &MainMenuScreen)
     {
        PreviousScreen = CurrentScreen;
        DrawScreen(&MainMenuScreen);
     }
}

void UpdateMainMenuScreen(void) // This is the only thing that needs to be updated on this screen
{
  if (CurrentScreen == &MainMenuScreen)
     {

         // update time code in here

     }
     
}

// Event Handlers

void btn_MainMenuScreen_SettingsOnClick()
{
  Init_SettingsMenuScreen();
}

void btn_MainMenuScreen_InformationOnClick()
{
  Init_InformationScreen(&scr_InformationScreen);
}

void btn_MainMenuScreen_ErrorsOnClick()
{
  Init_ErrorScreen(&scr_ErrorScreen);
}

void btn_MainMenuScreen_RealTimeScreenOnClick() 
{
  Init_RealTimeScreen(&scr_RealTimeScreen);
}