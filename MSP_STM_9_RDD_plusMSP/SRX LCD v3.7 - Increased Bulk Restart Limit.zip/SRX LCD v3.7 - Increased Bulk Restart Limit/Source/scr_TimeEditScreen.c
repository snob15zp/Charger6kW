#include "scr_TimeEditScreen.h"
#include "scr_TimeDateEditScreen.h"
#include "scr_MainMenuScreen.h"
#include "scr_SettingsMenuScreen.h"
#include "scr_RealTimeScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"
#include "rtc.h"
#include "externalRtc.h"


time scr_TimeEditScreen;

TLabel *TimeValues[MAX_VALS];

extern Tscreen* CurrentScreen;
extern Tscreen* PreviousScreen;

enum TIME_DIGITS curValue = HourValue;

int cnt = 0;

void Init_TimeEditScreen()
{
     if (CurrentScreen != &TimeEditScreen)
     {
        TimeValues[HourValue]   = &lbl_TimeEditScreen_Hours;
        //TimeValues[Colon1]      = &lbl_TimeEditScreen_Colon1;
        TimeValues[MinuteValue] = &lbl_TimeEditScreen_Minutes;
        //TimeValues[Colon2]      = &lbl_TimeEditScreen_Colon2;
        TimeValues[SecondsValue]= &lbl_TimeEditScreen_Seconds;
        
        PreviousScreen = CurrentScreen;
        
        if (PreviousScreen == (&TimeDateEditScreen))
        {
         curValue = HourValue;
        }

        DrawScreen(&TimeEditScreen);
        SelectDigit(TimeValues[curValue]);
        
        UpdateTimeEditScreen(&curIntTime);
     }
}

void UpdateTimeEditScreen(time *t)
{
 char tempHour[3];
 char tempMin[3];
 char tempSec[3];
 
 int i =0;
 
 IntGetTime(t);
 
 sprintf(tempHour,"%02u", (unsigned long)t->hour);
 sprintf(tempMin,"%02u", (unsigned long)t->min);
 sprintf(tempsec,"%02u", (unsigned long)t->sec);
 
 printd("Hour='%u'\r\n",(unsigned long)t->hour);
 printd("Minute='%u'\r\n",(unsigned long)t->min);
 printd("Second='%u'\r\n",(unsigned long)t->sec);
 
  if (CurrentScreen == &TimeEditScreen)
     {
     
      for (i ; i < MAX_VALS ; i++)
     {
         if (curValue == i)
        {
          ClearLbl(TimeValues[i],boxRound_TimeEditScreen_BackgroundPanel.Color);
          TFT_Set_Font(TimeValues[i]->FontName, SELECTED_DIGIT_COLOR, FO_HORIZONTAL);
        }

        else
        {
           ClearLbl(TimeValues[i],boxRound_TimeEditScreen_BackgroundPanel.Color);
           TFT_Set_Font(TimeValues[i]->FontName, UNSELECTED_DIGIT_COLOR, FO_HORIZONTAL);
        }

     
       if (i == HourValue)
          {
           TimeValues[i]->Caption[0] =  tempHour[0];
           TimeValues[i]->Caption[1] = tempHour[1];
           TimeValues[i]->Caption[2] = 0x00;
           TFT_Write_Text(TimeValues[i]->Caption, TimeValues[i]->Left, TimeValues[i]->Top);
          }

       if (i == MinuteValue)
          {
           TimeValues[i]->Caption[0] =  tempMin[0];
           TimeValues[i]->Caption[1] = tempMin[1];
           TimeValues[i]->Caption[2] = 0x00;
           TFT_Write_Text(TimeValues[i]->Caption,  TimeValues[i]->Left,  TimeValues[i]->Top);
          }

       if (i == SecondsValue)
          {
           TimeValues[i]->Caption[0] =  tempSec[0];
           TimeValues[i]->Caption[1] = tempSec[1];
           TimeValues[i]->Caption[2] = 0x00;
           TFT_Write_Text(TimeValues[i]->Caption,  TimeValues[i]->Left,  TimeValues[i]->Top);
         }
     
     
     
     }
  }
     

}

void Save_TimeEditScreen(void)      // This section is when updating values on Screen and saving the set values to struct.
{

     if (CurrentScreen == &TimeEditScreen)     // this should be saved to the actual struct of the external RTC
     {
         char val1,val2;   // array of 6 characters holding value of each digit
         int temp;
         int tot;
         int tu  = 0;
         int dig = 0;
         
          for (tu ; tu < TimeUnit ; tu++)
          {
             val1 = TimeValues[tu]->Caption[0];
             val2 = TimeValues[tu]->Caption[1];
             
             
            if(val1 != '0')
             {
               temp = ( (((int)(val1-'0'))*10) + ((int)(val2-'0')) )  ;
             }
             
            else
             {
               temp = ( ((int)(val1-'0')) + ((int)(val2-'0')) );
             }
             
             if (tu == 0)
             {
              curTime.hour = (unsigned char)temp;
             }
             
              if (tu == 1)
             {
              curTime.min = (unsigned char)temp;
             }
             
              if (tu == 2)
             {
              curTime.sec = (unsigned char)temp;
             }
          }

          ExtSetTime(&curTime);
          
          curIntTime.sec   = curTime.sec;
          curIntTime.min   = curTime.min;
          curIntTime.hour  = curTime.hour;
          
          IntSetTime(&curIntTime);

     }

}

void NextTimeSelection(void)
{
if (curValue == SecondsValue)
   {
      DeselectDigit(TimeValues[curValue]);
      curValue = HourValue;
      SelectDigit(TimeValues[curValue]);
      return;
   }

  DeselectDigit(TimeValues[curValue]);
  SelectDigit(TimeValues[curValue+1]);
  curValue = curValue+1;
  
}

void IncrementTimeDigits(TLabel *Label)
{

char timex[MAX_CHARS];
char x,y;
int i = 0;

for(i;i<MAX_CHARS;i++)
{
  timex[i] = Label->Caption[i];
}
   x = timex[0];
   y = timex[1];
   
  if(curValue == HourValue)
  {
      if((x=='0') && (y == '9') )
      {
        y = '0';
        x = '1';
      }
      
      else if((x =='1') && (y =='9'))
      {
        x = '2';
        y = '0';
      }
      
      else if ((x == '2')&&(y == '3'))
      {
        x = '0';
        y = '0';
      }
      
      else
      y++;
   }
   
  if(curValue == MinuteValue)
  {
   if((x=='0') && (y == '9') )
      {
        y = '0';
        x = '1';
      }

      else if((x =='1') && (y =='9'))
      {
        x = '2';
        y = '0';
      }

      else if ((x == '2')&&(y == '9'))
      {
        x = '3';
        y = '0';
      }

      else if ((x == '3')&&(y == '9'))
      {
        x = '4';
        y = '0';
      }

      else if ((x == '4')&&(y == '9'))
      {
        x = '5';
        y = '0';
      }

      else if ((x == '5')&&(y == '9'))
      {
        x = '0';
        y = '0';
      }

      else
      y++;

  }
   
  if(curValue == SecondsValue)
  {
   if((x=='0') && (y == '9') )
      {
        y = '0';
        x = '1';
      }

      else if((x =='1') && (y =='9'))
      {
        x = '2';
        y = '0';
      }

      else if ((x == '2')&&(y == '9'))
      {
        x = '3';
        y = '0';
      }

      else if ((x == '3')&&(y == '9'))
      {
        x = '4';
        y = '0';
      }

      else if ((x == '4')&&(y == '9'))
      {
        x = '5';
        y = '0';
      }

      else if ((x == '5')&&(y == '9'))
      {
        x = '0';
        y = '0';
      }

      else
      y++;

  }

  ClearDigit(Label,boxRound_TimeEditScreen_BackgroundPanel.Color);
  Label->Caption[0]  = x;
  Label->Caption[1]  = y;
      
  SelectDigit(Label);
}

void DecrementTimeDigits(TLabel *Label)
{

char timex[MAX_CHARS];
char x,y;
int i = 0;


for(i;i<MAX_CHARS;i++)
{
  timex[i] = Label->Caption[i];
}
   x = timex[0];
   y = timex[1];

if(curValue == HourValue)
{
            if((x=='0') && (y == '0') )
            {
              x = '2';
              y = '3';

            }

            else if((x =='2') && (y =='0'))
            {
              x = '1';
              y = '9';
            }

            else if ((x == '1')&&(y == '0'))
            {
              x = '0';
              y = '9';
            }

            else
            y--;
}

if(curValue == MinuteValue)
{
      if((x=='0') && (y == '0') )
          {
            x = '5';
            y = '9';

          }

          else if((x =='5') && (y =='0'))
          {
            x = '4';
            y = '9';
          }

          else if ((x == '4')&&(y == '0'))
          {
            x = '3';
            y = '9';
          }

          else if ((x == '3')&&(y == '0'))
          {
            x = '2';
            y = '9';
          }

          else if ((x == '2')&&(y == '0'))
          {
            x = '1';
            y = '9';
          }

          else if ((x == '1')&&(y == '0'))
          {
            x = '0';
            y = '9';
          }

          else
          y--;
}

if(curValue == SecondsValue)
{
       if((x=='0') && (y == '0') )
          {
            x = '5';
            y = '9';
          }

          else if((x =='5') && (y =='0'))
          {
            x = '4';
            y = '9';
          }

          else if ((x == '4')&&(y == '0'))
          {
            x = '3';
            y = '9';
          }

          else if ((x == '3')&&(y == '0'))
          {
            x = '2';
            y = '9';
          }

          else if ((x == '2')&&(y == '0'))
          {
            x = '1';
            y = '9';
          }

          else if ((x == '1')&&(y == '0'))
          {
            x = '0';
            y = '9';
          }

          else
          y--;
}
  
  ClearDigit(Label,boxRound_TimeEditScreen_BackgroundPanel.Color);
  Label->Caption[0]  = x;
  Label->Caption[1]  = y;

  SelectDigit(Label);
}






//Event Handlers

void btn_TimedEditScreen_BackOnClick() 
{
  Init_TimeDateEditScreen();
}

void btn_TimedEditScreen_NextOnClick() 
{
  NextTimeSelection();
}

void lbl_TimeEditScreen_HoursOnClick()
{
  if (curValue != HourValue)
  {
    DeselectDigit(TimeValues[curValue]);
    curValue = HourValue;
    SelectDigit(TimeValues[curValue]);
  }
}

void lbl_TimeEditScreen_MinutesOnClick()
{
  if (curValue != MinuteValue)
  {
    DeselectDigit(TimeValues[curValue]);
    curValue = MinuteValue;
    SelectDigit(TimeValues[curValue]);
  }
}

void lbl_TimeEditScreen_SecondsOnClick()
{
  if (curValue != SecondsValue)
  {
    DeselectDigit(TimeValues[curValue]);
    curValue = SecondsValue;
    SelectDigit(TimeValues[curValue]);
  }
}


void btn_TimedEditScreen_UpOnPress() 
{
  if (cnt >= 100)
  {
  IncrementTimeDigits(TimeValues[curValue]);
  delay_ms(100);
  }
  
  cnt++;
}

void btn_TimedEditScreen_UpOnClick() 
{
  IncrementTimeDigits(TimeValues[curValue]);
  cnt = 0;
}

void btn_TimedEditScreen_UpOnDown()
{

}



void btn_TimedEditScreen_DownOnClick() 
{
  DecrementTimeDigits(Timevalues[curValue]);
  cnt = 0;

}
void btn_TimedEditScreen_DownOnPress()
{
  if (cnt >= 100)
  {
  DecrementTimeDigits(TimeValues[curValue]);
  delay_ms(100);
  }

  cnt++;

}

void btn_TimedEditScreen_DownOnDown()
{



}

void btn_TimedEditScreen_AcceptOnClick() 
{
 Save_TimeEditScreen();  // Saves the changes that have been applied in the edit screen
 Init_TimeDateEditScreen();
}