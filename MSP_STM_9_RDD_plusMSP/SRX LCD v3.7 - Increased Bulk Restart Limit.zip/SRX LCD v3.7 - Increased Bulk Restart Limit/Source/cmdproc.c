
#include "general.h"
#include "cmdlib.h"
#include "cmdproc.h"
#include "debug.h"
#include "externalRtc.h"
#include "log.h"
#include "rtc.h"
#include "coolmax.h"
#include "localConfig.h"

#define EOL_MARKER putString("~\r\n")

sbit Mmc_Chip_Select at LATG9_bit;  // sdcard chip select
sbit Mmc_Chip_Select_Direction at TRISG9_bit;

sbit Mmc_Card_Detect at RF13_bit;
sbit Mmc_Card_Detect_Direction_bit at TRISF13_bit;

const flash command_type commandList[commandNo] = {
  {"TEST", cmdTest},
  {"VER", cmdVersion},
  {"EDIT", cmdEdit},
  {"REAL", cmdReal},
  {"REAL2", cmdReal2},
  {"STATUS", cmdStatus},
  {"FLOATV", cmdFloatVolt},
  {"NOMV", cmdNominalVolt},
  {"EVENTS", cmdEvents},
  {"SYSINFO", cmdSysInfo},
  {"WDTRESET", cmdWDTReset},
  {"COMMS", cmdComms},
  {"TIME", cmdTIme},
  {"TOUCH", cmdTouchCal},
  {"FORMAT", cmdFormatSDC}
  #ifdef ENABLE_LOG
  ,{"LOG", cmdLog}
  ,{"CHGRESET", cmdChargeReset}
  #endif
};

//***************************************************
//COMMANDS
//***************************************************

void cmdVersion(void)
{
        char tmpstr[MAX_CHAN_DESC_STRING_LEN+1];
        strncpy(tmpstr,VERSION_STRING,MAX_CHAN_DESC_STRING_LEN);
        printp("#VERSION:%s\r\n", tmpstr);
}

void cmdEdit(void)
{
        //DrawScreen(&EditNum);

        time t;

        t.sec = 0;  // has been changed from zero
        t.min = 0;
        t.hour = 0;
        t.date = 0;
        t.month = 0;
        t.year = 0;

        //IntSetTime(&t);


        printp("#EDIT:\r\n");
}

void cmdTest(void)
{

        double f;
        unsigned char c;
        int i;
        unsigned int u;
        long l;
        char *s = "";
        time t;

        f = 1.123;
        c = 34;
        i = -45;
        u = 12;
        l = 789;

        getParam("bdulfs",&c,&i,&u,&l,&f,&s);

        //printp("#TEST:%d %d %u %ld %05.3f,'%s'\r\n",c,i,u,l,f,s);

        //printp("#TEST:%d %c %d %u %ld %05.3f,'%s'\r\n",(long volatile) c,c,(long volatile) i,(long volatile) u,l,f,s);

        //printp("#TEST:%u,%u,'%s',%05.3f\r\n",i,u,s,f);



        //IntGetTime(&t);

        //printp("#TEST:%u,%u,%u,%u,%u,%u\r\n",u,u,u,u,u,u);

        //printp("#TEST:%u,%u,%u,%u,%u,%u\r\n",(unsigned long) t.sec,(unsigned long) t.min,(unsigned long) t.hour, (unsigned long) t.date, (unsigned long)t.month, (unsigned long)t.year);

        /*
        printp("#TEST:%u ",(unsigned int) c);
        printp("'%c' ",c);
        printp("%d ",i);
        printp("%u ",u);
        printp("%ld ",l);
        printp("%5.3f ",f);
        printp("'%s'\r\n",s);
        */
}
void cmdTime(void)
{
     printp("TIME:CTRL: %lu-%lu-%lu %lu:%lu:%lu\r\n", (unsigned long) coolmax_time.yy, (unsigned long) coolmax_time.mo, (unsigned long) coolmax_time.md, (unsigned long) coolmax_time.hh, (unsigned long) coolmax_time.mn, (unsigned long) coolmax_time.ss);
     printp("TIME:LCD: %lu-%lu-%lu %lu:%lu:%lu\r\n", (unsigned long) lcd_time.yy, (unsigned long) lcd_time.mo, (unsigned long) lcd_time.md, (unsigned long) lcd_time.hh, (unsigned long) lcd_time.mn, (unsigned long) lcd_time.ss);
}

void cmdReal(void)
{
        if (!isUserConfigInit)
        {
           printe("UNINITIALISED DATA FOUND\r\n");
           return;
        }
        printp("#REAL,PV:%5.1f,PA:%5.1f,BV:%5.1f,BA:%5.1f\r\n", telemetry.pvVoltage, telemetry.pvCurrent, telemetry.outputVoltage, telemetry.outputCurrent);
}

void cmdReal2(void)
{
        if (!isUserConfigInit)
        {
           printe("UNINITIALISED DATA FOUND\r\n");
           return;
        }
        printp("#REAL2,OV:%5.1f,OC:%5.1f,PW:%5.1f,BT:%5.1f\r\n", telemetry.ocVoltage, telemetry.outputCharge, telemetry.pvPower, telemetry.batteryTemp);
}

void cmdNominalVolt(void)
{
        double f;
        f = -999999.9;

        getParam("f",&f);

        if (!isUserConfigInit)
        {
           printe("UNINITIALISED DATA FOUND\r\n");
           return;
        }

        if (f <= -999999.9)
        {
           printp("#NOMV:%5.1f\r\n", userConfig_R.setPointsConfig.nominalVolt);
           return;
        }

        if ((f < 24.0) || (f > 132.0))
        {
           printe("INVALID NOMINAL VOLTAGE SPECIFIED\r\n");
           return;
        }

        userConfig_W.setPointsConfig.nominalVolt = f;
        userConfig_W.setPointsConfig.bulkVolt = f * 1.1f;
        userConfig_W.setPointsConfig.floatVolt = f * 1.08f;
        userConfig_W.setPointsConfig.bulkResetVolt = f * 0.89f;
        userConfig_W.lowOutVoltGenset.triggerVal = f * 0.78f;
        userConfig_W.lowOutVoltGenset.resetVal = f * 1.07f;

        printp("#NOMV:%5.1f\r\n", userConfig_R.setPointsConfig.nominalVolt);
        return;
}

void cmdStatus(void)
{
        printp("#STATUS\r\n");
        UpdateUSBBuffers();
        printp("#STATUS:FACT_CFG_CRC: %02x\r\n",(unsigned int) telemetry.status.config_factoryCRC);
        UpdateUSBBuffers();
        printp("#STATUS:FACT_CFG_CHK: %02x\r\n",(unsigned int) telemetry.status.config_factoryCheck);
        UpdateUSBBuffers();
        printp("#STATUS:EVNT_CFG_CRC: %02x\r\n",(unsigned int) telemetry.status.config_eventCRC);
        UpdateUSBBuffers();
        printp("#STATUS:EVNT_CFG_CHK: %02x\r\n",(unsigned int) telemetry.status.config_eventCheck);
        UpdateUSBBuffers();
        printp("#STATUS:USER_CFG_CRC: %02x\r\n",(unsigned int) telemetry.status.config_userCRC);
        UpdateUSBBuffers();
        printp("#STATUS:USER_CFG_CHK: %02x\r\n",(unsigned int) telemetry.status.config_userCheck);
        UpdateUSBBuffers();
        printp("#STATUS:STATISTICS: %02x\r\n",(unsigned int) telemetry.status.statistics);
        UpdateUSBBuffers();
        printp("#STATUS:FLAGS: %02x\r\n",(unsigned int) telemetry.status.flags);
        UpdateUSBBuffers();
        printp("#STATUS:TELEM: %02x\r\n",(unsigned int) telemetry.status.telemetry);
        UpdateUSBBuffers();
        printp("#STATUS:COMMS: %02x\r\n",(unsigned int) telemetry.status.communications);
        UpdateUSBBuffers();
        printp("#STATUS:CTRL_IS_SLAVE: %02x\r\n",(unsigned int) telemetry.status.control_isSlave);
        UpdateUSBBuffers();
        printp("#STATUS:CTRL_USING_BLK: %02x\r\n",(unsigned int) telemetry.status.control_usingBulk);
        UpdateUSBBuffers();
        printp("#STATUS:CTRL_MODE: %02x\r\n",(unsigned int) telemetry.status.control_mode);
        UpdateUSBBuffers();
        printp("#STATUS:CTRL_OUTPUT_ENABLED: %02x\r\n",(unsigned int) telemetry.status.control_outputEnabled);
        UpdateUSBBuffers();
        printp("#STATUS:CTRL_SMART_SHUTDOWN: %02x\r\n",(unsigned int) telemetry.status.control_smartShutdown);
        UpdateUSBBuffers();
        printp("#STATUS:SAFE_OPER: %02x\r\n",(unsigned int) telemetry.status.safety_operation);
        UpdateUSBBuffers();
}

void cmdEvents(void)
{       
        printp("#EVENTS\r\n");
        UpdateUSBBuffers();
        if (telemetry.eventFlags.flags != 0)
        {
          if (telemetry.eventFlags.systemPower != 0)
          {
             printp("#EVENTS:SYS_POWER: %02x\r\n",(unsigned int) telemetry.eventFlags.systemPower);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.lowOutVoltWarn != 0)
          {
             printp("#EVENTS:LOW_OUT_VOLT_WARN: %02x\r\n",(unsigned int) telemetry.eventFlags.lowOutVoltWarn);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.lowOutVoltFault != 0)
          {
             printp("#EVENTS:LOW_OUT_VOLT_FAULT: %02x\r\n",(unsigned int) telemetry.eventFlags.lowOutVoltFault);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.lowOutVoltGenSet != 0)
          {
             printp("#EVENTS:LOW_OUT_VOLT_GENSET: %02x\r\n",(unsigned int) telemetry.eventFlags.lowOutVoltGenSet);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.highOutVoltFault != 0)
          {
             printp("#EVENTS:HIGH_OUT_VOLT_FAULT: %02x\r\n",(unsigned int) telemetry.eventFlags.highOutVoltFault);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.highOutCurrentFault != 0)
          {
             printp("#EVENTS:HIGH_OUT_CURRENT_FAULT: %02x\r\n",(unsigned int) telemetry.eventFlags.highOutCurrentFault);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.highDischargeCurrentFault != 0)
          {
             printp("#EVENTS:HIGH_DISCHARGE_CURRENT_FAULT: %02x\r\n",(unsigned int) telemetry.eventFlags.highDischargeCurrentFault);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.highBatteryTempFault != 0)
          {
             printp("#EVENTS:HIGH_BATTERY_TEMP_FAULT: %02x\r\n",(unsigned int) telemetry.eventFlags.highBatteryTempFault);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.inputBreakerOpen != 0)
          {
             printp("#EVENTS:IN_BREAKER_OPEN_FAULT: %02x\r\n",(unsigned int) telemetry.eventFlags.inputBreakerOpen);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.outputBreakerOpen != 0)
          {
             printp("#EVENTS:OUT_BREAKER_OPEN_FAULT: %02x\r\n",(unsigned int) telemetry.eventFlags.outputBreakerOpen);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.tempSensorFault != 0)
          {
             printp("#EVENTS:TEMP_SENSOR_FAULT: %02x\r\n",(unsigned int) telemetry.eventFlags.tempSensorFault);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.negativePVCurrentSutdown != 0)
          {
             printp("#EVENTS:NEG_PV_CURRENT_SHUTDOWN: %02x\r\n",(unsigned int) telemetry.eventFlags.negativePVCurrentSutdown);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.highPVCurrentShutdown != 0)
          {
             printp("#EVENTS:HIGH_PV_CURRENT_SHUTDOWN: %02x\r\n",(unsigned int) telemetry.eventFlags.highPVCurrentShutdown);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.highPVVoltShutdown != 0)
          {
             printp("#EVENTS:HIGH_PV_VOLT_SHUTDOWN: %02x\r\n",(unsigned int) telemetry.eventFlags.highPVVoltShutdown);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.highOutCurrentShutdown != 0)
          {
             printp("#EVENTS:HIGH_OUT_CURRENT_SHUTDOWN: %02x\r\n",(unsigned int) telemetry.eventFlags.highOutCurrentShutdown);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.highOutVoltShutdown != 0)
          {
             printp("#EVENTS:HIGH_OUT_VOLT_SHUTDOWN: %02x\r\n",(unsigned int) telemetry.eventFlags.highOutVoltShutdown);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.logFull != 0)
          {
             printp("#EVENTS:LOG_FULL: %02x\r\n",(unsigned int) telemetry.eventFlags.logFull);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.solarPanelMissing != 0)
          {
             printp("#EVENTS:PANEL_MISSING_FAULT: %02x\r\n",(unsigned int) telemetry.eventFlags.solarPanelMissing);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.configValueOutOfRange != 0)
          {
             printp("#EVENTS:CONFIG_VALUE_OUT_OF_RANGE: %02x\r\n",(unsigned int) telemetry.eventFlags.configValueOutOfRange);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.fanFault != 0)
          {
             printp("#EVENTS:FAN_FAULT: %02x\r\n",(unsigned int) telemetry.eventFlags.fanFault);
             UpdateUSBBuffers();
          }
          if (telemetry.eventFlags.highHeatSinkTemp != 0)
          {
             printp("#EVENTS:HIGH_HEAT_SINK_TEMP_FAULT: %02x\r\n",(unsigned int) telemetry.eventFlags.highHeatSinkTemp);
             UpdateUSBBuffers();
          }
        }
        else
        {
             printp("#EVENTS:NONE\r\n");
             UpdateUSBBuffers();
        }
}

void cmdSysInfo(void)
{
        printp("#SYSINFO\r\n");
        UpdateUSBBuffers();
        printp("#SYSINFO:SERIAL_NUM: %s\r\n",sysInfo.serialNumber);
        UpdateUSBBuffers();
        printp("#SYSINFO:PRODUCT_ID: %s\r\n",sysInfo.productID);
        UpdateUSBBuffers();
        printp("#SYSINFO:MODEL_TYPE: %s\r\n",sysInfo.modelType);
        UpdateUSBBuffers();
        printp("#SYSINFO:FW_VERSION: %s\r\n",sysInfo.fwVersion);
        UpdateUSBBuffers();
        printp("#SYSINFO:HW_VERSION: %s\r\n",sysInfo.hwVersion);
        UpdateUSBBuffers();
}

void cmdFloatVolt(void)
{
        double f;
        f = -999999.9;

        getParam("f",&f);

        if (!isUserConfigInit)
        {
           printe("UNINITIALISED DATA FOUND\r\n");
           return;
        }

        if (f <= -999999.9)
        {
           printp("#FLOATV:%5.1f\r\n", userConfig_R.setPointsConfig.floatVolt);
           return;
        }

        if ((f < 20.0) || (f > 160.0))
        {
           printe("INVALID FLOAT VOLTAGE SPECIFIED\r\n");
           return;
        }

        userConfig_W.setPointsConfig.floatVolt = f;
        printp("#FLOATV:%5.1f\r\n", userConfig_W.setPointsConfig.floatVolt);

}

void cmdWDTReset(void)
{
     for(;;);
}

void cmdComms(void)
{
        printp("#COMMS\r\n");
        UpdateUSBBuffers();
        printp("#COMMS:MODBUS_ID: 0x%02x\r\n", (unsigned int) userConfig_R.commsConfig.modBusAddress);
        UpdateUSBBuffers();
        printp("#COMMS:CANBUS_ID: %d\r\n", userConfig_R.commsConfig.canBusID);
        UpdateUSBBuffers();
        printp("#COMMS:BAUD_RATE: %d\r\n", (unsigned int) userConfig_R.commsConfig.canBaudRate);
        UpdateUSBBuffers();
        printp("#COMMS:IS_SLAVE: %u\r\n", userConfig_R.commsConfig.isSlave);
        UpdateUSBBuffers();
}

void cmdTouchCal(void)
{
     unsigned int x_min;
     unsigned int x_max;
     unsigned int y_min;
     unsigned int y_max;

     TP_TFT_Get_Calibration_Consts(&x_min, &x_max, &y_min, &y_max);    // Get calibration constants
     printp("TOUCH:LCD: XMIN:%lu XMAX:%lu YMIN:%lu YMAX:%lu\r\n", (unsigned long) x_min, (unsigned long) x_max, (unsigned long) y_min, (unsigned long) y_max);
}

// TODO: move to SD card source file if it is implemented.
void cmdSetSDCSPI(void)
{
     SPI2_Init_Advanced(_SPI_MASTER, _SPI_8_BIT, 8, _SPI_SS_DISABLE, _SPI_DATA_SAMPLE_END, _SPI_CLK_IDLE_LOW, _SPI_IDLE_2_ACTIVE);
}

void cmdFormatSDC(void)
{
    unsigned int ret;

    Mmc_Card_Detect_Direction_bit = 1;
    Delay_ms(10);
    
    if (Mmc_Card_Detect == 0)
    {
        printp("SD card detected\r\n");
    } else {
        printp("SD card not detected\r\n");
    }
     
    cmdSetSDCSPI();

    // Format and initialize SD card
    ret = Mmc_Fat_QuickFormat("aerl");
    if (ret == 0) {
       printp("Successfully formated SD card\r\n");
    } else {
       printp("Failed formatting: %d\r\n", ret);
    }
}

void cmdChargeReset(void)
{
int ret;
  ret = ConfigRead();
  printd ("Read Daily Charge %ld, %ld\r\n", (long) CONFIG.dailyCharge, (long) ret);
  UpdateUSBBuffers();
  printd ("Read Total Charge %ld\r\n", (long) CONFIG.totalCharge);
  UpdateUSBBuffers();

  ConfigSetDefaults();  // Will turn off midnight reset
  
  ret = ConfigWrite();
  printd ("Write Daily Charge %ld, %ld\r\n", (long) CONFIG.dailyCharge, (long) ret);
  UpdateUSBBuffers();
  printd ("Write Total Charge %ld\r\n", (long) CONFIG.totalCharge);
  UpdateUSBBuffers();

  ret = ConfigRead();
  printd ("Read Daily Charge %ld, %ld\r\n", (long) CONFIG.dailyCharge, (long) ret);
  UpdateUSBBuffers();
  printd ("Read Total Charge %ld\r\n", (long) CONFIG.totalCharge);
  UpdateUSBBuffers();
  
}

LogEntry logEntry;
EventLogEntry eventLogEntry;

void cmdLogDumpCSV(long start, unsigned long num)
{
    unsigned long numEntries = LogGetEntryCount();
    long i;
    long end;
    
    if (start < 0)
    {
        i = numEntries + start;
        if (i < 0)
        {
            i = 0;
        }
    }
    else
    {
        i = start;
    }
    
    end = i + num;
    if (end > numEntries)
    {
        end = numEntries;
    }
    
    for (; i<end; i++)
    {
        if (!LogGetEntry(i, &logEntry))
        {
            printf("error[%ld]\r\n", i);
        }
        else
        {
            printf("%ld,", LogGetEntryID(i));
            printf("%02d/%02d/%d,%02d:%02d:%02d,", (int)logEntry.day,
                (int)logEntry.month, (int)logEntry.year, (int)logEntry.hour,
                (int)logEntry.min, (int)logEntry.sec);
            printf("%.2f,", logEntry.pvVoltage);
            printf("%.2f,", logEntry.pvCurrent);
            printf("%.2f,", logEntry.outputVoltage);
            printf("%.2f,", logEntry.outputCurrent);
            printf("%.2f,", logEntry.ocVoltage);
            printf("%.4f,", logEntry.outputCharge);
            printf("%.0f\r\n", logEntry.pvPower);
            WDT ^= 1;
        }
    }
    UpdateUSBBuffers();
}

void cmdEventLogDumpCSV(long start, unsigned long num)
{
    unsigned long numEntries = LogGetEventEntryCount();
    long i;
    long end;

    if (start < 0)
    {
        i = numEntries + start;
        if (i < 0)
        {
            i = 0;
        }
    }
    else
    {
        i = start;
    }

    end = i + num;
    if (end > numEntries)
    {
        end = numEntries;
    }
    
    for (; i<end; i++)
    {
        if (!LogGetEventEntry(i, &eventLogEntry))
        {
            printf("error[%ld]\r\n", i);
        }
        else
        {
            printf("%ld,", LogGetEventEntryID(i));
            printf("%02d/%02d/%d,%02d:%02d:%02d,", (int)eventLogEntry.day,
                (int)eventLogEntry.month, (int)eventLogEntry.year, (int)eventLogEntry.hour,
                (int)eventLogEntry.min, (int)eventLogEntry.sec);

            printf("0x%.8lX,", eventLogEntry.eventFlags.flags);
            printf("0x%.8lX%.8lX,", ((unsigned long*)&eventLogEntry.status.status)[1],
                    ((unsigned long*)&eventLogEntry.status.status)[0]);
            printf("%d,%d,%d\r\n", eventLogEntry.outputOn, eventLogEntry.outputOff, eventLogEntry.forcedReset);
            WDT ^= 1;
        }
    }
    UpdateUSBBuffers();
}

time logIntTime;

#ifdef ENABLE_LOG_DEBUG
void cmdLogAdd(float voltage)
{
    memset(&logEntry, 0, sizeof(LogEntry));
    
    IntGetTime(&logIntTime);
    IntGetDate(&logIntTime);
    logEntry.day = logIntTime.date;
    logEntry.month = logIntTime.month;
    logEntry.year = logIntTime.year + 2000;
    logEntry.hour = logIntTime.hour;
    logEntry.min = logIntTime.min;
    logEntry.sec = logIntTime.sec;
    
    logEntry.pvVoltage = voltage;
    logEntry.pvCurrent = 32.567f;
    logEntry.outputVoltage = 33.567f;
    logEntry.outputCurrent = 34.567f;
    logEntry.ocVoltage = 35.567f;
    logEntry.outputCharge = 0.004567f;
    logEntry.pvPower = 8334.567f;

    if (!LogAddEntry(&logEntry))
    {
        printe("Error saving log entry.\r\n");
    }
}

void cmdEventLogAdd(uint32_t eventFlags)
{
    memset(&eventLogEntry, 0, sizeof(EventLogEntry));

    IntGetTime(&logIntTime);
    IntGetDate(&logIntTime);
    eventLogEntry.day = logIntTime.date;
    eventLogEntry.month = logIntTime.month;
    eventLogEntry.year = logIntTime.year + 2000;
    eventLogEntry.hour = logIntTime.hour;
    eventLogEntry.min = logIntTime.min;
    eventLogEntry.sec = logIntTime.sec;

    eventLogEntry.eventFlags.flags = eventFlags;
    eventLogEntry.status.status = 0xFFFFFFFFFFFFFFFFull;

    eventLogEntry.outputOn = 0;
    eventLogEntry.outputOff = 0;
    eventLogEntry.forcedReset = 0;
    
    if (!LogAddEventEntry(&eventLogEntry))
    {
        printe("Error saving event log entry.\r\n");
    }
}
#endif

void cmdPrintLogHelp()
{
    printe("Usage:\r\nlog [command]\r\n\r\n"
           "Commands:\r\n"
           "csv [index <start> <num> | id <start> <num>]\r\n"
           "period [<period ms>]\r\n"
           "reset [stats|event]\r\n");
}

void cmdResponse()
{
    UpdateUSBBuffers();
    printf("\r\n");
    UpdateUSBBuffers();
}

void cmdResponseCSV()
{
    UpdateUSBBuffers();
    printf("CSV\r\n");
    UpdateUSBBuffers();
}

void cmdResponseOK()
{
    UpdateUSBBuffers();
    printf("OK\r\n");
    UpdateUSBBuffers();
}

void cmdResponseError()
{
    UpdateUSBBuffers();
    printf("Error\r\n");
    UpdateUSBBuffers();
}

void cmdResponseEntryCount(unsigned long entryCount)
{
    UpdateUSBBuffers();
    printf("EntryCount: %ld\r\n", entryCount);
    UpdateUSBBuffers();
}

void cmdLog(void)
{
    char* param1 = 0;
    char* param2 = 0;
    char* param3 = 0;
    char* param4 = 0;

    getParam("ssss", &param1, &param2, &param3, &param4);
    if (param1)
    {
        if (strcmp("info", param1) == 0)
        {
            cmdResponse();
            LogPrintInfo();
            cmdResponseOK();
            return;
        }
        else if (strcmp("reset", param1) == 0)
        {
            int resetType = -1;
            if (param2)
            {
                if (strcmp("stats", param2) == 0)
                {
                    resetType = LOG_RESET_STATS;
                }
                else if (strcmp("event", param2) == 0)
                {
                    resetType = LOG_RESET_EVENT;
                }
            }
            else
            {
                resetType = LOG_RESET_ALL;
            }
            
            if (resetType >= 0)
            {
                cmdResponse();
                if (LogReset(resetType))
                {
                    cmdResponseOK();
                }
                else
                {
                    cmdResponseError();
                }
                return;
            }
        }
        else if (strcmp("count", param1) == 0)
        {
            cmdResponseEntryCount(LogGetEntryCount());
            cmdResponseOK();
            return;
        }
        else if (strcmp("csv", param1) == 0)
        {
            long startIndex = 0;
            long num = -1;
            
            cmdResponseCSV();
                    
            if (param2)
            {
                if (strcmp("id", param2) == 0)
                {
                    unsigned long startID;
                    if (param3)
                    {
                        startID = atol(param3);
                        if (param4)
                        {
                            num = atol(param4);
                        }
                        else
                        {
                            num = 1;
                        }
                        startIndex = LogGetEntryIndex(startID);
                    }
                }
                else if (strcmp("index", param2) == 0)
                {
                    if (param3)
                    {
                        startIndex = atol(param3);
                    }
                    else
                    {
                        startIndex = 0;
                    }
                    if (param4)
                    {
                        num = atol(param4);
                    }
                    else
                    {
                        num = 1;
                    }
                }
            }
            else
            {
                num = LogGetEntryCount();
            }
            
            if (num < 0)
            {
                cmdResponseError();
            }
            else if (startIndex == LOG_BAD_VALUE)
            {
                cmdResponseOK();
            }
            else
            {
                cmdLogDumpCSV(startIndex, num);
                cmdResponseOK();
            }
            return;
        }
        else if (strcmp("eventcount", param1) == 0)
        {
            cmdResponseEntryCount(LogGetEventEntryCount());
            cmdResponseOK();
            return;
        }
        else if (strcmp("eventcsv", param1) == 0)
        {
            long startIndex = 0;
            long num = -1;
            
            cmdResponseCSV();

            if (param2)
            {
                if (strcmp("id", param2) == 0)
                {
                    unsigned long startID;
                    if (param3)
                    {
                        startID = atol(param3);
                        if (param4)
                        {
                            num = atol(param4);
                        }
                        else
                        {
                            num = 1;
                        }
                        startIndex = LogGetEventEntryIndex(startID);
                    }
                }
                else if (strcmp("index", param2) == 0)
                {
                    if (param3)
                    {
                        startIndex = atol(param3);
                    }
                    else
                    {
                        startIndex = 0;
                    }
                    if (param4)
                    {
                        num = atol(param4);
                    }
                    else
                    {
                        num = 1;
                    }
                }
            }
            else
            {
                num = LogGetEventEntryCount();
            }
            
            if (num < 0)
            {
                cmdResponseError();
            }
            else if (startIndex == LOG_BAD_VALUE)
            {
                cmdResponseOK();
            }
            else
            {
                cmdEventLogDumpCSV(startIndex, num);
                cmdResponseOK();
            }
            return;
        }
        else if (strcmp("period", param1) == 0)
        {
            cmdResponse();
            if (!param2)
            {
                printf("LogPeriod: %d\r\n", LogGetPeriod());
                cmdResponseOK();
            }
            else if (LogSetPeriod(atol(param2)))
            {
                cmdResponseOK();
            }
            else
            {
                cmdResponseError();
            }
            return;
        }
#ifdef ENABLE_LOG_DEBUG
        else if (strcmp("add", param1) == 0)
        {
            cmdLogAdd(23.5f);
            return;
        }
        else if (strcmp("addevent", param1) == 0)
        {
            cmdEventLogAdd(0xFFFFFFFFul);
            return;
        }
        else if (strcmp("fill", param1) == 0)
        {
            unsigned long i;
            unsigned long max = LogGetMaxEntries();
            
            unsigned int step = max/10;
            printf ("Creating %ld entries\r\n", max);
            UpdateUSBBuffers();
            
            for (i=0; i<max; i++)
            {
                if (i % step == 0)
                {
                    printf("%ld\r\n", i);
                    UpdateUSBBuffers();
                }
                cmdLogAdd(i);
                WDT ^= 1;
            }
            return;
        }
        else if (strcmp("fillevent", param1) == 0)
        {
            unsigned long i;
            unsigned long max = LogGetEventMaxEntries();
            
            unsigned int step = max/10;
            printf ("Creating %ld event entries\r\n", max);
            UpdateUSBBuffers();
            
            for (i=0; i<max; i++)
            {
                if (i % step == 0)
                {
                    printf("%ld\r\n", i);
                    UpdateUSBBuffers();
                }
                cmdEventLogAdd(i << 1);
                WDT ^= 1;
            }
            return;
        }
#endif
    }
    
    cmdPrintLogHelp();
}