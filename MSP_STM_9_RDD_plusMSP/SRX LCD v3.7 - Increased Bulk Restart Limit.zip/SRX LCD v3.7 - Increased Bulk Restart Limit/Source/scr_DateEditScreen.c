#include "scr_TimeEditScreen.h"
#include "scr_TimeDateEditScreen.h"
#include "scr_DateEditScreen.h"
#include "scr_MainMenuScreen.h"
#include "scr_SettingsMenuScreen.h"
#include "scr_RealTimeScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"
#include "rtc.h"

TLabel *DateValues[DATE_VALS];

enum DATE_DIGITS curDate = DayValue;

extern Tscreen* CurrentScreen;
extern Tscreen* PreviousScreen;

time scr_DateEditScreen;

int z=0;

void Init_DateEditScreen(time *t)
{
     if (CurrentScreen != &DateEditScreen)
     {
        DateValues[DayValue] = &lbl_DateEditScreen_Day;
        DateValues[MonthValue] = &lbl_DateEditScreen_Month;
        DateValues[YearValue] = &lbl_DateEditScreen_Year;
        
        PreviousScreen = CurrentScreen;
        
         if (PreviousScreen == (&TimeDateEditScreen))
        {
         curDate = DayValue;
        }
        
        DrawScreen(&DateEditScreen);
        SelectDigit(DateValues[curDate]);
        
        UpdateDateEditScreen(&curIntTime);
     }
}



void UpdateDateEditScreen(time *t)
{
  char tempYear[3];
  char tempMonth[3];
  char tempDay[3];

  
  int i = 0;
  
  IntGetDate(t);
  
  sprintf(tempYear,"%02u", (unsigned long)t->year);
  sprintf(tempMonth,"%02u", (unsigned long)t->month);
  sprintf(tempDay,"%02u", (unsigned long)t->date);
  

  if (CurrentScreen == &DateEditScreen)
     {
       for (i ; i < DATE_VALS ; i++)
       {
        if (curDate == i)
        {
          ClearLbl(DateValues[i],boxRound_DateEditScreen_BackgroundPanel.Color);
          TFT_Set_Font(DateValues[i]->FontName, SELECTED_DIGIT_COLOR, FO_HORIZONTAL);
        }
        else
        {
          ClearLbl(DateValues[i],boxRound_DateEditScreen_BackgroundPanel.Color);
          TFT_Set_Font(DateValues[i]->FontName, UNSELECTED_DIGIT_COLOR, FO_HORIZONTAL);
        }
        
        if (i == DayValue)
          {
           DateValues[i]->Caption[0] =  tempDay[0];
           DateValues[i]->Caption[1] = tempDay[1];
           DateValues[i]->Caption[2] = 0x00;
           TFT_Write_Text(DateValues[i]->Caption, DateValues[i]->Left, DateValues[i]->Top);
          }
          
       if (i == MonthValue)
          {
           DateValues[i]->Caption[0] =  tempMonth[0];
           DateValues[i]->Caption[1] = tempMonth[1];
           DateValues[i]->Caption[2] = 0x00;
           TFT_Write_Text(DateValues[i]->Caption, DateValues[i]->Left, DateValues[i]->Top);
          }
          
       if (i == YearValue)
          {
           DateValues[i]->Caption[0] =  tempYear[0];
           DateValues[i]->Caption[1] = tempYear[1];
           DateValues[i]->Caption[2] = 0x00;
           TFT_Write_Text(DateValues[i]->Caption, DateValues[i]->Left, DateValues[i]->Top);
          }

       
       
       }

     }

}

void Save_DateEditScreen(void)      // This section is when updating values on Screen and saving the set values to struct.
{
    char val1,val2;   // array of 6 characters holding value of each digit
         int temp;
         int tot;
         int du  = 0;
         int dig = 0;


   if (CurrentScreen == &DateEditScreen)
     {
     
      for (du ; du < DATE_VALS ; du++)
          {
             val1 = DateValues[du]->Caption[0];
             val2 = DateValues[du]->Caption[1];
             
         if(val1 != '0')
             {
               temp = ( (((int)(val1-'0'))*10) + ((int)(val2-'0')) )  ;
             }
         else
             {
               temp = ( ((int)(val1-'0')) + ((int)(val2-'0')) );
             }
         
         if (du == DayValue)
             {
              curTime.date = (unsigned char)temp;
             }

              if (du == MonthValue)
             {
              curTime.month = (unsigned char)temp;
             }

              if (du == YearValue)
             {
              curTime.year = (unsigned char)temp;
             }
     
             ExtSetDate(&curTime);
             
           curIntTime.date   = curTime.date;
           curIntTime.month   = curTime.month;
           curIntTime.year  = curTime.year;
           
           IntSetDate(&curIntTime);
     
     }







   /* char tempDate[9];
    
     if (CurrentScreen == &DateEditScreen)
     {
      tempDate[0] = DateValues[DayValue]->Caption[0];
      tempDate[1] = DateValues[DayValue]->Caption[1];
      tempDate[2] = '/';
      tempDate[3] = DateValues[MonthValue]->Caption[0];
      tempDate[4] = DateValues[MonthValue]->Caption[1];
      tempDate[5] = '/';
      tempDate[6] = DateValues[YearValue]->Caption[0];
      tempDate[7] = DateValues[YearValue]->Caption[1];
      tempDate[8] = 0x00;
      
     ClearLbl(&lbl_RealTimeScreen_Date,RealTimeScreen.Color);   // in this section should be saving to a struct variable.
     DrawLbl(&lbl_RealTimeScreen_Date,tempDate, 9); */

     }
}

void NextDateSelection(void)
{
if (curDate == YearValue)
   {
      DeselectDigit(DateValues[curDate]);
      curDate = DayValue;
      SelectDigit(DateValues[curDate]);
      return;
   }

  DeselectDigit(DateValues[curDate]);
  SelectDigit(DateValues[curDate+1]);
  curDate = curDate+1;


}


void IncrementDateDigits(TLabel *Label)
{

char date[MAX_CHARS];
char x,y;
int i = 0;


for(i;i<MAX_CHARS;i++)
{
  date[i] = Label->Caption[i];
}
   x = date[0];
   y = date[1];

  if(curDate == DayValue)
  {
      if((x=='0') && (y == '9') )
      {
        y = '0';
        x = '1';
      }

      else if((x =='1') && (y =='9'))
      {
        x = '2';
        y = '0';
      }

      else if ((x == '2')&&(y == '9'))
      {
        x = '3';
        y = '0';
      }
      
      else if ((x == '3')&&(y == '1'))
      {
        x = '0';
        y = '1';
      }
      

      else
      y++;
   }

  if(curDate == MonthValue)
  {
   if((x=='0') && (y == '9') )
      {
        x = '1';
        y = '0';

      }

      else if((x =='1') && (y =='2'))
      {
        x = '0';
        y = '1';
      }

      else
      y++;

  }

  if(curDate == YearValue)
  {
      if((x =='0') && (y =='9'))
      {
        x = '1';
        y = '2';
      }
      
      else if((x =='1') && (y =='9'))
      {
        x = '2';
        y = '0';
      }

      else if ((x == '2')&&(y == '9'))
      {
        x = '3';
        y = '0';
      }

      else if ((x == '3')&&(y == '9'))
      {
        x = '4';
        y = '0';
      }
      
         else if ((x == '4')&&(y == '9'))
      {
        x = '5';
        y = '0';
      }
      
         else if ((x == '5')&&(y == '0'))
      {
        x = '1';
        y = '9';
      }

      else
      y++;

  }
  
  ClearDigit(Label,boxRound_DateEditScreen_BackgroundPanel.Color);
  Label->Caption[0]  = x;
  Label->Caption[1]  = y;

  SelectDigit(Label);
}

void DecrementDateDigits(TLabel *Label)
{

char date[MAX_CHARS];
char x,y;
int i = 0;


for(i;i<MAX_CHARS;i++)
{
  date[i] = Label->Caption[i];
}
   x = date[0];
   y = date[1];

if(curDate == DayValue)
{
            if((x=='0') && (y == '1') )
            {
              x = '3';
              y = '1';

            }

            else if((x =='3') && (y =='0'))
            {
              x = '2';
              y = '9';
            }

            else if ((x == '2')&&(y == '0'))
            {
              x = '1';
              y = '9';
            }
            
            else if ((x == '1')&&(y == '0'))
            {
              x = '0';
              y = '9';
            }

            else
            y--;
}

if(curDate == MonthValue)
{
       if((x=='1') && (y == '0') )
      {
        x = '0';
        y = '9';

      }

      else if((x =='0') && (y =='1'))
      {
        x = '1';
        y = '2';
      }
          else
          y--;
}

if(curDate == YearValue)
{

      
      if ((x == '5')&&(y == '0'))
      {
        x = '4';
        y = '9';
      }
      
       else if ((x == '4')&&(y == '0'))
      {
        x = '3';
        y = '9';
      }
      
        else if ((x == '3')&&(y == '0'))
      {
        x = '2';
        y = '9';
      }

      else if ((x == '2')&&(y == '0'))
      {
        x = '1';
        y = '9';
      }

      else if ((x=='1') && (y == '9') )
      {
        y = '0';
        x = '5';
      }
      
      else if ((x=='0') && (y == '0') )
      {
        y = '0';
        x = '5';
      }
      
      
      
      else
      y--;
}

  ClearDigit(Label,boxRound_DateEditScreen_BackgroundPanel.Color);
  Label->Caption[0]  = x;
  Label->Caption[1]  = y;

  SelectDigit(Label);
}

//Event Handlers

void btn_DatedEditScreen_BackOnClick() 
{
 Init_TimeDateEditScreen();

}

void btn_DateEditScreen_NextOnClick() 
{
  NextDateSelection();
}

void btn_DateEditScreen_UpOnPress() 
{

if (z >= 100)
  {
  IncrementDateDigits(DateValues[curDate]);
  delay_ms(100);
  }
   z ++;
}

void btn_DateEditScreen_UpOnClick() 
{
  IncrementDateDigits(DateValues[curDate]);
  z = 0;
}

void btn_DatedEditScreen_DownOnClick() 
{
 DecrementDateDigits(DateValues[curDate]);
  z = 0;
}

void btn_DatedEditScreen_DownOnPress() 
{
   if (z >= 100)
  {
  DecrementDateDigits(DateValues[curDate]);
  delay_ms(100);
  }

  z++;
}



void btn_DatedEditScreen_AcceptOnClick() 
{
     Save_DateEditScreen(void);
     Init_TimeDateEditScreen();
}

void lbl_DateEditScreen_DayOnClick()
{
      DeselectDigit(DateValues[curDate]);
      curDate = DayValue;
      SelectDigit(DateValues[curDate]);
}

void lbl_DateEditScreen_MonthOnClick()
{
      DeselectDigit(DateValues[curDate]);
      curDate = MonthValue;
      SelectDigit(DateValues[curDate]);
}

void lbl_DateEditScreen_YearOnClick()
{
      DeselectDigit(DateValues[curDate]);
      curDate = YearValue;
      SelectDigit(DateValues[curDate]);
}