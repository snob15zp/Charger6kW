#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "screen.h"
#include "general.h"



void ClearLbl( TLabel *_label, unsigned int backgnd_color) {
  TFT_Set_Font(_label->FontName, backgnd_color, FO_HORIZONTAL);
  TFT_Write_Text(_label->Caption, _label->Left, _label->Top);
  strcpy(_label->Caption, " ");
}

void DrawLbl( TLabel *_label, char* labelStr, int len) 
{
  strncpy(_label->Caption, labelStr, len-1);
  _label->Caption[len-1] = 0x00;
  DrawLabel(_label);
}

/*void CenterNotificationLabel( TLabel *_label, char *text)
{
 int txtlngth, padding, length, i;

 length = strlen(_label->Caption);

 padding = (length/2);

 txtlngth = (padding + strlen(text) );

 if (txtlngth > (length-padding)-1)
 txtlngth = ((length-padding)-1);

 ClearLbl(_label,boxRound_NotificationScreenPanel.Color);

 for (i = 0 ; i < padding ; i++)
 {
  _label->Caption[i] = ' ';
 }
 
 ClearLbl(_label,boxRound_NotificationScreenPanel.Color);
 
 strncpy(_label->Caption[i], text, txtlngth);
 _label->Caption[txtlngth] = 0x00;   // length of message + 1 maybe
 TFT_Set_Font(_label->FontName, CL_BLACK, FO_HORIZONTAL);
 TFT_Write_Text( _label->Caption,  _label->Left,  _label->Top);

 i =0;
}
*/



void DeselectRoundBox(TBox_Round *SelectionBox, int Color)
{
 if (SelectionBox->Visible == 0)
 {
  TFT_Set_Brush(SelectionBox->Transparent, Color, 0, SelectionBox->Gradient_Orientation,Color, Color);
  TFT_Set_Pen(Color, SelectionBox->Pen_Width);

  if (SelectionBox->Height > SelectionBox->Width)
       TFT_Rectangle_Round_Edges(SelectionBox->Left + 1, SelectionBox->Top + 1, SelectionBox->Left + SelectionBox->Width - 2,SelectionBox->Top + SelectionBox->Height - 2, SelectionBox->Corner_Radius);

    else
        TFT_Rectangle_Round_Edges(SelectionBox->Left + 1, SelectionBox->Top + 1, SelectionBox->Left + SelectionBox->Width - 2,SelectionBox->Top + SelectionBox->Height - 2, SelectionBox->Corner_Radius);
 }

}

//DIGIT EDITING FUNCTIONS TO BE USED WHEN EDITING SETPOINTS, TIME, DATE ETC
void SelectDigit(TLabel *Digit) //General Use Function
{
     TFT_Set_Font(Digit->FontName,SELECTED_DIGIT_COLOR, FO_HORIZONTAL);
     TFT_Write_Text(Digit->Caption, Digit->Left, Digit->Top);
}

void DeselectDigit(TLabel *Digit) //General Use Function
{
   TFT_Set_Font(Digit->FontName,UNSELECTED_DIGIT_COLOR, FO_HORIZONTAL);
   TFT_Write_Text(Digit->Caption, Digit->Left, Digit->Top);
}

void SelectCode(TLabel *Code) //General Use Function
{
     TFT_Set_Font(Code->FontName,SELECTED_CODE_COLOR, FO_HORIZONTAL);
     TFT_Write_Text(Code->Caption, Code->Left, Code->Top);
}

void DeselectCode(TLabel *Code) //General Use Function
{
   TFT_Set_Font(Code->FontName,UNSELECTED_CODE_COLOR, FO_HORIZONTAL);
   TFT_Write_Text(Code->Caption, Code->Left, Code->Top);
}








void ClearDigit(TLabel *value, unsigned int background_color)
{
  TFT_Set_Font(value->FontName, background_color, FO_HORIZONTAL);
  TFT_Write_Text(value->Caption, value->Left, value->Top);
}

void IncrementDigitValue(TLabel *value) // General Use Function
{
 char digit;

  digit =  value->Caption[0];
  
  ClearDigit(value, BACKGROUND_PANEL_COLOR); //clears previous caption content
  
  if (digit == '9')
  digit = '0';
 
  else if (digit == '.')
  digit ='.';
  
  else if (digit == '-') //'_')
  {
  //value->Top = 83;
  value->Left = 5;       //Changes for Helevtica Font for G3 to move over Positive Sign
  digit = '+';
  }
  
  else if (digit == '+')
  {
  //value->Top = 52;
  value->Left = 13;       //Changes for Helevtica Font for G3 to move over Minus Sign
  digit = '-'; //'_';
  }

  else
  digit++;

 value->Caption[0] = digit; //writes the new digit to caption
 SelectDigit(value); //writes whatever is in caption
}

void DecrementDigitValue(TLabel *value)
{
 char digit;

  digit =  value->Caption[0];
  
  ClearDigit(value, BACKGROUND_PANEL_COLOR); //clears previous caption content
  
  if (digit == '0')
  digit = '9';

  else if (digit == '.')
  digit ='.';

  else if (digit == '-') //'_')
  {
  //value->Top = 83;
  value->Left = 5;       //Changes for Helevtica Font for G3 to move over Positive Sign
  digit = '+';
  }

  else if (digit == '+')
  {
  //value->Top = 52;
  value->Left = 13;       //Changes for Helevtica Font for G3 to move over Minus Sign
  digit = '-'; //'_';
  }

  else
  digit--;

 value->Caption[0] = digit; //writes the new digit to caption
 SelectDigit(value); //writes whatever is in caption
}

void IncrementDigitValue6(TLabel *value) // General Use Function
{
 char digit;

  digit =  value->Caption[0];
  
  ClearDigit(value, BACKGROUND_PANEL_COLOR); //clears previous caption content
  
  if (digit == '5')
  digit = '0';

  else if (digit == '.')
  digit ='.';

  else if (digit == '-') //'_')
  {
  //value->Top = 83;
  value->Left = 5;       //Changes for Helevtica Font for G3 to move over Positive Sign
  digit = '+';
  }

  else if (digit == '+')
  {
  //value->Top = 52;
  value->Left = 13;       //Changes for Helevtica Font for G3 to move over Minus Sign
  digit = '-'; //'_';
  }

  else
  digit++;

 value->Caption[0] = digit; //writes the new digit to caption
 SelectDigit(value); //writes whatever is in caption
}

void DecrementDigitValue6(TLabel *value)
{
 char digit;

  digit =  value->Caption[0];
 
  ClearDigit(value, BACKGROUND_PANEL_COLOR); //clears previous caption content
 
  if (digit == '0')
  digit = '5';

  else if (digit == '.')
  digit ='.';

  else if (digit == '-') //'_')
  {
  //value->Top = 83;
  value->Left = 5;       //Changes for Helevtica Font for G3 to move over Positive Sign
  digit = '+';
  }

  else if (digit == '+')
  {
  //value->Top = 52;
  value->Left = 13;       //Changes for Helevtica Font for G3 to move over Minus Sign
  digit = '-'; //'_';
  }

  else
  digit--;


 value->Caption[0] = digit; //writes the new digit to caption
 SelectDigit(value); //writes whatever is in caption
}