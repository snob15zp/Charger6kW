#include "scr_MainMenuScreen.h"
#include "scr_RealTimeScreen.h"
#include "scr_ErrorScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "protocol.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"
#include "coolmax.h"
#include "scr_NotificationScreen.h"

TLabel *AlarmPosition[MAX_ALARMS];

scr_ErrorScreen_Type scr_ErrorScreen;

extern TScreen*  CurrentScreen;
extern Tscreen* PreviousScreen;

enum ALARM_LABELPOS CurAlarmPos = Pos1;


void Init_ErrorScreen(scr_ErrorScreen_Type *screen)
{

     if (CurrentScreen != &ErrorScreen)
     {
       AlarmPosition[Pos1] = &lbl_ErrorScreen_Pos1;
       AlarmPosition[Pos2] = &lbl_ErrorScreen_Pos2;
       AlarmPosition[Pos3] = &lbl_ErrorScreen_Pos3;
       AlarmPosition[Pos4] = &lbl_ErrorScreen_Pos4;
       AlarmPosition[Pos5] = &lbl_ErrorScreen_Pos5;
       AlarmPosition[Pos6] = &lbl_ErrorScreen_Pos6;
       AlarmPosition[Pos7] = &lbl_ErrorScreen_Pos7;
       AlarmPosition[Pos8] = &lbl_ErrorScreen_Pos8;
       AlarmPosition[Pos9] = &lbl_ErrorScreen_Pos9;
       AlarmPosition[Pos10]= &lbl_ErrorScreen_Pos10;
       
     //Clear all the default data in there.
     ClearLbl(AlarmPosition[Pos1],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos2],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos3],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos4],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos5],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos6],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos7],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos8],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos9],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos10],boxRound_ErrorScreen_BackgroundPanel1.Color);
     
       PreviousScreen = CurrentScreen;
       DrawScreen(&ErrorScreen);
     }
     
     UpdateErrorScreen();
}



void UpdateErrorScreen(void) // This is the only thing that needs to be updated on this screen
{
  if (CurrentScreen == &ErrorScreen)
     {
         CurAlarmPos = Pos1;
         
         RefreshErrorScreen();
          
          if (telemetry.eventFlags.systemPower != 0) //FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, CL_BLACK, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F009", 12);
           AlarmPosition[CurAlarmPos]->Caption[12] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);
           
           if(CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.lowOutVoltWarn != 0)   // WARNING
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, CL_BLACK, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "W001", 12);
           AlarmPosition[CurAlarmPos]->Caption[12] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;

          }

          if ((telemetry.eventFlags.lowOutVoltFault != 0) && (telemetry.status.control_outputEnabled != 0)) // FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F001", 12);
           AlarmPosition[CurAlarmPos]->Caption[12] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }


          if (telemetry.eventFlags.lowOutVoltGenSet != 0) //FAULT or Warning?
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, CL_BLACK, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "W003", 12);
           AlarmPosition[CurAlarmPos]->Caption[12] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.highOutVoltFault != 0) // FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F002", 13);
           AlarmPosition[CurAlarmPos]->Caption[13] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.highOutCurrentFault != 0) // FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F003", 13);
           AlarmPosition[CurAlarmPos]->Caption[13] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.highDischargeCurrentFault != 0)  // FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F005", 13);
           AlarmPosition[CurAlarmPos]->Caption[13] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.highBatteryTempFault != 0) // FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F006", 13);
           AlarmPosition[CurAlarmPos]->Caption[13] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.inputBreakerOpen != 0) //FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F007", 11);
           AlarmPosition[CurAlarmPos]->Caption[11] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.outputBreakerOpen != 0) // FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F008", 12);
           AlarmPosition[CurAlarmPos]->Caption[12] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.tempSensorFault != 0) // FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, CL_BLACK, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "W002", 11);
           AlarmPosition[CurAlarmPos]->Caption[11] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.negativePVCurrentSutdown != 0) // FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F010", 11);
           AlarmPosition[CurAlarmPos]->Caption[11] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.highPVCurrentShutdown != 0) // FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F011", 12);
           AlarmPosition[CurAlarmPos]->Caption[12] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

          if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.highPVVoltShutdown != 0) // FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F012", 12);
           AlarmPosition[CurAlarmPos]->Caption[12] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.highOutCurrentShutdown != 0) // FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F013", 13);
           AlarmPosition[CurAlarmPos]->Caption[13] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.highOutVoltShutdown != 0) // FAULT
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F014", 13);
           AlarmPosition[CurAlarmPos]->Caption[13] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.logFull != 0)
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "W004", 8);
           AlarmPosition[CurAlarmPos]->Caption[8] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.solarPanelMissing != 0)
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, CL_BLACK, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "W005", 13);
           AlarmPosition[CurAlarmPos]->Caption[13] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.configValueOutOfRange != 0)
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "W006", 12);
           AlarmPosition[CurAlarmPos]->Caption[12] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }

          if (telemetry.eventFlags.fanFault != 0)
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F015", 9);
           AlarmPosition[CurAlarmPos]->Caption[9] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;

          }
          if (telemetry.eventFlags.highHeatSinkTemp != 0)
          {
           ClearLbl(AlarmPosition[CurAlarmPos],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[CurAlarmPos]->FontName, 0xD9E7, FO_HORIZONTAL);

           strncpy(AlarmPosition[CurAlarmPos]->Caption, "F016", 13);
           AlarmPosition[CurAlarmPos]->Caption[13] = 0x00;

           TFT_Write_Text(AlarmPosition[CurAlarmPos]->Caption, AlarmPosition[CurAlarmPos]->Left, AlarmPosition[CurAlarmPos]->Top);

           if( CurAlarmPos < 10)
           CurAlarmPos++;
          }
          
          if (CurAlarmPos < 1)
          {
           ClearLbl(AlarmPosition[Pos1],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[Pos1]->FontName, CL_BLACK, FO_HORIZONTAL);
           strncpy(AlarmPosition[Pos1]->Caption, "NO ALARMS", 9);
           AlarmPosition[Pos1]->Caption[9] = 0x00;
           TFT_Write_Text(AlarmPosition[Pos1]->Caption, AlarmPosition[Pos1]->Left, AlarmPosition[Pos1]->Top);
          }

          if(CurAlarmPos < Pos7)
          {

           ClearLbl(AlarmPosition[Pos6],boxRound_ErrorScreen_BackgroundPanel1.Color);
           TFT_Set_Font(AlarmPosition[Pos6]->FontName, CL_BLACK, FO_HORIZONTAL);
           strncpy(AlarmPosition[Pos6]->Caption, "", 9);
           AlarmPosition[Pos6]->Caption[9] = 0x00;
           TFT_Write_Text(AlarmPosition[Pos6]->Caption, AlarmPosition[Pos6]->Left, AlarmPosition[Pos6]->Top);

           }


      }
      
}

void RefreshErrorScreen()
{

     ClearLbl(AlarmPosition[Pos1],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos2],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos3],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos4],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos5],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos6],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos7],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos8],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos9],boxRound_ErrorScreen_BackgroundPanel1.Color);
     ClearLbl(AlarmPosition[Pos10],boxRound_ErrorScreen_BackgroundPanel1.Color);

}




//Event Handlers Here

void btn_ErrorScreen_MenuOnClick() 
{
 
 Init_RealTimeScreen(&scr_RealTimeScreen);

}

void btn_ErrorScreen_ConfirmErrorsOnClick() 
{
 requestRemoteReset = true;      //reset unit here
 isRemoteResetSent = 0;
 notificationScreenType = STATUS_SCREEN_PASS;
 Init_NotificationScreen();
 
 //Init_RealTimeScreen(&scr_RealTimeScreen);
}