#include "general.h"
#include "externalRtc.h"
#include "rtc.h"
#include "cmdlib.h"


#define ADDR_MCP7940M                  ((unsigned char)0xDE)

#define REG_RTCSEC                     ((unsigned char)0x00)
#define REG_RTCMIN                     ((unsigned char)0x01)
#define REG_RTCHOUR                    ((unsigned char)0x02)
#define REG_RTCWKDAY                   ((unsigned char)0x03)
#define REG_RTCDATE                    ((unsigned char)0x04)
#define REG_RTCRTCMTH                  ((unsigned char)0x05)
#define REG_RTCYEAR                    ((unsigned char)0x06)
#define REG_CONTROL                    ((unsigned char)0x07)

#define RTC_IDLE_QNT_ATTEMPTS          5

#define I2C_BUS_ERR_NO                 0
#define I2C_BUS_ERR_RD_IDLE            1
#define I2C_BUS_ERR_RD_WRITE_1         2
#define I2C_BUS_ERR_RD_WRITE_2         3
#define I2C_BUS_ERR_RD_WRITE_3         4
#define I2C_BUS_ERR_RD_READ            5
#define I2C_BUS_ERR_RD_START           6
#define I2C_BUS_ERR_RD_RESTART         7

#define I2C_BUS_ERR_WR_IDLE            8
#define I2C_BUS_ERR_WR_WRITE_1         9
#define I2C_BUS_ERR_WR_WRITE_2         10
#define I2C_BUS_ERR_WR_WRITE_3         11
#define I2C_BUS_ERR_WR_START           12

sbit Soft_I2C_Scl           at RA2_bit;
sbit Soft_I2C_Sda           at RA3_bit;
sbit Soft_I2C_Scl_Direction at TRISA2_bit;
sbit Soft_I2C_Sda_Direction at TRISA3_bit;

ExtTime curTime;

unsigned char buffer[16];

int i2c_rd_Regs(unsigned char addr_device, unsigned char reg, unsigned char *ptr, int nByte)
{
int indx;
        Soft_I2C_Start();
        Soft_I2C_Write(addr_device);
        Soft_I2C_Write(reg);
        Soft_I2C_Start();
        Soft_I2C_Write(addr_device | 0x01);
        for ( indx = 0; indx < nByte; indx++ )
        {
            if ( (indx + 1) < nByte )
                ptr[indx] = Soft_I2C_Read(1);
            else
                ptr[indx] = Soft_I2C_Read(0);
        }
        Soft_I2C_Stop();
        return 0;
}

int i2c_wr_Regs(unsigned char addr_device, unsigned char reg, unsigned char *ptr, int nByte)
{
int indx;
        Soft_I2C_Start();
        Soft_I2C_Write(addr_device);
        Soft_I2C_Write(reg);
        for ( indx = 0; indx < nByte; indx++ )
        {
            Soft_I2C_Write(ptr[indx]);
        }
        Soft_I2C_Stop();
        return 0;
}

//set the clock frequency of the I2C
void ExtRtcInit()
{
     Soft_I2C_Init();
}

void ExtRtcStart()
{
    buffer[0] = 0x40;
    i2c_wr_Regs(ADDR_MCP7940M, REG_CONTROL, &buffer[0], 1);
    Delay_ms(2);

    i2c_rd_Regs(ADDR_MCP7940M, REG_RTCHOUR, &buffer[0], 1);
    buffer[0] &= 0x3f;
    i2c_wr_Regs(ADDR_MCP7940M, REG_RTCHOUR, &buffer[0], 1);
    Delay_ms(2);

    i2c_rd_Regs(ADDR_MCP7940M, REG_RTCSEC, &buffer[0], 1);
    buffer[0] |= 0x80;
    i2c_wr_Regs(ADDR_MCP7940M, REG_RTCSEC, &buffer[0], 1);
    Delay_ms(2);

//     set1HzClock(true);
//     ret = check1HzClock(true);
//     if (!ret)
////        printe("Unable to Start External RTC\r\n");
//     }
}

int ExtGetTime(ExtTime *t)
{
    i2c_rd_Regs(ADDR_MCP7940M, REG_RTCSEC, &buffer[0], 8);
    
    t->sec = ConvertfromBCD(buffer[0] & 0x7f) % 60;
    t->min = ConvertfromBCD(buffer[1]) % 60;
    t->hour = ConvertfromBCD(buffer[2]) % 24;
    t->date = ConvertfromBCD(buffer[4]);
    t->month = ConvertfromBCD(buffer[5] & 0x1f);
    t->year = ConvertfromBCD(buffer[6]);

    return 0;
}

int ExtSetTime(ExtTime *t)
{
    buffer[0] = ConvertToBCD(t->sec % 60);
    buffer[0] |= 0x80;
    buffer[1] = ConvertToBCD(t->min % 60);
    buffer[2] = ConvertToBCD(t->hour % 24);
    i2c_wr_Regs(ADDR_MCP7940M, REG_RTCSEC, &buffer[0], 3);
    return 0;
}

int ExtSetDate(ExtTime *t)
{
    buffer[0] = ConvertToBCD(t->date);
    buffer[1] = ConvertToBCD(t->month);
    buffer[2] = ConvertToBCD(t->year);
    i2c_wr_Regs(ADDR_MCP7940M, REG_RTCDATE, &buffer[0], 3);
    return 0;
}

int check1HzClock(int on)
{
/*
        if ((localBuffer[0] & 0x80) != 0x00)  //Oscillator Disabled if CH Bit Set
        {
                return false;
        }
        
        localBuffer[0] &= 0x40;

        if (on == false)
        {
                ret =  (localBuffer[0] == 0x40);
        }
        else
        {
                ret =  (localBuffer[0] == 0x00);
        }

        delay_ms(20);
        //Check 12/24 Hr Format Bit in DS1307 Register 0x02
  //      CS_RTC = 0;

//        SPI2_Write(HOURS_REG_READ);

//        localBuffer[0] = (unsigned char) SPI2_Read((unsigned long) 0xFF);
//        CS_RTC = 1;

        if ((localBuffer[0] & 0x40) != 0x00)  //24 Hour Time Format if Bit Cleared
        {
                return false;
        }
*/
        return true;
}

int set1HzClock(int on)
{

        unsigned char localBuffer[5];

        //waitTime(20);
        //Set BSQWE Bit for Square Wave Output in DS1307 Register



        if (on == false)
        {
               localBuffer[0] = 0x40;
        }
        else
        {
               localBuffer[0] = 0x00;
        }
        
//        CS_RTC = 0;

//        SPI2_Write(CTRL_REG_WRITE);
//        SPI2_Write(localBuffer[0]);
//        CS_RTC = 1;

        delay_ms(20);
        
//        CS_RTC = 0;

///        SPI2_Write(HOURS_REG_READ);

//        localBuffer[0] = (unsigned char) SPI2_Read((unsigned long) 0xFF);
//        CS_RTC = 1;

        if ((localBuffer[0] & 0x40) != 0x00)  //24 Hour Time Format if Bit Cleared
        {
            delay_ms(20);
            localBuffer[0] &= 0xBF;
            
//            CS_RTC = 0;
            
//            SPI2_Write(HOURS_REG_WRITE);
//            SPI2_Write(localBuffer[0]);

//            CS_RTC = 1;
        }
        
        return true;
        
}