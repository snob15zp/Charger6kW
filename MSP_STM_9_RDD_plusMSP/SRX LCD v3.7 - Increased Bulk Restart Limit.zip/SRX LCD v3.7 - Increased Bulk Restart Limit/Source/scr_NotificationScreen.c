#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "scr_NotificationScreen.h"
#include "scr_ErrorScreen.h"
#include "scr_MainMenuScreen.h"
#include "scr_SetpointsScreen1.h"
#include "scr_SetpointsScreen2.h"
#include "scr_PincodeScreen.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"
#include "coolmax.h"
#include "general.h"

extern TScreen*  CurrentScreen;
extern Tscreen* PreviousScreen;

int notificationScreenType = STATUS_SCREEN_PASS;

void Init_NotificationScreen(void)
{

    
     if (CurrentScreen != &Notification_Screen)
     {
       PreviousScreen = CurrentScreen;
       
       if (notificationScreenType == STATUS_SCREEN_PASS)
       {
        lbl_NotificationScreen_Warning.Visible = false;
        lbl_NotificationScreen_Status.Visible = true;
        
        lbl_NotificationScreen_WarningSetpoint.Visible = false;

        btn_NotificationScreen_Return.Visible = false;
        btn_NotificationScreen_Return.Active = false;
        btn_NotificationScreen_Menu.Visible = true;
        btn_NotificationScreen_Menu.Active = true;
       }
       
       if ( notificationScreenType == STATUS_SCREEN_WARNING)
       {
        lbl_NotificationScreen_Status.Visible = false;
        lbl_NotificationScreen_Warning.Visible = true;
        
        lbl_NotificationScreen_WarningSetpoint.Visible = true;

        btn_NotificationScreen_Menu.Visible = false;
        btn_NotificationScreen_Menu.Active = false;
        btn_NotificationScreen_Return.Visible = true;
        btn_NotificationScreen_Return.Active = true;


       }

       DrawScreen(&Notification_Screen);
       UpdateNotificationScreen("WAITING...");

     }


     
}


void UpdateNotificationScreen(char *message)
{
  
  if (CurrentScreen == &Notification_Screen)
     {
       char text[32];
       
       strncpy(text,message, 32);
       

       ClearLbl(&lbl_NotificationScreen_InfoLabel,boxRound_NotificationScreenPanel.Color);
       strncpy(lbl_NotificationScreen_InfoLabel.Caption, text, 32);
       lbl_NotificationScreen_InfoLabel.Caption[32] = 0x00;   // length of message + 1 maybe
       TFT_Set_Font(lbl_NotificationScreen_InfoLabel.FontName, CL_BLACK, FO_HORIZONTAL);
       TFT_Write_Text( lbl_NotificationScreen_InfoLabel.Caption,  lbl_NotificationScreen_InfoLabel.Left,  lbl_NotificationScreen_InfoLabel.Top);
     }

}

// Event Handlers                      lbl_NotificationScreen_WarningSetpoint

void btn_NotificationScreen_MenuOnClick() 
{
   Init_MainMenuScreen();
}

void btn_NotificationScreen_ReturnOnClick() 
{
  if (PreviousScreen == (&SetpointsScreen1) )// && (notificationScreenType = STATUS_SCREEN_WARNING) )
  {
  Init_SetpointsScreen1(&scr_SetpointsScreen1);
  }
  
 /*else if ((PreviousScreen == (&SetpointsScreen1) ) && (notificationScreenType = STATUS_SCREEN_PASS) )
  {
     Init_MainMenuScreen();
  }*/
  
 if (PreviousScreen == (&SetpointsScreen2) )// && (notificationScreenType = STATUS_SCREEN_WARNING) )
 {
 Init_SetpointsScreen2(&scr_SetpointsScreen2);
 }
 
 /*else if  ( (PreviousScreen == (&SetpointsScreen2) ) && (notificationScreenType = STATUS_SCREEN_PASS) )
 {
     Init_MainMenuScreen();
 }*/
 
 
}