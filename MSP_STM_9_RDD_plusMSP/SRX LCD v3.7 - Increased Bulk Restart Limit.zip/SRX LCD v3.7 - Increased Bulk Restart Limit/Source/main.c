// ----------------------------------------------------------------------------
// Project Name : CoolmaxLCD (AERL Coolmax SR Maximizer 'Touch')
// Copyright    : (c) Australian Energy Research Laboratories (AERL) 2013
// Authours     : Adrian Edmonds, Carl Joyce & Pavle Krkeljas
// Website      : http://www.aerl.com.au
// Hardware     : MCU          : PIC32MX460F512L
//                Dev. Board   : Mikroelektronika MikroMMB for PIC32
//                http://www.mikroe.com/eng/products/view/595/mikromedia-for-pic32/
//                Oscillator   : XT-PLL, 80.000MHz
//                Ext. Modules : -
//                Compiler     : mikroC PRO for PIC32
//                http://www.mikroe.com/eng/products/view/623/mikroc-pro-for-pic32/
// Description  : This project controls the AERL Coolmax SR Maximizer 'Touch'
//                series of Maximum Power-Point Tracker (MPPT) Solar Charge
//                Controllers.
// Rev. History : 2012_10_01 -> Project Created
//                2012_11_01 ->
//                2012_12_21 -> Initial Test Release
//                2013_01_14 -> Initial Trial Release
//                2013_02_01 -> Initial Production Release
// ------------------------- Included Files -----------------------------------

#include "serial1.h"
#include "debug.h"
#include "rs485.h"
#include "timer.h"
#include "general.h"
#include "scr_ErrorScreen.h"
#include "cmdproc.h"
#include "cmdlib.h"
#include "externalRtc.h"
#include "rtc.h"
#include "fram.h"
#include "localConfig.h"
#include "log.h"
#include "coolmax.h"
#include "CoolMax_LCD_objects.h"
#include "scr_SplashScreen.h"
#include "scr_RealTimeScreen.h"
#include "scr_SetpointsScreen1.h"
#include "scr_SetpointsScreen2.h"
#include "scr_InformationScreen.h"
#include "scr_CanBusInfoScreen.h"
#include "scr_TimeEditScreen.h"
#include "scr_OutputOnOffScreen.h"
#include "protocol.h"
#include "mb.h"
#include "mbport.h"
#include "mbutils.h"
#include "port.h"

// ------------------------ Static Variables ----------------------------------
//static UCHAR mbCoilBuf[MB_COIL_NUM / 8];         // There are no coils to set
static UCHAR mbDiscreteInputBuf[MB_DISCRETE_NUM / 8]; // 96 / 8 = 12
static USHORT mbInputRegBuf[MB_INPUT_REG_NUM];
static USHORT mbHoldingRegBuf[MB_HOLDING_REG_NUM];

//static FLOAT usReg;
// ----------------------- Instance Variables ---------------------------------
sbit ALARM1 at LATA5_bit;
sbit ALARM1_DIR at TRISA5_bit;

sbit ALARM2 at LATA4_bit;
sbit ALARM2_DIR at TRISA4_bit;

sbit WDT at LATD2_bit;
sbit WDT_DIR at TRISD2_bit;

sbit TFT_BLED_ at LATA9_bit;
sbit TFT_BLED_Direction_ at TRISA9_bit;

sbit DIP1 at LATG15_bit;      //Dipswitch 1
sbit DIP1_DIR at TRISG15_bit;

sbit DIP2 at LATG13_bit;      //Dipswitch 2
sbit DIP2_DIR at TRISG13_bit;

sbit DIP3 at LATG12_bit;      //Dipswitch 3
sbit DIP3_DIR at TRISG12_bit;

sbit DIP4 at LATG14_bit;      //Dipswitch 4
sbit DIP4_DIR at TRISG14_bit;


int count = 0;
int switcher = 0;
unsigned char Password[5] = {'1','1','1','1','\0'};
int PassCodeFlag = false;

unsigned char LastMinute = 0;
unsigned char LastHour = 0;
unsigned char LastDay = 0;

Tscreen* PreviousScreen;
extern TScreen* CurrentScreen;

void MB_InitRegisters(void);
void MB_CopyStructToCoils(void);
void MB_CopyStructToDiscreteInputs(void);
void MB_CopyStructToInputRegs(void);
void MB_CopyStructToHoldingRegs(void);
// ----------------------------------------------------------------------------
// Testcode to increment values on Real-Time Screen
// ----------------------------------------------------------------------------
void TestIncrement()
{
    telemetry.pvVoltage += 0.1;
    telemetry.outputCharge += 12.0;
    telemetry.ocVoltage += 15.0;
    telemetry.pvPower += 17.0;
    telemetry.batteryTemp += 22.0;

    if ((telemetry.pvVoltage > 150.00) || (telemetry.pvVoltage < 0.0 ))
       telemetry.pvVoltage = 0.0;

    if ((telemetry.outputCharge > 150.00) || (telemetry.outputCharge < 0.0 ))
       telemetry.outputCharge = 0.0;

    if ((telemetry.ocVoltage > 150.00) || (telemetry.ocVoltage < 0.0 ))
       telemetry.ocVoltage = 0.0;

    if ((telemetry.pvPower > 150.00) || (telemetry.pvPower < 0.0 ))
       telemetry.pvPower = 0.0;

    if ((telemetry.batteryTemp > 150.00) || (telemetry.batteryTemp < 0.0 ))
       telemetry.batteryTemp = 0.0;
}
// --------------------------- Main Event -------------------------------------

#ifdef ENABLE_MIDNIGHT_RESET
int IsMidnight()
{
   int midnight = curIntTime.min == 0 && LastMinute == 59 && curIntTime.hour == 0 &&
            LastHour == 23 && curIntTime.date != LastDay;

   LastMinute = curIntTime.min;
   LastHour = curIntTime.hour;
   LastDay = curIntTime.date;

   return midnight;
}
#endif

void MainEvent()
{
    if (TP_TFT_Press_Detect())
    {
      bkLightCounter = BACKLIGHT_TIMER_MAX;
    }
    
    WDT ^= 1;

    Check_TP();
    
    if (isRemoteResetSent > 0)
    {
      if (isRemoteResetSent == 1)
      {
        if (CurrentScreen != &SplashScreen)
        {
          InitializeOnOffScreenDefaults();
          PreviousScreen = CurrentScreen;
          DrawScreen(&SplashScreen);
        }
      }
      isRemoteResetSent++;
      if (isRemoteResetSent >  2400)
      {
          Init_RealTimeScreen(&scr_RealTimeScreen);
          isRemoteResetSent = 0;
      }
    }
    
    if ((count % 400) == 0)
    {
       IntGetTime(&curIntTime);
       IntGetDate(&curIntTime);
       
       lcd_time.yy = curIntTime.year + 2000;
       lcd_time.mo = curIntTime.month;
       lcd_time.md = curIntTime.date;
       lcd_time.hh = curIntTime.hour;
       lcd_time.mn = curIntTime.min;
       lcd_time.ss = curIntTime.sec;
       UpdateRxCoolMaxData();
       FlashAlarmButton();
    }

    if ((count % 1200) == 0)
    {
       Update_RealTimeScreen(&scr_RealTimeScreen);
       UpdateSetpointsScreen1(&scr_SetpointsScreen1);
       UpdateSetpointsScreen2(&scr_SetpointsScreen2);
       UpdateInformationScreen();
       UpdateErrorScreen();
       UpdateCanBusInfoScreen();
       UpdateTxCoolMaxData();
       RefreshOutputControlStateEnableButton();
       UpdateOutputOnOffScreen();
       
       if (bkLightCounter > 0)
       {
         bkLightCounter--;
       }

#ifdef ENABLE_MIDNIGHT_RESET
       if (IsMidnight() && CONFIG.midnightReset)
       {
//          if (telemetry.status.control_autoOn) // &&
//              (!telemetry.status.control_outputEnabled || telemetry.status.control_smartShutdown))
//          {
             // Reset if the output is supposed to be on but it is currently disabled
#ifdef ENABLE_LOG
             LogMidnightReset();
#endif
             requestRemoteReset = true;
             isRemoteResetSent = 0;
//          }
       }
#endif
#ifdef ENABLE_LOG
       LogCheck();
#endif
    }

    MB_CopyStructToCoils();
    MB_CopyStructToDiscreteInputs();
    MB_CopyStructToInputRegs();
    MB_CopyStructToHoldingRegs();
    
    // Poll ModBus RS-485 port ...
    eMBPoll();
    //Delay_ms(50);
    
    // Execute Modbus call-back functions ...
    while (RS485_kbhit())
    {
       pxMBFrameCBByteReceived();
    }
    pxMBFrameCBTransmitterEmpty();

    count++;
}
// ------------------ Data Structure Initialisation ---------------------------
void InitMainStruct()
{
   telemetry.productID[0] = 0x00;
   telemetry.productID[1] = 0x00;
   telemetry.productID[2] = 0x00;
   telemetry.productID[3] = 0x00;
   telemetry.productID[4] = 0x00;
   telemetry.productID[5] = 0x00;
   telemetry.productID[6] = 0x00;
   telemetry.productID[7] = 0x00;

   telemetry.serialNumber[0] = 0x00;
   telemetry.serialNumber[1] = 0x00;
   telemetry.serialNumber[2] = 0x00;
   telemetry.serialNumber[3] = 0x00;
   telemetry.serialNumber[4] = 0x00;
   telemetry.serialNumber[5] = 0x00;
   telemetry.serialNumber[6] = 0x00;
   telemetry.serialNumber[7] = 0x00;
   
   telemetry.pvVoltage = 0.0f;
   telemetry.pvCurrent = 0.0f;
   telemetry.outputVoltage = 0.0f;
   telemetry.outputCurrent = 0.0f;
   telemetry.ocVoltage = 0.0f;
   telemetry.outputCharge = 0.0f;
   telemetry.pvPower = 0.0f;
   telemetry.batteryTemp = 0.0f;
   telemetry.time = 0;

   telemetry.status.config_factoryCRC = 0;
   telemetry.status.config_factoryCheck = 0;
   telemetry.status.config_userCRC = 0;
   telemetry.status.config_userCheck = 0;
   telemetry.status.config_eventCRC = 0;
   telemetry.status.config_eventCheck = 0;
   telemetry.status.statistics = 0;
   telemetry.status.flags = 0;
   telemetry.status.telemetry = 0;
   telemetry.status.communications = 0;
   telemetry.status.control_isSlave = 0;
   telemetry.status.control_usingBulk = 0;
   telemetry.status.control_mode = 0;
   telemetry.status.safety_operation = 0;
   telemetry.status.status = 0;

   telemetry.eventFlags.systemPower = 0;
   telemetry.eventFlags.lowOutVoltWarn = 0;
   telemetry.eventFlags.lowOutVoltFault = 0;
   telemetry.eventFlags.lowOutVoltGenSet = 0;
   telemetry.eventFlags.highOutVoltFault = 0;
   telemetry.eventFlags.highOutCurrentFault = 0;
   telemetry.eventFlags.highDischargeCurrentFault = 0;
   telemetry.eventFlags.highBatteryTempFault = 0;
   telemetry.eventFlags.inputBreakerOpen = 0;
   telemetry.eventFlags.outputBreakerOpen = 0;
   telemetry.eventFlags.tempSensorFault = 0;
   telemetry.eventFlags.negativePVCurrentSutdown = 0;
   telemetry.eventFlags.highPVCurrentShutdown = 0;
   telemetry.eventFlags.highPVVoltShutdown = 0;
   telemetry.eventFlags.highOutCurrentShutdown = 0;
   telemetry.eventFlags.highOutVoltShutdown = 0;
   telemetry.eventFlags.logFull = 0;
   telemetry.eventFlags.solarPanelMissing = 0;
   telemetry.eventFlags.configValueOutOfRange = 0;
   telemetry.eventFlags.fanFault = 0;
   telemetry.eventFlags.highHeatSinkTemp = 0;
   telemetry.eventFlags.flags = 0;
 
   userConfig_R.commsConfig.modBusAddress = 0x01;
   userConfig_R.commsConfig.canBusID = 0x600;
   userConfig_R.commsConfig.canBaudRate = 1;
   userConfig_R.commsConfig.isSlave = 0;
   
   userConfig_R.setPointsConfig.pvOcVolt = 0.0f;
   userConfig_R.setPointsConfig.pvMpVolt = 0.0f;
   userConfig_R.setPointsConfig.floatVolt = 0.0f;
   userConfig_R.setPointsConfig.bulkVolt = 0.0f;
   userConfig_R.setPointsConfig.bulkTime = 0;
   userConfig_R.setPointsConfig.bulkResetVolt = 0.0f;
   userConfig_R.setPointsConfig.tempCompensation = 0.0f;
   userConfig_R.setPointsConfig.nominalVolt = 0.0f;
 
   sysInfo.productID[0] = 0x00;
   sysInfo.productID[1] = 0x00;
   sysInfo.productID[2] = 0x00;
   sysInfo.productID[3] = 0x00;
   sysInfo.productID[4] = 0x00;
   sysInfo.productID[5] = 0x00;
   sysInfo.productID[6] = 0x00;
   sysInfo.productID[7] = 0x00;
   
   sysInfo.serialNumber[0] = 0x00;
   sysInfo.serialNumber[1] = 0x00;
   sysInfo.serialNumber[2] = 0x00;
   sysInfo.serialNumber[3] = 0x00;
   sysInfo.serialNumber[4] = 0x00;
   sysInfo.serialNumber[5] = 0x00;
   sysInfo.serialNumber[6] = 0x00;
   sysInfo.serialNumber[7] = 0x00;

   sysInfo.modelType[0] = 0x00;
   sysInfo.modelType[1] = 0x00;
   sysInfo.modelType[2] = 0x00;
   sysInfo.modelType[3] = 0x00;

   sysInfo.hwVersion[0] = 0x00;
   sysInfo.hwVersion[1] = 0x00;
   sysInfo.hwVersion[2] = 0x00;
   sysInfo.hwVersion[3] = 0x00;
   sysInfo.hwVersion[4] = 0x00;
   sysInfo.hwVersion[5] = 0x00;
   sysInfo.hwVersion[6] = 0x00;
   sysInfo.hwVersion[7] = 0x00;

   sysInfo.fwVersion[0] = 0x00;
   sysInfo.fwVersion[1] = 0x00;
   sysInfo.fwVersion[2] = 0x00;
   sysInfo.fwVersion[3] = 0x00;
   sysInfo.fwVersion[4] = 0x00;
   sysInfo.fwVersion[5] = 0x00;
   sysInfo.fwVersion[6] = 0x00;
   sysInfo.fwVersion[7] = 0x00;

   scr_SetpointsScreen1.initialised = false;
   scr_SetpointsScreen2.initialised = false;
 
   scr_CanBaseIfonScreen.modBusBaudRate = 0;
   

}
// ----------------------------------------------------------------------------




void InitDefaultData()
{
   // Initialize the Real-Time Screen ...
   Init_RealTimeScreen(&scr_RealTimeScreen);
   
   // Hardcoded default values for Live Telemetry ...

   telemetry.productID[0] = '_';
   telemetry.productID[1] = '_';
   telemetry.productID[2] = '_';
   telemetry.productID[3] = '_';
   telemetry.productID[4] = '-';
   telemetry.productID[5] = '_';
   telemetry.productID[6] = '_';
   telemetry.productID[7] = '_';

   telemetry.serialNumber[0] = '_';
   telemetry.serialNumber[1] = '_';
   telemetry.serialNumber[2] = '_';
   telemetry.serialNumber[3] = '_';
   telemetry.serialNumber[4] = '_';
   telemetry.serialNumber[5] = '_';
   telemetry.serialNumber[6] = '_';
   telemetry.serialNumber[7] = '_';

   telemetry.pvVoltage = 0.0f;
   telemetry.pvCurrent = 0.0f;
   telemetry.outputVoltage = 0.0f;
   telemetry.outputCurrent = 0.0f;
   telemetry.ocVoltage = 0.0f;
   telemetry.outputCharge = 0.0f;
   telemetry.pvPower = 0.0f;
   telemetry.batteryTemp = 0.0f;
   telemetry.time = 0;
   
   // Hardcoded default values for System Info ...
   memcpy(sysInfo.hwVersion, "_____", 5);
   memcpy(sysInfo.fwVersion, "_____", 5);
   memcpy(sysInfo.modelType, "__", 2);
   memcpy(sysInfo.productID, "________", 8);
   memcpy(sysInfo.serialNumber, "________", 8);

   // Hardcoded default values for Set-Points ...
   userConfig_R.setPointsConfig.pvOcVolt   = 0.0f;
   userConfig_R.setPointsConfig.pvMpVolt   = 0.0f;
   userConfig_R.setPointsConfig.floatVolt  = 0.0f;
   userConfig_R.setPointsConfig.bulkVolt   = 0.0f;
   userConfig_R.setPointsConfig.bulkTime   = 0;
   userConfig_R.setPointsConfig.bulkResetVolt = 0.0;
   userConfig_R.setPointsConfig.tempCompensation = 0.0f;
   userConfig_R.setPointsConfig.nominalVolt = 0.0f;
   
   curTime.hour = 0;
   curTime.min = 0;
   curTime.sec = 0;
   curTime.date = 1;
   curTime.month = 1;
   curTime.year = 13;
   
  curIntTime.sec   = 0;
  curIntTime.min   = 0;
  curIntTime.hour  = 0;
  curIntTime.date  = 1;
  curIntTime.month = 1;
  curIntTime.year  = 13;
  curIntTime.wkday = 1;
  
  lcd_time.yy = curTime.year + 2000;
  lcd_time.mo = curTime.month;
  lcd_time.md = curTime.date;
  lcd_time.hh = curTime.hour;
  lcd_time.mn = curTime.min;
  lcd_time.ss = curTime.sec;
  
  coolmax_time.yy = curTime.year + 2000;
  coolmax_time.mo = curTime.month;
  coolmax_time.md = curTime.date;
  coolmax_time.hh = curTime.hour;
  coolmax_time.mn = curTime.min;
  coolmax_time.ss = curTime.sec;
  
  
  
}

void UpdateInternalTimeDate(void) // updates internal struct with external struct data
{
  curIntTime.sec   = curTime.sec;
  curIntTime.min   = curTime.min;
  curIntTime.hour  = curTime.hour;
  curIntTime.date  = curTime.date;
  curIntTime.month = curTime.month;
  curIntTime.year  = curTime.year;
}

// ----------------------------------------------------------------------------
/*void InitDipSwitchState()
{
   DIP1_DIR = PIN_INPUT;
   DIP2_DIR = PIN_INPUT;
   DIP3_DIR = PIN_INPUT;
   DIP4_DIR = PIN_INPUT;
}*/
// ------------------------------ Main ----------------------------------------
void main(void)
{
   //int i;
   //char c;
   //char TestString[64];
   //unsigned int rxc;
   
   char count;

   eMBErrorCode eStatus;
   eMBErrorCode eStatus2;
  
   /*
   SYSKEY=0;                  // Unlock OSCCON
   SYSKEY=0xAA996655;
   SYSKEY=0x556699AA;
   OSCCONBits.PBDIV=2;        // Set new OSCCON value
   SYSKEY=0;                  // Re-lock OSCCON
   */
  
   JTAGEN_bit = 0;
   AD1PCFG = 0xFFFF;         // Configure Analog pins as digital I/O
  
   ALARM1_DIR = PIN_OUTPUT;  // temp set to input
   ALARM2_DIR = PIN_OUTPUT;

   ALARM1 = LOW;
   ALARM2 = LOW;
   
   InitBitsUSBDebug();
   InitBitsSer0_d();
   ExtRtcInit();  //Initialise External RTC
   IntRtcInit();  //Initialize Internal RTC

   InitTimer2(8192);
   //RS485_Init(9600UL, 80000UL, _UART_8BIT_NOPARITY, _UART_ONE_STOPBIT);

   // Initialiaze and Enable the Modbus Protocol Stack ...
   MB_InitRegisters();
   eStatus = eMBInit(MB_RTU, 0x01, 2, DESIRED_BAUDRATE, MB_PAR_NONE);
   eStatus2 = eMBEnable();

#ifdef ENABLE_FRAM
   FRAMInit();
#endif
   
   EnableInterrupts();

   InitUSBDebug();
   //RS485_InitRxTx();
   StartTimer2();

   for(count = 20; count > 0; count--)
   {
      printe("Start Countdown %d\r\n", (int)count);
      delay_ms(200);
      UpdateUSBBuffers();
   }
   if (eStatus != MB_ENOERR)
   {
      printe("Modbus Init: %d\r\n", (int)eStatus);
   }
   if (eStatus2 != MB_ENOERR)
   {
      printe("Modbus Enable: %d\r\n", (int)eStatus2);
   }
  
   Start_TP();
   
   ExtRtcStart();
   InitSer0_d();
   InitMainStruct();
   InitDefaultData();
   ExtGetTime(&curTime);
   UpdateInternalTimeDate();
   IntSetTime(&curIntTime);
   IntSetDate(&curIntTime);
#ifdef ENABLE_FRAM
   ConfigInit();
   ConfigRead();
#ifdef ENABLE_LOG
   LogInit();
#endif
#endif
   
   WDT_DIR = PIN_OUTPUT;
   WDT = LOW;

   TFT_BLED_Direction_ =   PIN_OUTPUT;
   TFT_BLED_ = HIGH;
   
   bkLightCounter = BACKLIGHT_TIMER_MAX;

   while(1)
   {
      // Check USB buffers for data ...
      UpdateUSBBuffers();
      WDT ^= 1;
      Delay_ms(2);
      prompt();
   }

}
// -------------------- Start ModBus Implementation ---------------------------
void MB_InitRegisters(void)
{
   // Clear all Modbus coils & registers to null characters ...
   int i = 0;
   /*for (i = 0; i < (MB_COIL_NUM / 8); i++)
   {
      mbCoilBuf[i] = 0x00;
   }*/
   for (i = 0; i < (MB_DISCRETE_NUM / 8); i++)
   {
      mbDiscreteInputBuf[i] = 0x00;
   }
   for (i = 0; i < MB_INPUT_REG_NUM; i++)
   {
      mbInputRegBuf[i] = 0x00;
   }
   for (i = 0; i < MB_HOLDING_REG_NUM; i++)
   {
      mbHoldingRegBuf[i] = 0x00;
   }
}
// ----------------------------------------------------------------------------
void MB_CopyStructToCoils(void)
{
   return;       // There is no data to copy to coils
}
// ----------------------------------------------------------------------------
void MB_CopyStructToDiscreteInputs(void)
{
   // Copy struct data to single-bit Discrete Inputs (read-only) ...
   int size = sizeof(telemetry.eventFlags);
   memcpy(&mbDiscreteInputBuf[0], &(telemetry.eventFlags.flags), size);
   memcpy(&mbDiscreteInputBuf[size], &(telemetry.status.status), sizeof(telemetry.status));
}
// ----------------------------------------------------------------------------
void MB_CopyStructToInputRegs(void)
{
    // Copy struct data to 16-bit (USHORT) Input Registers (read-only) ...
    memcpy(&mbInputRegBuf[0], &telemetry.bytes[0], sizeof(telemetry));
    memcpy(&mbInputRegBuf[40], &sysinfo.bytes[0], sizeof(sysInfo));
    
    // TODO : Add Factory Calibration settings into Read-Only registers ******
}
// ----------------------------------------------------------------------------
void MB_CopyStructToHoldingRegs(void)
{
   return;           // TODO : Implement copy data to Holding Registers
}
// ----------------------- Modbus Callback Functions --------------------------
eMBErrorCode eMBRegCoilsCB(UCHAR * pucRegBuffer, USHORT usAddress,
                           USHORT usNCoils, eMBRegisterMode eMode)
{
   eMBErrorCode eStatus = MB_ENOERR;
   
   int index = 0;
   index = (int)(usAddress - MB_COIL_START);
   
   if((index >= 0) && (index <= MB_COIL_NUM - usNCoils))
   {
       if (eMode == MB_REG_READ)
       {
           // TODO : Read Coils
       }
       else if (eMode == MB_REG_WRITE)
       {
          // TODO : Write Coils
       }
   }
   else
   {
      eStatus = MB_ENOREG;
      printe(" MB Coil Status: %d\r\n", (int)eStatus);
   }
   return eStatus;
}
// ----------------------------------------------------------------------------
eMBErrorCode eMBRegDiscreteCB(UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNDiscrete)
{
   eMBErrorCode eStatus = MB_ENOERR;
   
   int index = 0;
   index = (int)(usAddress - MB_DISCRETE_START); // Index number in discrete inputs
   
   if((index >= 0) && (index <= MB_DISCRETE_NUM - usNDiscrete))
   {
       while(usNDiscrete > 0)
       {
          if (usNDiscrete >= 8)
          {
             *pucRegBuffer++ = xMBUtilGetBits(mbDiscreteInputBuf, index, 8);
             index += 8;
             usNDiscrete -= 8;
          }
          else
          {
             *pucRegBuffer++ = xMBUtilGetBits(mbDiscreteInputBuf, index, usNDiscrete);
             index += usNDiscrete;
             usNDiscrete -= usNDiscrete;
          }
       }
   }
   else
   {
      eStatus = MB_ENOREG;
      printe(" MB Discrete Status: %d\r\n", (int)eStatus);
   }
   return eStatus;
}
// ----------------------------------------------------------------------------
eMBErrorCode eMBRegInputCB(UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNRegs)
{
    eMBErrorCode eStatus = MB_ENOERR;
    
    int index = 0;
    index = (int)(usAddress - MB_INPUT_REG_START);

    if((index >= 0) && (index <= MB_INPUT_REG_NUM - usNRegs))
    {
       while(usNRegs > 0)
       {
          *pucRegBuffer++ = (unsigned char)(mbInputRegBuf[index] >> 8);
          *pucRegBuffer++ = (unsigned char)(mbInputRegBuf[index] & 0xFF);
          index++;
          usNRegs--;
       }
   }
   else
   {
      eStatus = MB_ENOREG;
      printe(" MB Input Status: %d\r\n", (int)eStatus);
   }
   return eStatus;
}
// ----------------------------------------------------------------------------
eMBErrorCode eMBRegHoldingCB(UCHAR * pucRegBuffer, USHORT usAddress,
                             USHORT usNRegs, eMBRegisterMode eMode)
{
   eMBErrorCode eStatus = MB_ENOERR;
   
   int index = 0;
   index = (int)(usAddress - MB_HOLDING_REG_START); // Index number in Holding Registers
   
   if((index >= 0) && (index <= MB_HOLDING_REG_NUM - usNRegs))
   {
       if (eMode == MB_REG_READ)
       {
          // TODO : Read Holding Registers
          //        (Set-Points Config, Events Config & Comms Settings)
       }
       else if (eMode == MB_REG_WRITE)
       {
          // TODO : Write Holding Registers
          //        (Set-Points Config, Events Config & Comms Settings)
       }
   }
   else
   {
      eStatus = MB_ENOREG;
      printe(" MB Holding Status: %d\r\n", (int)eStatus);
   }
   return eStatus;
}
// ----------------------------------------------------------------------------
// End Of File (main.c)
// ----------------------------------------------------------------------------