#include <stdarg.h>

#include "general.h" 
#include "cmdlib.h"     
#include "cmdproc.h"
#include "debug.h"
#include "crc16.h"

#define NULL (void*) 0
#define NULL_STR_PTR 0

#define maxTempStr 255
#define maxCommandLen 64

char *paramList;      
char commandLine[maxCommandLen + 1];
char lastCommandLine[5][maxCommandLen + 1];
int lastCommandLineIdx = 0;
char tmpLastCommandLine[maxCommandLen + 1];

void execCommand(); 
char *field(char *str, char ch); 
void strupr(char *str);            

int CtrlBreak = false;
unsigned int inMainEventFlag = false;

char tempStr[maxTempStr];
int tempIdx = 0;

void PRINT(char c){

  putChar(c);

}

void PRINTS(char c)
{
    if (tempIdx >= (maxTempStr-20)) return;
    tempStr[tempIdx] = c;
    tempIdx++;
    tempStr[tempIdx] = 0x00;
}



//***************************************************
/* Useful library functions */                       
//***************************************************

void initCommandLine(void)
{
  strncpy(&(lastCommandLine[0][0]),"TEST",maxCommandLen);
  strncpy(&(lastCommandLine[1][0]),"VER",maxCommandLen);
  strncpy(&(lastCommandLine[2][0]),"TEST",maxCommandLen);
  strncpy(&(lastCommandLine[3][0]),"VER",maxCommandLen);
  strncpy(&(lastCommandLine[4][0]),"TEST",maxCommandLen);
  
}

/********************************************************************
 *        Name                : printp
 *        Description        : This a printf equivalent use to send a string com port with and also send a  prompt (" >") after each new line.
 *        Inputs                : format - the format string
 *                        ... - variable parameter list
 *        Outputs                : None
 *        Return Value: None
 *        Side Effects: None
 ********************************************************************/
void printp(char flash *format, ...)
{
        va_list param;
        int len; 
        int tmplen;        
        int i;
        unsigned char crcA;
        unsigned char crcB;  
                       
        if (inMainEventFlag == false)  //stop recursion
        {
           MainEvent();
        }
        
        if ((prevSentChar[0] == '\n') ||  (prevSentChar[0] == '\r'))           
        {
                putString("> ");
        }           
        else
        {
                if ((prevSentChar[0] == ' ') && (prevSentChar[1] == '>') && ((prevSentChar[2] == '\n') || (prevSentChar[2] == '\r')))
                {
                
                }   
        }         
        
        va_start(param, format);
        tempIdx = 0;
        tempStr[tempIdx] = 0x00;
        _doprntout(PRINTS, format, param);

//        vsprintf(tempStr, maxTempStr - 20, format, param);
//        va_end(param);

        tempStr[maxTempStr-1] = 0x00;
        len =  strlen(tempStr);
        if ( (len > 2) && (len < (maxTempStr - 20)) )    
        {
                if ((tempStr[len-2] == '\r') && (tempStr[len-1] == '\n'))
                {
                        for(i=0;i<len;i++)
                        {
                                if (tempStr[i] == '#') break;
                        }
                        tmplen = len - i;
                        if (tmplen > 2)
                        {                    
                                CalculateCRC16((unsigned char*) &tempStr[i],tmplen,false,0x00);
                                crcA = tempStr[len-2];
                                crcB = tempStr[len-1];
                                sprintf(&tempStr[len-2],"\t@%02X%02X\r\n> ",(unsigned int) crcA, (unsigned int) crcB);
                        }
                }                
        }                        
        tempStr[maxTempStr-1] = 0x00;
        
        for(i=0;i<maxTempStr;i++)
        {
                if (tempStr[i] == 0x00) break;
                putchar(tempStr[i]);
        }
        
        
        
}


/********************************************************************
 *        Name                : printf
 *        Description        : Output
 *        Inputs                :
 *                        format - the format string
 *                        ... - variable parameter list
 *        Outputs                : None
 *        Return Value: None
 *        Side Effects: None
 ********************************************************************/
void printf(char flash *format, ...)
{
    va_list param;
    int len;

    va_start(param, format);
    if(strlen(format) < (maxTempStr - 50)) {
        _doprntout(PRINT, format, param);
    } else
        putString("ERROR : PrintD String array overflow\r\n> ");
}


/********************************************************************
 *        Name                : printd
 *        Description        : Debug output (with detail) according to the mode
 *        Inputs                : mode - the amount of detail
 *                        format - the format string
 *                        ... - variable parameter list
 *        Outputs                : None
 *        Return Value: None
 *        Side Effects: None
 ********************************************************************/
void printd(char flash *format, ...)
{

#ifdef DEBUG

        va_list param;
        int len;

         
          
                if ((prevSentChar[0] == '\n')  ||  (prevSentChar[0] == '\r'))
                {
                        putString("> DEBUG : ");
                }           
                else
                {
                        if ((prevSentChar[0] == ' ') && (prevSentChar[1] == '>') && ((prevSentChar[2] == '\n') || (prevSentChar[2] == '\r')))
                        {
                                putString("DEBUG : ");
                        }   
                }
           
                va_start(param, format);
                if(strlen(format) < (maxTempStr - 50)) {
                
                        //vprintf(format, param);
                        _doprntout(PRINT, format, param);
                        
                        len =  strlen(format);
                        if (len > 0)
                        {
                                if ((format[len-1] == '\r') || (format[len-1] == '\n'))
                                {
                                        putString("> ");
                                }
                        }                      
                } else  
                        putString("ERROR : PrintD String array overflow\r\n> ");
                //va_end(param);

#endif
        
}

/********************************************************************
 *        Name                : printe
 *        Description        : Error output 
 *        Inputs                :
 *                        format - the format string
 *                        ... - variable parameter list
 *        Outputs                : None
 *        Return Value: None
 *        Side Effects: None
 ********************************************************************/
void printe(char flash *format, ...)
{
        va_list param;
        int len;

         
          
                if ((prevSentChar[0] == '\n')        ||  (prevSentChar[0] == '\r'))           
                {
                        putString("> ERROR : ");
                }           
                else
                {
                        if ((prevSentChar[0] == ' ') && (prevSentChar[1] == '>') && ((prevSentChar[2] == '\n') || (prevSentChar[2] == '\r')))
                        {
                                putString("ERROR : ");
                        }   
                }
           
                va_start(param, format);
                if(strlen(format) < (maxTempStr - 50)) {
                        
                        //vprintf(format, param);
                        _doprntout(PRINT, format, param);
                        
                        len =  strlen(format);
                        if (len > 0)
                        {
                                if ((format[len-1] == '\r') || (format[len-1] == '\n'))
                                {
                                        putString("> ");
                                }
                        }                      
                } else  
                        putString("ERROR : PrintD String array overflow\r\n> ");
                //va_end(param);
        
}


int isZero(char *str)
{
        while(*str) {
                if (! ((*str == '0') || (*str == '.') || (*str == '+') || (*str == '-')) )
                {
                        return false;
                }
                str++;        
        }
                                     
        return true;
}

int isEmpty(char *str)
{
        while(*str) {
                if (*str != ' ')
                {
                        return false;
                }        
                str++;
        }
                                     
        return true;
}

int GetDoubleParam(double *val,char * str)
{                             
        double dd;
        
        if ((str != (char *) NULL_STR_PTR) && (*str != 0x00)) 
        {   
                if (isEmpty(str) == false)  
                {       
                        dd = atof(str);
                        if ((dd < 1E-8) && (dd > -1E-8))  //If zero
                        {                                          
                                if (isZero(str) == false)
                                {
                                        return false;
                                }    
                                
                        }
                        *val = dd;
                }                      
        } 
        
        return true;      
} 


/********************************************************************
 *        Name                : getParam
 *        Description        : Parse to extract all the parameters requested
 *        Inputs                : format - the format string indicating typedefs of the variables to extract.
 *                                b = unsigned byte
 *                                    d = signed short int
 *                                     u =  unsigned short int
 *                                     l = long int
 *                                     s = string started or terminated with spaces or if containing spaces double quotes ("")
 *                                     t = enumerated type (Invalid or Unknown enunerated types will raise a sys log error)
 *                        ... - variable parameter list
 *        Outputs                : None
 *        Return Value: None
 *        Side Effects: Various globals are modified.
 ********************************************************************/
void getParam(char flash *format, ...)
{       
        double vald;   
        int ret;
        char *opt1;
        unsigned char flag, setFlag;
        va_list param;
        void *vaptr;
 
        if(!paramList || !format) return;
                
        va_start(param, format);
        
        while(*format && *paramList) {
                while((*paramList <= ' ') && *paramList) paramList++; /* Skip any other blanks */
                if(!*paramList) break;

                opt1 = field(paramList, ' ');
                setFlag = (*paramList != '?');  
                
                
                switch(*(format++)) {
                        
                        case 'b':
                                vaptr = va_arg(param, unsigned char *);
                                if ((setFlag) && (vaptr != NULL))   
                                {     
                                        ret = GetDoubleParam(&vald,paramList);
                                        if (ret)
                                        {       
                                                if (vald > 255.0)
                                                {
                                                        vald = 255.0;
                                                }
                                                if (vald < 0.0)
                                                {
                                                        vald = 0.0;
                                                }
                                                *( (unsigned char *) vaptr) = (unsigned char) vald;
                                        }
                                }
                                break; 
                        case 'd':  
                                vaptr = va_arg(param, int *);
                                if ((setFlag) && (vaptr != NULL))   
                                {     
                                        ret = GetDoubleParam(&vald,paramList);
                                        if (ret)
                                        {       
                                                if (vald > 32767.0)
                                                {
                                                        vald = 32767.0;
                                                }
                                                if (vald < -32767.0)
                                                {
                                                        vald = -32767.0;
                                                }
                                                *( (int *) vaptr) = (int) vald;
                                        }
                                }
                                break; 
                        case 'u': 
                                vaptr = va_arg(param, unsigned int *);
                                if ((setFlag) && (vaptr != NULL))   
                                {     
                                        ret = GetDoubleParam(&vald,paramList);
                                        if (ret)
                                        {       
                                                if (vald > 65535.0)
                                                {
                                                        vald = 65535.0;
                                                }
                                                if (vald < 0.0)
                                                {
                                                        vald = 0.0;
                                                }
                                                *( (unsigned int *) vaptr) = (unsigned int) vald;
                                        }
                                }
                                break; 
                        case 'l':
                                vaptr = va_arg(param, long *);
                                if ((setFlag) && (vaptr != NULL))
                                {
                                        ret = GetDoubleParam(&vald,paramList);
                                        if (ret)
                                        {       
                                                if (vald > 2147483647.0)
                                                {
                                                        vald = 2147483647.0;
                                                }
                                                if (vald < -2147483647.0)
                                                {
                                                        vald = -2147483647.0;
                                                }
                                                *( (long *) vaptr) = (long) vald;
                                        }
                                }
                                break;
                        case 'f':
                                vaptr = va_arg(param, double *);
                                if ((setFlag) && (vaptr != NULL))   
                                {     
                                        ret = GetDoubleParam(&vald,paramList);
                                        if (ret)
                                        {       
                                                *( (double *) vaptr) = vald;
                                        }
                                }
                                break;                                                           
                        case 's':
                                vaptr = va_arg(param, char **);   
                                
                                if ((setFlag) && (vaptr != NULL))
                                {                                                                        
                                        flag = false;
                                        if(*paramList == '\"') {
                                                paramList++;
                                                flag = true;
                                        }
                                                                                             
                                        *( (char **) vaptr) = paramList;
                                         
                                        for(; *paramList && (*paramList != (flag ? '\"' : ' ')); paramList++);
                                        *paramList = (char)0;                      
                                        
                                }
                                break;          
                }
                paramList = opt1;

        }
        
        //va_end(param);

}




/********************************************************************
 *        Name                : instr
 *        Description        : Find a particular character within a string
 *        Inputs                : str - the string to be searched
 *                          ch - the character to search for
 *        Outputs                : None
 *        Return Value: Pointer to the character within the string, 
 *                        or 0 if no such character is found
 *        Comments:
 *                Searching for a null character will always return 0 (not found), since
 *                this is the ASCIIZ string terminator 
 ********************************************************************/
char *instr(char *str, char ch)
{
        if(!*str) return (char *) NULL_STR_PTR;
        while(*str && (*str != ch))
                str++;

        if(*str)
                return (str);
        else
                return (char *) NULL_STR_PTR;
}


/********************************************************************
 *        Name                : field
 *        Description        : Find a character delimited field within a string
 *        Inputs                : str - the string to be searched
 *                          ch - the character delimiting fields
 *        Outputs                : None
 *        Return Value: Pointer to the start of the string, 
 *                        or to the next field in the string
 *        Side Effects: The original string will get split up.
 *
 ********************************************************************/
char *field(char *str, char ch)
{
        unsigned char flag;

        if(!*str) return (char *) NULL_STR_PTR;
        for(flag = false; *str && (flag || (*str != ch)); str++)
        if(*str == '\"') flag = !flag;

        if(*str) {
                *str = (char)0;
                return(++str);
        } else
                return(str);
}


/********************************************************************
 *        Name                : ltrim
 *        Description        : Used for stripping leading blanks
 *        Inputs                : str - the string to be stripped
 *        Outputs                : None
 *        Return Value: None
 *        Side Effects: The original string will get stripped.
 *
 ********************************************************************/
/* Strip all characters up to the first valid alphanumeric character in a string.*/
/* Strip all characters up to the first valid alphanumeric character in a string.*/
void ltrim(char *str)
{
        unsigned char flag = false;
        char *str1;
        str1  = str;
        while(*str) {
                if(!flag && (*str > ' ') && (*str < 127))
                        flag = true;
                if(flag)
                        *(str1++) = *str;
                str++;
        }
        *str1 = *str;
}

/********************************************************************
 *        Name                : strupr
 *        Description        : Used for Uppercasing a string
 *        Inputs                : str - the string to be uppercased
 *        Outputs                : None
 *        Return Value: None
 *        Side Effects: The original string will get uppercased
 *
 ********************************************************************/
/* Strip all characters up to the first valid alphanumeric character in a string.*/
void strupr(char *str)
{
        char *str1;
        str1 = str;
        while(*str) {
                *(str1++) = toupper(*str);
                str++;
        }
        *str1 = *str;
}

char xgetche()
{
        char ch;  
        
        UpdateUSBBuffers();

        if (kbhit()) 
        {
                
        ch = getchar();
        
                if(ch == 13)
                {                
                        sendChar(13);
                        sendChar(10);
                }
                else
                {           
                    if ( (ch == 10) || (ch == 0x1b) || (ch == '~') || ( (ch == '[') && (prevSentChar[0] == 0x1b) ) || ( (prevSentChar[1] == 0x1b) && (prevSentChar[0] == '[') ) )
                    {
                      //Do not echo character 
                    }
                    else
                    {                    
                        sendChar(ch);
                    }
                }  
        
                prevSentChar[3] = prevSentChar[2];
                prevSentChar[2] = prevSentChar[1];
                prevSentChar[1] = prevSentChar[0];
                prevSentChar[0] = ch;
        
                return(ch);        
        }

        do {
                UpdateUSBBuffers();
                MainEvent();
        
        } while(!kbhit());
    
        ch = getchar();
        if(ch == 13)
        {
                sendChar(13);
                sendChar(10);
        }
        else
        {       
                if ( (ch == 10) || (ch == 0x1b) || ( (ch == '[') && (prevSentChar[0] == 0x1b) ) || ( (prevSentChar[1] == 0x1b) && (prevSentChar[0] == '[') ) )
               {
                 //Do not echo character 
               }
               else
               {                     
                   sendChar(ch);
               }
        }  
  
        prevSentChar[3] = prevSentChar[2];
        prevSentChar[2] = prevSentChar[1];
        prevSentChar[1] = prevSentChar[0];
        prevSentChar[0] = ch;

        return(ch);
}


void getLine()
{
        char *pos, ch;
        unsigned char len;
        int i;
        char lastchar[3];
        char overchar[2];
        int idx;
        
        pos = commandLine;
        
        len = 0;
        overchar[0] = 0x00;
        overchar[1] = 0x00;
        idx = lastCommandLineIdx;
        
        do {
                ch = xgetche();
        
                lastchar[2] = lastchar[1];
                lastchar[1] = lastchar[0];
                lastchar[0] = ch;
                if(ch == 3) { /* Check for Ctrl-Brk */    
                        CtrlBreak = true;
                        *commandLine = 0;
                        return;
                }
    
                switch(ch) {
                        case 13: /* CR */                                
                                for (i=0;i<len;i++)
                                {
                                        if (commandLine[i] == 0x00)
                                        {
                                                commandLine[i] = ' ';
                                        }
                                }
                                commandLine[len] = 0x00;
                                return;
                        case 8: /* Backspace */
                                if(len > 0) {
                                        len--;
                                        *pos = 0x00;
                                        pos--;
                                }
                                sendChar(0x1b);
                                sendChar('[');
                                sendChar('K');
                                break;                                                        
                        default: /* Other valid alphanumeric keys */
                                if((len < maxCommandLen) && (ch >= 32) && (ch <= 126)  && (ch != '~') ) {                                                                                                                                                                
                                        overchar[1] = overchar[0];
                                        overchar[0] = *pos;
                                        *(pos++) = ch;
                                        len++;
                                }
                }
                
                if ( (lastchar[2] == 0x1b) && (lastchar[1] == '[') && (lastchar[0] == 'A'))
                {                
                        sendChar(0x1b);
                        sendChar('[');
                        sendChar('2');
                        sendChar('K');
                        sendChar('\r');
                        sendChar('>');
                        sendChar(' ');
                        pos = commandLine;
                        memset(commandLine,0x00,(unsigned int) maxCommandLen);
                        len = 0;                                                                        
                        if (idx > 0)        
                        {
                                idx--;
                        }
                        else
                        {
                                idx = 4;
                        }                                
                        for(i=0;i<strlen(&(lastCommandLine[idx][0]));i++)                                        
                        {
                                ch = lastCommandLine[idx][i];                                                                                                        
                                overchar[1] = overchar[0];
                                overchar[0] = *pos;
                                *(pos++) = ch;
                                sendChar(ch);
                                len++;
                        }                                                        
                        
                }
                
                if ( (lastchar[2] == 0x1b) && (lastchar[1] == '[') && (lastchar[0] == 'B'))
                {                        
                        sendChar(0x1b);
                        sendChar('[');
                        sendChar('2');
                        sendChar('K');
                        sendChar('\r');
                        sendChar('>');
                        sendChar(' ');
                        pos = commandLine;
                        memset(commandLine,0x00,(unsigned int) maxCommandLen);
                        len = 0;
                        idx = (idx+1) % 5;                        
                        for(i=0;i<strlen(&(lastCommandLine[idx][0]));i++)                                        
                        {
                                ch = lastCommandLine[idx][i];                                                                                                        
                                overchar[1] = overchar[0];
                                overchar[0] = *pos;
                                *(pos++) = ch;
                                sendChar(ch);                                
                                len++;
                        }                
                        
                }
                
                /* Home Key */
                
                if ( (lastchar[2] == 0x1b) && (lastchar[1] == '[') && (lastchar[0] == '2'))
                {                        
                        sendChar(0x1b);
                        sendChar('[');
                        sendChar('2');
                        sendChar('K');
                        sendChar('\r');
                        sendChar('>');
                        sendChar(' ');
                        pos = commandLine;
                        memset(commandLine,0x00,(unsigned int) maxCommandLen);
                        len = 0;        
                        idx = lastCommandLineIdx;                        
                }
                
                /* Complete left and right arrows */
                
                if ( (lastchar[2] == 0x1b) && (lastchar[1] == '[') && (lastchar[0] == 'D'))
                {
                        if(len > 2) 
                        {                
                                sendChar(0x1b);
                                sendChar('[');
                                sendChar('D');                                
                                len-=2;
                                pos-=3;                        
                                *(pos+1) = overchar[1];                                
                                *(pos+2) = overchar[0];                                                                
                        }
                }
                
                
                if ( (lastchar[2] == 0x1b) && (lastchar[1] == '[') && (lastchar[0] == 'C'))
                {                        
                        sendChar(0x1b);
                        sendChar('[');
                        sendChar('C');
                        len-=2;
                        pos-=1;                        
                        *(pos-1) = overchar[1];                                
                        *(pos) = overchar[0];                                                        
                }
                
                
        } while(true);
}

/********************************************************************
 *        Name                : prompt
 *        Description        : Display the prompt. (> )
 *                        Wait for and then execute a command
 *        Inputs                : None
 *        Outputs                : None
 *        Return Value: None
 *        Side Effects: Global "commandLine","paramList" is modified. (hardcoded)
 *        History                : 28-Jan-2008 (PD)
 *                        Function header and comments.
 ********************************************************************/
void prompt()
{
        if (!((prevSentChar[0] == ' ') && (prevSentChar[1] == '>')))
        {
                putString("> ");
        }

        
        getLine();
        

        
        ltrim(commandLine);
        strncpy(tmpLastCommandLine,commandLine,(int) maxCommandLen);
        paramList = instr(commandLine, ' ');       
                
        if (paramList != (char *) NULL_STR_PTR) {
                *paramList = (char)0;
                paramList++;
        } else    
        {
                paramList = (char *) NULL_STR_PTR; 
        }        
                
        strupr(commandLine);
        
        if (commandLine[0] == '>')
        {
                commandLine[1] = (char) 0;
        }  
        
        CtrlCReceived = false;
        
        execCommand();
}

/********************************************************************
 *        Name                : execCommand
 *        Description        : Execute the command that corresponds to the string in "commandLine"
 *                             this is done by Looking up the function to execute in the commandList table thats index matches the string in "commandLine"
 *        Inputs                : None
 *        Outputs                : None
 *        Return Value: None
 *        Side Effects: Depends on command being executed.
 *        History                : 28-Jan-2008 (PD)
 *                        Function header and comments.
 ********************************************************************/
void execCommand()
{
        unsigned char no, flag;
        int i;
        int idx;        
        int idx_1;    
        

        if(!*commandLine) return; /* Do nothing if <Enter> pressed */

        no = commandNo;
        flag = true;
        
        while(no--)
        if(!strcmp(commandLine, commandList[no].name)) {
                idx = -1;
                for(i=0;i<5;i++)
                {
                        //Check if command already used in last command array
                        if (strcmp(tmpLastCommandLine, &(lastCommandLine[i][0])) == 0)
                        {
                                idx = i;
                                break;
                        }
                }
                if (idx != -1)                
                {                        
                        // Shuffle and resort lastCommandLine array based on re-used entry
                        for(i=0;i<5;i++)
                        {
                                idx_1 = (idx+1) % 5;
                                if (idx_1 == lastCommandLineIdx)
                                {
                                        break;
                                }
                                strncpy(&(lastCommandLine[idx][0]),&(lastCommandLine[idx_1][0]),(int) maxCommandLen);        
                                idx = (idx+1) % 5;                                                                
                        }
                        lastCommandLineIdx = idx;
                }
                strncpy(&(lastCommandLine[lastCommandLineIdx][0]),tmpLastCommandLine,(int) maxCommandLen);                                        
                lastCommandLineIdx =(lastCommandLineIdx+1) % 5;        
                                                
                flag = false;  
                                                
                if(commandList[no].func)
                        commandList[no].func();
                break;
        }
        if(flag)
        {
                putString("#ERROR:Unknown Command: \"");
                putString(commandLine);
                putString("\"\r\n");
        }
}