#include "general.h"
#include "cmdlib.h"
#include "localConfig.h"
#include "fram.h"
#include "crc16.h"

const unsigned int CONFIG_CRC_SIZE = 2;
const unsigned int CONFIG_SIZE = sizeof(Config) + CONFIG_CRC_SIZE;
const unsigned int CONFIG_READ_ATTEMPTS = 2;
const unsigned int CONFIG_WRITE_ATTEMPTS = 2;
const unsigned long CONFIG_ADDR = 0;

unsigned char configTempBuffer[CONFIG_SIZE];

LocalConfig CONFIG;

void ConfigSetDefaults()
{
   CONFIG.midnightReset = 0;
   CONFIG.dailyCharge = 0;
   CONFIG.totalCharge = 0;
}

void ConfigInit()
{
   memset(&CONFIG, 0, sizeof(LocalConfig));
}

int ConfigRead()
{
    int attempt = 0;

    while (attempt < CONFIG_READ_ATTEMPTS)
    {
        if (!FRAMReadBuffer(CONFIG_ADDR, configTempBuffer, CONFIG_SIZE))
        {
            return false;
        }

        if (CalculateCRC16(configTempBuffer, CONFIG_SIZE, true, 0x00) == 2)
        {
            memcpy(&CONFIG, configTempBuffer, sizeof(Config));
            
            // This data might be invalid so try to reset any bad values
            if (CONFIG.dailyCharge < 0 || CONFIG.dailyCharge > 10000.0f ||
                CONFIG.totalCharge < 0 || CONFIG.totalCharge > 10000000.0f)
            {
                unsigned char* ptr = (unsigned char*) &CONFIG;
                int i;
                unsigned char mr = CONFIG.midnightReset;

                ptr[0] = 0;
                CONFIG.midnightReset = mr;
                ptr[1] = 0;
                ptr[2] = 0;
                ptr[3] = 0;
                CONFIG.dailyCharge = 0.0f;
                CONFIG.totalCharge = 0.0f;
                for (i=0; i<20; i++)
                {
                    CONFIG.spare[i] = 0;
                }
            }

            return true;
        }
        else
        {
            attempt++;
        }
    }
    
    ConfigSetDefaults();
    
    return false;
}

int ConfigWrite()
{
    int attempt = 0;

    while (attempt < CONFIG_WRITE_ATTEMPTS)
    {
        memcpy(configTempBuffer, &CONFIG, sizeof(Config));
        CalculateCRC16(configTempBuffer, CONFIG_SIZE, false, 0x00);
        
        if (!FRAMWriteBuffer(CONFIG_ADDR, configTempBuffer, CONFIG_SIZE))
        {
            return false;
        }
        
        // Verify
        if (!FRAMReadBuffer(CONFIG_ADDR, configTempBuffer, CONFIG_SIZE))
        {
            return false;
        }
        if (CalculateCRC16(configTempBuffer, CONFIG_SIZE, true, 0x00) == 2)
        {
            return true;
        }

        attempt++;
    }
    return false;
}

int ConfigReset()
{
    ConfigSetDefaults();
    return ConfigWrite();
}

int ConfigResetCharge()
{
    CONFIG.dailyCharge = 0;
    CONFIG.totalCharge = 0;
    return ConfigWrite();
}