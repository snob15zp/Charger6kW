#include "scr_RealTimeScreen.h"
#include "scr_SplashScreen.h"
#include "scr_MainMenuScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "scr_InformationScreen.h"
#include "scr_ErrorScreen.h"
#include "scr_SettingsMenuScreen.h"
#include "scr_OutputOnOffScreen.h"
#include "protocol.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"
#include "externalRtc.h"
#include "rtc.h"
#include "localConfig.h"

extern TScreen*  CurrentScreen;
extern Tscreen* PreviousScreen;

scr_RealTimeScreen_Type scr_RealTimeScreen;
//telemetry_t pic32_telem;


void Init_RealTimeScreen(scr_RealTimeScreen_Type *screen)
{
     if (CurrentScreen != &RealTimeScreen)
     {

        ClearLbl(&lbl_RealTimeScreen_FirmwareVersion,CL_BLACK);
        TFT_Set_Font(lbl_RealTimeScreen_FirmwareVersion.FontName, CL_WHITE, FO_HORIZONTAL);
        strncpy(lbl_RealTimeScreen_FirmwareVersion.Caption, VERSION, 5);
        lbl_RealTimeScreen_FirmwareVersion.Caption[5] = 0x00;
        TFT_Write_Text(lbl_RealTimeScreen_FirmwareVersion.Caption, lbl_RealTimeScreen_FirmwareVersion.Left, lbl_RealTimeScreen_FirmwareVersion.Top);
        
        PreviousScreen = CurrentScreen;
        DrawScreen(&RealTimeScreen);
        
     }

}

void Update_RealTimeScreen(scr_RealTimeScreen_Type *screen)   //passing pointer to struct.
{
     char pvVolts[MAX_SIZE];    // local variables only
     char pvAmps[MAX_SIZE];
     char chVolts[MAX_SIZE];
     char chAmps[MAX_SIZE];
     char outCharge[MAX_SIZE];
     char ocVolt[MAX_SIZE];
     char pvPower[MAX_SIZE];
     char batTemp[MAX_SIZE];
     char batTempName[18+1];
     char date[MAX_SIZE];
     char firmVer[5];
     
     int len = 0;
     
     GetRealtimeMainStruct();
     
     if (CurrentScreen == &RealTimeScreen)
     {
        DispTelemetryTime(&curIntTime);
        DispTelemetryDate(&curIntTime);
        DispNotifactions();
     
        ClearLbl(&lbl_RealTimeScreenPvVolts_Value,boxRound_RealTimeScreenPvVolts.Color);
        sprintf(pvVolts,"%5.1f V", Screen->PVVolts); // writing what is in Screen struct into local variable
        DrawLbl(&lbl_RealTimeScreenPvVolts_Value, pvVolts, 8);
        //printd("Label='%s'\r\n",pvVolts); //prints out debug information
        
        ClearLbl(&lbl_RealTimeScreenChrgVolts_Value,boxRound_RealTimeScreenChrgVolts.Color);
        sprintf(chVolts,"%5.1f V", Screen->ChrgVolts);
        DrawLbl(&lbl_RealTimeScreenChrgVolts_Value, chVolts, 8);
        //printd("Label='%s'\r\n",chVolts); //prints out debug information
        
        UpdateBatteryStatus();
        
        if ((telemetry.status.control_outputEnabled == 0) && (telemetry.status.control_smartShutdown == 0) || (ReadOutputState == Output_SHUTDOWN))
        {
            ClearLbl(&lbl_RealTimeScreenPvAmps_Value,boxRound_RealTimeScreenPvAmps.Color);
            sprintf(pvAmps,"  OFF");
            DrawLbl(&lbl_RealTimeScreenPvAmps_Value, pvAmps, 8);
            //printd("Label='%s'\r\n",pvAmps); //prints out debug information

            ClearLbl(&lbl_RealTimeScreenChrgAmps_Value,boxRound_RealTimeScreenChrgAmps.Color);
            sprintf(chAmps,"  OFF");
            DrawLbl(&lbl_RealTimeScreenChrgAmps_Value, chAmps, 8);
            
            ClearLbl(&lbl_RealTimeScreenDailyOc_Value,boxRound_RealTimeScreen_BackgroundPanel.Color);
            sprintf(outCharge,"(OFF)");
            DrawLbl(&lbl_RealTimeScreenDailyOc_Value, outCharge, 6);

            ClearLbl(&lbl_RealTimeScreenPvPower_Value,boxRound_RealTimeScreen_BackgroundPanel.Color);   // was overflowing when values went into thousands, changed to one decimal place in V1.2
            sprintf(pvPower,"000 W");
            DrawLbl(&lbl_RealTimeScreenPvPower_Value, pvPower, 10);
            
        }
        else
        {
            if ((telemetry.status.control_outputEnabled == 1) && (telemetry.status.control_smartShutdown == 1))
            {
            ClearLbl(&lbl_RealTimeScreenPvAmps_Value,boxRound_RealTimeScreenPvAmps.Color);
            sprintf(pvAmps," 0 A");
            DrawLbl(&lbl_RealTimeScreenPvAmps_Value, pvAmps, 8);
            //printd("Label='%s'\r\n",pvAmps); //prints out debug information

            ClearLbl(&lbl_RealTimeScreenChrgAmps_Value,boxRound_RealTimeScreenChrgAmps.Color);
            sprintf(chAmps," 0 A");
            DrawLbl(&lbl_RealTimeScreenChrgAmps_Value, chAmps, 8);

            ClearLbl(&lbl_RealTimeScreenDailyOc_Value,boxRound_RealTimeScreen_BackgroundPanel.Color);
            sprintf(outCharge,"(0.0)");
            DrawLbl(&lbl_RealTimeScreenDailyOc_Value, outCharge, 6);

            ClearLbl(&lbl_RealTimeScreenPvPower_Value,boxRound_RealTimeScreen_BackgroundPanel.Color);   // was overflowing when values went into thousands, changed to one decimal place in V1.2
            sprintf(pvPower,"000 W");
            DrawLbl(&lbl_RealTimeScreenPvPower_Value, pvPower, 10);
                        
            }
            else
            {
                    if ((telemetry.status.control_outputEnabled == 0) && (telemetry.status.control_smartShutdown == 1))   //G3 Ground Fault condition
                    {
                            ClearLbl(&lbl_RealTimeScreenPvAmps_Value,boxRound_RealTimeScreenPvAmps.Color);
                            sprintf(pvAmps," 0 A");
                            DrawLbl(&lbl_RealTimeScreenPvAmps_Value, pvAmps, 8);
                            //printd("Label='%s'\r\n",pvAmps); //prints out debug information

                            ClearLbl(&lbl_RealTimeScreenChrgAmps_Value,boxRound_RealTimeScreenChrgAmps.Color);
                            sprintf(chAmps," 0 A");
                            DrawLbl(&lbl_RealTimeScreenChrgAmps_Value, chAmps, 8);

                            ClearLbl(&lbl_RealTimeScreenDailyOc_Value,boxRound_RealTimeScreen_BackgroundPanel.Color);
                            sprintf(outCharge,"(0.0)");
                            DrawLbl(&lbl_RealTimeScreenDailyOc_Value, outCharge, 6);

                            ClearLbl(&lbl_RealTimeScreenPvPower_Value,boxRound_RealTimeScreen_BackgroundPanel.Color);   // was overflowing when values went into thousands, changed to one decimal place in V1.2
                            sprintf(pvPower,"000 W");
                            DrawLbl(&lbl_RealTimeScreenPvPower_Value, pvPower, 10);
                    }
                    else
                    {
                              ClearLbl(&lbl_RealTimeScreenPvAmps_Value,boxRound_RealTimeScreenPvAmps.Color);
                              sprintf(pvAmps,"%+5.1f A", Screen->PVAmps);
                              DrawLbl(&lbl_RealTimeScreenPvAmps_Value, pvAmps, 8);
                              //printd("Label='%s'\r\n",pvAmps); //prints out debug information

                              ClearLbl(&lbl_RealTimeScreenChrgAmps_Value,boxRound_RealTimeScreenChrgAmps.Color);
                              sprintf(chAmps,"%+5.1f A", Screen->ChrgAmps);
                              DrawLbl(&lbl_RealTimeScreenChrgAmps_Value, chAmps, 8);

                              ClearLbl(&lbl_RealTimeScreenDailyOc_Value,boxRound_RealTimeScreen_BackgroundPanel.Color);
                              sprintf(outCharge,"(%4.1f)", Screen->DailyCharge);
                              DrawLbl(&lbl_RealTimeScreenDailyOc_Value, outCharge, 10);

                              ClearLbl(&lbl_RealTimeScreenPvPower_Value,boxRound_RealTimeScreen_BackgroundPanel.Color);   // was overflowing when values went into thousands, changed to one decimal place in V1.2
                              sprintf(pvPower,"%+4.0f W", Screen->PVPower);
                              DrawLbl(&lbl_RealTimeScreenPvPower_Value, pvPower, 10);
                              
                    }
            }
        }
       /*ClearLbl(&lbl_RealTimeScreen_Date,CurrentScreen->Color);
        sprintf(date,"%8u", Screen->Date);
        DrawLbl(&lbl_RealTimeScreen_Date, date, 9);*/
        
        ClearLbl(&lbl_RealTimeScreenTotalOc_Value, boxRound_RealTimeScreen_BackgroundPanel.Color);
        sprintf(outCharge,"%6.0f Ah", Screen->TotalCharge);
        DrawLbl(&lbl_RealTimeScreenTotalOc_Value, outCharge, strlen(outCharge)+1);
        
        ClearLbl(&lbl_RealTimeScreenPvOcVolt_Value,boxRound_RealTimeScreen_BackgroundPanel.Color);
        sprintf(ocVolt,"%4.0f V", Screen->PVOcVolts);
        DrawLbl(&lbl_RealTimeScreenPvOcVolt_Value, ocVolt, 9);
        
        ClearLbl(&lbl_RealTimeScreenBatTemp_Name,boxRound_RealTimeScreen_BackgroundPanel.Color);
        if ((userConfig_R.setPointsConfig.tempCompensation > 0.01f) || (userConfig_R.setPointsConfig.tempCompensation < -0.01f))
        {
           strncpy(batTempName,"Temperature (B) ",18);
        }
        else
        {
           strncpy(batTempName,"Temperature (I) ",18);
        }
        DrawLbl(&lbl_RealTimeScreenBatTemp_Name, batTempName, 18);
        
        ClearLbl(&lbl_RealTimeScreenBatTemp_Value,boxRound_RealTimeScreen_BackgroundPanel.Color);
        sprintf(batTemp,"%+3.2f C", Screen->BatTemp);
        DrawLbl(&lbl_RealTimeScreenBatTemp_Value, batTemp, 10);

        //printd("Label='%f'\r\n",scr_RealTimeScreen.PVVolts); //prints out debug information
        
     }
}

void DispTelemetryTime(time *t)  // Displays internal clock time
{
  char tempHour[3];
  char tempMin[3];
  char telemTime[5];
  
  
  sprintf(tempHour,"%02u", (unsigned long)t->hour);
  sprintf(tempMin,"%02u",  (unsigned long)t->min);

  //printd("Hour='%u'\r\n",(unsigned long)t->hour);
  //printd("Minute='%u'\r\n",(unsigned long)t->min);
  
  telemTime[0] = tempHour[0];
  telemTime[1] = tempHour[1];
  telemTime[2] = ':';
  telemTime[3] = tempMin[0];
  telemTime[4] = tempMin[1];
  telemTime[5] = 0x00;

  ClearLbl(&lbl_RealTimeScreen_RtcTime,CL_BLACK);
  DrawLbl(&lbl_RealTimeScreen_RtcTime,telemTime, 7);
}

void DispTelemetryDate(time *t)
{
  char tempYear[3];
  char tempMonth[3];
  char tempDay[3];
  char telemDate[8];
  
  sprintf(tempYear,"%02u", (unsigned long)t->year);
  sprintf(tempMonth,"%02u", (unsigned long)t->month);
  sprintf(tempDay,"%02u", (unsigned long)t->date);
  
   telemDate[0] = tempDay[0];
   telemDate[1] = tempDay[1];
   telemDate[2] = '/';
   telemDate[3] = tempMonth[0];
   telemDate[4] = tempMonth[1];
   telemDate[5] = '/';
   telemDate[6] = tempYear[0];
   telemDate[7] = tempYear[1];
   
   ClearLbl(&lbl_RealTimeScreen_Date,CL_BLACK);
   DrawLbl(&lbl_RealTimeScreen_Date,telemDate, 9);
}

void UpdateBatteryStatus()
{
 if( telemetry.outputVoltage < userConfig_W.setPointsConfig.bulkResetVolt )
  {
   Line9.Color = 0xD9E7;
   DrawLine(&Line9);
  }
 else if( (telemetry.outputVoltage < userConfig_W.setPointsConfig.floatVolt) && (telemetry.outputVoltage > userConfig_W.setPointsConfig.bulkResetVolt) )
  {
   Line9.Color = 0xF567;
   DrawLine(&Line9);
  }
 else if( telemetry.outputVoltage > userConfig_W.setPointsConfig.floatVolt )
  {
   Line9.Color = 0x5E88;
   DrawLine(&Line9);
  }
 else
  {
   Line9.Color = 0xFFFF;
   DrawLine(&Line9);
  }
  
}

// Flash On/OFF button in the event of a ground fault.

void GFFlashONOFFButton()
{
 //int x = 0;

// x = strncmp("NO ERRORS", lbl_ErrorScreen_Pos1.Caption, 9);

 if(CurrentScreen == &RealTimeScreen) // String matches, ie error is present
 {

      if(btn_RealTimeScreen_OnOff.Color == 0xFFFF)
      {
       btn_RealTimeScreen_OnOff.Color = 0xD9E7;
       btn_RealTimeScreen_OnOff.Caption = "GRND FAULT";
       DrawRoundButton(&btn_RealTimeScreen_OnOff);
      }


      else if(btn_RealTimeScreen_OnOff.Color == 0xD9E7)
      {
       btn_RealTimeScreen_OnOff.Color = 0xFFFF;
       btn_RealTimeScreen_OnOff.Caption = "GRND FAULT";
       DrawRoundButton(&btn_RealTimeScreen_OnOff);
      }
 }
 else
 {
      if(btn_RealTimeScreen_OnOff.Color == 0xD9E7)
      {
       btn_RealTimeScreen_OnOff.Color = 0xFFFF;
       btn_RealTimeScreen_OnOff.Caption = "GRND FAULT";
       DrawRoundButton(&btn_RealTimeScreen_OnOff);
      }
 }

}

// Set the On/OFF button back to normal after ground fault is resolved.

void GFResolvedONOFFButton()
{
 btn_RealTimeScreen_OnOff.Color = 0xFFFF;
 btn_RealTimeScreen_OnOff.Caption = "ON/OFF";
 DrawRoundButton(&btn_RealTimeScreen_OnOff);
}

void DispNotifactions()
{
   if ((telemetry.status.control_outputEnabled != 0) && (telemetry.status.control_smartShutdown == 0))
   {
     if (telemetry.status.control_usingBulk != 0)
     {
                 if (telemetry.status.control_mode == CTRL_MODE_OUT_REG)
                 {
                         ClearLbl(&lbl_RealTimeScreen_FltBlk,CL_BLACK);
                         TFT_Set_Font(lbl_RealTimeScreen_FltBlk.FontName, CL_WHITE, FO_HORIZONTAL);
                         strncpy(lbl_RealTimeScreen_FltBlk.Caption, "Absorb", 6);
                         lbl_RealTimeScreen_FltBlk.Caption[6] = 0x00;
                         TFT_Write_Text(lbl_RealTimeScreen_FltBlk.Caption, lbl_RealTimeScreen_FltBlk.Left, lbl_RealTimeScreen_FltBlk.Top);
                 }
                 else
                 {
                         ClearLbl(&lbl_RealTimeScreen_FltBlk,CL_BLACK);
                         TFT_Set_Font(lbl_RealTimeScreen_FltBlk.FontName, CL_WHITE, FO_HORIZONTAL);
                         strncpy(lbl_RealTimeScreen_FltBlk.Caption, "Bulk", 4);
                         lbl_RealTimeScreen_FltBlk.Caption[4] = 0x00;
                         TFT_Write_Text(lbl_RealTimeScreen_FltBlk.Caption, lbl_RealTimeScreen_FltBlk.Left, lbl_RealTimeScreen_FltBlk.Top);
                 }
     }
     else
     {
         ClearLbl(&lbl_RealTimeScreen_FltBlk,CL_BLACK);
         TFT_Set_Font(lbl_RealTimeScreen_FltBlk.FontName, CL_WHITE, FO_HORIZONTAL);
         strncpy(lbl_RealTimeScreen_FltBlk.Caption, "Float", 5);
         lbl_RealTimeScreen_FltBlk.Caption[5] = 0x00;
         TFT_Write_Text(lbl_RealTimeScreen_FltBlk.Caption, lbl_RealTimeScreen_FltBlk.Left, lbl_RealTimeScreen_FltBlk.Top);
     }
  }
  else
  {
     if ((telemetry.status.control_outputEnabled == 0) && (telemetry.status.control_smartShutdown == 0))
     {
         ClearLbl(&lbl_RealTimeScreen_FltBlk,CL_BLACK);
         TFT_Set_Font(lbl_RealTimeScreen_FltBlk.FontName, CL_WHITE, FO_HORIZONTAL);
         strncpy(lbl_RealTimeScreen_FltBlk.Caption, "OFF  ", 5);
         lbl_RealTimeScreen_FltBlk.Caption[5] = 0x00;
         TFT_Write_Text(lbl_RealTimeScreen_FltBlk.Caption, lbl_RealTimeScreen_FltBlk.Left, lbl_RealTimeScreen_FltBlk.Top);
         GFResolvedONOFFButton();
     }
     else
     {
         if ((telemetry.status.control_outputEnabled != 0) && (telemetry.status.control_smartShutdown != 0))
         {
            ClearLbl(&lbl_RealTimeScreen_FltBlk,CL_BLACK);
            TFT_Set_Font(lbl_RealTimeScreen_FltBlk.FontName, CL_WHITE, FO_HORIZONTAL);
            strncpy(lbl_RealTimeScreen_FltBlk.Caption, "AUTO ", 5);
            lbl_RealTimeScreen_FltBlk.Caption[5] = 0x00;
            TFT_Write_Text(lbl_RealTimeScreen_FltBlk.Caption, lbl_RealTimeScreen_FltBlk.Left, lbl_RealTimeScreen_FltBlk.Top);
         }
         else // ((telemetry.status.control_outputEnabled == 0) && (telemetry.status.control_smartShutdown != 0))
         {
            ClearLbl(&lbl_RealTimeScreen_FltBlk,CL_BLACK);
            TFT_Set_Font(lbl_RealTimeScreen_FltBlk.FontName, 0xD9E7, FO_HORIZONTAL);
            strncpy(lbl_RealTimeScreen_FltBlk.Caption, "GFD", 5);
            lbl_RealTimeScreen_FltBlk.Caption[5] = 0x00;
            TFT_Write_Text(lbl_RealTimeScreen_FltBlk.Caption, lbl_RealTimeScreen_FltBlk.Left, lbl_RealTimeScreen_FltBlk.Top);
            GFFlashONOFFButton();
         }
     }
  }
  
  if(sysInfo.modelType[0] == 'M')
  {
       ClearLbl(&lbl_RealTimeScreen_HvMv,CL_BLACK);
       TFT_Set_Font(lbl_RealTimeScreen_HvMv.FontName, CL_WHITE, FO_HORIZONTAL);
       lbl_RealTimeScreen_HvMv.Caption[0] = 'M';
       lbl_RealTimeScreen_HvMv.Caption[1] = 'V';
       lbl_RealTimeScreen_HvMv.Caption[2] = 0x00;
       TFT_Write_Text(lbl_RealTimeScreen_HvMv.Caption, lbl_RealTimeScreen_HvMv.Left, lbl_RealTimeScreen_HvMv.Top);

  }
  
  else if (sysInfo.modelType[0] == 'H')
  {
       ClearLbl(&lbl_RealTimeScreen_HvMv,CL_BLACK);
       TFT_Set_Font(lbl_RealTimeScreen_HvMv.FontName, CL_WHITE, FO_HORIZONTAL);
       lbl_RealTimeScreen_HvMv.Caption[0] = 'H';
       lbl_RealTimeScreen_HvMv.Caption[1] = 'V';
       lbl_RealTimeScreen_HvMv.Caption[2] = 0x00;
       TFT_Write_Text(lbl_RealTimeScreen_HvMv.Caption, lbl_RealTimeScreen_HvMv.Left, lbl_RealTimeScreen_HvMv.Top);
  }

}

void SendRealtime2MainStruct()
{
// maybe setting the time and date values to be sent to msp430
}

void GetRealtimeMainStruct()
{
   scr_RealTimeScreen.PVVolts     =  telemetry.pvVoltage;
   scr_RealTimeScreen.PVAmps      =  telemetry.pvCurrent;
   scr_RealTimeScreen.ChrgVolts   =  telemetry.outputVoltage;
   scr_RealTimeScreen.ChrgAmps    =  telemetry.outputCurrent;
   scr_RealTimeScreen.DailyCharge =  telemetry.outputCharge;
   scr_RealTimeScreen.PVOcVolts   =  telemetry.ocVoltage;
   scr_RealTimeScreen.PVPower     =  telemetry.pvPower;
   scr_RealTimeScreen.BatTemp     =  telemetry.batteryTemp;
   
   scr_RealTimeScreen.TotalCharge = CONFIG.totalCharge + CONFIG.dailyCharge;
}

void FlashAlarmButton()
{
 //int x = 0;

// x = strncmp("NO ERRORS", lbl_ErrorScreen_Pos1.Caption, 9);

 if(CurrentScreen == &RealTimeScreen) // Strings do not match, ie errors are present
 {
      if( (telemetry.eventFlags.negativePVCurrentSutdown != 0) || (telemetry.eventFlags.fanFault != 0) || (telemetry.eventFlags.configValueOutOfRange != 0) || (telemetry.eventFlags.highPVCurrentShutdown != 0) || (telemetry.eventFlags.highPVVoltShutdown != 0) || (telemetry.eventFlags.highOutCurrentShutdown != 0) ||
      (telemetry.eventFlags.highOutVoltShutdown != 0) || (telemetry.eventFlags.highHeatSinkTemp != 0) || (telemetry.eventFlags.highDischargeCurrentFault != 0) ||
      (telemetry.eventFlags.highBatteryTempFault != 0) )
      {

            if(btn_RealTimeScreen_Errors.Color == 0xFFFF)
            {
             btn_RealTimeScreen_Errors.Color = 0xD9E7;
             DrawRoundButton(&btn_RealTimeScreen_Errors);
            }


            else if(btn_RealTimeScreen_Errors.Color == 0xD9E7)
            {
             btn_RealTimeScreen_Errors.Color = 0xFFFF;
             DrawRoundButton(&btn_RealTimeScreen_Errors);
            }
      }
      else
      {
           if(btn_RealTimeScreen_Errors.Color == 0xD9E7)
           {
           btn_RealTimeScreen_Errors.Color = 0xFFFF;
           DrawRoundButton(&btn_RealTimeScreen_Errors);
           }
      }

  }

}

// Event Handlers

void btn_RealTimeScreen_OnOffOnClick()
{
  Init_OutputOnOffScreen();  // added to go to new ONOFF Page.
}

void btn_RealTimeScreen_ErrorsOnClick()
{
  Init_ErrorScreen(&scr_ErrorScreen);
}

void btn_RealTimeScreen_MenuOnClick()
{
  Init_MainMenuScreen();
}

void btn_RealTimeScreen_SettingsOnClick()
{
  Init_SettingsMenuScreen();
}