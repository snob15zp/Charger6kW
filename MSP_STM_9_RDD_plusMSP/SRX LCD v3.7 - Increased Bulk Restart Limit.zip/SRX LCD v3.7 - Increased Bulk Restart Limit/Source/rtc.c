#include "rtc.h"

time curIntTime;

void IntRtcInit(void)
{

  Set_RTCCON();
}

void Set_RTCCON(void)
{
  SYSKEY=0xAA996655;
  SYSKEY=0x556699AA;
   
  RTCOE_bit   = 0; //RTCC clock output enabled � clock presented onto an I/O
  SOSCEN_bit = 1;  // Enabled RTC to be clocked.
  HALFSEC_bit = 0; // First half period of second
  RTCSYNC_bit = 0; //RTC Value registers can be read without concern about a rollover ripple
  RTCWREN_bit = 1; //RTC Value registers can be written to by the user
  RTCCLKON_bit= 1; //RTCC Clock is actively running
  RTSECSEL_bit= 1;
  SIDL_bit    = 0; //Continue normal operation in Idle mode
  ON__RTCCON_bit = 1; // RTCC Module is Enabled ,set to 0 to disable.
  CAL0_bit = 0;
  CAL1_bit = 0;
  CAL2_bit = 0;
  CAL3_bit = 0;
  CAL4_bit = 0;
  CAL5_bit = 0;
  CAL6_bit = 0;
  CAL7_bit = 0;
  CAL8_bit = 0;
  CAL9_bit = 0;
}

/*void Set_RTCALRM(void)   //Dont need to worry about this at the moment
{
  ARPT0_bit = 0;
  ARPT1_bit = 0;
  ARPT2_bit = 0;
  ARPT3_bit = 0;
  ARPT4_bit = 0;
  ARPT5_bit = 0;
  ARPT6_bit = 0;
  ARPT7_bit = 0;

  // Alarm triggers once every hour B0:B3 = 1010
  AMASK0_bit = 1;             //This field should not be written when the RTCC ON bit = �1� (RTCCON<15>) and ALRMSYNC = 1.
  AMASK1_bit = 0;             //This field should not be written when the RTCC ON bit = �1� (RTCCON<15>) and ALRMSYNC = 1.
  AMASK2_bit = 1;             //This field should not be written when the RTCC ON bit = �1� (RTCCON<15>) and ALRMSYNC = 1.
  AMASK3_bit = 0;             //This field should not be written when the RTCC ON bit = �1� (RTCCON<15>) and ALRMSYNC = 1.

  ALRMSYNC_bit = 0;

  PIV_bit =  0;   //PIV is writable and determines the initial value of the Alarm Pulse. when ALRMEN = 0
  CHIME_bit = 0; //chime is disabled
  ALRMEN_bit = 0;
}*/

unsigned char ConvertfromBCD(unsigned char c)
{
        unsigned char b1;
        unsigned char b2;

        b1 = c & 0x0f;
        b2 = (c & 0xf0) >> 4;

        return (b2*10) + b1;
}

unsigned char ConvertToBCD(unsigned char c)
{
        unsigned char b1;
        unsigned char b2;

        b1 = c / 10;
        b2 = c % 10;

        return (b1<<4) | b2;
}

int IntSetTime(time *t)
{

unsigned char setTimeBuffer[3];
unsigned long TimeReg; //register variable

        setTimeBuffer[0] = ConvertToBCD(t->sec % 60);
        setTimeBuffer[1] = ConvertToBCD(t->min % 60);
        setTimeBuffer[2] = ConvertToBCD(t->hour % 24);

        TimeReg = 0; //makes sure the register is cleared before
        
        //Ors the Register with the BCD value of hours and than shifts it by 8
        TimeReg = TimeReg | setTimeBuffer[2];
        TimeReg <<= 8;
        
        //Ors the Register with the Minutes BCD and shifts hours and mins by 8
        TimeReg = TimeReg | setTimeBuffer[1];
        TimeReg <<= 8;
        
        //Ors the Register containing Hours and Minutes with Seconds and moves all by 8 and leaves bit0-bit8 empty.
        TimeReg = TimeReg | setTimeBuffer[0];
        TimeReg <<= 8;
        
        //RTCCONCLR=0x8000; // turn off the RTCC
        //while(RTCCON&0x40); // wait for clock to be turned off
        
        RTCTIME = TimeReg;
        
        //RTCCONSET=0x8000; // turn on the RTCC
        //while(!(RTCCON&0x40)); // wait for clock to be turned on

        return 0;
}

int IntSetDate(time *t)
{
 unsigned char setDateBuffer[4];
 unsigned long DateReg;
 
        setDateBuffer[0] = ConvertToBCD(t->date);
        setDateBuffer[1] = ConvertToBCD(t->month);
        setDateBuffer[2] = ConvertToBCD(t->year);
        setDateBuffer[3] = ConvertToBCD(t->wkday);
        
        DateReg = 0;
        
        DateReg = DateReg | setDateBuffer[2];   //year
        DateReg <<= 8;
        
        DateReg = DateReg | setDateBuffer[1];   //month
        DateReg <<= 8;

        DateReg = DateReg | setDateBuffer[0];   //date
        DateReg <<= 8;

        DateReg = DateReg | setDateBuffer[3];   //weekday


        //RTCCONCLR=0x8000; // turn off the RTCC
        //while(RTCCON&0x40); // wait for clock to be turned off

        RTCDATE = DateReg;  //write everything to the date register
        
        //RTCCONSET=0x8000; // turn on the RTCC
        //while(!(RTCCON&0x40)); // wait for clock to be turned on

        return 0;
}

int IntGetTime(time *t)
{
        unsigned char GetTimeBuffer[3];
        unsigned long GetTimeReg;


        while(RTCCON&0x04); // wait for RTSYNC bit to go low

        GetTimeReg = RTCTIME;

        GetTimeReg = GetTimeReg >> 8; //Flush out the first unused 8bits.
        
        GetTimeBuffer[0] = (unsigned char) (GetTimeReg & 0x00FF);
        GetTimeReg >>= 8;
        
        GetTimeBuffer[1] = (unsigned char) (GetTimeReg & 0x00FF);
        GetTimeReg >>= 8;
        
        GetTimeBuffer[2] = (unsigned char) (GetTimeReg & 0x00FF);

        t->sec = ConvertfromBCD(GetTimeBuffer[0]) % 60;
        t->min = ConvertfromBCD(GetTimeBuffer[1]) % 60;
        t->hour = ConvertfromBCD(GetTimeBuffer[2]) % 24;


        return 0;
}


int IntGetDate(time *t)
{
        unsigned char GetDateBuffer[4];
        unsigned long GetDateReg;


        while(RTCCON&0x04); // wait for RTSYNC bit to go low

        GetDateReg = RTCDATE;  //coppy everything from RTCDATE
        
        GetDateBuffer[0] = (unsigned char) (GetDateReg & 0x00FF); // save wkday
        GetDateReg >>= 8;

        GetDateBuffer[1] = (unsigned char) (GetDateReg & 0x00FF); // save date
        GetDateReg >>= 8;

        GetDateBuffer[2] = (unsigned char) (GetDateReg & 0x00FF); // save month
        GetDateReg >>= 8;

        GetDateBuffer[3] = (unsigned char) (GetDateReg & 0x00FF); // save year

        t->wkday= ConvertfromBCD(GetDateBuffer[0]);
        t->date = ConvertfromBCD(GetDateBuffer[1]);
        t->month = ConvertfromBCD(GetDateBuffer[2]);
        t->year = ConvertfromBCD(GetDateBuffer[3]);
        


        return 0;
}