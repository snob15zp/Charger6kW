#include "serial1.h"

// USARTD0 Transmitter buffer
#define TX_BUFFER_SIZE_USARTD0 64
unsigned int tx_buffer_usartd0[TX_BUFFER_SIZE_USARTD0];

#if TX_BUFFER_SIZE_USARTD0 <= 256
unsigned char tx_wr_index_usartd0=0,tx_rd_index_usartd0=0,tx_counter_usartd0=0;
#else
unsigned int tx_wr_index_usartd0=0,tx_rd_index_usartd0=0,tx_counter_usartd0=0;
#endif

// USARTD0 Receiver buffer
#define RX_BUFFER_SIZE_USARTD0 192
unsigned int rx_buffer_usartd0[RX_BUFFER_SIZE_USARTD0];

#if RX_BUFFER_SIZE_USARTD0 <= 256
unsigned char rx_wr_index_usartd0=0,rx_rd_index_usartd0=0,rx_counter_usartd0=0;
#else
unsigned int rx_wr_index_usartd0=0,rx_rd_index_usartd0=0,rx_counter_usartd0=0;
#endif

// This flag is set on USARTD0 Receiver buffer overflow
bit rx_buffer_overflow_usartd0;

int rxbytesread;

// USARTD0 initialization
void usartd0_init(void)
{
//-------------------------------------------------------------------------------
  //   UART 1 SETUP
  //------------------------------------
  //UART1_Init_Advanced(1200, 80000, _UART_LOW_SPEED, _UART_9BIT_NOPARITY,_UART_ONE_STOPBIT) ;

  UART1_Init_Advanced(1200, 80000, _UART_LOW_SPEED, _UART_8BIT_NOPARITY,_UART_ONE_STOPBIT) ;

  Delay_ms(100)  ;                        // Wait for UART module to stabilize
  //--------------------------------------
  U1IP0_bit = 1 ;           // set interrupt
  U1IP1_bit = 1 ;           // priority
  U1IP2_bit = 1 ;           // to 7

  U1STA.B7 = 1;            //RX Interrupt on FUll Buffer of 4 chars.
  U1STA.B6 = 1;

  U1STA.B15 = 1;           //TX Interrupt when Empty Buffer of 4 chars.
  U1STA.B14 = 0;

  U1RXIF_bit = 0  ;         // ensure interrupt not pending
  U1TXIF_bit = 0  ;         // ensure interrupt not pending

  U1RXIE_bit = 0 ;                 //disable RX1 intterupt
  U1TXIE_bit = 0 ;                 //disable TX1 intterupt



  //------------------

  //-----------------------------------------------------------------------------
}

void InitSer0_d(void)
{

  //U1STA.B5 = 1;             //Address Enable
  U1STA.B5 = 0;             //Address Disable

//  Enable UART1 Rx Interrupts
  U1RXIE_bit = 1 ;                 //enable RX1 intterupt
  U1TXIE_bit = 0 ;                 //disable TX1 intterupt


}

void InitBitsSer0_d(void)
{
    rxbytesread = 0;
    rx_buffer_overflow_usartd0 = 0;
    flushRx0_d();
    flushTx0_d();
    usartd0_init();
}

void flushRx0_d(void)
{
    rx_wr_index_usartd0=0;
    rx_rd_index_usartd0=0;
    rx_counter_usartd0=0;
}


int kbhit0_d(void)
{

#if RX_BUFFER_SIZE_USARTD0<256
    unsigned char tmp;
#else
    unsigned int tmp;
#endif

    DisableInterrupts()  ;
    tmp = rx_counter_usartd0;
    EnableInterrupts()  ;

    return ((tmp != 0) || (U1STA.B0));

}


void flushTx0_d(void)
{
    tx_wr_index_usartd0=0;
    tx_rd_index_usartd0=0;
    tx_counter_usartd0=0;
}


void putString0_d(char *s)
{
     while(*s != 0x00)
     {
        putchar0_d((unsigned int) *s);
        s++;
     }
}

void putchar0_d(unsigned int c)
{
    sendChar0_d(c);
}


int txBufferFull0_d(void)
{

#if TX_BUFFER_SIZE_USARTD0<256
    unsigned char tmp;
#else
    unsigned int tmp;
#endif

    DisableInterrupts()  ;
    tmp = tx_counter_usartd0;
    EnableInterrupts()  ;

    return (tmp == TX_BUFFER_SIZE_USARTD0);

}

unsigned int getchar0_d(void)
{
unsigned int datac;

while ((rx_counter_usartd0==0) && (!U1STA.B0));

if ((rx_counter_usartd0==0) && (U1STA.B0))
{
     datac =  U1RXREG;
     return datac;
}

datac=rx_buffer_usartd0[rx_rd_index_usartd0++];
#if RX_BUFFER_SIZE_USARTD0 != 256
if (rx_rd_index_usartd0 == RX_BUFFER_SIZE_USARTD0) rx_rd_index_usartd0=0;
#endif
DisableInterrupts()  ;
--rx_counter_usartd0;
EnableInterrupts()  ;
return datac;
}

// Write a character to the USARTD0 Transmitter buffer
// USARTD0 is used as the default output device by the 'putchar' function
void sendChar0_d(unsigned int c)
{
   while (tx_counter_usartd0 == TX_BUFFER_SIZE_USARTD0);
   DisableInterrupts()  ;
   if (tx_counter_usartd0 || (U1STA.B9))
   {
   tx_buffer_usartd0[tx_wr_index_usartd0++]=c;
#if TX_BUFFER_SIZE_USARTD0 != 256
   if (tx_wr_index_usartd0 == TX_BUFFER_SIZE_USARTD0) tx_wr_index_usartd0=0;
#endif
      ++tx_counter_usartd0;
      U1TXIE_bit = 1;
      U1TXIF_bit = 1  ;
      EnableInterrupts()  ;
   }
else
   {
      EnableInterrupts()  ;
      UART1_Write(c);
   }
}

void UART1_Handler() iv IVT_UART_1 ilevel 7 ics ICS_SRS {

     unsigned int uart_rd;
     unsigned char status;

     if (U1RXIF_bit)
     {

        while (U1STA.B0)
        {
           status=0;
           //U1STA.B5 = 0;             //Address Disable
           uart_rd = U1RXREG;
           if (status == 0)
           {
               rx_buffer_usartd0[rx_wr_index_usartd0++]=uart_rd;
            #if RX_BUFFER_SIZE_USARTD0 == 256
               // special case for receiver buffer size=256
               if (++rx_counter_usartd0 == 0)
               {
            #else
               if (rx_wr_index_usartd0 == RX_BUFFER_SIZE_USARTD0) rx_wr_index_usartd0=0;

               if (++rx_counter_usartd0 == RX_BUFFER_SIZE_USARTD0)
               {
                  rx_counter_usartd0=0;
            #endif
                  rx_buffer_overflow_usartd0=1;
                };
           }

        }
        U1RXIF_bit = 0;             // Clear UART1 RX Interrupt flag
      }

      if (U1TXIF_bit)
      {
         if (tx_counter_usartd0)
         {
          --tx_counter_usartd0;
          UART1_Write(tx_buffer_usartd0[tx_rd_index_usartd0++]);
          #if TX_BUFFER_SIZE_USARTD0 != 256
          if (tx_rd_index_usartd0 == TX_BUFFER_SIZE_USARTD0) tx_rd_index_usartd0=0;
          #endif
          U1TXIE_bit = 1;
         }
         else
         {
            U1TXIE_bit = 0 ;
         }
         U1TXIF_bit = 0;
      }
}