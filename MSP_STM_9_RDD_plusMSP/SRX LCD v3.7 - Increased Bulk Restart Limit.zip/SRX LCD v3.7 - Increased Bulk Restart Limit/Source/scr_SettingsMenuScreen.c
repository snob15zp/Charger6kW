#include "general.h"
#include "scr_SettingsMenuScreen.h"
#include "scr_CanBusInfoScreen.h"
#include "scr_MainMenuScreen.h"
#include "scr_SetpointsScreen1.h"
#include "scr_TimeDateEditScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "scr_SetpointsScreen2.h"
#include "scr_SetpointsScreen1.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"
#include "localConfig.h"

extern Tscreen* CurrentScreen;
extern Tscreen* PreviousScreen;

void Init_SettingsMenuScreen(void)
{
     if (CurrentScreen != &SettingsMenuScreen)
     {
        PreviousScreen = CurrentScreen;
        DrawScreen(&SettingsMenuScreen);
     }
}

void UpdateSettingsMenuScreen(void) // This is the only thing that needs to be updated on this screen
{
  if (CurrentScreen == &SettingsMenuScreen)
     {

         // update time code in here

     }

}

// Event Handlers

void btn_SettingsMenuScreen_SetpointsOnClick()
{

       scr_SetpointsScreen1.initialised = false;
       scr_SetpointsScreen2.initialised = false;
       Init_SetpointsScreen1(&scr_SetpointsScreen1);

}

void btn_SettingsMenuScreen_TimeAndDateOnClick()
{
  Init_TimeDateEditScreen();
}

void btn_SettingsMenuScreen_CanBusInfoOnClick() 
{
  Init_CanBusInfoScreen(&scr_CanBaseIfonScreen);
}

void btn_SettingsMenuScreen_MenuOnClick()
{
  Init_MainMenuScreen();
}