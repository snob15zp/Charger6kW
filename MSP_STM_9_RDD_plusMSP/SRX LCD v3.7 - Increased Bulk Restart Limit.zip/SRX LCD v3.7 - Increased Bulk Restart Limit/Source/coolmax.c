#include "serial1.h"
#include "debug.h"
#include "general.h"
#include "cmdlib.h"
#include "coolmax.h"
#include "protocol.h"
#include "crc16.h"
#include "scr_SetPointsScreen1.h"
#include "scr_SetPointsScreen2.h"
#include "scr_NotificationScreen.h"
#include "scr_OutputOnOffScreen.h"
#include "mb.h"
#include "localConfig.h"


#define DLE 0x10
#define ETX 0x03
#define STX 0x02

#define PACKET_LENGTH  254

#define IDLE 0
#define RECEIVING_PACKET 1
#define RECEIVED_PACKET 2

#define FOOTER_LENGTH 6

// Global variables
unsigned char tx_buffer[PACKET_LENGTH];
unsigned char rx_buffer[PACKET_LENGTH];
unsigned char tx_count = 0;
unsigned char rx_count = 0;
unsigned char expected_rx_count = 0;
unsigned char rx_state = IDLE;
unsigned int tx_buf_len = 0;
unsigned char prev_rx = 0xFF;

int coolmax_protocol_request_state = 0;

telemetry_t telemetry;
factoryConfig_t factoryConfig;
userConfig_t userConfig_R;
userConfig_t userConfig_W;
eventConfig_t eventConfig;
sysInfo_t sysInfo;
command_t command;
setPointsConfig_t setpointsConfig;
setTime_t setTime;
miscState_t miscState;

TimeStruct coolmax_time;
TimeStruct lcd_time;


int isUserConfigInit = false;
int requestRemoteReset = false;
int isRemoteResetSent = 0;
int isSysInfoInit = false;
int requestOutputEnabled = false;
int isOutputEnabledSent = false;
int requestSmartShutdownUpdate = false;
int isMiscStateInit = false;


char statusMessage[MAX_STATUS_MSG_LEN+1];
int requestUserConfigRetry = 0;

void uart_receive(void);
int uart_send(int type, int isRequest);

void CopyUserConfigData()
{
    userConfig_W.lowOutVoltGenset.enabled = userConfig_R.lowOutVoltGenset.enabled;
    userConfig_W.lowOutVoltGenset.triggerVal = userConfig_R.lowOutVoltGenset.triggerVal;
    userConfig_W.lowOutVoltGenset.resetVal = userConfig_R.lowOutVoltGenset.resetVal;
    userConfig_W.lowOutVoltGenset.hystTime = userConfig_R.lowOutVoltGenset.hystTime;
    userConfig_W.lowOutVoltGenset.holdTime = userConfig_R.lowOutVoltGenset.holdTime;
    userConfig_W.commsConfig.modBusAddress = userConfig_R.commsConfig.modBusAddress;
    userConfig_W.commsConfig.canBaudRate = userConfig_R.commsConfig.canBaudRate;
    userConfig_W.commsConfig.canBusID = userConfig_R.commsConfig.canBusID;
    userConfig_W.commsConfig.isSlave = userConfig_R.commsConfig.isSlave;
    userConfig_W.setPointsConfig.pvOcVolt = userConfig_R.setPointsConfig.pvOcVolt;
    userConfig_W.setPointsConfig.pvMpVolt = userConfig_R.setPointsConfig.pvMpVolt;
    userConfig_W.setPointsConfig.floatVolt = userConfig_R.setPointsConfig.floatVolt;
    userConfig_W.setPointsConfig.bulkVolt = userConfig_R.setPointsConfig.bulkVolt;
    userConfig_W.setPointsConfig.bulkTime = userConfig_R.setPointsConfig.bulkTime;
    userConfig_W.setPointsConfig.bulkResetVolt = userConfig_R.setPointsConfig.bulkResetVolt;
    userConfig_W.setPointsConfig.tempCompensation = userConfig_R.setPointsConfig.tempCompensation;
    userConfig_W.setPointsConfig.nominalVolt = userConfig_R.setPointsConfig.nominalVolt;

    // Copy Modbus Address to variable used by Modbus stack ...
    eMBAssignAddress(userConfig_R.commsConfig.modBusAddress);
          
    scr_SetpointsScreen1.initialised = false;
    scr_SetpointsScreen2.initialised = false;
    GetSetpoints1MainStruct();     // Transfers values from MainStruct to values in local struct.
    GetSetpoints2MainStruct();
}

int CompareUserConfigData()
{
    if (userConfig_W.lowOutVoltGenset.enabled != userConfig_R.lowOutVoltGenset.enabled) return 0;
    if (fabs(userConfig_W.lowOutVoltGenset.triggerVal - userConfig_R.lowOutVoltGenset.triggerVal) > FLOAT_PREC) return 0;
    if (fabs(userConfig_W.lowOutVoltGenset.resetVal - userConfig_R.lowOutVoltGenset.resetVal) > FLOAT_PREC) return 0;
    if (userConfig_W.lowOutVoltGenset.hystTime != userConfig_R.lowOutVoltGenset.hystTime) return 0;
    if (userConfig_W.lowOutVoltGenset.holdTime != userConfig_R.lowOutVoltGenset.holdTime) return 0;
    if (userConfig_W.commsConfig.modBusAddress != userConfig_R.commsConfig.modBusAddress) return 0;
    if (userConfig_W.commsConfig.canBaudRate != userConfig_R.commsConfig.canBaudRate) return 0;
    if (userConfig_W.commsConfig.canBusID != userConfig_R.commsConfig.canBusID) return 0;
    if (userConfig_W.commsConfig.isSlave != userConfig_R.commsConfig.isSlave) return 0;
    if (fabs(userConfig_W.setPointsConfig.pvOcVolt - userConfig_R.setPointsConfig.pvOcVolt) > FLOAT_PREC) return 0;
    if (fabs(userConfig_W.setPointsConfig.pvMpVolt - userConfig_R.setPointsConfig.pvMpVolt) > FLOAT_PREC) return 0;
    if (fabs(userConfig_W.setPointsConfig.floatVolt - userConfig_R.setPointsConfig.floatVolt) > FLOAT_PREC) return 0;
    if (fabs(userConfig_W.setPointsConfig.bulkVolt - userConfig_R.setPointsConfig.bulkVolt) > FLOAT_PREC) return 0;
    if (userConfig_W.setPointsConfig.bulkTime != userConfig_R.setPointsConfig.bulkTime) return 0;
    if (fabs(userConfig_W.setPointsConfig.bulkResetVolt - userConfig_R.setPointsConfig.bulkResetVolt) > FLOAT_PREC) return 0;
    if (fabs(userConfig_W.setPointsConfig.tempCompensation - userConfig_R.setPointsConfig.tempCompensation) > FLOAT_PREC) return 0;
    if (fabs(userConfig_W.setPointsConfig.nominalVolt - userConfig_R.setPointsConfig.nominalVolt) > FLOAT_PREC) return 0;

    return true;
}


void UpdateTxCoolMaxData()
{
    int res;
    long diff;

    coolmax_protocol_request_state++;
    
    if(isSysInfoInit)
    {
      Password[0] = sysInfo.serialNumber[1];
      Password[1] = sysInfo.serialNumber[0];
      Password[2] = sysInfo.serialNumber[3];
      Password[3] = sysInfo.serialNumber[2];
      Password[4] = 0x00;
    }
    
    switch (coolmax_protocol_request_state)
    {
       case 2:
              if (!requestRemoteReset)
              {
                 if(!requestOutputEnabled)
                 {
                   RequestTelemetryPacket();
                 }
                 else
                 {
                  SendOutputPacket(WriteOutputState == Output_ON);
                  requestOutputEnabled = false;
                 }
              }
              else
              {
                  SendResetPacket();
                  UpdateNotificationScreen("INITIATING RESTART");
                  requestRemoteReset = false;
              }
              break;
       case 4:
              if (!isUserConfigInit)
              {
                 RequestUserConfigPacket();
              }
              else
              {
                 res = CompareUserConfigData();
                 if (!res)
                 {
                   requestUserConfigRetry++;
                   sprintf(statusMessage,"APPLYING SETTINGS",requestUserConfigRetry);
                   printd("%s\r\n",statusMessage);
                   UpdateNotificationScreen(statusMessage);
                   SendUserConfigPacket();
                   coolmax_protocol_request_state = -2;
                 }
                 else
                 {
                   if (requestUserConfigRetry > 0)
                   {
                      sprintf(statusMessage,"SETTINGS SAVED");
                      printd("%s\r\n",statusMessage);
                      UpdateNotificationScreen(statusMessage);
                   }
                   requestUserConfigRetry = 0;
                   RequestTelemetryPacket();
                 }
              }
              break;
       case 6:
              if (!requestRemoteReset)
              {
                 if(!requestOutputEnabled)
                 {
                   RequestTelemetryPacket();
                 }
                 else
                 {
                  SendOutputPacket(WriteOutputState == Output_ON);
                  requestOutputEnabled = false;
                 }
              }
              else
              {
                  SendResetPacket();
                  UpdateNotificationScreen("INITIATING RESTART");
                  requestRemoteReset = false;
              }
              break;
       case 8:
              if (!isSysInfoInit)
              {
                 RequestSysInfoPacket();
              }
              else
              {
                 res = CompareUserConfigData();
                 if (!res)
                 {
                   requestUserConfigRetry++;
                   sprintf(statusMessage,"APPLYING SETTINGS",requestUserConfigRetry);
                   printd("%s\r\n",statusMessage);
                   UpdateNotificationScreen(statusMessage);
                   SendUserConfigPacket();
                   coolmax_protocol_request_state = -2;
                 }
                 else
                 {
                   if (requestUserConfigRetry > 0)
                   {
                      sprintf(statusMessage,"SETTINGS SAVED");
                      printd("%s\r\n",statusMessage);
                      UpdateNotificationScreen(statusMessage);
                   }
                   requestUserConfigRetry = 0;
                   RequestTelemetryPacket();
                 }
              }
              break;
       case 10:
              diff = Time_dateDiff(&coolmax_time,&lcd_time);
              if (abs(diff) > 10)
              {
                 sprintf(statusMessage,"SAVING TIME");
                 printd("%s\r\n",statusMessage);
                 SendTimePacket();
              }
              else
              {
                 if(!requestOutputEnabled)
                 {
                   RequestTelemetryPacket();
                 }
                 else
                 {
                  SendOutputPacket(WriteOutputState == Output_ON);
                  requestOutputEnabled = false;
                 }
              }
              coolmax_protocol_request_state = 0;
              break;
              
       /*
       case 12:
               if(!isMiscStateInit)
               {
                 RequestMiscState();
               }
               else
               {
                   if(requestSmartShutdownUpdate == true)
                   {
                    miscState.enableSmartShutdown = WriteSmartShutDownState;
                    SendMiscPacket();
                    requestSmartShutdownUpdate = false;
                   }
               }
               coolmax_protocol_request_state = 0;
               break; 
       */
    }

}

void RequestTelemetryPacket()
{
    uart_send(TYPE_TELEMETRY, true);
}

void RequestUserConfigPacket()
{
    uart_send(TYPE_USER, true);
}

void RequestSysInfoPacket()
{
    uart_send(TYPE_SYS_INFO, true);
}

void SendUserConfigPacket()
{
    uart_send(TYPE_USER, false);
}

void SendResetPacket()
{
    command.commandCode = COMMAND_RESET;
    command.arg = 0;
    uart_send(TYPE_COMMAND, false);
}

void SendTimePacket()
{
    setTime.time = (uint64_t) ((uint32_t) Time_datetoEpoch(&lcd_time));
    setTime.time *= (uint64_t) 1000;
    uart_send(TYPE_SET_TIME, false);
}

void SendOutputPacket(int enable)
{
    command.commandCode = COMMAND_ENABLE_OUTPUT;
    command.arg = enable;
    uart_send(TYPE_COMMAND, false);
}

void SendMiscPacket(void)
{
    uart_send(TYPE_MISC_STATE, false);
}

void RequestMiscState()
{
    uart_send(TYPE_MISC_STATE, true);
}

void UpdateRxCoolMaxData()
{
    unsigned char rxs;
    unsigned int rxc;
    char c;
    char TestString[64];

    while (kbhit0_d())
    {
        rxc = getchar0_d();

        rxs = (unsigned char) (rxc & 0xFF);
        
        if(rx_state != RECEIVED_PACKET)
        {
                if((rxs == STX) && (prev_rx == DLE))
                {
                        // A packet has started
                        rx_buffer[0] = DLE;
                        rx_buffer[1] = STX;
                        rx_count = 2;
                        expected_rx_count = 0;
                        rx_state = RECEIVING_PACKET;
                }
                else if(rx_state == RECEIVING_PACKET)
                {
                        rx_buffer[rx_count++] = rxs;
                        if(rx_count <= 4)
                        {
                                if (((rx_count == 3) && (rxs != DLE)) || ((rx_count == 4) && (prev_rx == DLE)))
                                {
                                        expected_rx_count = rxs;
                                }
                        }
                        else if(rx_count <= expected_rx_count)
                        {
                                if((prev_rx == DLE) && (rxs == ETX))
                                {
                                        if (rx_count == expected_rx_count)
                                        {
                                                rx_state = RECEIVED_PACKET;
                                                ///sprintf(TestString, "%02x ", (unsigned int) (rxc));
                                                //putString(TestString);
                                                //putString("RX PCKT\r\n");
                                                uart_receive();
                                                flushRx0_d();
                                                
                                        }
                                        else
                                        {
                                                // Length doesn't match
                                                rx_state = IDLE;
                                        }
                                }
                        }
                        else
                        {
                                // Bad packet - reset state
                                rx_state = IDLE;
                        }
                }
                else if ((rxs == DLE) && (prev_rx == DLE))
                {
                        rxs = 0xFF;
                }
        }
        prev_rx = rxs;
    }



}



void uart_receive(void)
{
        unsigned char i;
        unsigned char k;
        unsigned char crc_start;
        packetIdentifier_t packetID;
        unsigned char *bytes = 0;
        unsigned char structSize = 0;
        unsigned char version = 0;
        char TestString[64];
        uint32_t timeSecs;

        if(rx_state == RECEIVED_PACKET)
        {
                crc_start = rx_count - FOOTER_LENGTH;
                k = crc_start;
                // Un-stuff crc bytes
                if(rx_buffer[k] == DLE)
                {
                        k++;
                }
                k++;
                if(rx_buffer[k] == DLE)
                {
                        k++;
                }
                rx_buffer[crc_start+1] = rx_buffer[k];
                if(CalculateCRC16(rx_buffer,crc_start+2,1,0x00) == 2)
                {
                        // Process packet
                        k = 4;
                        if(rx_buffer[k] == DLE)
                        {
                                k++;
                        }
                        packetID.byte = rx_buffer[k++];
                        //printd("RXS PACKET %u\r\n", (unsigned int) packetID.type);
                        switch(packetID.type)
                        {
                        case TYPE_TELEMETRY:
                                bytes = telemetry.bytes;
                                structSize = sizeof(telemetry_t);
                                version = VERSION_TELEMETRY;
                                break;
                        case TYPE_FACTORY:
                                bytes = factoryConfig.bytes;
                                structSize = sizeof(factoryConfig_t);
                                version = VERSION_FACTORY;
                                break;
                        case TYPE_USER:
                                bytes = userConfig_R.bytes;
                                structSize = sizeof(userConfig_t);
                                version = VERSION_USER;
                                break;
                        case TYPE_EVENTS:
                                bytes = eventConfig.bytes;
                                structSize = sizeof(eventConfig_t);
                                version = VERSION_EVENTS;
                                break;
                        case TYPE_SYS_INFO:
                                bytes = sysInfo.bytes;
                                structSize = sizeof(sysInfo_t);
                                version = VERSION_SYS_INFO;
                                break;
                        case TYPE_COMMAND:
                                bytes = command.bytes;
                                structSize = sizeof(command_t);
                                version = VERSION_COMMAND;
                                break;
                        case TYPE_SET_TIME:
                                bytes = setTime.bytes;
                                structSize = sizeof(setTime_t);
                                version = VERSION_COMMAND;
                                break;
                        case TYPE_MISC_STATE:
                                bytes = miscState.bytes;
                                structSize = sizeof(miscState_t);
                                version = VERSION_MISC_STATE;
                                break;
                        default:
                                // Unknown packet type
                                // FIXME: remove
                                break;
                        }

                        if(packetID.request)
                        {
                                // Send requested packet, Should not happen as PIC32 is master.
                        }
                        else if(bytes && (packetID.version == version))
                        {
                                i = 0;
                                if (packetID.type > 0)
                                {
                                   printd("RX PACKET %u\r\n", (unsigned int) packetID.type);
                                }
                                // Un-stuff received data and load it into the appropriate struct
                                while(k < crc_start)
                                {
                                        if(rx_buffer[k] == DLE)
                                        {
                                                k++;
                                        }
                                        if (i >= structSize)
                                        {
                                                // Too much data
                                                // FIXME: remove
                                                break;
                                        }
                                        if (k >= crc_start)
                                        {
                                                // Bad stuffing - DLE at the end of the data buffer
                                                // FIXME: remove
                                                break;
                                        }
                                        bytes[i++] = rx_buffer[k++];


                                        //sprintf(TestString, "%02x ", (unsigned int) (bytes[i-1]));
                                        //putString(TestString);
                                }
                                if(i == structSize)
                                {
                                         //printd("RX DONE\r\n");
                                         if (packetID.type == TYPE_USER)
                                         {
                                            if (isUserConfigInit)
                                            {
                                               requestRemoteReset = true;
                                               isRemoteResetSent = 0;
                                            }
                                            UpdateNotificationScreen("SETTINGS SAVED\r\n");
                                            isUserConfigInit = true;
                                            CopyUserConfigData();

                                         }
                                         if (packetID.type == TYPE_SYS_INFO)
                                         {
                                            isSysInfoInit = true;
                                         }
                                         if(packetID.type == TYPE_COMMAND)
                                         {
                                                if (command.commandCode == COMMAND_REPLY_STARTUP)
                                                {
                                                    printd("REMOTE RESET DONE\r\n");
                                                    UpdateNotificationScreen("REMOTE RESET DONE\r\n");
                                                    isRemoteResetSent = 1;
                                                    isUserConfigInit = false;
                                                    isSysInfoInit = false;
                                                }
                                                if (command.commandCode == COMMAND_ENABLE_OUTPUT)
                                                {
                                                    isOutputEnabledSent = true;
                                                }
                                         }
                                         
                                         if (packetID.type == TYPE_TELEMETRY)
                                         {
                                              timeSecs = (uint32_t) (telemetry.time / 1000);
                                              Time_epochToDate((long) timeSecs, &coolmax_time);
                                              
                                              if (telemetry.status.safety_operation)
                                              {
                                                ReadOutputState = Output_SHUTDOWN;
                                              }
                                              else if (telemetry.status.control_smartShutdown)   //Smart ShutDown indicates ground fault in G3
                                              {
                                                ReadOutputState = Output_GROUNDFAULT;
                                              }
                                              else if (telemetry.status.control_outputEnabled != 0)
                                              {
                                                ReadOutputState = Output_ON;
                                              }
                                              else
                                              {
                                                ReadOutputState = Output_OFF;
                                              }
                                              //ReadSmartShutDownState = miscState.enableSmartShutdown;

                                              // When ouput charge is less than dailyCharge in FRAM, the dailyCharge will be added to totalCharge
                                              // This will happen anytime the unit is reset. This will work even if midnight reset is off because dailyCharge and totalCharge are stored in FRAM
                                              // TODO: test if 1Ah tolerance is enough
                                              if (telemetry.outputCharge <= 0 || telemetry.outputCharge < (CONFIG.dailyCharge - 1.0f))
                                              {
                                                  CONFIG.totalCharge += CONFIG.dailyCharge;
                                              }
                                              CONFIG.dailyCharge = telemetry.outputCharge;
                                              if (CONFIG.dailyCharge < 0)
                                              {
                                                  CONFIG.dailyCharge = 0;
                                              }
                                              // TODO: only right the charge values and the checksum to save time
                                              ConfigWrite();
                                         }
                                         if (packetID.type == TYPE_MISC_STATE)
                                         {
                                            //UpdateSmartShutDownStateOnOffScreen();
                                            //isMiscStateInit = true;
                                            return;
                                         }
                                         
                                }
                                else
                                {
                                        // FIXME: remove
                                }
                        }
                }
                else
                {
                        // FIXME: remove
                }

                rx_state = IDLE;
                rx_count = 0;
        }
}

int uart_send(int type,int isRequest)
{
        unsigned char *bytes;
        unsigned char structSize;
        unsigned char version;
        int i;
        int k;
        unsigned char c;
        unsigned char d;
        packetIdentifier_t packetID;
         char TestString[64];

        switch(type)
        {
        case TYPE_TELEMETRY:
                bytes = telemetry.bytes;
                structSize = sizeof(telemetry_t);
                version = VERSION_TELEMETRY;
                break;
        case TYPE_FACTORY:
                bytes = factoryConfig.bytes;
                structSize = sizeof(factoryConfig_t);
                version = VERSION_FACTORY;
                break;
        case TYPE_USER:
                bytes = userConfig_W.bytes;
                structSize = sizeof(userConfig_t);
                version = VERSION_USER;
                break;
        case TYPE_EVENTS:
                bytes = eventConfig.bytes;
                structSize = sizeof(eventConfig_t);
                version = VERSION_EVENTS;
                break;
        case TYPE_SYS_INFO:
                bytes = sysInfo.bytes;
                structSize = sizeof(sysInfo_t);
                version = VERSION_SYS_INFO;
                break;
        case TYPE_COMMAND:
                bytes = command.bytes;
                structSize = sizeof(command_t);
                version = VERSION_COMMAND;
                break;
        case TYPE_SET_TIME:
                bytes = setTime.bytes;
                structSize = sizeof(setTime_t);
                version = VERSION_SET_TIME;
                break;
        case TYPE_MISC_STATE:
                bytes = miscState.bytes;
                structSize = sizeof(miscState_t);
                version = VERSION_MISC_STATE;
                break;
        default:
                return BAD_STRUCT_TYPE;
        }

        packetID.type = type;

        if (isRequest)
        {
           packetID.request = 1;
           packetID.version = 0;
        }
        else
        {
           packetID.request = 0;
           packetID.version = version;
        }


        tx_buffer[0] = DLE;
        tx_buffer[1] = STX;

        // Length is written in index 2 and 3 later

        k = 4;
        if (packetID.byte == DLE)
        {
                tx_buffer[k++] = DLE;
        }
        tx_buffer[k++] = packetID.byte;

        if (!isRequest)
        {
          // Copy data from the struct
          for (i=0; i<structSize; i++)
          {
                  if (bytes[i] == DLE)
                  {
                          if(k >= PACKET_LENGTH - FOOTER_LENGTH)
                          {
                                  // Error: Too much data
                                  return TOO_MUCH_DATA;
                          }
                          tx_buffer[k++] = DLE;
                  }
                  if(k >= PACKET_LENGTH - FOOTER_LENGTH)
                  {
                          // Error: Too much data
                          return TOO_MUCH_DATA;
                  }
                  tx_buffer[k++] = bytes[i];
          }
        }

        tx_buf_len = k+FOOTER_LENGTH;
        // Write total packet length
        if (tx_buf_len == DLE)
        {
                tx_buffer[2] = DLE;
                tx_buffer[3] = DLE;
        }
        else
        {
                tx_buffer[2] = tx_buf_len;
                tx_buffer[3] = 0;
        }

        CalculateCRC16(tx_buffer,k+2,0,0x00);
        c = tx_buffer[k];
        d = tx_buffer[k+1];
        if (c == DLE)
        {
                tx_buffer[k++] = DLE;
        }
        tx_buffer[k++] = c;
        if (d == DLE)
        {
                tx_buffer[k++] = DLE;
        }
        tx_buffer[k++] = d;
        for(; k<tx_buf_len-2; k++)
        {
                tx_buffer[k] = 0;
        }

        tx_buffer[k++] = DLE;
        tx_buffer[k++] = ETX;

        // FIXME: remove - for testing only
        if(tx_buf_len != k)
        {
            return INVALID_PACKET_SIZE;
        }

        if (packetID.type > 0)
        {
           printd("TX PACKET %u\r\n", (unsigned int) packetID.type);
        }

        flushTx0_d();
        for(i=0;i<tx_buf_len;i++)
        {
            putchar0_d((unsigned int) tx_buffer[i]);
            //sprintf(TestString, "%02x ", (unsigned int) (tx_buffer[i]));
            //putString(TestString);
        }

        //printd("TX DONE\r\n");

        return 0;
}