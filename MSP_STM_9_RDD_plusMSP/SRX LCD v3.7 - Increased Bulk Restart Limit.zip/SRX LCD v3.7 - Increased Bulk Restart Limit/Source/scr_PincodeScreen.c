#include "scr_PincodeScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "scr_SetpointsEditScreen.h"
#include "scr_SetpointsScreen1.h"
#include "scr_SetpointsScreen2.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"
#include "general.h"


TLabel *DigCode[MAX_CODES];

scr_PincodeScreen_Type scr_PincodeScreen;

extern Tscreen* CurrentScreen;
extern Tscreen* PreviousScreen;

enum CODE_DIGIT curCode = FirstCode;

int trys = 0;

void Init_PincodeScreen(scr_PincodeScreen_Type *t)
{
     int x = 0;
     
     lbl_PincodeScreen_Instruction.Visible = true;
     TFT_Set_Font(lbl_PincodeScreen_Instruction.FontName,CL_WHITE, FO_HORIZONTAL);
     TFT_Write_Text(lbl_PincodeScreen_Instruction.Caption, lbl_PincodeScreen_Instruction.Left, lbl_PincodeScreen_Instruction.Top);


     if (CurrentScreen != &PincodeScreen)
     {

       DigCode[FirstCode] =  &lbl_PincodeScreen_Dig1;
       DigCode[SecondCode] = &lbl_PincodeScreen_Dig2;
       DigCode[ThirdCode] =  &lbl_PincodeScreen_Dig3;
       DigCode[LastCode] =   &lbl_PincodeScreen_Dig4;
       
       PreviousScreen = CurrentScreen;
     }
     scr_PincodeScreen.Code1 = '_';
     scr_PincodeScreen.Code2 = '_';
     scr_PincodeScreen.Code3 = '_';
     scr_PincodeScreen.Code4 = '_';
     
     if(PreviousScreen == (&SetpointsScreen1))
     PassSetpointValues1(&scr_SetpointsEditScreen);

     if(PreviousScreen == (&SetpointsScreen2))
     PassSetpointValues2(&scr_SetpointsEditScreen);

     for(x;x <= 4;x++)
     {
       if (x<4)
       {
       ClearLbl(DigCode[x],CurrentScreen->Color);
       DigCode[x]->Caption[0] = '_';  //initi underscore
       DigCode[x]->Caption[1] = 0x00;
       TFT_Set_Font(DigCode[x]->FontName,CL_WHITE, FO_HORIZONTAL);
       TFT_Write_Text(DigCode[x]->Caption, DigCode[x]->Left, DigCode[x]->Top);
       
       scr_PincodeScreen.PassCode[x] = ' '; //presets the passcode
       }
       
       else if(x==4)
       {
       scr_PincodeScreen.PassCode[x] = 0x00;
       curCode = FirstCode;
       }
     
     }
     DrawScreen(&PincodeScreen);
     SelectDigit(DigCode[curCode]);
     
}


void UpdatePincodeScreen(scr_PincodeScreen_Type *t)
{


}

void Save_PincodeScreen(scr_PincodeScreen_Type *t)
{


}

void PincodeLogic(unsigned char value)
{
  lbl_PincodeScreen_Instruction.Visible = 0;
  TFT_Set_Font(lbl_PincodeScreen_Instruction.FontName,CL_BLACK, FO_HORIZONTAL);
  TFT_Write_Text(lbl_PincodeScreen_Instruction.Caption,lbl_PincodeScreen_Instruction.Left,lbl_PincodeScreen_Instruction.Top);
  
    if(curCode < LastCode)
   {
     DeselectCode(DigCode[curCode]);
     ClearLbl(DigCode[curCode],CurrentScreen->Color);
     DigCode[curCode]->Caption[0] = '*';
     DigCode[curCode]->Caption[1] = 0x00;
     TFT_Set_Font(DigCode[curCode]->FontName,UNSELECTED_CODE_COLOR, FO_HORIZONTAL);
     TFT_Write_Text(DigCode[curCode]->Caption, DigCode[curCode]->Left, DigCode[curCode]->Top);
     scr_PincodeScreen.PassCode[curCode] = value;
     curCode += 1;
     SelectCode(DigCode[curCode]);
   }

    else if(curCode == LastCode)
   {

     ClearLbl(DigCode[curCode],CurrentScreen->Color);
     DigCode[curCode]->Caption[0] = '*';
     DigCode[curCode]->Caption[1] = 0x00;
     TFT_Set_Font(DigCode[curCode]->FontName,UNSELECTED_CODE_COLOR, FO_HORIZONTAL);
     TFT_Write_Text(DigCode[curCode]->Caption, DigCode[curCode]->Left, DigCode[curCode]->Top);
     scr_PincodeScreen.PassCode[curCode] = value;
     scr_PincodeScreen.PassCode[curCode+1] = 0x00;
     curCode += 1;  //finished pin state
   }
}

void DeleteCodeLogic(unsigned char deleted)
{
  if(curCode > FirstCode)
 {
   if(curCode != FinishedPin)
   DeselectCode(DigCode[curCode]);
   
   curCode -=1;
   ClearLbl(DigCode[curCode],CurrentScreen->Color);
   DigCode[curCode]->Caption[0] = deleted;  // UNDERSCORE
   DigCode[curCode]->Caption[1] = 0x00;
   TFT_Set_Font(DigCode[curCode]->FontName,UNSELECTED_CODE_COLOR, FO_HORIZONTAL);
   TFT_Write_Text(DigCode[curCode]->Caption, DigCode[curCode]->Left, DigCode[curCode]->Top);
   SelectCode(DigCode[curCode]);
   scr_PincodeScreen.PassCode[curCode] = deleted;

 }

 else if(curCode == FirstCode)
 {
 DeselectCode(DigCode[curCode]);
 ClearLbl(DigCode[curCode],CurrentScreen->Color);
 DigCode[curCode]->Caption[0] = deleted;
 DigCode[curCode]->Caption[1] = 0x00;
 TFT_Set_Font(DigCode[curCode]->FontName,SELECTED_CODE_COLOR, FO_HORIZONTAL);
 TFT_Write_Text(DigCode[curCode]->Caption, DigCode[curCode]->Left, DigCode[curCode]->Top);

 //re writes the instruction prompt
 lbl_PincodeScreen_Instruction.Visible = 0;
 TFT_Set_Font(lbl_PincodeScreen_Instruction.FontName,UNSELECTED_CODE_COLOR, FO_HORIZONTAL);
 TFT_Write_Text(lbl_PincodeScreen_Instruction.Caption, lbl_PincodeScreen_Instruction.Left, lbl_PincodeScreen_Instruction.Top);

 }
}





//Event Handlers
void btn_PincodeScreen_Num0OnDown() 
{
   PincodeLogic('0');
   


}

void btn_PincodeScreen_Num1OnDown() //Button Number 1
{
  PincodeLogic('1');
}

void btn_PincodeScreen_Num2OnDown() //Button Number 2
{
 PincodeLogic('2');
}

void btn_PincodeScreen_Num3OnDown() //Button Number 3
{
 PincodeLogic('3');
}

void btn_PincodeScreen_Num4OnDown() 
{
 PincodeLogic('4');
}

void btn_PincodeScreen_Num5OnDown() 
{
  PincodeLogic('5');
}

void btn_PincodeScreen_Num6OnDown() 
{
  PincodeLogic('6');
}

void btn_PincodeScreen_Num7OnDown() 
{
  PincodeLogic('7');
}

void btn_PincodeScreen_Num8OnDown() 
{
 PincodeLogic('8');
}

void btn_PincodeScreen_Num9OnDown() 
{
  PincodeLogic('9');
}

void btn_PincodeScreen_DeleteOnDown() 
{
  DeleteCodeLogic('_'); 
  
  if (DigCode[FirstCode]->Caption[0] == '_')  // UNDERSCORE
  {
    if (PreviousScreen == &SetpointsScreen1)
    Init_SetpointsScreen1(&scr_SetpointsScreen1);

    if (PreviousScreen == &SetpointsScreen2)
    Init_SetpointsScreen2(&scr_SetpointsScreen2);
  }
  
}

void btn_PincodeScreen_EnterOnDown() 
{
  int x = 0;
  int xx = 0;
  unsigned char PasswordX[5] = {'1','1','1','1','\0'};
  
  x = strncmp(scr_PincodeScreen.PassCode, Password, 4);
  xx = strncmp(scr_PincodeScreen.PassCode, PasswordX, 4);
  
   if((x==0) || (xx == 0)) //if the two strings are the same
   {
   
   if(PreviousScreen == &SetpointsScreen1)  // if data is entered correctly and Pincode Screen got entered from Screen 1
   CurrentScreen = &SetpointsScreen1;
                                                                                                                        // So when editing of data has been completed, accept makes return to correct Screen.
   if(PreviousScreen == &SetpointsScreen2)  // if data is entered correctly and Pincode Screen got entered from Screen 2
   CurrentScreen = &SetpointsScreen2;
   
   PassCodeFlag = true;
   trys = 0;
   
   Init_SetpointsEditScreen(&scr_SetpointsEditScreen);
   }
   
   else
   {
   //trys += 1;
   
   //if(trys == 2)
   //{
    //trys = 0;
    PassCodeFlag = false;

    if (PreviousScreen == &SetpointsScreen1)
    Init_SetpointsScreen1(&scr_SetpointsScreen1);

    if (PreviousScreen == &SetpointsScreen2)
    Init_SetpointsScreen2(&scr_SetpointsScreen2);

   }
   
   //printd("Label='%s'\r\n",Password); //prints out debug information
   //printd("Label='%s'\r\n",scr_PincodeScreen.PassCode); //prints out debug information
   
}