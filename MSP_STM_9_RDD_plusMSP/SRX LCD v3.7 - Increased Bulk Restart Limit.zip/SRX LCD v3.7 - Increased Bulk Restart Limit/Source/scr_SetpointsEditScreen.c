#include "scr_SetpointsEditScreen.h"
#include "scr_SetpointsScreen2.h"
#include "scr_SetpointsScreen1.h"
#include "scr_MainMenuScreen.h"
#include "scr_SettingsMenuScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "protocol.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"
#include "general.h"

TLabel *DigitValues[MAXIMUM_DIGITS];
TBox_Round *BackgroundPanel[1];

scr_SetpointsEditScreen_Type scr_SetpointsEditScreen;


extern Tscreen* CurrentScreen;
extern Tscreen* PreviousScreen;

enum SELECTED_DIGIT curDigit=FirstDigit;


void Init_SetpointsEditScreen(scr_SetpointsEditScreen_Type *screen)
{
     if (CurrentScreen != &SetpointsEditScreen)
     {
        DigitValues[FirstDigit]   = &lbl_SetpointsEditScreen_Digit1;
        DigitValues[SecondDigit]  = &lbl_SetpointsEditScreen_Digit2;
        DigitValues[ThirdDigit]   = &lbl_SetpointsEditScreen_Digit3;
        DigitValues[Decimal]      = &lbl_SetpointsEditScreen_Decimal;
        DigitValues[FourthDigit]  = &lbl_SetpointsEditScreen_Digit4;
        DigitValues[LastDigit]    = &lbl_SetpointsEditScreen_Digit5;
        
        BackgroundPanel[0] = &boxRound_SetpointsEditScreen_BackgroundPanel;
        PreviousScreen = CurrentScreen;
        
        for(curDigit=FirstDigit; curDigit<=LastDigit; curDigit++)
        {
                DigitValues[curDigit]->Caption[0] =  ' ';
                DigitValues[curDigit]->Caption[1] = 0x00;
                TFT_Write_Text(DigitValues[curDigit]->Caption, DigitValues[curDigit]->Left, DigitValues[curDigit]->Top);
        }
        curDigit = FirstDigit;
        
        if (PreviousScreen == (&SetpointsScreen1) || (&SetpointsScreen2) )
        {
         curDigit = FirstDigit;
        }
        DrawScreen(&SetpointsEditScreen);
        
        if(PreviousScreen == (&SetpointsScreen1))
        PassSetpointValues1(&scr_SetpointsEditScreen);

        if(PreviousScreen == (&SetpointsScreen2))
        PassSetpointValues2(&scr_SetpointsEditScreen);
        
        
        UpdateSetpointsEditScreen(&scr_SetpointsEditScreen);
        SelectDigit(DigitValues[curDigit]);



     }

}


void UpdateSetpointsEditScreen(scr_SetpointsEditScreen_Type *Screen)
{
 int i=0;
 char tempchar[7];
     
 if (CurrentScreen == &SetpointsEditScreen)
     {
     ClearLbl(&lbl_SetpointsEditScreen_ScreenTitle,CurrentScreen->Color); //clears the initial Screen title
     DrawLbl(&lbl_SetpointsEditScreen_ScreenTitle,Screen->SetpointTitle,MAXIMUM_TITLE_SIZE); //draws new title
     

    for (i ; i < MAXIMUM_DIGITS ; i++)
    {
        // saving the float format into a temporary char array
      if (Screen->DecimalPlaces == 2)
      {
      sprintf(tempChar,"%06.2f", Screen->RawFloatValue); //saves what is in RawFloat into local char array
      //tempchar[6] = 0x00;
      if (i == FourthDigit)           //Changes for Helevtica Font for G3 to move over Decimal place
      {
       DigitValues[i]->Left = 198;
      }
      }
      
      if (Screen->DecimalPlaces == 1)
      {
      sprintf(tempChar,"%+06.1f", Screen->RawFloatValue); //saves what is in RawFloat into local char array //%+06.1f
      //tempchar[6] = 0x00;
      if (i == FourthDigit)           //Changes for Helevtica Font for G3 to move over Decimal place
      {
       DigitValues[i]->Left = 230; //230
      }
      }
      

        if (curDigit == i)
        {
          ClearLbl(DigitValues[i],boxRound_SetpointsEditScreen_BackgroundPanel.Color);
          TFT_Set_Font(DigitValues[i]->FontName, SELECTED_DIGIT_COLOR, FO_HORIZONTAL);
        }
        
        else
        {
           ClearLbl(DigitValues[i],boxRound_SetpointsEditScreen_BackgroundPanel.Color);
           TFT_Set_Font(DigitValues[i]->FontName, UNSELECTED_DIGIT_COLOR, FO_HORIZONTAL);
        }
        
        if (DigitValues[i]->Visible == 1)
        {
          
          if (tempchar[i] == '+')
          tempchar[i] = '-';
          
          if(tempchar[i] == '-')
          {
          //tempchar[i] = '_';
          //DigitValues[i]->Top = 52;
          if (i == FirstDigit)           //Changes for Helevtica Font for G3 to move over Decimal place
          {
           DigitValues[i]->Left = 13;       //Changes for Helevtica Font for G3 to move over Minus Sign
          }
          }
          else
          {
          //DigitValues[i]->Top = 83;
          if (i == FirstDigit)           //Changes for Helevtica Font for G3 to move over Decimal place
          {
           DigitValues[i]->Left = 5;       //Changes for Helevtica Font for G3 to move over Minus Sign
          }
          }
          
          DigitValues[i]->Caption[0] =  tempChar[i];
          DigitValues[i]->Caption[1] = 0x00;
          TFT_Write_Text(DigitValues[i]->Caption, DigitValues[i]->Left, DigitValues[i]->Top);
        
        }
        
        if(lbl_SetpointsEditScreen_DigType.Visible == 1)
           {
            ClearLbl(&lbl_SetpointsEditScreen_DigType,boxRound_SetpointsEditScreen_BackgroundPanel.Color);
            strncpy(lbl_SetpointsEditScreen_DigType.Caption,Screen->DigType, 4);
            lbl_SetpointsEditScreen_DigType.Caption[4] = 0x00;
            TFT_Set_Font(lbl_SetpointsEditScreen_DigType.FontName, CL_BLACK, FO_HORIZONTAL);
            TFT_Write_Text(lbl_SetpointsEditScreen_DigType.Caption,lbl_SetpointsEditScreen_DigType.Left, lbl_SetpointsEditScreen_DigType.Top);
           }
        
        
      }
    }
}





void Save_SetpointsEditScreen(scr_SetpointsEditScreen_Type *Screen)      // This section is when updating values on Screen and saving the set values to struct.
{
     if (CurrentScreen == &SetpointsEditScreen)
     {
         char dig;   // array of 6 characters holding value of each digit
         float tot = 0.0f;
         int temp;
         int i=0;
         
           for (i ; i < MAXIMUM_DIGITS ; i++)
           {
               dig = DigitValues[i]->Caption[0];
               
               if((dig != '.')&&(dig != '+')&&(dig != '-')) //'_'))
               {
                temp = (int)(dig-'0');
                tot *= 10.0;
                tot += (float)temp;
               }
           }
           if (Screen->DecimalPlaces == 2)
           tot /= 100;
           
           if (Screen->DecimalPlaces == 1)
           tot /= 10;
           
           if (DigitValues[0]->Caption[0] == '-') //'_')
           tot *= -1;
           
           
          Screen->RawFloatValue = tot;

         }
}
     
//Supporting Functions
void NextDigitSelection()
{
if (curDigit == LastDigit)
   {
      DeselectDigit(DigitValues[curDigit]);
      curDigit = FirstDigit;
      SelectDigit(DigitValues[curDigit]);
      return;
   }
   
   
  DeselectDigit(DigitValues[curDigit]);
  SelectDigit(DigitValues[curDigit+1]);
  curDigit = curDigit+1;
}


//EventHandlers

void btn_SetpointsEditScreen_CancelOnClick() 
{
 // If any values have been changed before pressing this value, have to set it back to what the values were
  ClearLbl(&lbl_SetpointsEditScreen_ScreenTitle,CurrentScreen->Color);
  
  if(PreviousScreen == (&SetpointsScreen1))
  Init_SetpointsScreen1(&scr_SetpointsScreen1);

  if(PreviousScreen == (&SetpointsScreen2))
  Init_SetpointsScreen2(&scr_SetpointsScreen2);
  

}

void btn_SetpointsEditScreen_NextOnClick() 
{
   NextDigitSelection();
}

void btn_SetpointsEditScreen_UpOnClick() 
{
  if ((lbl_SetpointsEditScreen_DigType.Caption[0] == 'M') && (curDigit == FourthDigit))
  {
     IncrementDigitValue6(DigitValues[curDigit]);
  }
  else
  {
     IncrementDigitValue(DigitValues[curDigit]);
  }
}

void btn_SetpointsEditScreen_DownOnClick() 
{
  if ((lbl_SetpointsEditScreen_DigType.Caption[0] == 'M') && (curDigit == FourthDigit))
  {
     DecrementDigitValue6(DigitValues[curDigit]);
  }
  else
  {
     DecrementDigitValue(DigitValues[curDigit]);
  }
}

void btn_SetpointsEditScreen_AcceptOnClick() 
{
   Save_SetpointsEditScreen(&scr_SetpointsEditScreen);
   
  if(PreviousScreen == (&SetpointsScreen1))
  Init_SetpointsScreen1(&scr_SetpointsScreen1);

  if(PreviousScreen == (&SetpointsScreen2))
  Init_SetpointsScreen2(&scr_SetpointsScreen2);

}

void lbl_SetpointsEditScreen_Digit1OnClick()
{
      DeselectDigit(DigitValues[curDigit]);
      curDigit = FirstDigit;
      SelectDigit(DigitValues[curDigit]);
}

void lbl_SetpointsEditScreen_Digit2OnClick()
{
      DeselectDigit(DigitValues[curDigit]);
      curDigit = SecondDigit;
      SelectDigit(DigitValues[curDigit]);
}

void lbl_SetpointsEditScreen_Digit3OnClick()
{
      DeselectDigit(DigitValues[curDigit]);
      curDigit = ThirdDigit;
      SelectDigit(DigitValues[curDigit]);
}

void lbl_SetpointsEditScreen_Digit4OnClick()
{
      DeselectDigit(DigitValues[curDigit]);
      curDigit = FourthDigit;
      SelectDigit(DigitValues[curDigit]);
}

void lbl_SetpointsEditScreen_Digit5OnClick()
{
      DeselectDigit(DigitValues[curDigit]);
      curDigit = LastDigit;
      SelectDigit(DigitValues[curDigit]);
}