#include "debug.h"
#include "general.h"

#define USB_INPUT_REPORT_BYTES 64
#define USB_OUTPUT_REPORT_BYTES 64

// USB_debug Transmitter buffer
#define TX_BUFFER_SIZE_DEBUG 128
#define USB_WRITE_ATTEMPTS 3
char tx_buffer_usb_debug[TX_BUFFER_SIZE_DEBUG];
unsigned int tx_wr_index_usb_debug=0,tx_rd_index_usb_debug=0,tx_counter_usb_debug=0;

// USB_debug Receiver buffer
#define RX_BUFFER_SIZE_DEBUG 256
char rx_buffer_usb_debug[RX_BUFFER_SIZE_DEBUG];
unsigned int rx_wr_index_usb_debug=0,rx_rd_index_usb_debug=0,rx_counter_usb_debug=0;

// This flag is set on usb_debug Receiver buffer overflow
bit rx_buffer_overflow_usb_debug;

char readbuff[USB_INPUT_REPORT_BYTES];
char writebuff[USB_OUTPUT_REPORT_BYTES];

int CtrlCReceived = false;
char prevSentChar[4] = {0x00,0x00,0x00,0x00};
void sendChar(char c);

void InitBitsUSBDebug(void)
{
  USBIE_bit = 0;
  USBIP0_bit = 1;
  USBIP1_bit = 1;
  USBIP2_bit = 1;
  
  rx_wr_index_usb_debug=0;
  rx_rd_index_usb_debug=0;
  rx_counter_usb_debug=0;
  
  tx_wr_index_usb_debug=0;
  tx_rd_index_usb_debug=0;
  tx_counter_usb_debug=0;
  
  rx_buffer_overflow_usb_debug = 0;
}

void InitUSBDebug(void)
{
  USBIE_bit = 1;                   //enable USB intterupt
  HID_Enable(&readbuff,&writebuff);
}

void USB_ReadBuffers()
{    
     char uart_rd;
     int i;
     int len;
     len = (int) HID_Read();
     
     if (len == 0) return;
     
     for(i=0;(i<USB_INPUT_REPORT_BYTES);i++)
     {
      uart_rd = readbuff[i];
      
      if (uart_rd == 0x00) break;

      rx_buffer_usb_debug[rx_wr_index_usb_debug++]=uart_rd;
      if (rx_wr_index_usb_debug == RX_BUFFER_SIZE_DEBUG) rx_wr_index_usb_debug=0;
      if (++rx_counter_usb_debug == RX_BUFFER_SIZE_DEBUG)
      {
        rx_counter_usb_debug=0;
        rx_buffer_overflow_usb_debug=1;
      };
     }
}

void USB_WriteBuffers()
{
    int i = 0;
    int count = 0;
     
    while (tx_counter_usb_debug)
    {
        --tx_counter_usb_debug;
        writebuff[i] = tx_buffer_usb_debug[tx_rd_index_usb_debug++];
        i++;
        if (tx_rd_index_usb_debug == TX_BUFFER_SIZE_DEBUG) tx_rd_index_usb_debug=0;
        if (i >= USB_OUTPUT_REPORT_BYTES)
        {
            int remainingAttempts = USB_WRITE_ATTEMPTS;
            while (remainingAttempts > 0)
            {
                remainingAttempts--;
                if (HID_Write(&writebuff, USB_OUTPUT_REPORT_BYTES))
                {
                    break;
                }
            }

            i = 0;
        }
    }

    if (i > 0)
    {
        int remainingAttempts = USB_WRITE_ATTEMPTS;
        for(;i<USB_OUTPUT_REPORT_BYTES;i++)
        {
            writebuff[i] = 0x00;
        }
        while (remainingAttempts > 0)
        {
            remainingAttempts--;
            if (HID_Write(&writebuff, USB_OUTPUT_REPORT_BYTES))
            {
                break;
            }
        }
    }
}

void putchar(char c)
{
      if (c == '\r')
      {
        sendChar('\r');
        sendChar('\n');
      }
      else
      {
        if ( (c == '\n')  && (prevSentChar[0] != '\r'))
        {
                sendChar('\r');
                sendChar('\n');
        }
        else
        {
                if (c != '\n')
                {
                        sendChar(c);
                }
        }
      }


      prevSentChar[3] = prevSentChar[2];
      prevSentChar[2] = prevSentChar[1];
      prevSentChar[1] = prevSentChar[0];
      prevSentChar[0] = c;

}

void sendChar(char c)
{
    if (tx_counter_usb_debug == TX_BUFFER_SIZE_DEBUG)
    {
        USB_WriteBuffers();
    }
    tx_buffer_usb_debug[tx_wr_index_usb_debug++]=c;
    if (tx_wr_index_usb_debug == TX_BUFFER_SIZE_DEBUG) tx_wr_index_usb_debug=0;
    ++tx_counter_usb_debug;
}

char getchar(void)
{
  char datac;
  while (rx_counter_usb_debug==0);
  datac=rx_buffer_usb_debug[rx_rd_index_usb_debug++];
  if (rx_rd_index_usb_debug == RX_BUFFER_SIZE_DEBUG) rx_rd_index_usb_debug=0;
  --rx_counter_usb_debug;
  return datac;
}

int kbhit(void)
{
    return (rx_counter_usb_debug != 0);
}

void putString(char *s)
{
     while(*s != 0x00)
     {
        putchar(*s);
        s++;
     }
}

void UpdateUSBBuffers()
{
  USB_ReadBuffers();
  USB_WriteBuffers();
}

void USB_Handler() iv IVT_USB_1 ilevel 7 ics ICS_SRS {
     USB_Interrupt_Proc();
}