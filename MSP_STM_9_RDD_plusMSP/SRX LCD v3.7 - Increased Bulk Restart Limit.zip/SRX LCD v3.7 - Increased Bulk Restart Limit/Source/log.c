#include "general.h"
#include "__Time.h"
#include "rtc.h"
#include "cmdlib.h"
#include "log.h"
#include "fram.h"
#include "crc16.h"

typedef struct
{
    unsigned long startIndex;
    unsigned long numEntries;
    unsigned long startID;
    unsigned long startEventIndex;
    unsigned long numEventEntries;
    unsigned long startEventID;
    unsigned long : 32; // Some extra space for later
    unsigned long : 32;
    unsigned int logPeriod;
    unsigned int version;
} LogHeader;

typedef struct
{
    unsigned long timestamp;

    int pvVoltage;
    int pvCurrent;
    int outputVoltage;
    int outputCurrent;
    int ocVoltage;
    int pvPower;
    float outputCharge;
} CompressedLogEntry;

typedef struct
{
    unsigned long timestamp;

    unsigned char lowOutVoltWarn : 1;
    unsigned char lowOutVoltFault : 1;
    unsigned char lowOutVoltGenSet : 1;
    unsigned char highOutVoltFault : 1;
    unsigned char highOutCurrentFault : 1;
    unsigned char highDischargeCurrentFault : 1;
    unsigned char highBatteryTempFault : 1;
    unsigned char inputBreakerOpen : 1; // Not used
    unsigned char outputBreakerOpen : 1; // Not used
    unsigned char tempSensorFault : 1;
    unsigned char negativePVCurrentSutdown : 1;
    unsigned char highPVCurrentShutdown : 1;
    unsigned char highPVVoltShutdown : 1;
    unsigned char highOutCurrentShutdown : 1;
    unsigned char highOutVoltShutdown : 1;
    unsigned char highHeatSinkTemp : 1;
    unsigned char fanFault : 1;
    unsigned char logFull : 1;
    unsigned char solarPanelMissing : 1;
    unsigned char configValueOutOfRange : 1;

    unsigned char config_factoryCRC : 1;
    unsigned char config_factoryCheck : 1;
    unsigned char config_userCRC : 1;
    unsigned char config_userCheck : 1;
    unsigned char config_eventCRC : 1;
    unsigned char config_eventCheck : 1;
    unsigned char control_isSlave : 1;
    unsigned char control_usingBulk : 1;
    unsigned char control_mode : 2;
    unsigned char control_outputEnabled : 1;
    unsigned char control_smartShutdown : 1;
    unsigned char control_autoOn : 1;
    unsigned char control_remoteShutdown : 1;
    unsigned char safety_operation : 1;

    unsigned char forcedReset : 1;
    unsigned char outputOn : 1;
    unsigned char outputOff : 1;
    
    unsigned char : 2;
} CompressedEventLogEntry;

const unsigned int LOG_CRC_SIZE = 2;
const unsigned int LOG_HEADER_SIZE = sizeof(LogHeader) + LOG_CRC_SIZE;
const unsigned int LOG_COMPRESSED_ENTRY_SIZE = sizeof(CompressedLogEntry) + LOG_CRC_SIZE;
const unsigned int LOG_COMPRESSED_EVENT_ENTRY_SIZE = sizeof(CompressedEventLogEntry) + LOG_CRC_SIZE;
const unsigned int LOG_TEMP_BUFFER_SIZE = LOG_HEADER_SIZE > LOG_COMPRESSED_ENTRY_SIZE ? LOG_HEADER_SIZE : LOG_COMPRESSED_ENTRY_SIZE;
const unsigned long LOG_MAX_VALUE = LOG_BAD_VALUE - 1;
const unsigned int LOG_VERSION = 1;
const int LOG_WRITE_ATTEMPTS = 2;
const int LOG_READ_ATTEMPTS = 2;
const float LOG_USAGE = 0.9;
const int DEFAULT_LOG_PERIOD = 1;   // 60
const int MAX_LOG_PERIOD = 1;  // 60
const int LOG_VERIFY_WRITE = true;

const float LOG_PVVOLT_BASE = 300.0;
const float LOG_OUTVOLT_BASE = 255.0;
const float LOG_PVCURR_BASE = 285.0;
const float LOG_OUTCURR_BASE = 250.0;
const float LOG_PVPOWER_BASE = ( LOG_PVVOLT_BASE * LOG_PVCURR_BASE );
const float LOG_CHARGE_UPDATE_RATE_HZ = 2.0;
const float LOG_CHARGE_BASE = LOG_OUTCURR_BASE / (60*60 * LOG_CHARGE_UPDATE_RATE_HZ);

// There are 128 bytes before the header to allow for config data
unsigned long logHeaderStart = 0x00022;
unsigned long logStart;
unsigned long logLength;
unsigned long logMaxEntries;
unsigned long eventLogStart;
unsigned long eventLogLength;
unsigned long eventLogMaxEntries;

unsigned char logTempReadBuffer[LOG_TEMP_BUFFER_SIZE];
unsigned char logTempWriteBuffer[LOG_TEMP_BUFFER_SIZE];
LogHeader logHeader;

unsigned long logLastTelemtryTime;
unsigned long logStartTime;
unsigned long logEndTime;
unsigned int logSampleCount;
LogEntry currentLogEntry;
EventLogEntry currentEventLogEntry;
CompressedLogEntry compressedLogEntry;
CompressedEventLogEntry compressedEventLogEntry;
int eventLogSet = false;
int logHeaderCRCGood = false;
int logDidReset = false;

int LogReadBuffer(unsigned long memAddr, unsigned char* buffer, int len);
int LogWriteBuffer(unsigned long memAddr, unsigned char* buffer, int len);

void LogInit()
{
    int doLogReset = false;
    
    logStart = logHeaderStart + LOG_HEADER_SIZE;
    logMaxEntries = (unsigned long)((FRAM_MEMORY_SIZE - LOG_HEADER_SIZE - logHeaderStart) * LOG_USAGE / LOG_COMPRESSED_ENTRY_SIZE);
    logLength = LOG_COMPRESSED_ENTRY_SIZE * logMaxEntries;
    eventLogStart = logStart + logLength;
    eventLogMaxEntries = (FRAM_MEMORY_SIZE - LOG_HEADER_SIZE - logHeaderStart - logLength) / LOG_COMPRESSED_EVENT_ENTRY_SIZE;
    eventLogLength = LOG_COMPRESSED_EVENT_ENTRY_SIZE * eventLogMaxEntries;

    if (LogReadBuffer(logHeaderStart, (unsigned char*) &logHeader, sizeof(LogHeader)))
    {
        logHeaderCRCGood = true;

        if (logHeader.version != LOG_VERSION)
        {
            // Update current log to new version if needed. Just clear it for now.
            doLogReset = true;
        }
    }
    else
    {
        printe("Log init failed\r\n");
        logHeaderCRCGood = false;
        doLogReset = true;
    }
    
    if (doLogReset)
    {
        printp("Resetting log...\r\n");
        logDidReset = true;
        if (!LogReset(LOG_RESET_ALL))
        {
            printe("Log reset failed\r\n");
        }
    }
    else
    {
        logDidReset = false;
    }
    
    logLastTelemtryTime = 0;
    logStartTime = 0;
    logEndTime = 0;
    logSampleCount = 0;
    memset(&currentLogEntry, 0, sizeof(LogEntry));
    memset(&currentEventLogEntry, 0, sizeof(EventLogEntry));
    memset(&compressedLogEntry, 0, sizeof(CompressedLogEntry));
    memset(&compressedEventLogEntry, 0, sizeof(CompressedEventLogEntry));
    eventLogSet = false;
}

void LogAddSample()
{
    currentLogEntry.pvVoltage += telemetry.pvVoltage;
    currentLogEntry.pvCurrent += telemetry.pvCurrent;
    currentLogEntry.outputVoltage += telemetry.outputVoltage;
    currentLogEntry.outputCurrent += telemetry.outputCurrent;
    currentLogEntry.ocVoltage += telemetry.ocVoltage;
    currentLogEntry.outputCharge = telemetry.outputCharge;
    currentLogEntry.pvPower += telemetry.pvPower;
    logSampleCount++;
}

void LogStartEntry()
{
    TimeStruct ts;
    
    currentLogEntry.day = curIntTime.date;
    currentLogEntry.month = curIntTime.month;
    currentLogEntry.year = curIntTime.year + 2000;
    currentLogEntry.hour = curIntTime.hour;
    currentLogEntry.min = (curIntTime.min / logHeader.logPeriod) * logHeader.logPeriod;
    currentLogEntry.sec = 0;
    
    ts.ss = currentLogEntry.sec;
    ts.mn = currentLogEntry.min;
    ts.hh = currentLogEntry.hour;
    ts.md = currentLogEntry.day;
    ts.mo = currentLogEntry.month;
    ts.yy = currentLogEntry.year;

    logStartTime = Time_dateToEpoch(&ts);
    logEndTime = logStartTime + logHeader.logPeriod * 60;
    
    currentLogEntry.pvVoltage = 0;
    currentLogEntry.pvCurrent = 0;
    currentLogEntry.outputVoltage = 0;
    currentLogEntry.outputCurrent = 0;
    currentLogEntry.ocVoltage = 0;
    currentLogEntry.outputCharge = 0;
    currentLogEntry.pvPower = 0;
    logSampleCount = 0;
    
    LogAddSample();
}

void LogEvent()
{
    currentEventLogEntry.day = curIntTime.date;
    currentEventLogEntry.month = curIntTime.month;
    currentEventLogEntry.year = curIntTime.year + 2000;
    currentEventLogEntry.hour = curIntTime.hour;
    currentEventLogEntry.min = curIntTime.min;
    currentEventLogEntry.sec = curIntTime.sec;
    currentEventLogEntry.eventFlags.flags = telemetry.eventFlags.flags;
    currentEventLogEntry.status.status = telemetry.status.status;
    currentEventLogEntry.outputOn = 0;
    currentEventLogEntry.outputOff = 0;
    currentEventLogEntry.forcedReset = false;
    LogAddEventEntry(&currentEventLogEntry);
}

void LogMidnightReset()
{
    currentEventLogEntry.day = curIntTime.date;
    currentEventLogEntry.month = curIntTime.month;
    currentEventLogEntry.year = curIntTime.year + 2000;
    currentEventLogEntry.hour = curIntTime.hour;
    currentEventLogEntry.min = curIntTime.min;
    currentEventLogEntry.sec = curIntTime.sec;
    currentEventLogEntry.eventFlags.flags = telemetry.eventFlags.flags;
    currentEventLogEntry.status.status = telemetry.status.status;
    currentEventLogEntry.outputOn = 0;
    currentEventLogEntry.outputOff = 0;
    currentEventLogEntry.forcedReset = true;
    LogAddEventEntry(&currentEventLogEntry);
}

void LogPower(int on)
{
    currentEventLogEntry.day = curIntTime.date;
    currentEventLogEntry.month = curIntTime.month;
    currentEventLogEntry.year = curIntTime.year + 2000;
    currentEventLogEntry.hour = curIntTime.hour;
    currentEventLogEntry.min = curIntTime.min;
    currentEventLogEntry.sec = curIntTime.sec;
    currentEventLogEntry.eventFlags.flags = telemetry.eventFlags.flags;
    currentEventLogEntry.status.status = telemetry.status.status;
    if (on)
    {
       currentEventLogEntry.outputOn = 1;
       currentEventLogEntry.outputOff = 0;
    }
    else
    {
       currentEventLogEntry.outputOn = 0;
       currentEventLogEntry.outputOff = 1;
    }
    currentEventLogEntry.forcedReset = false;
    LogAddEventEntry(&currentEventLogEntry);
}

void LogCheck()
{
    unsigned long currentTime;
    unsigned long tt = telemetry.time / 1000;

    TimeStruct ts;
    ts.ss = curIntTime.sec;
    ts.mn = curIntTime.min;
    ts.hh = curIntTime.hour;
    ts.md = curIntTime.date;
    ts.mo = curIntTime.month;
    ts.yy = curIntTime.year + 2000;

    currentTime = Time_dateToEpoch(&ts);
    
    if (telemetry.time != 0 &&
        (!eventLogSet || telemetry.eventFlags.flags != currentEventLogEntry.eventFlags.flags ||
        (telemetry.status.status & 0x01FF00000000003F) != (currentEventLogEntry.status.status & 0x01FF00000000003F)))
    {
        eventLogSet = true;
        LogEvent();
    }
    
    if (!logSampleCount)
    {
        if (tt != logLastTelemtryTime)
        {
            if (telemetry.time != 0)
            {
                 LogStartEntry();
            }
            logLastTelemtryTime = tt;
        }
    }
    else
    {
        if (currentTime < logStartTime || currentTime >= logEndTime)
        {
            currentLogEntry.pvVoltage /= logSampleCount;
            currentLogEntry.pvCurrent /= logSampleCount;
            currentLogEntry.outputVoltage /= logSampleCount;
            currentLogEntry.outputCurrent /= logSampleCount;
            currentLogEntry.ocVoltage /= logSampleCount;
            currentLogEntry.pvPower /= logSampleCount;
            LogAddEntry(&currentLogEntry);
            
            logStartTime = 0;
            logEndTime = 0;
            logSampleCount = 0;
        }
        
        if (tt != logLastTelemtryTime)
        {
            if (telemetry.time != 0)
            {
                if (logSampleCount)
                {
                    LogAddSample();
                }
                else
                {
                    LogStartEntry();
                }
            }
            logLastTelemtryTime = tt;
        }
    }
}

void LogPrintInfo()
{
    printf("Start index: %ld\r\n", logHeader.startIndex);
    printf("Entries: %ld\r\n", logHeader.numEntries);
    printf("Start ID: %ld\r\n", logHeader.startID);
    printf("Max entries: %ld\r\n", logMaxEntries);
    printf("Start event index: %ld\r\n", logHeader.startEventIndex);
    printf("Event entries: %ld\r\n", logHeader.numEventEntries);
    printf("Start event ID: %ld\r\n", logHeader.startEventID);
    printf("Max event entries: %ld\r\n", eventLogMaxEntries);
    printf("Period: %d\r\n", logHeader.logPeriod);
    printf("Version: %d\r\n", logHeader.version);
    if (logDidReset)
    {
        printf("Warning: Log was reset!\r\n");
    }
    if (!logHeaderCRCGood)
    {
        printf("Error: Bad log header CRC!\r\n");
    }
}

#define LOG_COMPRESS_FLOAT(val, base) ((int)(val/base * 4096.0f))
#define LOG_COMPRESS_FLOAT_LONG(val, base) ((long)(val/base * 4096.0f))
#define LOG_DECOMPRESS_FLOAT(val, base) (val/4096.0f * base)

void LogCompressEntry(LogEntry* pLogEntry, CompressedLogEntry* pCompressedLogEntry)
{
    TimeStruct ts;
    ts.ss = pLogEntry->sec;
    ts.mn = pLogEntry->min;
    ts.hh = pLogEntry->hour;
    ts.md = pLogEntry->day;
    ts.mo = pLogEntry->month;
    ts.yy = pLogEntry->year;
    
    pCompressedLogEntry->timestamp = Time_dateToEpoch(&ts);

    pCompressedLogEntry->pvVoltage = LOG_COMPRESS_FLOAT(pLogEntry->pvVoltage, LOG_PVVOLT_BASE);
    pCompressedLogEntry->pvCurrent = LOG_COMPRESS_FLOAT(pLogEntry->pvCurrent, LOG_PVCURR_BASE);
    pCompressedLogEntry->outputVoltage = LOG_COMPRESS_FLOAT(pLogEntry->outputVoltage, LOG_OUTVOLT_BASE);
    pCompressedLogEntry->outputCurrent = LOG_COMPRESS_FLOAT(pLogEntry->outputCurrent, LOG_OUTCURR_BASE);
    pCompressedLogEntry->ocVoltage = LOG_COMPRESS_FLOAT(pLogEntry->ocVoltage, LOG_PVVOLT_BASE);
    pCompressedLogEntry->pvPower = LOG_COMPRESS_FLOAT(pLogEntry->pvPower, LOG_PVPOWER_BASE);
    pCompressedLogEntry->outputCharge = pLogEntry->outputCharge;
}

void LogUncompressEntry(CompressedLogEntry* pCompressedLogEntry, LogEntry* pLogEntry)
{
    TimeStruct ts;
    Time_epochToDate(pCompressedLogEntry->timestamp, &ts);
    
    pLogEntry->sec = ts.ss;
    pLogEntry->min = ts.mn;
    pLogEntry->hour = ts.hh;
    pLogEntry->day = ts.md;
    pLogEntry->month = ts.mo;
    pLogEntry->year = ts.yy;

    pLogEntry->pvVoltage = LOG_DECOMPRESS_FLOAT(pCompressedLogEntry->pvVoltage, LOG_PVVOLT_BASE);
    pLogEntry->pvCurrent = LOG_DECOMPRESS_FLOAT(pCompressedLogEntry->pvCurrent, LOG_PVCURR_BASE);
    pLogEntry->outputVoltage = LOG_DECOMPRESS_FLOAT(pCompressedLogEntry->outputVoltage, LOG_OUTVOLT_BASE);
    pLogEntry->outputCurrent = LOG_DECOMPRESS_FLOAT(pCompressedLogEntry->outputCurrent, LOG_OUTCURR_BASE);
    pLogEntry->ocVoltage = LOG_DECOMPRESS_FLOAT(pCompressedLogEntry->ocVoltage, LOG_PVVOLT_BASE);
    pLogEntry->pvPower = LOG_DECOMPRESS_FLOAT(pCompressedLogEntry->pvPower, LOG_PVPOWER_BASE);
    pLogEntry->outputCharge = pCompressedLogEntry->outputCharge;
}

void LogCompressEventEntry(EventLogEntry* pLogEntry, CompressedEventLogEntry* pCompressedLogEntry)
{
    TimeStruct ts;
    ts.ss = pLogEntry->sec;
    ts.mn = pLogEntry->min;
    ts.hh = pLogEntry->hour;
    ts.md = pLogEntry->day;
    ts.mo = pLogEntry->month;
    ts.yy = pLogEntry->year;

    pCompressedLogEntry->timestamp = Time_dateToEpoch(&ts);

    pCompressedLogEntry->lowOutVoltWarn = pLogEntry->eventFlags.lowOutVoltWarn;
    pCompressedLogEntry->lowOutVoltFault = pLogEntry->eventFlags.lowOutVoltFault;
    pCompressedLogEntry->lowOutVoltGenSet = pLogEntry->eventFlags.lowOutVoltGenSet;
    pCompressedLogEntry->highOutVoltFault = pLogEntry->eventFlags.highOutVoltFault;
    pCompressedLogEntry->highOutCurrentFault = pLogEntry->eventFlags.highOutCurrentFault;
    pCompressedLogEntry->highDischargeCurrentFault = pLogEntry->eventFlags.highDischargeCurrentFault;
    pCompressedLogEntry->highBatteryTempFault = pLogEntry->eventFlags.highBatteryTempFault;
    pCompressedLogEntry->inputBreakerOpen = pLogEntry->eventFlags.inputBreakerOpen;
    pCompressedLogEntry->outputBreakerOpen = pLogEntry->eventFlags.outputBreakerOpen;
    pCompressedLogEntry->tempSensorFault = pLogEntry->eventFlags.tempSensorFault;
    pCompressedLogEntry->negativePVCurrentSutdown = pLogEntry->eventFlags.negativePVCurrentSutdown;
    pCompressedLogEntry->highPVCurrentShutdown = pLogEntry->eventFlags.highPVCurrentShutdown;
    pCompressedLogEntry->highPVVoltShutdown = pLogEntry->eventFlags.highPVVoltShutdown;
    pCompressedLogEntry->highOutCurrentShutdown = pLogEntry->eventFlags.highOutCurrentShutdown;
    pCompressedLogEntry->highOutVoltShutdown = pLogEntry->eventFlags.highOutVoltShutdown;
    pCompressedLogEntry->highHeatSinkTemp = pLogEntry->eventFlags.highHeatSinkTemp;
    pCompressedLogEntry->fanFault = pLogEntry->eventFlags.fanFault;
    pCompressedLogEntry->logFull = pLogEntry->eventFlags.logFull;
    pCompressedLogEntry->solarPanelMissing = pLogEntry->eventFlags.solarPanelMissing;
    pCompressedLogEntry->configValueOutOfRange = pLogEntry->eventFlags.configValueOutOfRange;

    pCompressedLogEntry->config_factoryCRC = pLogEntry->status.config_factoryCRC;
    pCompressedLogEntry->config_factoryCheck = pLogEntry->status.config_factoryCheck;
    pCompressedLogEntry->config_userCRC = pLogEntry->status.config_userCRC;
    pCompressedLogEntry->config_userCheck = pLogEntry->status.config_userCheck;
    pCompressedLogEntry->config_eventCRC = pLogEntry->status.config_eventCRC;
    pCompressedLogEntry->config_eventCheck = pLogEntry->status.config_eventCheck;
    pCompressedLogEntry->control_isSlave = pLogEntry->status.control_isSlave;
    pCompressedLogEntry->control_usingBulk = pLogEntry->status.control_usingBulk;
    pCompressedLogEntry->control_mode = pLogEntry->status.control_mode;
    pCompressedLogEntry->control_outputEnabled = pLogEntry->status.control_outputEnabled;
    pCompressedLogEntry->control_smartShutdown = pLogEntry->status.control_smartShutdown;
    pCompressedLogEntry->control_autoOn = pLogEntry->status.control_autoOn;
    pCompressedLogEntry->control_remoteShutdown = pLogEntry->status.control_remoteShutdown;
    pCompressedLogEntry->safety_operation = pLogEntry->status.safety_operation;

    pCompressedLogEntry->outputOn = pLogEntry->outputOn;
    pCompressedLogEntry->outputOff = pLogEntry->outputOff;
    pCompressedLogEntry->forcedReset = pLogEntry->forcedReset;
}

void LogUncompressEventEntry(CompressedEventLogEntry* pCompressedLogEntry, EventLogEntry* pLogEntry)
{
    TimeStruct ts;
    Time_epochToDate(pCompressedLogEntry->timestamp, &ts);

    pLogEntry->sec = ts.ss;
    pLogEntry->min = ts.mn;
    pLogEntry->hour = ts.hh;
    pLogEntry->day = ts.md;
    pLogEntry->month = ts.mo;
    pLogEntry->year = ts.yy;

    pLogEntry->eventFlags.lowOutVoltWarn = pCompressedLogEntry->lowOutVoltWarn;
    pLogEntry->eventFlags.lowOutVoltFault = pCompressedLogEntry->lowOutVoltFault;
    pLogEntry->eventFlags.lowOutVoltGenSet = pCompressedLogEntry->lowOutVoltGenSet;
    pLogEntry->eventFlags.highOutVoltFault = pCompressedLogEntry->highOutVoltFault;
    pLogEntry->eventFlags.highOutCurrentFault = pCompressedLogEntry->highOutCurrentFault;
    pLogEntry->eventFlags.highDischargeCurrentFault = pCompressedLogEntry->highDischargeCurrentFault;
    pLogEntry->eventFlags.highBatteryTempFault = pCompressedLogEntry->highBatteryTempFault;
    pLogEntry->eventFlags.inputBreakerOpen = pCompressedLogEntry->inputBreakerOpen;
    pLogEntry->eventFlags.outputBreakerOpen = pCompressedLogEntry->outputBreakerOpen;
    pLogEntry->eventFlags.tempSensorFault = pCompressedLogEntry->tempSensorFault;
    pLogEntry->eventFlags.negativePVCurrentSutdown = pCompressedLogEntry->negativePVCurrentSutdown;
    pLogEntry->eventFlags.highPVCurrentShutdown = pCompressedLogEntry->highPVCurrentShutdown;
    pLogEntry->eventFlags.highPVVoltShutdown = pCompressedLogEntry->highPVVoltShutdown;
    pLogEntry->eventFlags.highOutCurrentShutdown = pCompressedLogEntry->highOutCurrentShutdown;
    pLogEntry->eventFlags.highOutVoltShutdown = pCompressedLogEntry->highOutVoltShutdown;
    pLogEntry->eventFlags.highHeatSinkTemp = pCompressedLogEntry->highHeatSinkTemp;
    pLogEntry->eventFlags.fanFault = pCompressedLogEntry->fanFault;
    pLogEntry->eventFlags.logFull = pCompressedLogEntry->logFull;
    pLogEntry->eventFlags.solarPanelMissing = pCompressedLogEntry->solarPanelMissing;
    pLogEntry->eventFlags.configValueOutOfRange = pCompressedLogEntry->configValueOutOfRange;

    pLogEntry->status.config_factoryCRC = pCompressedLogEntry->config_factoryCRC;
    pLogEntry->status.config_factoryCheck = pCompressedLogEntry->config_factoryCheck;
    pLogEntry->status.config_userCRC = pCompressedLogEntry->config_userCRC;
    pLogEntry->status.config_userCheck = pCompressedLogEntry->config_userCheck;
    pLogEntry->status.config_eventCRC = pCompressedLogEntry->config_eventCRC;
    pLogEntry->status.config_eventCheck = pCompressedLogEntry->config_eventCheck;
    pLogEntry->status.control_isSlave = pCompressedLogEntry->control_isSlave;
    pLogEntry->status.control_usingBulk = pCompressedLogEntry->control_usingBulk;
    pLogEntry->status.control_mode = pCompressedLogEntry->control_mode;
    pLogEntry->status.control_outputEnabled = pCompressedLogEntry->control_outputEnabled;
    pLogEntry->status.control_smartShutdown = pCompressedLogEntry->control_smartShutdown;
    pLogEntry->status.control_autoOn = pCompressedLogEntry->control_autoOn;
    pLogEntry->status.control_remoteShutdown = pCompressedLogEntry->control_remoteShutdown;
    pLogEntry->status.safety_operation = pCompressedLogEntry->safety_operation;

    pLogEntry->outputOn = pCompressedLogEntry->outputOn;
    pLogEntry->outputOff = pCompressedLogEntry->outputOff;
    pLogEntry->forcedReset = pCompressedLogEntry->forcedReset;
}

int LogReadBuffer(unsigned long memAddr, unsigned char* buffer, int len)
{
    int attempt = 0;

    if (len <= 0)
    {
        return false;
    }
    
    if (len > LOG_TEMP_BUFFER_SIZE - LOG_CRC_SIZE)
    {
        printe("Can't read to log buffer: too long.\r\n");
        return false;
    }

    while (attempt < LOG_READ_ATTEMPTS)
    {
        if (!FRAMReadBuffer(memAddr, logTempReadBuffer, len + LOG_CRC_SIZE))
        {
            return false;
        }

        if (CalculateCRC16(logTempReadBuffer, len + LOG_CRC_SIZE, true, 0x00) == 2)
        {
            memcpy(buffer, logTempReadBuffer, len);
            return true;
        }
        else
        {
            attempt++;
        }
    }
    return false;
}

int LogWriteBuffer(unsigned long memAddr, unsigned char* buffer, int len)
{
    int attempt = 0;

    if (len <= 0)
    {
        return false;
    }
    
    if (len > LOG_TEMP_BUFFER_SIZE - LOG_CRC_SIZE)
    {
        printe("Can't write fram log buffer: too long.\r\n");
        return false;
    }

    memcpy(logTempWriteBuffer, buffer, len);
    CalculateCRC16(logTempWriteBuffer, len + LOG_CRC_SIZE, false, 0x00);

    while (attempt < LOG_WRITE_ATTEMPTS)
    {
        if (!FRAMWriteBuffer(memAddr, logTempWriteBuffer, len + LOG_CRC_SIZE))
        {
            return false;
        }
        
        if (LOG_VERIFY_WRITE)
        {
            if (!FRAMReadBuffer(memAddr, logTempReadBuffer, len + LOG_CRC_SIZE))
            {
                return false;
            }

            if (CalculateCRC16(logTempReadBuffer, len + LOG_CRC_SIZE, true, 0x00) == 2)
            {
                return true;
            }
        }
        else
        {
            return true;
        }

        attempt++;
    }
    return false;
}

unsigned long LogGetEntryCount()
{
    return logHeader.numEntries;
}

unsigned long LogGetEntryID(unsigned long index)
{
    if (index >= logHeader.numEntries)
    {
        return LOG_BAD_VALUE;
    }
    
    return (index + logHeader.startID) % LOG_MAX_VALUE;
}

unsigned long LogGetEntryIndex(unsigned long id)
{
    unsigned long index;
    
    if (id == LOG_BAD_VALUE)
    {
        return LOG_BAD_VALUE;
    }
    
    if (id >= logHeader.startID)
    {
        index = id - logHeader.startID;
    }
    else
    {
        index = LOG_MAX_VALUE + 1 - logHeader.startID + id;
    }
    
    if (index >= logHeader.numEntries)
    {
        return LOG_BAD_VALUE;
    }
    else
    {
        return index;
    }
}

unsigned long LogGetMaxEntries()
{
    return logMaxEntries;
}

unsigned long LogGetEventEntryCount()
{
    return logHeader.numEventEntries;
}

unsigned long LogGetEventEntryID(unsigned long index)
{
    if (index >= logHeader.numEventEntries)
    {
        return LOG_BAD_VALUE;
    }
    return (index + logHeader.startEventID) % LOG_MAX_VALUE;
}

unsigned long LogGetEventEntryIndex(unsigned long id)
{
    unsigned long index;

    if (id == LOG_BAD_VALUE)
    {
        return LOG_BAD_VALUE;
    }

    if (id >= logHeader.startEventID)
    {
        index = id - logHeader.startEventID;
    }
    else
    {
        index = LOG_MAX_VALUE + 1 - logHeader.startEventID + id;
    }

    if (index >= logHeader.numEventEntries)
    {
        return LOG_BAD_VALUE;
    }
    else
    {
        return index;
    }
}

unsigned long LogGetEventMaxEntries()
{
    return eventLogMaxEntries;
}

int LogGetEntry(unsigned long index, LogEntry* logEntry)
{
    unsigned long realIndex;
    unsigned long addr;

    if (index >= logHeader.numEntries)
    {
        return false;
    }
    realIndex = (index + logHeader.startIndex) % logMaxEntries;
    addr = logStart + realIndex * LOG_COMPRESSED_ENTRY_SIZE;

    if (!LogReadBuffer(addr, (unsigned char*) &compressedLogEntry, sizeof(CompressedLogEntry)))
    {
        return false;
    }

    memset(logEntry, 0, sizeof(LogEntry));
    LogUncompressEntry(&compressedLogEntry, logEntry);
    return true;
}

int LogGetEntryByID(unsigned long id, LogEntry* logEntry)
{
    return LogGetEntry(LogGetEntryIndex(id), logEntry);
}

int LogGetEventEntry(unsigned long index, EventLogEntry* logEntry)
{
    unsigned long realIndex;
    unsigned long addr;

    if (index >= logHeader.numEventEntries)
    {
        return false;
    }
    realIndex = (index + logHeader.startEventIndex) % eventLogMaxEntries;
    addr = eventLogStart + realIndex * LOG_COMPRESSED_EVENT_ENTRY_SIZE;

    if (!LogReadBuffer(addr, (unsigned char*) &compressedEventLogEntry, sizeof(CompressedEventLogEntry)))
    {
        return false;
    }

    memset(logEntry, 0, sizeof(EventLogEntry));
    LogUncompressEventEntry(&compressedEventLogEntry, logEntry);
    return true;
}

int LogGetEventEntryByID(unsigned long id, EventLogEntry* logEntry)
{
    return LogGetEventEntry(LogGetEventEntryIndex(id), logEntry);
}

int LogAddEntry(LogEntry* logEntry)
{
    unsigned long startIndex = logHeader.startIndex;
    unsigned long numEntries = logHeader.numEntries;
    unsigned long startID = logHeader.startID;
    unsigned long newEntryIndex;
    unsigned long addr;

    newEntryIndex = (startIndex + numEntries) % logMaxEntries;
    if (numEntries >= logMaxEntries - 1)
    {
        numEntries = logMaxEntries - 1;
        startIndex = (startIndex + 1) % logMaxEntries;
        startID = (startID + 1) % LOG_MAX_VALUE;
    }
    else
    {
        numEntries++;
    }
    addr = logStart + newEntryIndex * LOG_COMPRESSED_ENTRY_SIZE;
    
    LogCompressEntry(logEntry, &compressedLogEntry);
    if (!LogWriteBuffer(addr, (unsigned char*) &compressedLogEntry, sizeof(CompressedLogEntry)))
    {
        return false;
    }
    
    logHeader.startIndex = startIndex;
    logHeader.numEntries = numEntries;
    logHeader.startID = startID;
    if (LogWriteBuffer(logHeaderStart, (unsigned char*) &logHeader, sizeof(LogHeader)))
    {
        return true;
    }
    else
    {
        return false;
    }
}

int LogAddEventEntry(EventLogEntry* logEntry)
{
    unsigned long startIndex = logHeader.startEventIndex;
    unsigned long numEntries = logHeader.numEventEntries;
    unsigned long startID = logHeader.startEventID;
    unsigned long newEntryIndex;
    unsigned long addr;

    newEntryIndex = (startIndex + numEntries) % eventLogMaxEntries;
    if (numEntries >= eventLogMaxEntries - 1)
    {
        numEntries = eventLogMaxEntries - 1;
        startIndex = (startIndex + 1) % eventLogMaxEntries;
        startID = (startID + 1) % LOG_MAX_VALUE;
    }
    else
    {
        numEntries++;
    }
    addr = eventLogStart + newEntryIndex * LOG_COMPRESSED_EVENT_ENTRY_SIZE;

    LogCompressEventEntry(logEntry, &compressedEventLogEntry);
    if (!LogWriteBuffer(addr, (unsigned char*) &compressedEventLogEntry, sizeof(CompressedEventLogEntry)))
    {
        return false;
    }

    logHeader.startEventIndex = startIndex;
    logHeader.numEventEntries = numEntries;
    logHeader.startEventID = startID;
    if (LogWriteBuffer(logHeaderStart, (unsigned char*) &logHeader, sizeof(LogHeader)))
    {
        return true;
    }
    else
    {
        return false;
    }
}

unsigned int LogGetPeriod()
{
    return logHeader.logPeriod;
}

int LogSetPeriod(unsigned int period)
{
    if (period <= 0 || period > MAX_LOG_PERIOD)
    {
        return false;
    }

    logHeader.logPeriod = period;
    return LogWriteBuffer(logHeaderStart, (unsigned char*) &logHeader, sizeof(LogHeader));
}

int LogReset(LogResetType resetType)
{
    switch (resetType)
    {
    case LOG_RESET_STATS:
        logHeader.startIndex = 0;
        logHeader.numEntries = 0;
        logHeader.startID = 0;
        break;
        
    case LOG_RESET_EVENT:
        logHeader.startEventIndex = 0;
        logHeader.numEventEntries = 0;
        logHeader.startEventID = 0;
        break;
        
    default:
        logHeader.startIndex = 0;
        logHeader.numEntries = 0;
        logHeader.startID = 0;
        logHeader.startEventIndex = 0;
        logHeader.numEventEntries = 0;
        logHeader.startEventID = 0;
        logHeader.logPeriod = DEFAULT_LOG_PERIOD;
        logHeader.version = LOG_VERSION;
        break;
    }
    
    return LogWriteBuffer(logHeaderStart, (unsigned char*) &logHeader, sizeof(LogHeader));
}