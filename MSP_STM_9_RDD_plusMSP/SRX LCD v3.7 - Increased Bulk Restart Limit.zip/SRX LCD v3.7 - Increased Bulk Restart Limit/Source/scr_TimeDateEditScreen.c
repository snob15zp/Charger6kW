#include "scr_TimeDateEditScreen.h"
#include "scr_DateEditScreen.h"
#include "scr_SetpointsEditScreen.h"
#include "scr_SetpointsScreen2.h"
#include "scr_SetpointsScreen1.h"
#include "scr_MainMenuScreen.h"
#include "scr_SettingsMenuScreen.h"
#include "scr_TimeEditScreen.h"
#include "CoolMax_LCD_objects.h"
#include "CoolMax_LCD_resources.h"
#include "screen.h"
#include "debug.h"
#include "cmdlib.h"

extern Tscreen* CurrentScreen;
extern Tscreen* PreviousScreen;

void Init_TimeDateEditScreen(void)
{
     if (CurrentScreen != &TimeDateEditScreen)
     {
        PreviousScreen = CurrentScreen;
        DrawScreen(&TimeDateEditScreen);
     }
}

void UpdateTimeDateEditScreen(void)
{
  if (CurrentScreen == &TimeDateEditScreen)
     {



     }

}

//Event Handlers

void btn_TimeDateEditScreen_TimeSelectOnClick() 
{
Init_TimeEditScreen();
}

void btn_TimeDateEditScreen_DateSelectOnClick() 
{
Init_DateEditScreen(&scr_DateEditScreen);
}

void btn_TimedDateEditScreen_BackOnClick() 
{
 Init_SettingsMenuScreen();
}